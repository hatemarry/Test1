package com.bes_line.mst;

// Entity Class for STDACT
/**
 *
 * @(#) STDACTRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2012-8-10
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class STDACTRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String facid; 		// (VARCHAR2, 2.0)
    public String shpkd; 		// (VARCHAR2, 3.0)
    public String actcd; 		// (VARCHAR2, 30.0)
    public String blkno; 		// (VARCHAR2, 10.0)
    public String evtcd; 		// (VARCHAR2, 10.0)
    public String actnm; 		// (VARCHAR2, 200.0)
    public String crtyn; 		// (VARCHAR2, 1.0)
    public int hvyrt; 		// (NUMBER, 3.0)
    public String joblk; 		// (VARCHAR2, 30.0)
    public String dptno; 		// (VARCHAR2, 6.0)
    public int adate; 		// (NUMBER, 8.0)
    public int mdate; 		// (NUMBER, 8.0)
    public String auser; 		// (VARCHAR2, 30.0)
    public String muser; 		// (VARCHAR2, 30.0)

public STDACTRec(){ } // default constructor

public STDACTRec(
       String facid, String shpkd, String actcd, String blkno, String evtcd, String actnm, 
       String crtyn, int hvyrt, String joblk, String dptno, int adate, int mdate, 
       String auser, String muser){
    this.facid = facid;
    this.shpkd = shpkd;
    this.actcd = actcd;
    this.blkno = blkno;
    this.evtcd = evtcd;
    this.actnm = actnm;
    this.crtyn = crtyn;
    this.hvyrt = hvyrt;
    this.joblk = joblk;
    this.dptno = dptno;
    this.adate = adate;
    this.mdate = mdate;
    this.auser = auser;
    this.muser = muser;
} // Constructor


// Getter 
public String getFacid(){ return facid;}
public String getShpkd(){ return shpkd;}
public String getActcd(){ return actcd;}
public String getBlkno(){ return blkno;}
public String getEvtcd(){ return evtcd;}
public String getActnm(){ return actnm;}
public String getCrtyn(){ return crtyn;}
public int getHvyrt(){ return hvyrt;}
public String getJoblk(){ return joblk;}
public String getDptno(){ return dptno;}
public int getAdate(){ return adate;}
public int getMdate(){ return mdate;}
public String getAuser(){ return auser;}
public String getMuser(){ return muser;}

// Setter 
public void setFacid(String facid){ this.facid = facid;}
public void setShpkd(String shpkd){ this.shpkd = shpkd;}
public void setActcd(String actcd){ this.actcd = actcd;}
public void setBlkno(String blkno){ this.blkno = blkno;}
public void setEvtcd(String evtcd){ this.evtcd = evtcd;}
public void setActnm(String actnm){ this.actnm = actnm;}
public void setCrtyn(String crtyn){ this.crtyn = crtyn;}
public void setHvyrt(int hvyrt){ this.hvyrt = hvyrt;}
public void setJoblk(String joblk){ this.joblk = joblk;}
public void setDptno(String dptno){ this.dptno = dptno;}
public void setAdate(int adate){ this.adate = adate;}
public void setMdate(int mdate){ this.mdate = mdate;}
public void setAuser(String auser){ this.auser = auser;}
public void setMuser(String muser){ this.muser = muser;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = facid + "" ; break;
  case  2 : field = shpkd + "" ; break;
  case  3 : field = actcd + "" ; break;
  case  4 : field = blkno + "" ; break;
  case  5 : field = evtcd + "" ; break;
  case  6 : field = actnm + "" ; break;
  case  7 : field = crtyn + "" ; break;
  case  8 : field = hvyrt + "" ; break;
  case  9 : field = joblk + "" ; break;
  case  10 : field = dptno + "" ; break;
  case  11 : field = adate + "" ; break;
  case  12 : field = mdate + "" ; break;
  case  13 : field = auser + "" ; break;
  case  14 : field = muser + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("facid")){ field = facid + "" ; 
     } else if(rec.equalsIgnoreCase("shpkd")){ field = shpkd + "" ; 
     } else if(rec.equalsIgnoreCase("actcd")){ field = actcd + "" ; 
     } else if(rec.equalsIgnoreCase("blkno")){ field = blkno + "" ; 
     } else if(rec.equalsIgnoreCase("evtcd")){ field = evtcd + "" ; 
     } else if(rec.equalsIgnoreCase("actnm")){ field = actnm + "" ; 
     } else if(rec.equalsIgnoreCase("crtyn")){ field = crtyn + "" ; 
     } else if(rec.equalsIgnoreCase("hvyrt")){ field = hvyrt + "" ; 
     } else if(rec.equalsIgnoreCase("joblk")){ field = joblk + "" ; 
     } else if(rec.equalsIgnoreCase("dptno")){ field = dptno + "" ; 
     } else if(rec.equalsIgnoreCase("adate")){ field = adate + "" ; 
     } else if(rec.equalsIgnoreCase("mdate")){ field = mdate + "" ; 
     } else if(rec.equalsIgnoreCase("auser")){ field = auser + "" ; 
     } else if(rec.equalsIgnoreCase("muser")){ field = muser + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "FACID", "SHPKD", "ACTCD", "BLKNO", "EVTCD", "ACTNM", "CRTYN", 
       "HVYRT", "JOBLK", "DPTNO", "ADATE", "MDATE", "AUSER", "MUSER"
       };
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "FACID", "SHPKD", "ACTCD", "BLKNO", "EVTCD"};
    return tempx;
}

}// end STDACTRec class