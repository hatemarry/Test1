package com.bes_line.mst;

// Entity Class for MENUTB_TST_DATA
/**
 *
 * @(#) MENUTB_TST_DATARec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2012-8-10
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class MENUTB_TST_DATARec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public int seqno; 		// (NUMBER, 5.0)
    public String syscd; 		// (VARCHAR2, 500.0)
    public String sysnm; 		// (VARCHAR2, 500.0)
    public String meggu; 		// (VARCHAR2, 500.0)
    public String megnm; 		// (VARCHAR2, 500.0)
    public String midgu; 		// (VARCHAR2, 500.0)
    public String midnm; 		// (VARCHAR2, 500.0)
    public String bpdtl; 		// (VARCHAR2, 500.0)
    public String owner; 		// (VARCHAR2, 500.0)
    public String lvlid; 		// (VARCHAR2, 500.0)
    public String lvseq; 		// (VARCHAR2, 500.0)
    public String pgmid; 		// (VARCHAR2, 500.0)
    public String pgmnm; 		// (VARCHAR2, 500.0)
    public String commt; 		// (VARCHAR2, 500.0)
    public String pgmod; 		// (VARCHAR2, 500.0)
    public String par1; 		// (VARCHAR2, 500.0)
    public String par2; 		// (VARCHAR2, 500.0)
    public String par3; 		// (VARCHAR2, 500.0)
    public String par4; 		// (VARCHAR2, 500.0)
    public String par5; 		// (VARCHAR2, 500.0)
    public String par6; 		// (VARCHAR2, 500.0)
    public String useyn; 		// (VARCHAR2, 500.0)
    public String remrk; 		// (VARCHAR2, 500.0)

public MENUTB_TST_DATARec(){ } // default constructor

public MENUTB_TST_DATARec(
       int seqno, String syscd, String sysnm, String meggu, String megnm, String midgu, 
       String midnm, String bpdtl, String owner, String lvlid, String lvseq, String pgmid, 
       String pgmnm, String commt, String pgmod, String par1, String par2, String par3, 
       String par4, String par5, String par6, String useyn, String remrk){
    this.seqno = seqno;
    this.syscd = syscd;
    this.sysnm = sysnm;
    this.meggu = meggu;
    this.megnm = megnm;
    this.midgu = midgu;
    this.midnm = midnm;
    this.bpdtl = bpdtl;
    this.owner = owner;
    this.lvlid = lvlid;
    this.lvseq = lvseq;
    this.pgmid = pgmid;
    this.pgmnm = pgmnm;
    this.commt = commt;
    this.pgmod = pgmod;
    this.par1 = par1;
    this.par2 = par2;
    this.par3 = par3;
    this.par4 = par4;
    this.par5 = par5;
    this.par6 = par6;
    this.useyn = useyn;
    this.remrk = remrk;
} // Constructor


// Getter 
public int getSeqno(){ return seqno;}
public String getSyscd(){ return syscd;}
public String getSysnm(){ return sysnm;}
public String getMeggu(){ return meggu;}
public String getMegnm(){ return megnm;}
public String getMidgu(){ return midgu;}
public String getMidnm(){ return midnm;}
public String getBpdtl(){ return bpdtl;}
public String getOwner(){ return owner;}
public String getLvlid(){ return lvlid;}
public String getLvseq(){ return lvseq;}
public String getPgmid(){ return pgmid;}
public String getPgmnm(){ return pgmnm;}
public String getCommt(){ return commt;}
public String getPgmod(){ return pgmod;}
public String getPar1(){ return par1;}
public String getPar2(){ return par2;}
public String getPar3(){ return par3;}
public String getPar4(){ return par4;}
public String getPar5(){ return par5;}
public String getPar6(){ return par6;}
public String getUseyn(){ return useyn;}
public String getRemrk(){ return remrk;}

// Setter 
public void setSeqno(int seqno){ this.seqno = seqno;}
public void setSyscd(String syscd){ this.syscd = syscd;}
public void setSysnm(String sysnm){ this.sysnm = sysnm;}
public void setMeggu(String meggu){ this.meggu = meggu;}
public void setMegnm(String megnm){ this.megnm = megnm;}
public void setMidgu(String midgu){ this.midgu = midgu;}
public void setMidnm(String midnm){ this.midnm = midnm;}
public void setBpdtl(String bpdtl){ this.bpdtl = bpdtl;}
public void setOwner(String owner){ this.owner = owner;}
public void setLvlid(String lvlid){ this.lvlid = lvlid;}
public void setLvseq(String lvseq){ this.lvseq = lvseq;}
public void setPgmid(String pgmid){ this.pgmid = pgmid;}
public void setPgmnm(String pgmnm){ this.pgmnm = pgmnm;}
public void setCommt(String commt){ this.commt = commt;}
public void setPgmod(String pgmod){ this.pgmod = pgmod;}
public void setPar1(String par1){ this.par1 = par1;}
public void setPar2(String par2){ this.par2 = par2;}
public void setPar3(String par3){ this.par3 = par3;}
public void setPar4(String par4){ this.par4 = par4;}
public void setPar5(String par5){ this.par5 = par5;}
public void setPar6(String par6){ this.par6 = par6;}
public void setUseyn(String useyn){ this.useyn = useyn;}
public void setRemrk(String remrk){ this.remrk = remrk;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = seqno + "" ; break;
  case  2 : field = syscd + "" ; break;
  case  3 : field = sysnm + "" ; break;
  case  4 : field = meggu + "" ; break;
  case  5 : field = megnm + "" ; break;
  case  6 : field = midgu + "" ; break;
  case  7 : field = midnm + "" ; break;
  case  8 : field = bpdtl + "" ; break;
  case  9 : field = owner + "" ; break;
  case  10 : field = lvlid + "" ; break;
  case  11 : field = lvseq + "" ; break;
  case  12 : field = pgmid + "" ; break;
  case  13 : field = pgmnm + "" ; break;
  case  14 : field = commt + "" ; break;
  case  15 : field = pgmod + "" ; break;
  case  16 : field = par1 + "" ; break;
  case  17 : field = par2 + "" ; break;
  case  18 : field = par3 + "" ; break;
  case  19 : field = par4 + "" ; break;
  case  20 : field = par5 + "" ; break;
  case  21 : field = par6 + "" ; break;
  case  22 : field = useyn + "" ; break;
  case  23 : field = remrk + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("seqno")){ field = seqno + "" ; 
     } else if(rec.equalsIgnoreCase("syscd")){ field = syscd + "" ; 
     } else if(rec.equalsIgnoreCase("sysnm")){ field = sysnm + "" ; 
     } else if(rec.equalsIgnoreCase("meggu")){ field = meggu + "" ; 
     } else if(rec.equalsIgnoreCase("megnm")){ field = megnm + "" ; 
     } else if(rec.equalsIgnoreCase("midgu")){ field = midgu + "" ; 
     } else if(rec.equalsIgnoreCase("midnm")){ field = midnm + "" ; 
     } else if(rec.equalsIgnoreCase("bpdtl")){ field = bpdtl + "" ; 
     } else if(rec.equalsIgnoreCase("owner")){ field = owner + "" ; 
     } else if(rec.equalsIgnoreCase("lvlid")){ field = lvlid + "" ; 
     } else if(rec.equalsIgnoreCase("lvseq")){ field = lvseq + "" ; 
     } else if(rec.equalsIgnoreCase("pgmid")){ field = pgmid + "" ; 
     } else if(rec.equalsIgnoreCase("pgmnm")){ field = pgmnm + "" ; 
     } else if(rec.equalsIgnoreCase("commt")){ field = commt + "" ; 
     } else if(rec.equalsIgnoreCase("pgmod")){ field = pgmod + "" ; 
     } else if(rec.equalsIgnoreCase("par1")){ field = par1 + "" ; 
     } else if(rec.equalsIgnoreCase("par2")){ field = par2 + "" ; 
     } else if(rec.equalsIgnoreCase("par3")){ field = par3 + "" ; 
     } else if(rec.equalsIgnoreCase("par4")){ field = par4 + "" ; 
     } else if(rec.equalsIgnoreCase("par5")){ field = par5 + "" ; 
     } else if(rec.equalsIgnoreCase("par6")){ field = par6 + "" ; 
     } else if(rec.equalsIgnoreCase("useyn")){ field = useyn + "" ; 
     } else if(rec.equalsIgnoreCase("remrk")){ field = remrk + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "SEQNO", "SYSCD", "SYSNM", "MEGGU", "MEGNM", "MIDGU", "MIDNM", 
       "BPDTL", "OWNER", "LVLID", "LVSEQ", "PGMID", "PGMNM", "COMMT", 
       "PGMOD", "PAR1", "PAR2", "PAR3", "PAR4", "PAR5", "PAR6", 
       "USEYN", "REMRK"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "SEQNO"};
    return tempx;
}

}// end MENUTB_TST_DATARec class