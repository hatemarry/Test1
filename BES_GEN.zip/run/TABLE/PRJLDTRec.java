package com.bes_line.mst;

// Entity Class for PRJLDT
/**
 *
 * @(#) PRJLDTRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2012-8-8
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class PRJLDTRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String facid; 		// (VARCHAR2, 2.0)
    public String prjno; 		// (VARCHAR2, 10.0)
    public String revnm; 		// (VARCHAR2, 30.0)
    public String blkno; 		// (VARCHAR2, 10.0)
    public String evtcd; 		// (VARCHAR2, 3.0)
    public int ltime; 		// (NUMBER, 3.0)
    public int btime; 		// (NUMBER, 3.0)
    public int basic; 		// (NUMBER, 3.0)
    public String stscd; 		// (VARCHAR2, 3.0)
    public String remrk; 		// (VARCHAR2, 100.0)
    public int adate; 		// (NUMBER, 8.0)
    public int mdate; 		// (NUMBER, 8.0)
    public String auser; 		// (VARCHAR2, 30.0)
    public String muser; 		// (VARCHAR2, 30.0)

public PRJLDTRec(){ } // default constructor

public PRJLDTRec(
       String facid, String prjno, String revnm, String blkno, String evtcd, int ltime, 
       int btime, int basic, String stscd, String remrk, int adate, int mdate, 
       String auser, String muser){
    this.facid = facid;
    this.prjno = prjno;
    this.revnm = revnm;
    this.blkno = blkno;
    this.evtcd = evtcd;
    this.ltime = ltime;
    this.btime = btime;
    this.basic = basic;
    this.stscd = stscd;
    this.remrk = remrk;
    this.adate = adate;
    this.mdate = mdate;
    this.auser = auser;
    this.muser = muser;
} // Constructor


// Getter 
public String getFacid(){ return facid;}
public String getPrjno(){ return prjno;}
public String getRevnm(){ return revnm;}
public String getBlkno(){ return blkno;}
public String getEvtcd(){ return evtcd;}
public int getLtime(){ return ltime;}
public int getBtime(){ return btime;}
public int getBasic(){ return basic;}
public String getStscd(){ return stscd;}
public String getRemrk(){ return remrk;}
public int getAdate(){ return adate;}
public int getMdate(){ return mdate;}
public String getAuser(){ return auser;}
public String getMuser(){ return muser;}

// Setter 
public void setFacid(String facid){ this.facid = facid;}
public void setPrjno(String prjno){ this.prjno = prjno;}
public void setRevnm(String revnm){ this.revnm = revnm;}
public void setBlkno(String blkno){ this.blkno = blkno;}
public void setEvtcd(String evtcd){ this.evtcd = evtcd;}
public void setLtime(int ltime){ this.ltime = ltime;}
public void setBtime(int btime){ this.btime = btime;}
public void setBasic(int basic){ this.basic = basic;}
public void setStscd(String stscd){ this.stscd = stscd;}
public void setRemrk(String remrk){ this.remrk = remrk;}
public void setAdate(int adate){ this.adate = adate;}
public void setMdate(int mdate){ this.mdate = mdate;}
public void setAuser(String auser){ this.auser = auser;}
public void setMuser(String muser){ this.muser = muser;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = facid + "" ; break;
  case  2 : field = prjno + "" ; break;
  case  3 : field = revnm + "" ; break;
  case  4 : field = blkno + "" ; break;
  case  5 : field = evtcd + "" ; break;
  case  6 : field = ltime + "" ; break;
  case  7 : field = btime + "" ; break;
  case  8 : field = basic + "" ; break;
  case  9 : field = stscd + "" ; break;
  case  10 : field = remrk + "" ; break;
  case  11 : field = adate + "" ; break;
  case  12 : field = mdate + "" ; break;
  case  13 : field = auser + "" ; break;
  case  14 : field = muser + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("facid")){ field = facid + "" ; 
     } else if(rec.equalsIgnoreCase("prjno")){ field = prjno + "" ; 
     } else if(rec.equalsIgnoreCase("revnm")){ field = revnm + "" ; 
     } else if(rec.equalsIgnoreCase("blkno")){ field = blkno + "" ; 
     } else if(rec.equalsIgnoreCase("evtcd")){ field = evtcd + "" ; 
     } else if(rec.equalsIgnoreCase("ltime")){ field = ltime + "" ; 
     } else if(rec.equalsIgnoreCase("btime")){ field = btime + "" ; 
     } else if(rec.equalsIgnoreCase("basic")){ field = basic + "" ; 
     } else if(rec.equalsIgnoreCase("stscd")){ field = stscd + "" ; 
     } else if(rec.equalsIgnoreCase("remrk")){ field = remrk + "" ; 
     } else if(rec.equalsIgnoreCase("adate")){ field = adate + "" ; 
     } else if(rec.equalsIgnoreCase("mdate")){ field = mdate + "" ; 
     } else if(rec.equalsIgnoreCase("auser")){ field = auser + "" ; 
     } else if(rec.equalsIgnoreCase("muser")){ field = muser + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "FACID", "PRJNO", "REVNM", "BLKNO", "EVTCD", "LTIME", "BTIME", 
       "BASIC", "STSCD", "REMRK", "ADATE", "MDATE", "AUSER", "MUSER"
       };
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "FACID", "PRJNO", "REVNM", "BLKNO", "EVTCD"};
    return tempx;
}

}// end PRJLDTRec class