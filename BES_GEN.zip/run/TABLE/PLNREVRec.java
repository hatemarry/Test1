package com.bes_line.mst;

// Entity Class for PLNREV
/**
 *
 * @(#) PLNREVRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2012-8-8
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class PLNREVRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String facid; 		// (VARCHAR2, 2.0)
    public int aplyy; 		// (NUMBER, 4.0)
    public String aplqt; 		// (VARCHAR2, 3.0)
    public String revno; 		// (VARCHAR2, 3.0)
    public String revnm; 		// (VARCHAR2, 30.0)
    public String stscd; 		// (VARCHAR2, 3.0)
    public String remrk; 		// (VARCHAR2, 100.0)
    public int adate; 		// (NUMBER, 8.0)
    public int mdate; 		// (NUMBER, 8.0)
    public String auser; 		// (VARCHAR2, 30.0)
    public String muser; 		// (VARCHAR2, 30.0)

public PLNREVRec(){ } // default constructor

public PLNREVRec(
       String facid, int aplyy, String aplqt, String revno, String revnm, String stscd, 
       String remrk, int adate, int mdate, String auser, String muser){
    this.facid = facid;
    this.aplyy = aplyy;
    this.aplqt = aplqt;
    this.revno = revno;
    this.revnm = revnm;
    this.stscd = stscd;
    this.remrk = remrk;
    this.adate = adate;
    this.mdate = mdate;
    this.auser = auser;
    this.muser = muser;
} // Constructor


// Getter 
public String getFacid(){ return facid;}
public int getAplyy(){ return aplyy;}
public String getAplqt(){ return aplqt;}
public String getRevno(){ return revno;}
public String getRevnm(){ return revnm;}
public String getStscd(){ return stscd;}
public String getRemrk(){ return remrk;}
public int getAdate(){ return adate;}
public int getMdate(){ return mdate;}
public String getAuser(){ return auser;}
public String getMuser(){ return muser;}

// Setter 
public void setFacid(String facid){ this.facid = facid;}
public void setAplyy(int aplyy){ this.aplyy = aplyy;}
public void setAplqt(String aplqt){ this.aplqt = aplqt;}
public void setRevno(String revno){ this.revno = revno;}
public void setRevnm(String revnm){ this.revnm = revnm;}
public void setStscd(String stscd){ this.stscd = stscd;}
public void setRemrk(String remrk){ this.remrk = remrk;}
public void setAdate(int adate){ this.adate = adate;}
public void setMdate(int mdate){ this.mdate = mdate;}
public void setAuser(String auser){ this.auser = auser;}
public void setMuser(String muser){ this.muser = muser;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = facid + "" ; break;
  case  2 : field = aplyy + "" ; break;
  case  3 : field = aplqt + "" ; break;
  case  4 : field = revno + "" ; break;
  case  5 : field = revnm + "" ; break;
  case  6 : field = stscd + "" ; break;
  case  7 : field = remrk + "" ; break;
  case  8 : field = adate + "" ; break;
  case  9 : field = mdate + "" ; break;
  case  10 : field = auser + "" ; break;
  case  11 : field = muser + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("facid")){ field = facid + "" ; 
     } else if(rec.equalsIgnoreCase("aplyy")){ field = aplyy + "" ; 
     } else if(rec.equalsIgnoreCase("aplqt")){ field = aplqt + "" ; 
     } else if(rec.equalsIgnoreCase("revno")){ field = revno + "" ; 
     } else if(rec.equalsIgnoreCase("revnm")){ field = revnm + "" ; 
     } else if(rec.equalsIgnoreCase("stscd")){ field = stscd + "" ; 
     } else if(rec.equalsIgnoreCase("remrk")){ field = remrk + "" ; 
     } else if(rec.equalsIgnoreCase("adate")){ field = adate + "" ; 
     } else if(rec.equalsIgnoreCase("mdate")){ field = mdate + "" ; 
     } else if(rec.equalsIgnoreCase("auser")){ field = auser + "" ; 
     } else if(rec.equalsIgnoreCase("muser")){ field = muser + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "FACID", "APLYY", "APLQT", "REVNO", "REVNM", "STSCD", "REMRK", 
       "ADATE", "MDATE", "AUSER", "MUSER"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "FACID", "APLYY", "APLQT", "REVNO"};
    return tempx;
}

}// end PLNREVRec class