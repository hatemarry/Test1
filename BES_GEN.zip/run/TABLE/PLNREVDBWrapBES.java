package com.bes_line.mst;

// DBWrapper Class for PLNREV
/**
 *
 * @(#) PLNREVDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2012-8-8
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class PLNREVDBWrapBES extends DBWrapper{

public PLNREVDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Get one Record 
* @param String facid, int aplyy, String aplqt, String revno
* @return PLNREVRec 
* @author besTeam 
* @date 2012-8-8
*/
public PLNREVRec select(String facid, int aplyy, String aplqt, String revno) throws Exception{
    PLNREVRec plnrev = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, aplyy, aplqt, revno, revnm, stscd, remrk, adate, mdate, " +
                              "auser, muser " +
                       "  from PLNREV  " +
                       "  where facid = ? and aplyy = ? and aplqt = ? and revno = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setInt(2,aplyy); 
        pstmt.setString(3,aplqt); 
        pstmt.setString(4,revno); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            plnrev = new PLNREVRec(); // PLNREVRec Constructor
                     plnrev.setFacid(rs.getString("facid"));
                     plnrev.setAplyy(rs.getInt("aplyy"));
                     plnrev.setAplqt(rs.getString("aplqt"));
                     plnrev.setRevno(rs.getString("revno"));
                     plnrev.setRevnm(rs.getString("revnm"));
                     plnrev.setStscd(rs.getString("stscd"));
                     plnrev.setRemrk(rs.getString("remrk"));
                     plnrev.setAdate(rs.getInt("adate"));
                     plnrev.setMdate(rs.getInt("mdate"));
                     plnrev.setAuser(rs.getString("auser"));
                     plnrev.setMuser(rs.getString("muser"));
        } else {
            throw new DataNotFoundException();
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return plnrev;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector plnrevV = new java.util.Vector();
    PLNREVRec plnrev = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, aplyy, aplqt, revno, revnm, stscd, remrk, adate, mdate, " +
                              "auser, muser " +
                       "  from PLNREV ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            plnrev = new PLNREVRec(); // PLNREVRec Constructor
                     plnrev.setFacid(rs.getString("facid"));
                     plnrev.setAplyy(rs.getInt("aplyy"));
                     plnrev.setAplqt(rs.getString("aplqt"));
                     plnrev.setRevno(rs.getString("revno"));
                     plnrev.setRevnm(rs.getString("revnm"));
                     plnrev.setStscd(rs.getString("stscd"));
                     plnrev.setRemrk(rs.getString("remrk"));
                     plnrev.setAdate(rs.getInt("adate"));
                     plnrev.setMdate(rs.getInt("mdate"));
                     plnrev.setAuser(rs.getString("auser"));
                     plnrev.setMuser(rs.getString("muser"));
            plnrevV.addElement(plnrev);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return plnrevV;
} // end selectAll

/**
* Get All Record(condition : last Key except) 
* @param String facid, int aplyy, String aplqt
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectAll(String facid, int aplyy, String aplqt) throws Exception{
    java.util.Vector plnrevV = new java.util.Vector();
    PLNREVRec plnrev = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, aplyy, aplqt, revno, revnm, stscd, remrk, adate, mdate, " +
                              "auser, muser " +
                       "  from PLNREV  " +
                       "  where facid = ? and aplyy = ? and aplqt = ?  " +
                       "  order by revno"; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setInt(2,aplyy); 
        pstmt.setString(3,aplqt); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            plnrev = new PLNREVRec(); // PLNREVRec Constructor
                     plnrev.setFacid(rs.getString("facid"));
                     plnrev.setAplyy(rs.getInt("aplyy"));
                     plnrev.setAplqt(rs.getString("aplqt"));
                     plnrev.setRevno(rs.getString("revno"));
                     plnrev.setRevnm(rs.getString("revnm"));
                     plnrev.setStscd(rs.getString("stscd"));
                     plnrev.setRemrk(rs.getString("remrk"));
                     plnrev.setAdate(rs.getInt("adate"));
                     plnrev.setMdate(rs.getInt("mdate"));
                     plnrev.setAuser(rs.getString("auser"));
                     plnrev.setMuser(rs.getString("muser"));
            plnrevV.addElement(plnrev);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return plnrevV;
} // end selectAll

/**
* Get between Record(condition : last Key from - to) 
* @param String facid, int aplyy, String aplqt, String f_revno, String t_revno
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectBetween(String facid, int aplyy, String aplqt, String f_revno, String t_revno) throws Exception{
    return selectBetween(facid, aplyy, aplqt, f_revno, t_revno, 0);
} // end selectBetween

/**
* Get between Record(condition : last Key from - to) 
* @param String facid, int aplyy, String aplqt, String f_revno, String t_revno, int lastKeyOrder(0 : ASC-Default, 1 : DESC)
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectBetween(String facid, int aplyy, String aplqt, String f_revno, String t_revno, int lastKeyOrder) throws Exception{
    java.util.Vector plnrevV = new java.util.Vector();
    PLNREVRec plnrev = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, aplyy, aplqt, revno, revnm, stscd, remrk, adate, mdate, " +
                              "auser, muser " +
                       "  from PLNREV  " +
                       "  where facid = ? and aplyy = ? and aplqt = ?  " +
                       "  and revno between ? and ?  ";
               if(lastKeyOrder == 1){
                   query += " order by DESC revno"; 
               } else {
                   query += " order by revno"; 
               } // end if(lastKeyOrder == 1)
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setInt(2,aplyy); 
        pstmt.setString(3,aplqt); 
        pstmt.setString(4,f_revno); 
        pstmt.setString(5,t_revno); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            plnrev = new PLNREVRec(); // PLNREVRec Constructor
                     plnrev.setFacid(rs.getString("facid"));
                     plnrev.setAplyy(rs.getInt("aplyy"));
                     plnrev.setAplqt(rs.getString("aplqt"));
                     plnrev.setRevno(rs.getString("revno"));
                     plnrev.setRevnm(rs.getString("revnm"));
                     plnrev.setStscd(rs.getString("stscd"));
                     plnrev.setRemrk(rs.getString("remrk"));
                     plnrev.setAdate(rs.getInt("adate"));
                     plnrev.setMdate(rs.getInt("mdate"));
                     plnrev.setAuser(rs.getString("auser"));
                     plnrev.setMuser(rs.getString("muser"));
            plnrevV.addElement(plnrev);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return plnrevV;
} // end selectBetween

/**
* Select Data Over the key value(s) and default return count(20) 
* @param String facid, int aplyy, String aplqt, String revno
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectOver(String facid, int aplyy, String aplqt, String revno) throws Exception{
return selectOver(facid, aplyy, aplqt, revno,20) ;
}// end selectOver
/**
* Select Data Over(Next) the key value(s) and return record count 
* @param String facid, int aplyy, String aplqt, String revno, int 
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectOver(String facid, int aplyy, String aplqt, String revno, int page) throws Exception{
    java.util.Vector plnrevV = new java.util.Vector();
    PLNREVRec plnrev = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, aplyy, aplqt, revno, revnm, stscd, remrk, adate, mdate, " +
                              "auser, muser " +
                       "  from PLNREV  " +
                       "  where facid = ?  and  aplyy = ?  and  aplqt = ?  and  revno >= ? order by revno "; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setInt(2,aplyy); 
        pstmt.setString(3,aplqt); 
        pstmt.setString(4,revno); 
        rs = pstmt.executeQuery();
        int count = 0;//������� SQL���忡�� Limit�ؾ� ������...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            plnrev = new PLNREVRec(); // PLNREVRec Constructor
                     plnrev.setFacid(rs.getString("facid"));
                     plnrev.setAplyy(rs.getInt("aplyy"));
                     plnrev.setAplqt(rs.getString("aplqt"));
                     plnrev.setRevno(rs.getString("revno"));
                     plnrev.setRevnm(rs.getString("revnm"));
                     plnrev.setStscd(rs.getString("stscd"));
                     plnrev.setRemrk(rs.getString("remrk"));
                     plnrev.setAdate(rs.getInt("adate"));
                     plnrev.setMdate(rs.getInt("mdate"));
                     plnrev.setAuser(rs.getString("auser"));
                     plnrev.setMuser(rs.getString("muser"));
            plnrevV.addElement(plnrev);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return plnrevV;
} // end selectOver

/**
* Select Data Under(Previous) the key value(s) and default return count(20) 
* @param String facid, int aplyy, String aplqt, String revno
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectUnder(String facid, int aplyy, String aplqt, String revno) throws Exception{
return selectUnder(facid, aplyy, aplqt, revno,20) ;
}// end selectUnder
/**
* Select Data Under(Previous) the key value(s) and return record count 
* @param String facid, int aplyy, String aplqt, String revno, int
* @return java.util.Vector
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectUnder(String facid, int aplyy, String aplqt, String revno, int page) throws Exception{
    java.util.Vector plnrevV = new java.util.Vector();
    PLNREVRec plnrev = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, aplyy, aplqt, revno, revnm, stscd, remrk, adate, mdate, " +
                              "auser, muser " +
                       "  from PLNREV  " +
                       "  where facid = ?  and aplyy = ?  and aplqt = ?  and revno <= ? order by revno desc" ; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setInt(2,aplyy); 
        pstmt.setString(3,aplqt); 
        pstmt.setString(4,revno); 
        rs = pstmt.executeQuery();
        int count = 0;//������� SQL���忡�� Limit�ؾ� ������...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            plnrev = new PLNREVRec(); // PLNREVRec Constructor
                     plnrev.setFacid(rs.getString("facid"));
                     plnrev.setAplyy(rs.getInt("aplyy"));
                     plnrev.setAplqt(rs.getString("aplqt"));
                     plnrev.setRevno(rs.getString("revno"));
                     plnrev.setRevnm(rs.getString("revnm"));
                     plnrev.setStscd(rs.getString("stscd"));
                     plnrev.setRemrk(rs.getString("remrk"));
                     plnrev.setAdate(rs.getInt("adate"));
                     plnrev.setMdate(rs.getInt("mdate"));
                     plnrev.setAuser(rs.getString("auser"));
                     plnrev.setMuser(rs.getString("muser"));
            plnrevV.add(0,plnrev);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return plnrevV;
} // end selectUnder

// Insert Data 
/**
* Add Record 
* @param PLNREVRec 
* @return void 
* @author besTeam 
* @date 2012-8-8
*/
public void insert(PLNREVRec plnrev) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into PLNREV( " +
                              "facid, aplyy, aplqt, revno, revnm, stscd, remrk, adate, mdate, " +
                              "auser, muser"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, plnrev.getFacid());
        pstmt.setInt(2, plnrev.getAplyy());
        pstmt.setString(3, plnrev.getAplqt());
        pstmt.setString(4, plnrev.getRevno());
        pstmt.setString(5, plnrev.getRevnm());
        pstmt.setString(6, plnrev.getStscd());
        pstmt.setString(7, plnrev.getRemrk());
        pstmt.setInt(8, plnrev.getAdate());
        pstmt.setInt(9, plnrev.getMdate());
        pstmt.setString(10, plnrev.getAuser());
        pstmt.setString(11, plnrev.getMuser());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param PLNREVRec 
* @return void 
* @author besTeam 
* @date 2012-8-8
*/
public void update(PLNREVRec plnrev) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update PLNREV SET "+
                        "facid = ?, aplyy = ?, aplqt = ?, revno = ?, revnm = ?, stscd = ?, remrk = ?, adate = ?, mdate = ?, auser = ?, " +
                              "muser = ?"+
                        " where facid = ? and aplyy = ? and aplqt = ? and revno = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, plnrev.getFacid());
        pstmt.setInt(2, plnrev.getAplyy());
        pstmt.setString(3, plnrev.getAplqt());
        pstmt.setString(4, plnrev.getRevno());
        pstmt.setString(5, plnrev.getRevnm());
        pstmt.setString(6, plnrev.getStscd());
        pstmt.setString(7, plnrev.getRemrk());
        pstmt.setInt(8, plnrev.getAdate());
        pstmt.setInt(9, plnrev.getMdate());
        pstmt.setString(10, plnrev.getAuser());
        pstmt.setString(11, plnrev.getMuser());
        // Key
        pstmt.setString(12, plnrev.getFacid()); 
        pstmt.setInt(13, plnrev.getAplyy()); 
        pstmt.setString(14, plnrev.getAplqt()); 
        pstmt.setString(15, plnrev.getRevno()); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String facid, int aplyy, String aplqt, String revno
* @return void 
* @author besTeam 
* @date 2012-8-8
*/
public void delete(String facid, int aplyy, String aplqt, String revno) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From PLNREV "+
                       "where facid = ? and aplyy = ? and aplqt = ? and revno = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setInt(2,aplyy); 
        pstmt.setString(3,aplqt); 
        pstmt.setString(4,revno); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param PLNREVRec 
* @return void 
* @author besTeam 
* @date 2012-8-8
*/
public void delete(PLNREVRec plnrev) throws Exception{
     delete(plnrev.getFacid(), plnrev.getAplyy(), plnrev.getAplqt(), plnrev.getRevno());
} // end Delete

/**
* Get Rows Count 
* @param String facid, int aplyy, String aplqt, String revno
* @return int 
* @author besTeam 
* @date 2012-8-8
*/
public int count(String facid, int aplyy, String aplqt, String revno) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from PLNREV " +
                       " where facid = ? and aplyy = ? and aplqt = ? and revno = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setInt(2,aplyy); 
        pstmt.setString(3,aplqt); 
        pstmt.setString(4,revno); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param void 
* @return int 
* @author besTeam 
* @date 2012-8-8
*/
public int count() throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from PLNREV  ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}// end PLNREVDBWrap class