/* STDACT Table Create script */
CREATE TABLE STDACT(
    FACID varchar2(2,0) NOT NULL , 
    SHPKD varchar2(3,0) NOT NULL , 
    ACTCD varchar2(30,0) NOT NULL , 
    BLKNO varchar2(10,0) NOT NULL , 
    EVTCD varchar2(10,0) NOT NULL , 
    ACTNM varchar2(200,0), 
    CRTYN varchar2(1,0), 
    HVYRT number(3,0), 
    JOBLK varchar2(30,0), 
    DPTNO varchar2(6,0), 
    ADATE number(8,0), 
    MDATE number(8,0), 
    AUSER varchar2(30,0), 
    MUSER varchar2(30,0), 
    Primary Key (FACID, SHPKD, ACTCD, BLKNO, EVTCD)
);