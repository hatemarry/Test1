package com.bes_line.mst;

// DBWrapper Class for STDACT
/**
 *
 * @(#) STDACTDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2012-8-10
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class STDACTDBWrapBES extends DBWrapper{

public STDACTDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Get one Record 
* @param String facid, String shpkd, String actcd, String blkno, String evtcd
* @return STDACTRec 
* @author besTeam 
* @date 2012-8-10
*/
public STDACTRec select(String facid, String shpkd, String actcd, String blkno, String evtcd) throws Exception{
    STDACTRec stdact = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, shpkd, actcd, blkno, evtcd, actnm, crtyn, hvyrt, joblk, " +
                              "dptno, adate, mdate, auser, muser " +
                       "  from STDACT  " +
                       "  where facid = ? and shpkd = ? and actcd = ? and blkno = ? and evtcd = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,shpkd); 
        pstmt.setString(3,actcd); 
        pstmt.setString(4,blkno); 
        pstmt.setString(5,evtcd); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            stdact = new STDACTRec(); // STDACTRec Constructor
                     stdact.setFacid(rs.getString("facid"));
                     stdact.setShpkd(rs.getString("shpkd"));
                     stdact.setActcd(rs.getString("actcd"));
                     stdact.setBlkno(rs.getString("blkno"));
                     stdact.setEvtcd(rs.getString("evtcd"));
                     stdact.setActnm(rs.getString("actnm"));
                     stdact.setCrtyn(rs.getString("crtyn"));
                     stdact.setHvyrt(rs.getInt("hvyrt"));
                     stdact.setJoblk(rs.getString("joblk"));
                     stdact.setDptno(rs.getString("dptno"));
                     stdact.setAdate(rs.getInt("adate"));
                     stdact.setMdate(rs.getInt("mdate"));
                     stdact.setAuser(rs.getString("auser"));
                     stdact.setMuser(rs.getString("muser"));
        } else {
            throw new DataNotFoundException();
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return stdact;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector stdactV = new java.util.Vector();
    STDACTRec stdact = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, shpkd, actcd, blkno, evtcd, actnm, crtyn, hvyrt, joblk, " +
                              "dptno, adate, mdate, auser, muser " +
                       "  from STDACT ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            stdact = new STDACTRec(); // STDACTRec Constructor
                     stdact.setFacid(rs.getString("facid"));
                     stdact.setShpkd(rs.getString("shpkd"));
                     stdact.setActcd(rs.getString("actcd"));
                     stdact.setBlkno(rs.getString("blkno"));
                     stdact.setEvtcd(rs.getString("evtcd"));
                     stdact.setActnm(rs.getString("actnm"));
                     stdact.setCrtyn(rs.getString("crtyn"));
                     stdact.setHvyrt(rs.getInt("hvyrt"));
                     stdact.setJoblk(rs.getString("joblk"));
                     stdact.setDptno(rs.getString("dptno"));
                     stdact.setAdate(rs.getInt("adate"));
                     stdact.setMdate(rs.getInt("mdate"));
                     stdact.setAuser(rs.getString("auser"));
                     stdact.setMuser(rs.getString("muser"));
            stdactV.addElement(stdact);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return stdactV;
} // end selectAll

/**
* Get All Record(condition : last Key except) 
* @param String facid, String shpkd, String actcd, String blkno
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectAll(String facid, String shpkd, String actcd, String blkno) throws Exception{
    java.util.Vector stdactV = new java.util.Vector();
    STDACTRec stdact = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, shpkd, actcd, blkno, evtcd, actnm, crtyn, hvyrt, joblk, " +
                              "dptno, adate, mdate, auser, muser " +
                       "  from STDACT  " +
                       "  where facid = ? and shpkd = ? and actcd = ? and blkno = ?  " +
                       "  order by evtcd"; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,shpkd); 
        pstmt.setString(3,actcd); 
        pstmt.setString(4,blkno); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            stdact = new STDACTRec(); // STDACTRec Constructor
                     stdact.setFacid(rs.getString("facid"));
                     stdact.setShpkd(rs.getString("shpkd"));
                     stdact.setActcd(rs.getString("actcd"));
                     stdact.setBlkno(rs.getString("blkno"));
                     stdact.setEvtcd(rs.getString("evtcd"));
                     stdact.setActnm(rs.getString("actnm"));
                     stdact.setCrtyn(rs.getString("crtyn"));
                     stdact.setHvyrt(rs.getInt("hvyrt"));
                     stdact.setJoblk(rs.getString("joblk"));
                     stdact.setDptno(rs.getString("dptno"));
                     stdact.setAdate(rs.getInt("adate"));
                     stdact.setMdate(rs.getInt("mdate"));
                     stdact.setAuser(rs.getString("auser"));
                     stdact.setMuser(rs.getString("muser"));
            stdactV.addElement(stdact);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return stdactV;
} // end selectAll

/**
* Get between Record(condition : last Key from - to) 
* @param String facid, String shpkd, String actcd, String blkno, String f_evtcd, String t_evtcd
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectBetween(String facid, String shpkd, String actcd, String blkno, String f_evtcd, String t_evtcd) throws Exception{
    return selectBetween(facid, shpkd, actcd, blkno, f_evtcd, t_evtcd, 0);
} // end selectBetween

/**
* Get between Record(condition : last Key from - to) 
* @param String facid, String shpkd, String actcd, String blkno, String f_evtcd, String t_evtcd, int lastKeyOrder(0 : ASC-Default, 1 : DESC)
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectBetween(String facid, String shpkd, String actcd, String blkno, String f_evtcd, String t_evtcd, int lastKeyOrder) throws Exception{
    java.util.Vector stdactV = new java.util.Vector();
    STDACTRec stdact = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, shpkd, actcd, blkno, evtcd, actnm, crtyn, hvyrt, joblk, " +
                              "dptno, adate, mdate, auser, muser " +
                       "  from STDACT  " +
                       "  where facid = ? and shpkd = ? and actcd = ? and blkno = ?  " +
                       "  and evtcd between ? and ?  ";
               if(lastKeyOrder == 1){
                   query += " order by DESC evtcd"; 
               } else {
                   query += " order by evtcd"; 
               } // end if(lastKeyOrder == 1)
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,shpkd); 
        pstmt.setString(3,actcd); 
        pstmt.setString(4,blkno); 
        pstmt.setString(5,f_evtcd); 
        pstmt.setString(6,t_evtcd); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            stdact = new STDACTRec(); // STDACTRec Constructor
                     stdact.setFacid(rs.getString("facid"));
                     stdact.setShpkd(rs.getString("shpkd"));
                     stdact.setActcd(rs.getString("actcd"));
                     stdact.setBlkno(rs.getString("blkno"));
                     stdact.setEvtcd(rs.getString("evtcd"));
                     stdact.setActnm(rs.getString("actnm"));
                     stdact.setCrtyn(rs.getString("crtyn"));
                     stdact.setHvyrt(rs.getInt("hvyrt"));
                     stdact.setJoblk(rs.getString("joblk"));
                     stdact.setDptno(rs.getString("dptno"));
                     stdact.setAdate(rs.getInt("adate"));
                     stdact.setMdate(rs.getInt("mdate"));
                     stdact.setAuser(rs.getString("auser"));
                     stdact.setMuser(rs.getString("muser"));
            stdactV.addElement(stdact);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return stdactV;
} // end selectBetween

/**
* Select Data Over the key value(s) and default return count(20) 
* @param String facid, String shpkd, String actcd, String blkno, String evtcd
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectOver(String facid, String shpkd, String actcd, String blkno, String evtcd) throws Exception{
return selectOver(facid, shpkd, actcd, blkno, evtcd,20) ;
}// end selectOver
/**
* Select Data Over(Next) the key value(s) and return record count 
* @param String facid, String shpkd, String actcd, String blkno, String evtcd, int 
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectOver(String facid, String shpkd, String actcd, String blkno, String evtcd, int page) throws Exception{
    java.util.Vector stdactV = new java.util.Vector();
    STDACTRec stdact = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, shpkd, actcd, blkno, evtcd, actnm, crtyn, hvyrt, joblk, " +
                              "dptno, adate, mdate, auser, muser " +
                       "  from STDACT  " +
                       "  where facid = ?  and  shpkd = ?  and  actcd = ?  and  blkno = ?  and  evtcd >= ? order by evtcd "; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,shpkd); 
        pstmt.setString(3,actcd); 
        pstmt.setString(4,blkno); 
        pstmt.setString(5,evtcd); 
        rs = pstmt.executeQuery();
        int count = 0;//������� SQL���忡�� Limit�ؾ� ������...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            stdact = new STDACTRec(); // STDACTRec Constructor
                     stdact.setFacid(rs.getString("facid"));
                     stdact.setShpkd(rs.getString("shpkd"));
                     stdact.setActcd(rs.getString("actcd"));
                     stdact.setBlkno(rs.getString("blkno"));
                     stdact.setEvtcd(rs.getString("evtcd"));
                     stdact.setActnm(rs.getString("actnm"));
                     stdact.setCrtyn(rs.getString("crtyn"));
                     stdact.setHvyrt(rs.getInt("hvyrt"));
                     stdact.setJoblk(rs.getString("joblk"));
                     stdact.setDptno(rs.getString("dptno"));
                     stdact.setAdate(rs.getInt("adate"));
                     stdact.setMdate(rs.getInt("mdate"));
                     stdact.setAuser(rs.getString("auser"));
                     stdact.setMuser(rs.getString("muser"));
            stdactV.addElement(stdact);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return stdactV;
} // end selectOver

/**
* Select Data Under(Previous) the key value(s) and default return count(20) 
* @param String facid, String shpkd, String actcd, String blkno, String evtcd
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectUnder(String facid, String shpkd, String actcd, String blkno, String evtcd) throws Exception{
return selectUnder(facid, shpkd, actcd, blkno, evtcd,20) ;
}// end selectUnder
/**
* Select Data Under(Previous) the key value(s) and return record count 
* @param String facid, String shpkd, String actcd, String blkno, String evtcd, int
* @return java.util.Vector
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectUnder(String facid, String shpkd, String actcd, String blkno, String evtcd, int page) throws Exception{
    java.util.Vector stdactV = new java.util.Vector();
    STDACTRec stdact = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, shpkd, actcd, blkno, evtcd, actnm, crtyn, hvyrt, joblk, " +
                              "dptno, adate, mdate, auser, muser " +
                       "  from STDACT  " +
                       "  where facid = ?  and shpkd = ?  and actcd = ?  and blkno = ?  and evtcd <= ? order by evtcd desc" ; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,shpkd); 
        pstmt.setString(3,actcd); 
        pstmt.setString(4,blkno); 
        pstmt.setString(5,evtcd); 
        rs = pstmt.executeQuery();
        int count = 0;//������� SQL���忡�� Limit�ؾ� ������...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            stdact = new STDACTRec(); // STDACTRec Constructor
                     stdact.setFacid(rs.getString("facid"));
                     stdact.setShpkd(rs.getString("shpkd"));
                     stdact.setActcd(rs.getString("actcd"));
                     stdact.setBlkno(rs.getString("blkno"));
                     stdact.setEvtcd(rs.getString("evtcd"));
                     stdact.setActnm(rs.getString("actnm"));
                     stdact.setCrtyn(rs.getString("crtyn"));
                     stdact.setHvyrt(rs.getInt("hvyrt"));
                     stdact.setJoblk(rs.getString("joblk"));
                     stdact.setDptno(rs.getString("dptno"));
                     stdact.setAdate(rs.getInt("adate"));
                     stdact.setMdate(rs.getInt("mdate"));
                     stdact.setAuser(rs.getString("auser"));
                     stdact.setMuser(rs.getString("muser"));
            stdactV.add(0,stdact);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return stdactV;
} // end selectUnder

// Insert Data 
/**
* Add Record 
* @param STDACTRec 
* @return void 
* @author besTeam 
* @date 2012-8-10
*/
public void insert(STDACTRec stdact) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into STDACT( " +
                              "facid, shpkd, actcd, blkno, evtcd, actnm, crtyn, hvyrt, joblk, " +
                              "dptno, adate, mdate, auser, muser"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, stdact.getFacid());
        pstmt.setString(2, stdact.getShpkd());
        pstmt.setString(3, stdact.getActcd());
        pstmt.setString(4, stdact.getBlkno());
        pstmt.setString(5, stdact.getEvtcd());
        pstmt.setString(6, stdact.getActnm());
        pstmt.setString(7, stdact.getCrtyn());
        pstmt.setInt(8, stdact.getHvyrt());
        pstmt.setString(9, stdact.getJoblk());
        pstmt.setString(10, stdact.getDptno());
        pstmt.setInt(11, stdact.getAdate());
        pstmt.setInt(12, stdact.getMdate());
        pstmt.setString(13, stdact.getAuser());
        pstmt.setString(14, stdact.getMuser());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param STDACTRec 
* @return void 
* @author besTeam 
* @date 2012-8-10
*/
public void update(STDACTRec stdact) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update STDACT SET "+
                        "facid = ?, shpkd = ?, actcd = ?, blkno = ?, evtcd = ?, actnm = ?, crtyn = ?, hvyrt = ?, joblk = ?, dptno = ?, " +
                              "adate = ?, mdate = ?, auser = ?, muser = ?"+
                        " where facid = ? and shpkd = ? and actcd = ? and blkno = ? and evtcd = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, stdact.getFacid());
        pstmt.setString(2, stdact.getShpkd());
        pstmt.setString(3, stdact.getActcd());
        pstmt.setString(4, stdact.getBlkno());
        pstmt.setString(5, stdact.getEvtcd());
        pstmt.setString(6, stdact.getActnm());
        pstmt.setString(7, stdact.getCrtyn());
        pstmt.setInt(8, stdact.getHvyrt());
        pstmt.setString(9, stdact.getJoblk());
        pstmt.setString(10, stdact.getDptno());
        pstmt.setInt(11, stdact.getAdate());
        pstmt.setInt(12, stdact.getMdate());
        pstmt.setString(13, stdact.getAuser());
        pstmt.setString(14, stdact.getMuser());
        // Key
        pstmt.setString(15, stdact.getFacid()); 
        pstmt.setString(16, stdact.getShpkd()); 
        pstmt.setString(17, stdact.getActcd()); 
        pstmt.setString(18, stdact.getBlkno()); 
        pstmt.setString(19, stdact.getEvtcd()); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String facid, String shpkd, String actcd, String blkno, String evtcd
* @return void 
* @author besTeam 
* @date 2012-8-10
*/
public void delete(String facid, String shpkd, String actcd, String blkno, String evtcd) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From STDACT "+
                       "where facid = ? and shpkd = ? and actcd = ? and blkno = ? and evtcd = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,shpkd); 
        pstmt.setString(3,actcd); 
        pstmt.setString(4,blkno); 
        pstmt.setString(5,evtcd); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param STDACTRec 
* @return void 
* @author besTeam 
* @date 2012-8-10
*/
public void delete(STDACTRec stdact) throws Exception{
     delete(stdact.getFacid(), stdact.getShpkd(), stdact.getActcd(), stdact.getBlkno(), stdact.getEvtcd());
} // end Delete

/**
* Get Rows Count 
* @param String facid, String shpkd, String actcd, String blkno, String evtcd
* @return int 
* @author besTeam 
* @date 2012-8-10
*/
public int count(String facid, String shpkd, String actcd, String blkno, String evtcd) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from STDACT " +
                       " where facid = ? and shpkd = ? and actcd = ? and blkno = ? and evtcd = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,shpkd); 
        pstmt.setString(3,actcd); 
        pstmt.setString(4,blkno); 
        pstmt.setString(5,evtcd); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param void 
* @return int 
* @author besTeam 
* @date 2012-8-10
*/
public int count() throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from STDACT  ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}// end STDACTDBWrap class