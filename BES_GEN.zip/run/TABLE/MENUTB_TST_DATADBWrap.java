package com.bes_line.mst;

// DBWrapper's Wrapper  Class for MENUTB_TST_DATA
/**
 *
 * @(#) MENUTB_TST_DATADBWrap.java
 * Copyright 1999-2001 by Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2012-8-10
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class MENUTB_TST_DATADBWrap extends MENUTB_TST_DATADBWrapBES{
public MENUTB_TST_DATADBWrap(ConnectionContext ctx){
    super(ctx);
} // Constructor

////////////////// User Define Code Start //////////////////

////////////////// User Define  Code  End //////////////////
}// end MENUTB_TST_DATADBWrapBes class