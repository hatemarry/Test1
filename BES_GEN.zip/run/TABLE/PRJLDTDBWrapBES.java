package com.bes_line.mst;

// DBWrapper Class for PRJLDT
/**
 *
 * @(#) PRJLDTDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2012-8-8
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class PRJLDTDBWrapBES extends DBWrapper{

public PRJLDTDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Get one Record 
* @param String facid, String prjno, String revnm, String blkno, String evtcd
* @return PRJLDTRec 
* @author besTeam 
* @date 2012-8-8
*/
public PRJLDTRec select(String facid, String prjno, String revnm, String blkno, String evtcd) throws Exception{
    PRJLDTRec prjldt = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, prjno, revnm, blkno, evtcd, ltime, btime, basic, stscd, " +
                              "remrk, adate, mdate, auser, muser " +
                       "  from PRJLDT  " +
                       "  where facid = ? and prjno = ? and revnm = ? and blkno = ? and evtcd = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,prjno); 
        pstmt.setString(3,revnm); 
        pstmt.setString(4,blkno); 
        pstmt.setString(5,evtcd); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            prjldt = new PRJLDTRec(); // PRJLDTRec Constructor
                     prjldt.setFacid(rs.getString("facid"));
                     prjldt.setPrjno(rs.getString("prjno"));
                     prjldt.setRevnm(rs.getString("revnm"));
                     prjldt.setBlkno(rs.getString("blkno"));
                     prjldt.setEvtcd(rs.getString("evtcd"));
                     prjldt.setLtime(rs.getInt("ltime"));
                     prjldt.setBtime(rs.getInt("btime"));
                     prjldt.setBasic(rs.getInt("basic"));
                     prjldt.setStscd(rs.getString("stscd"));
                     prjldt.setRemrk(rs.getString("remrk"));
                     prjldt.setAdate(rs.getInt("adate"));
                     prjldt.setMdate(rs.getInt("mdate"));
                     prjldt.setAuser(rs.getString("auser"));
                     prjldt.setMuser(rs.getString("muser"));
        } else {
            throw new DataNotFoundException();
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return prjldt;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector prjldtV = new java.util.Vector();
    PRJLDTRec prjldt = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, prjno, revnm, blkno, evtcd, ltime, btime, basic, stscd, " +
                              "remrk, adate, mdate, auser, muser " +
                       "  from PRJLDT ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            prjldt = new PRJLDTRec(); // PRJLDTRec Constructor
                     prjldt.setFacid(rs.getString("facid"));
                     prjldt.setPrjno(rs.getString("prjno"));
                     prjldt.setRevnm(rs.getString("revnm"));
                     prjldt.setBlkno(rs.getString("blkno"));
                     prjldt.setEvtcd(rs.getString("evtcd"));
                     prjldt.setLtime(rs.getInt("ltime"));
                     prjldt.setBtime(rs.getInt("btime"));
                     prjldt.setBasic(rs.getInt("basic"));
                     prjldt.setStscd(rs.getString("stscd"));
                     prjldt.setRemrk(rs.getString("remrk"));
                     prjldt.setAdate(rs.getInt("adate"));
                     prjldt.setMdate(rs.getInt("mdate"));
                     prjldt.setAuser(rs.getString("auser"));
                     prjldt.setMuser(rs.getString("muser"));
            prjldtV.addElement(prjldt);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return prjldtV;
} // end selectAll

/**
* Get All Record(condition : last Key except) 
* @param String facid, String prjno, String revnm, String blkno
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectAll(String facid, String prjno, String revnm, String blkno) throws Exception{
    java.util.Vector prjldtV = new java.util.Vector();
    PRJLDTRec prjldt = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, prjno, revnm, blkno, evtcd, ltime, btime, basic, stscd, " +
                              "remrk, adate, mdate, auser, muser " +
                       "  from PRJLDT  " +
                       "  where facid = ? and prjno = ? and revnm = ? and blkno = ?  " +
                       "  order by evtcd"; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,prjno); 
        pstmt.setString(3,revnm); 
        pstmt.setString(4,blkno); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            prjldt = new PRJLDTRec(); // PRJLDTRec Constructor
                     prjldt.setFacid(rs.getString("facid"));
                     prjldt.setPrjno(rs.getString("prjno"));
                     prjldt.setRevnm(rs.getString("revnm"));
                     prjldt.setBlkno(rs.getString("blkno"));
                     prjldt.setEvtcd(rs.getString("evtcd"));
                     prjldt.setLtime(rs.getInt("ltime"));
                     prjldt.setBtime(rs.getInt("btime"));
                     prjldt.setBasic(rs.getInt("basic"));
                     prjldt.setStscd(rs.getString("stscd"));
                     prjldt.setRemrk(rs.getString("remrk"));
                     prjldt.setAdate(rs.getInt("adate"));
                     prjldt.setMdate(rs.getInt("mdate"));
                     prjldt.setAuser(rs.getString("auser"));
                     prjldt.setMuser(rs.getString("muser"));
            prjldtV.addElement(prjldt);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return prjldtV;
} // end selectAll

/**
* Get between Record(condition : last Key from - to) 
* @param String facid, String prjno, String revnm, String blkno, String f_evtcd, String t_evtcd
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectBetween(String facid, String prjno, String revnm, String blkno, String f_evtcd, String t_evtcd) throws Exception{
    return selectBetween(facid, prjno, revnm, blkno, f_evtcd, t_evtcd, 0);
} // end selectBetween

/**
* Get between Record(condition : last Key from - to) 
* @param String facid, String prjno, String revnm, String blkno, String f_evtcd, String t_evtcd, int lastKeyOrder(0 : ASC-Default, 1 : DESC)
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectBetween(String facid, String prjno, String revnm, String blkno, String f_evtcd, String t_evtcd, int lastKeyOrder) throws Exception{
    java.util.Vector prjldtV = new java.util.Vector();
    PRJLDTRec prjldt = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, prjno, revnm, blkno, evtcd, ltime, btime, basic, stscd, " +
                              "remrk, adate, mdate, auser, muser " +
                       "  from PRJLDT  " +
                       "  where facid = ? and prjno = ? and revnm = ? and blkno = ?  " +
                       "  and evtcd between ? and ?  ";
               if(lastKeyOrder == 1){
                   query += " order by DESC evtcd"; 
               } else {
                   query += " order by evtcd"; 
               } // end if(lastKeyOrder == 1)
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,prjno); 
        pstmt.setString(3,revnm); 
        pstmt.setString(4,blkno); 
        pstmt.setString(5,f_evtcd); 
        pstmt.setString(6,t_evtcd); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            prjldt = new PRJLDTRec(); // PRJLDTRec Constructor
                     prjldt.setFacid(rs.getString("facid"));
                     prjldt.setPrjno(rs.getString("prjno"));
                     prjldt.setRevnm(rs.getString("revnm"));
                     prjldt.setBlkno(rs.getString("blkno"));
                     prjldt.setEvtcd(rs.getString("evtcd"));
                     prjldt.setLtime(rs.getInt("ltime"));
                     prjldt.setBtime(rs.getInt("btime"));
                     prjldt.setBasic(rs.getInt("basic"));
                     prjldt.setStscd(rs.getString("stscd"));
                     prjldt.setRemrk(rs.getString("remrk"));
                     prjldt.setAdate(rs.getInt("adate"));
                     prjldt.setMdate(rs.getInt("mdate"));
                     prjldt.setAuser(rs.getString("auser"));
                     prjldt.setMuser(rs.getString("muser"));
            prjldtV.addElement(prjldt);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return prjldtV;
} // end selectBetween

/**
* Select Data Over the key value(s) and default return count(20) 
* @param String facid, String prjno, String revnm, String blkno, String evtcd
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectOver(String facid, String prjno, String revnm, String blkno, String evtcd) throws Exception{
return selectOver(facid, prjno, revnm, blkno, evtcd,20) ;
}// end selectOver
/**
* Select Data Over(Next) the key value(s) and return record count 
* @param String facid, String prjno, String revnm, String blkno, String evtcd, int 
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectOver(String facid, String prjno, String revnm, String blkno, String evtcd, int page) throws Exception{
    java.util.Vector prjldtV = new java.util.Vector();
    PRJLDTRec prjldt = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, prjno, revnm, blkno, evtcd, ltime, btime, basic, stscd, " +
                              "remrk, adate, mdate, auser, muser " +
                       "  from PRJLDT  " +
                       "  where facid = ?  and  prjno = ?  and  revnm = ?  and  blkno = ?  and  evtcd >= ? order by evtcd "; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,prjno); 
        pstmt.setString(3,revnm); 
        pstmt.setString(4,blkno); 
        pstmt.setString(5,evtcd); 
        rs = pstmt.executeQuery();
        int count = 0;//������� SQL���忡�� Limit�ؾ� ������...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            prjldt = new PRJLDTRec(); // PRJLDTRec Constructor
                     prjldt.setFacid(rs.getString("facid"));
                     prjldt.setPrjno(rs.getString("prjno"));
                     prjldt.setRevnm(rs.getString("revnm"));
                     prjldt.setBlkno(rs.getString("blkno"));
                     prjldt.setEvtcd(rs.getString("evtcd"));
                     prjldt.setLtime(rs.getInt("ltime"));
                     prjldt.setBtime(rs.getInt("btime"));
                     prjldt.setBasic(rs.getInt("basic"));
                     prjldt.setStscd(rs.getString("stscd"));
                     prjldt.setRemrk(rs.getString("remrk"));
                     prjldt.setAdate(rs.getInt("adate"));
                     prjldt.setMdate(rs.getInt("mdate"));
                     prjldt.setAuser(rs.getString("auser"));
                     prjldt.setMuser(rs.getString("muser"));
            prjldtV.addElement(prjldt);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return prjldtV;
} // end selectOver

/**
* Select Data Under(Previous) the key value(s) and default return count(20) 
* @param String facid, String prjno, String revnm, String blkno, String evtcd
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectUnder(String facid, String prjno, String revnm, String blkno, String evtcd) throws Exception{
return selectUnder(facid, prjno, revnm, blkno, evtcd,20) ;
}// end selectUnder
/**
* Select Data Under(Previous) the key value(s) and return record count 
* @param String facid, String prjno, String revnm, String blkno, String evtcd, int
* @return java.util.Vector
* @author besTeam 
* @date 2012-8-8
*/
public java.util.Vector selectUnder(String facid, String prjno, String revnm, String blkno, String evtcd, int page) throws Exception{
    java.util.Vector prjldtV = new java.util.Vector();
    PRJLDTRec prjldt = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select facid, prjno, revnm, blkno, evtcd, ltime, btime, basic, stscd, " +
                              "remrk, adate, mdate, auser, muser " +
                       "  from PRJLDT  " +
                       "  where facid = ?  and prjno = ?  and revnm = ?  and blkno = ?  and evtcd <= ? order by evtcd desc" ; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,prjno); 
        pstmt.setString(3,revnm); 
        pstmt.setString(4,blkno); 
        pstmt.setString(5,evtcd); 
        rs = pstmt.executeQuery();
        int count = 0;//������� SQL���忡�� Limit�ؾ� ������...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            prjldt = new PRJLDTRec(); // PRJLDTRec Constructor
                     prjldt.setFacid(rs.getString("facid"));
                     prjldt.setPrjno(rs.getString("prjno"));
                     prjldt.setRevnm(rs.getString("revnm"));
                     prjldt.setBlkno(rs.getString("blkno"));
                     prjldt.setEvtcd(rs.getString("evtcd"));
                     prjldt.setLtime(rs.getInt("ltime"));
                     prjldt.setBtime(rs.getInt("btime"));
                     prjldt.setBasic(rs.getInt("basic"));
                     prjldt.setStscd(rs.getString("stscd"));
                     prjldt.setRemrk(rs.getString("remrk"));
                     prjldt.setAdate(rs.getInt("adate"));
                     prjldt.setMdate(rs.getInt("mdate"));
                     prjldt.setAuser(rs.getString("auser"));
                     prjldt.setMuser(rs.getString("muser"));
            prjldtV.add(0,prjldt);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return prjldtV;
} // end selectUnder

// Insert Data 
/**
* Add Record 
* @param PRJLDTRec 
* @return void 
* @author besTeam 
* @date 2012-8-8
*/
public void insert(PRJLDTRec prjldt) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into PRJLDT( " +
                              "facid, prjno, revnm, blkno, evtcd, ltime, btime, basic, stscd, " +
                              "remrk, adate, mdate, auser, muser"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, prjldt.getFacid());
        pstmt.setString(2, prjldt.getPrjno());
        pstmt.setString(3, prjldt.getRevnm());
        pstmt.setString(4, prjldt.getBlkno());
        pstmt.setString(5, prjldt.getEvtcd());
        pstmt.setInt(6, prjldt.getLtime());
        pstmt.setInt(7, prjldt.getBtime());
        pstmt.setInt(8, prjldt.getBasic());
        pstmt.setString(9, prjldt.getStscd());
        pstmt.setString(10, prjldt.getRemrk());
        pstmt.setInt(11, prjldt.getAdate());
        pstmt.setInt(12, prjldt.getMdate());
        pstmt.setString(13, prjldt.getAuser());
        pstmt.setString(14, prjldt.getMuser());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param PRJLDTRec 
* @return void 
* @author besTeam 
* @date 2012-8-8
*/
public void update(PRJLDTRec prjldt) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update PRJLDT SET "+
                        "facid = ?, prjno = ?, revnm = ?, blkno = ?, evtcd = ?, ltime = ?, btime = ?, basic = ?, stscd = ?, remrk = ?, " +
                              "adate = ?, mdate = ?, auser = ?, muser = ?"+
                        " where facid = ? and prjno = ? and revnm = ? and blkno = ? and evtcd = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, prjldt.getFacid());
        pstmt.setString(2, prjldt.getPrjno());
        pstmt.setString(3, prjldt.getRevnm());
        pstmt.setString(4, prjldt.getBlkno());
        pstmt.setString(5, prjldt.getEvtcd());
        pstmt.setInt(6, prjldt.getLtime());
        pstmt.setInt(7, prjldt.getBtime());
        pstmt.setInt(8, prjldt.getBasic());
        pstmt.setString(9, prjldt.getStscd());
        pstmt.setString(10, prjldt.getRemrk());
        pstmt.setInt(11, prjldt.getAdate());
        pstmt.setInt(12, prjldt.getMdate());
        pstmt.setString(13, prjldt.getAuser());
        pstmt.setString(14, prjldt.getMuser());
        // Key
        pstmt.setString(15, prjldt.getFacid()); 
        pstmt.setString(16, prjldt.getPrjno()); 
        pstmt.setString(17, prjldt.getRevnm()); 
        pstmt.setString(18, prjldt.getBlkno()); 
        pstmt.setString(19, prjldt.getEvtcd()); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String facid, String prjno, String revnm, String blkno, String evtcd
* @return void 
* @author besTeam 
* @date 2012-8-8
*/
public void delete(String facid, String prjno, String revnm, String blkno, String evtcd) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From PRJLDT "+
                       "where facid = ? and prjno = ? and revnm = ? and blkno = ? and evtcd = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,prjno); 
        pstmt.setString(3,revnm); 
        pstmt.setString(4,blkno); 
        pstmt.setString(5,evtcd); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param PRJLDTRec 
* @return void 
* @author besTeam 
* @date 2012-8-8
*/
public void delete(PRJLDTRec prjldt) throws Exception{
     delete(prjldt.getFacid(), prjldt.getPrjno(), prjldt.getRevnm(), prjldt.getBlkno(), prjldt.getEvtcd());
} // end Delete

/**
* Get Rows Count 
* @param String facid, String prjno, String revnm, String blkno, String evtcd
* @return int 
* @author besTeam 
* @date 2012-8-8
*/
public int count(String facid, String prjno, String revnm, String blkno, String evtcd) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from PRJLDT " +
                       " where facid = ? and prjno = ? and revnm = ? and blkno = ? and evtcd = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,facid); 
        pstmt.setString(2,prjno); 
        pstmt.setString(3,revnm); 
        pstmt.setString(4,blkno); 
        pstmt.setString(5,evtcd); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param void 
* @return int 
* @author besTeam 
* @date 2012-8-8
*/
public int count() throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from PRJLDT  ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}// end PRJLDTDBWrap class