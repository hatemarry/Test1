package com.bes_line.mst;

// DBWrapper Class for MENUTB_TST_DATA
/**
 *
 * @(#) MENUTB_TST_DATADBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2012-8-10
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class MENUTB_TST_DATADBWrapBES extends DBWrapper{

public MENUTB_TST_DATADBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Get one Record 
* @param int seqno
* @return MENUTB_TST_DATARec 
* @author besTeam 
* @date 2012-8-10
*/
public MENUTB_TST_DATARec select(int seqno) throws Exception{
    MENUTB_TST_DATARec menutb_tst_data = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select seqno, syscd, sysnm, meggu, megnm, midgu, midnm, bpdtl, owner, " +
                              "lvlid, lvseq, pgmid, pgmnm, commt, pgmod, par1, par2, par3, " +
                              "par4, par5, par6, useyn, remrk " +
                       "  from MENUTB_TST_DATA  " +
                       "  where seqno = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setInt(1,seqno); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            menutb_tst_data = new MENUTB_TST_DATARec(); // MENUTB_TST_DATARec Constructor
                     menutb_tst_data.setSeqno(rs.getInt("seqno"));
                     menutb_tst_data.setSyscd(rs.getString("syscd"));
                     menutb_tst_data.setSysnm(rs.getString("sysnm"));
                     menutb_tst_data.setMeggu(rs.getString("meggu"));
                     menutb_tst_data.setMegnm(rs.getString("megnm"));
                     menutb_tst_data.setMidgu(rs.getString("midgu"));
                     menutb_tst_data.setMidnm(rs.getString("midnm"));
                     menutb_tst_data.setBpdtl(rs.getString("bpdtl"));
                     menutb_tst_data.setOwner(rs.getString("owner"));
                     menutb_tst_data.setLvlid(rs.getString("lvlid"));
                     menutb_tst_data.setLvseq(rs.getString("lvseq"));
                     menutb_tst_data.setPgmid(rs.getString("pgmid"));
                     menutb_tst_data.setPgmnm(rs.getString("pgmnm"));
                     menutb_tst_data.setCommt(rs.getString("commt"));
                     menutb_tst_data.setPgmod(rs.getString("pgmod"));
                     menutb_tst_data.setPar1(rs.getString("par1"));
                     menutb_tst_data.setPar2(rs.getString("par2"));
                     menutb_tst_data.setPar3(rs.getString("par3"));
                     menutb_tst_data.setPar4(rs.getString("par4"));
                     menutb_tst_data.setPar5(rs.getString("par5"));
                     menutb_tst_data.setPar6(rs.getString("par6"));
                     menutb_tst_data.setUseyn(rs.getString("useyn"));
                     menutb_tst_data.setRemrk(rs.getString("remrk"));
        } else {
            throw new DataNotFoundException();
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return menutb_tst_data;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector menutb_tst_dataV = new java.util.Vector();
    MENUTB_TST_DATARec menutb_tst_data = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select seqno, syscd, sysnm, meggu, megnm, midgu, midnm, bpdtl, owner, " +
                              "lvlid, lvseq, pgmid, pgmnm, commt, pgmod, par1, par2, par3, " +
                              "par4, par5, par6, useyn, remrk " +
                       "  from MENUTB_TST_DATA ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            menutb_tst_data = new MENUTB_TST_DATARec(); // MENUTB_TST_DATARec Constructor
                     menutb_tst_data.setSeqno(rs.getInt("seqno"));
                     menutb_tst_data.setSyscd(rs.getString("syscd"));
                     menutb_tst_data.setSysnm(rs.getString("sysnm"));
                     menutb_tst_data.setMeggu(rs.getString("meggu"));
                     menutb_tst_data.setMegnm(rs.getString("megnm"));
                     menutb_tst_data.setMidgu(rs.getString("midgu"));
                     menutb_tst_data.setMidnm(rs.getString("midnm"));
                     menutb_tst_data.setBpdtl(rs.getString("bpdtl"));
                     menutb_tst_data.setOwner(rs.getString("owner"));
                     menutb_tst_data.setLvlid(rs.getString("lvlid"));
                     menutb_tst_data.setLvseq(rs.getString("lvseq"));
                     menutb_tst_data.setPgmid(rs.getString("pgmid"));
                     menutb_tst_data.setPgmnm(rs.getString("pgmnm"));
                     menutb_tst_data.setCommt(rs.getString("commt"));
                     menutb_tst_data.setPgmod(rs.getString("pgmod"));
                     menutb_tst_data.setPar1(rs.getString("par1"));
                     menutb_tst_data.setPar2(rs.getString("par2"));
                     menutb_tst_data.setPar3(rs.getString("par3"));
                     menutb_tst_data.setPar4(rs.getString("par4"));
                     menutb_tst_data.setPar5(rs.getString("par5"));
                     menutb_tst_data.setPar6(rs.getString("par6"));
                     menutb_tst_data.setUseyn(rs.getString("useyn"));
                     menutb_tst_data.setRemrk(rs.getString("remrk"));
            menutb_tst_dataV.addElement(menutb_tst_data);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return menutb_tst_dataV;
} // end selectAll

/**
* Select Data Over the key value(s) and default return count(20) 
* @param int seqno
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectOver(int seqno) throws Exception{
return selectOver(seqno,20) ;
}// end selectOver
/**
* Select Data Over(Next) the key value(s) and return record count 
* @param int seqno, int 
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectOver(int seqno, int page) throws Exception{
    java.util.Vector menutb_tst_dataV = new java.util.Vector();
    MENUTB_TST_DATARec menutb_tst_data = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select seqno, syscd, sysnm, meggu, megnm, midgu, midnm, bpdtl, owner, " +
                              "lvlid, lvseq, pgmid, pgmnm, commt, pgmod, par1, par2, par3, " +
                              "par4, par5, par6, useyn, remrk " +
                       "  from MENUTB_TST_DATA  " +
                       "  where seqno >= ? order by seqno "; 
        pstmt = connection.prepareStatement(query);
        pstmt.setInt(1,seqno); 
        rs = pstmt.executeQuery();
        int count = 0;//������� SQL���忡�� Limit�ؾ� ������...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            menutb_tst_data = new MENUTB_TST_DATARec(); // MENUTB_TST_DATARec Constructor
                     menutb_tst_data.setSeqno(rs.getInt("seqno"));
                     menutb_tst_data.setSyscd(rs.getString("syscd"));
                     menutb_tst_data.setSysnm(rs.getString("sysnm"));
                     menutb_tst_data.setMeggu(rs.getString("meggu"));
                     menutb_tst_data.setMegnm(rs.getString("megnm"));
                     menutb_tst_data.setMidgu(rs.getString("midgu"));
                     menutb_tst_data.setMidnm(rs.getString("midnm"));
                     menutb_tst_data.setBpdtl(rs.getString("bpdtl"));
                     menutb_tst_data.setOwner(rs.getString("owner"));
                     menutb_tst_data.setLvlid(rs.getString("lvlid"));
                     menutb_tst_data.setLvseq(rs.getString("lvseq"));
                     menutb_tst_data.setPgmid(rs.getString("pgmid"));
                     menutb_tst_data.setPgmnm(rs.getString("pgmnm"));
                     menutb_tst_data.setCommt(rs.getString("commt"));
                     menutb_tst_data.setPgmod(rs.getString("pgmod"));
                     menutb_tst_data.setPar1(rs.getString("par1"));
                     menutb_tst_data.setPar2(rs.getString("par2"));
                     menutb_tst_data.setPar3(rs.getString("par3"));
                     menutb_tst_data.setPar4(rs.getString("par4"));
                     menutb_tst_data.setPar5(rs.getString("par5"));
                     menutb_tst_data.setPar6(rs.getString("par6"));
                     menutb_tst_data.setUseyn(rs.getString("useyn"));
                     menutb_tst_data.setRemrk(rs.getString("remrk"));
            menutb_tst_dataV.addElement(menutb_tst_data);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return menutb_tst_dataV;
} // end selectOver

/**
* Select Data Under(Previous) the key value(s) and default return count(20) 
* @param int seqno
* @return java.util.Vector 
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectUnder(int seqno) throws Exception{
return selectUnder(seqno,20) ;
}// end selectUnder
/**
* Select Data Under(Previous) the key value(s) and return record count 
* @param int seqno, int
* @return java.util.Vector
* @author besTeam 
* @date 2012-8-10
*/
public java.util.Vector selectUnder(int seqno, int page) throws Exception{
    java.util.Vector menutb_tst_dataV = new java.util.Vector();
    MENUTB_TST_DATARec menutb_tst_data = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select seqno, syscd, sysnm, meggu, megnm, midgu, midnm, bpdtl, owner, " +
                              "lvlid, lvseq, pgmid, pgmnm, commt, pgmod, par1, par2, par3, " +
                              "par4, par5, par6, useyn, remrk " +
                       "  from MENUTB_TST_DATA  " +
                       "  where seqno <= ? order by seqno desc" ; 
        pstmt = connection.prepareStatement(query);
        pstmt.setInt(1,seqno); 
        rs = pstmt.executeQuery();
        int count = 0;//������� SQL���忡�� Limit�ؾ� ������...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            menutb_tst_data = new MENUTB_TST_DATARec(); // MENUTB_TST_DATARec Constructor
                     menutb_tst_data.setSeqno(rs.getInt("seqno"));
                     menutb_tst_data.setSyscd(rs.getString("syscd"));
                     menutb_tst_data.setSysnm(rs.getString("sysnm"));
                     menutb_tst_data.setMeggu(rs.getString("meggu"));
                     menutb_tst_data.setMegnm(rs.getString("megnm"));
                     menutb_tst_data.setMidgu(rs.getString("midgu"));
                     menutb_tst_data.setMidnm(rs.getString("midnm"));
                     menutb_tst_data.setBpdtl(rs.getString("bpdtl"));
                     menutb_tst_data.setOwner(rs.getString("owner"));
                     menutb_tst_data.setLvlid(rs.getString("lvlid"));
                     menutb_tst_data.setLvseq(rs.getString("lvseq"));
                     menutb_tst_data.setPgmid(rs.getString("pgmid"));
                     menutb_tst_data.setPgmnm(rs.getString("pgmnm"));
                     menutb_tst_data.setCommt(rs.getString("commt"));
                     menutb_tst_data.setPgmod(rs.getString("pgmod"));
                     menutb_tst_data.setPar1(rs.getString("par1"));
                     menutb_tst_data.setPar2(rs.getString("par2"));
                     menutb_tst_data.setPar3(rs.getString("par3"));
                     menutb_tst_data.setPar4(rs.getString("par4"));
                     menutb_tst_data.setPar5(rs.getString("par5"));
                     menutb_tst_data.setPar6(rs.getString("par6"));
                     menutb_tst_data.setUseyn(rs.getString("useyn"));
                     menutb_tst_data.setRemrk(rs.getString("remrk"));
            menutb_tst_dataV.add(0,menutb_tst_data);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return menutb_tst_dataV;
} // end selectUnder

// Insert Data 
/**
* Add Record 
* @param MENUTB_TST_DATARec 
* @return void 
* @author besTeam 
* @date 2012-8-10
*/
public void insert(MENUTB_TST_DATARec menutb_tst_data) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into MENUTB_TST_DATA( " +
                              "seqno, syscd, sysnm, meggu, megnm, midgu, midnm, bpdtl, owner, " +
                              "lvlid, lvseq, pgmid, pgmnm, commt, pgmod, par1, par2, par3, " +
                              "par4, par5, par6, useyn, remrk"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setInt(1, menutb_tst_data.getSeqno());
        pstmt.setString(2, menutb_tst_data.getSyscd());
        pstmt.setString(3, menutb_tst_data.getSysnm());
        pstmt.setString(4, menutb_tst_data.getMeggu());
        pstmt.setString(5, menutb_tst_data.getMegnm());
        pstmt.setString(6, menutb_tst_data.getMidgu());
        pstmt.setString(7, menutb_tst_data.getMidnm());
        pstmt.setString(8, menutb_tst_data.getBpdtl());
        pstmt.setString(9, menutb_tst_data.getOwner());
        pstmt.setString(10, menutb_tst_data.getLvlid());
        pstmt.setString(11, menutb_tst_data.getLvseq());
        pstmt.setString(12, menutb_tst_data.getPgmid());
        pstmt.setString(13, menutb_tst_data.getPgmnm());
        pstmt.setString(14, menutb_tst_data.getCommt());
        pstmt.setString(15, menutb_tst_data.getPgmod());
        pstmt.setString(16, menutb_tst_data.getPar1());
        pstmt.setString(17, menutb_tst_data.getPar2());
        pstmt.setString(18, menutb_tst_data.getPar3());
        pstmt.setString(19, menutb_tst_data.getPar4());
        pstmt.setString(20, menutb_tst_data.getPar5());
        pstmt.setString(21, menutb_tst_data.getPar6());
        pstmt.setString(22, menutb_tst_data.getUseyn());
        pstmt.setString(23, menutb_tst_data.getRemrk());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param MENUTB_TST_DATARec 
* @return void 
* @author besTeam 
* @date 2012-8-10
*/
public void update(MENUTB_TST_DATARec menutb_tst_data) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update MENUTB_TST_DATA SET "+
                        "seqno = ?, syscd = ?, sysnm = ?, meggu = ?, megnm = ?, midgu = ?, midnm = ?, bpdtl = ?, owner = ?, lvlid = ?, " +
                              "lvseq = ?, pgmid = ?, pgmnm = ?, commt = ?, pgmod = ?, par1 = ?, par2 = ?, par3 = ?, par4 = ?, " +
                              "par5 = ?, par6 = ?, useyn = ?, remrk = ?"+
                        " where seqno = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setInt(1, menutb_tst_data.getSeqno());
        pstmt.setString(2, menutb_tst_data.getSyscd());
        pstmt.setString(3, menutb_tst_data.getSysnm());
        pstmt.setString(4, menutb_tst_data.getMeggu());
        pstmt.setString(5, menutb_tst_data.getMegnm());
        pstmt.setString(6, menutb_tst_data.getMidgu());
        pstmt.setString(7, menutb_tst_data.getMidnm());
        pstmt.setString(8, menutb_tst_data.getBpdtl());
        pstmt.setString(9, menutb_tst_data.getOwner());
        pstmt.setString(10, menutb_tst_data.getLvlid());
        pstmt.setString(11, menutb_tst_data.getLvseq());
        pstmt.setString(12, menutb_tst_data.getPgmid());
        pstmt.setString(13, menutb_tst_data.getPgmnm());
        pstmt.setString(14, menutb_tst_data.getCommt());
        pstmt.setString(15, menutb_tst_data.getPgmod());
        pstmt.setString(16, menutb_tst_data.getPar1());
        pstmt.setString(17, menutb_tst_data.getPar2());
        pstmt.setString(18, menutb_tst_data.getPar3());
        pstmt.setString(19, menutb_tst_data.getPar4());
        pstmt.setString(20, menutb_tst_data.getPar5());
        pstmt.setString(21, menutb_tst_data.getPar6());
        pstmt.setString(22, menutb_tst_data.getUseyn());
        pstmt.setString(23, menutb_tst_data.getRemrk());
        // Key
        pstmt.setInt(24, menutb_tst_data.getSeqno()); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param int seqno
* @return void 
* @author besTeam 
* @date 2012-8-10
*/
public void delete(int seqno) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From MENUTB_TST_DATA "+
                       "where seqno = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setInt(1,seqno); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param MENUTB_TST_DATARec 
* @return void 
* @author besTeam 
* @date 2012-8-10
*/
public void delete(MENUTB_TST_DATARec menutb_tst_data) throws Exception{
     delete(menutb_tst_data.getSeqno());
} // end Delete

/**
* Get Rows Count 
* @param int seqno
* @return int 
* @author besTeam 
* @date 2012-8-10
*/
public int count(int seqno) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from MENUTB_TST_DATA " +
                       " where seqno = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setInt(1,seqno); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param void 
* @return int 
* @author besTeam 
* @date 2012-8-10
*/
public int count() throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from MENUTB_TST_DATA  ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}// end MENUTB_TST_DATADBWrap class