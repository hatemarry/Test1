package com.bes_line.mst.EBH;

// DBWrapper Class for HA010M
/**
 *
 * @(#) HA010MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-30
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class HA010MDBWrapBES extends DBWrapper{

public HA010MDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Select Page 
* @param String proj_no
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-30
*/
public java.util.Vector selectPage(String fldname, int page, int pagesize, String whereOption ) throws Exception{
return selectPage(fldname,page,pagesize, "Asc", whereOption) ;
}// end selectPage
/**
* Select Page
* @param String proj_no* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-30
*/
public java.util.Vector selectPage(String fldname, int page, int pagesize, String keyorder, String whereOption) throws Exception{
    java.util.Vector eb.ha010mV = new java.util.Vector();
    HA010MRec eb.ha010m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select proj_no, prf_proj_indc, proj_no_grp, proj_desc_kor, proj_desc_engl, prod_ord_no, prod_ord_date, proj_cls_date, acct_cls_date, " +
                              "acct_code_npp, ship_type, ship_kind, proj_ittv_div, proj_ittv_dept, proj_exec_div, proj_exec_dept, acct_id_mgnt_proj, ship_bdth_actl, " +
                              "ship_loa_actl, ship_dpth_actl, ship_lbp_actl, ship_spd, stl_net_wt, gros_wt, ship_dwt_actl, ship_capa_size, sd_pln, " +
                              "sd_actl, sc_date_pln, sc_date_actl, kl_date_pln, kl_date_actl, lncg_date_pln, lncg_date_actl, strl_date_pln, strl_date_actl, " +
                              "cmpl_date_pln, cmpl_date_actl, dlvy_date_pln, dlvy_date_actl, main_engn_erec_dt_pln, main_engn_erec_dt_actl, main_proj_no, trst_main_proj_no, asst_trnfr_date, " +
                              "cnsm_mh, bdgt_mh, tagt_mh, proj_sale, proj_bdgt, proj_no_rgdt, proj_cls_rgdt, proj_po_type, cost_cntr, " +
                              "cad_unon_aply_indc, cad_unon_aply_indc_rgdt, cad_unon_aply_emp_no " +
                       "  from EB.HA010M  where 1 = 1 " +	whereOption  +
                       "  order by "+fldname+" "+keyorder; 
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();
        int count = 0;
        while((count < (page-1)*pagesize ) && ( rs.next())){  count ++; } // page??? ??????
            count = 0;
        while(rs.next()){
            count ++;
            if(count > pagesize ) break;
            eb.ha010m = new HA010MRec(); // HA010MRec Constructor
                     eb.ha010m.setProj_no(rs.getString("proj_no"));
                     eb.ha010m.setPrf_proj_indc(rs.getString("prf_proj_indc"));
                     eb.ha010m.setProj_no_grp(rs.getString("proj_no_grp"));
                     eb.ha010m.setProj_desc_kor(rs.getString("proj_desc_kor"));
                     eb.ha010m.setProj_desc_engl(rs.getString("proj_desc_engl"));
                     eb.ha010m.setProd_ord_no(rs.getString("prod_ord_no"));
                     eb.ha010m.setProd_ord_date(rs.getString("prod_ord_date"));
                     eb.ha010m.setProj_cls_date(rs.getString("proj_cls_date"));
                     eb.ha010m.setAcct_cls_date(rs.getString("acct_cls_date"));
                     eb.ha010m.setAcct_code_npp(rs.getString("acct_code_npp"));
                     eb.ha010m.setShip_type(rs.getString("ship_type"));
                     eb.ha010m.setShip_kind(rs.getString("ship_kind"));
                     eb.ha010m.setProj_ittv_div(rs.getString("proj_ittv_div"));
                     eb.ha010m.setProj_ittv_dept(rs.getString("proj_ittv_dept"));
                     eb.ha010m.setProj_exec_div(rs.getString("proj_exec_div"));
                     eb.ha010m.setProj_exec_dept(rs.getString("proj_exec_dept"));
                     eb.ha010m.setAcct_id_mgnt_proj(rs.getString("acct_id_mgnt_proj"));
                     eb.ha010m.setShip_bdth_actl(rs.getDouble("ship_bdth_actl"));
                     eb.ha010m.setShip_loa_actl(rs.getDouble("ship_loa_actl"));
                     eb.ha010m.setShip_dpth_actl(rs.getDouble("ship_dpth_actl"));
                     eb.ha010m.setShip_lbp_actl(rs.getDouble("ship_lbp_actl"));
                     eb.ha010m.setShip_spd(rs.getDouble("ship_spd"));
                     eb.ha010m.setStl_net_wt(rs.getDouble("stl_net_wt"));
                     eb.ha010m.setGros_wt(rs.getDouble("gros_wt"));
                     eb.ha010m.setShip_dwt_actl(rs.getDouble("ship_dwt_actl"));
                     eb.ha010m.setShip_capa_size(rs.getString("ship_capa_size"));
                     eb.ha010m.setSd_pln(rs.getString("sd_pln"));
                     eb.ha010m.setSd_actl(rs.getString("sd_actl"));
                     eb.ha010m.setSc_date_pln(rs.getString("sc_date_pln"));
                     eb.ha010m.setSc_date_actl(rs.getString("sc_date_actl"));
                     eb.ha010m.setKl_date_pln(rs.getString("kl_date_pln"));
                     eb.ha010m.setKl_date_actl(rs.getString("kl_date_actl"));
                     eb.ha010m.setLncg_date_pln(rs.getString("lncg_date_pln"));
                     eb.ha010m.setLncg_date_actl(rs.getString("lncg_date_actl"));
                     eb.ha010m.setStrl_date_pln(rs.getString("strl_date_pln"));
                     eb.ha010m.setStrl_date_actl(rs.getString("strl_date_actl"));
                     eb.ha010m.setCmpl_date_pln(rs.getString("cmpl_date_pln"));
                     eb.ha010m.setCmpl_date_actl(rs.getString("cmpl_date_actl"));
                     eb.ha010m.setDlvy_date_pln(rs.getString("dlvy_date_pln"));
                     eb.ha010m.setDlvy_date_actl(rs.getString("dlvy_date_actl"));
                     eb.ha010m.setMain_engn_erec_dt_pln(rs.getString("main_engn_erec_dt_pln"));
                     eb.ha010m.setMain_engn_erec_dt_actl(rs.getString("main_engn_erec_dt_actl"));
                     eb.ha010m.setMain_proj_no(rs.getString("main_proj_no"));
                     eb.ha010m.setTrst_main_proj_no(rs.getString("trst_main_proj_no"));
                     eb.ha010m.setAsst_trnfr_date(rs.getString("asst_trnfr_date"));
                     eb.ha010m.setCnsm_mh(rs.getDouble("cnsm_mh"));
                     eb.ha010m.setBdgt_mh(rs.getDouble("bdgt_mh"));
                     eb.ha010m.setTagt_mh(rs.getDouble("tagt_mh"));
                     eb.ha010m.setProj_sale(rs.getDouble("proj_sale"));
                     eb.ha010m.setProj_bdgt(rs.getDouble("proj_bdgt"));
                     eb.ha010m.setProj_no_rgdt(rs.getString("proj_no_rgdt"));
                     eb.ha010m.setProj_cls_rgdt(rs.getString("proj_cls_rgdt"));
                     eb.ha010m.setProj_po_type(rs.getString("proj_po_type"));
                     eb.ha010m.setCost_cntr(rs.getString("cost_cntr"));
                     eb.ha010m.setCad_unon_aply_indc(rs.getString("cad_unon_aply_indc"));
                     eb.ha010m.setCad_unon_aply_indc_rgdt(rs.getString("cad_unon_aply_indc_rgdt"));
                     eb.ha010m.setCad_unon_aply_emp_no(rs.getString("cad_unon_aply_emp_no"));
            eb.ha010mV.addElement(eb.ha010m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return eb.ha010mV;
} // end selectPage

/**
* SelectWhere 
* @param String proj_no
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-30
*/
public java.util.Vector selectWhere(String fldname, String whereOption ) throws Exception{
return selectWhere(fldname, "Asc", whereOption) ;
}// end selectWhere
/**
* SelectWhere
* @param String proj_no* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-30
*/
public java.util.Vector selectWhere(String fldname, String keyorder, String whereOption) throws Exception{
    java.util.Vector eb.ha010mV = new java.util.Vector();
    HA010MRec eb.ha010m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select proj_no, prf_proj_indc, proj_no_grp, proj_desc_kor, proj_desc_engl, prod_ord_no, prod_ord_date, proj_cls_date, acct_cls_date, " +
                              "acct_code_npp, ship_type, ship_kind, proj_ittv_div, proj_ittv_dept, proj_exec_div, proj_exec_dept, acct_id_mgnt_proj, ship_bdth_actl, " +
                              "ship_loa_actl, ship_dpth_actl, ship_lbp_actl, ship_spd, stl_net_wt, gros_wt, ship_dwt_actl, ship_capa_size, sd_pln, " +
                              "sd_actl, sc_date_pln, sc_date_actl, kl_date_pln, kl_date_actl, lncg_date_pln, lncg_date_actl, strl_date_pln, strl_date_actl, " +
                              "cmpl_date_pln, cmpl_date_actl, dlvy_date_pln, dlvy_date_actl, main_engn_erec_dt_pln, main_engn_erec_dt_actl, main_proj_no, trst_main_proj_no, asst_trnfr_date, " +
                              "cnsm_mh, bdgt_mh, tagt_mh, proj_sale, proj_bdgt, proj_no_rgdt, proj_cls_rgdt, proj_po_type, cost_cntr, " +
                              "cad_unon_aply_indc, cad_unon_aply_indc_rgdt, cad_unon_aply_emp_no " +
                       "  from EB.HA010M  where 1 = 1 " +	whereOption  +
                       "  order by "+fldname+" "+keyorder; 
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();
        while(rs.next()) { 
            eb.ha010m = new HA010MRec(); // HA010MRec Constructor
                     eb.ha010m.setProj_no(rs.getString("proj_no"));
                     eb.ha010m.setPrf_proj_indc(rs.getString("prf_proj_indc"));
                     eb.ha010m.setProj_no_grp(rs.getString("proj_no_grp"));
                     eb.ha010m.setProj_desc_kor(rs.getString("proj_desc_kor"));
                     eb.ha010m.setProj_desc_engl(rs.getString("proj_desc_engl"));
                     eb.ha010m.setProd_ord_no(rs.getString("prod_ord_no"));
                     eb.ha010m.setProd_ord_date(rs.getString("prod_ord_date"));
                     eb.ha010m.setProj_cls_date(rs.getString("proj_cls_date"));
                     eb.ha010m.setAcct_cls_date(rs.getString("acct_cls_date"));
                     eb.ha010m.setAcct_code_npp(rs.getString("acct_code_npp"));
                     eb.ha010m.setShip_type(rs.getString("ship_type"));
                     eb.ha010m.setShip_kind(rs.getString("ship_kind"));
                     eb.ha010m.setProj_ittv_div(rs.getString("proj_ittv_div"));
                     eb.ha010m.setProj_ittv_dept(rs.getString("proj_ittv_dept"));
                     eb.ha010m.setProj_exec_div(rs.getString("proj_exec_div"));
                     eb.ha010m.setProj_exec_dept(rs.getString("proj_exec_dept"));
                     eb.ha010m.setAcct_id_mgnt_proj(rs.getString("acct_id_mgnt_proj"));
                     eb.ha010m.setShip_bdth_actl(rs.getDouble("ship_bdth_actl"));
                     eb.ha010m.setShip_loa_actl(rs.getDouble("ship_loa_actl"));
                     eb.ha010m.setShip_dpth_actl(rs.getDouble("ship_dpth_actl"));
                     eb.ha010m.setShip_lbp_actl(rs.getDouble("ship_lbp_actl"));
                     eb.ha010m.setShip_spd(rs.getDouble("ship_spd"));
                     eb.ha010m.setStl_net_wt(rs.getDouble("stl_net_wt"));
                     eb.ha010m.setGros_wt(rs.getDouble("gros_wt"));
                     eb.ha010m.setShip_dwt_actl(rs.getDouble("ship_dwt_actl"));
                     eb.ha010m.setShip_capa_size(rs.getString("ship_capa_size"));
                     eb.ha010m.setSd_pln(rs.getString("sd_pln"));
                     eb.ha010m.setSd_actl(rs.getString("sd_actl"));
                     eb.ha010m.setSc_date_pln(rs.getString("sc_date_pln"));
                     eb.ha010m.setSc_date_actl(rs.getString("sc_date_actl"));
                     eb.ha010m.setKl_date_pln(rs.getString("kl_date_pln"));
                     eb.ha010m.setKl_date_actl(rs.getString("kl_date_actl"));
                     eb.ha010m.setLncg_date_pln(rs.getString("lncg_date_pln"));
                     eb.ha010m.setLncg_date_actl(rs.getString("lncg_date_actl"));
                     eb.ha010m.setStrl_date_pln(rs.getString("strl_date_pln"));
                     eb.ha010m.setStrl_date_actl(rs.getString("strl_date_actl"));
                     eb.ha010m.setCmpl_date_pln(rs.getString("cmpl_date_pln"));
                     eb.ha010m.setCmpl_date_actl(rs.getString("cmpl_date_actl"));
                     eb.ha010m.setDlvy_date_pln(rs.getString("dlvy_date_pln"));
                     eb.ha010m.setDlvy_date_actl(rs.getString("dlvy_date_actl"));
                     eb.ha010m.setMain_engn_erec_dt_pln(rs.getString("main_engn_erec_dt_pln"));
                     eb.ha010m.setMain_engn_erec_dt_actl(rs.getString("main_engn_erec_dt_actl"));
                     eb.ha010m.setMain_proj_no(rs.getString("main_proj_no"));
                     eb.ha010m.setTrst_main_proj_no(rs.getString("trst_main_proj_no"));
                     eb.ha010m.setAsst_trnfr_date(rs.getString("asst_trnfr_date"));
                     eb.ha010m.setCnsm_mh(rs.getDouble("cnsm_mh"));
                     eb.ha010m.setBdgt_mh(rs.getDouble("bdgt_mh"));
                     eb.ha010m.setTagt_mh(rs.getDouble("tagt_mh"));
                     eb.ha010m.setProj_sale(rs.getDouble("proj_sale"));
                     eb.ha010m.setProj_bdgt(rs.getDouble("proj_bdgt"));
                     eb.ha010m.setProj_no_rgdt(rs.getString("proj_no_rgdt"));
                     eb.ha010m.setProj_cls_rgdt(rs.getString("proj_cls_rgdt"));
                     eb.ha010m.setProj_po_type(rs.getString("proj_po_type"));
                     eb.ha010m.setCost_cntr(rs.getString("cost_cntr"));
                     eb.ha010m.setCad_unon_aply_indc(rs.getString("cad_unon_aply_indc"));
                     eb.ha010m.setCad_unon_aply_indc_rgdt(rs.getString("cad_unon_aply_indc_rgdt"));
                     eb.ha010m.setCad_unon_aply_emp_no(rs.getString("cad_unon_aply_emp_no"));
            eb.ha010mV.addElement(eb.ha010m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return eb.ha010mV;
} // end selectWhere

/**
* Get Rows CountPage 
* @param 
* @return int 
* @author besTeam 
* @date 2006-5-30
*/
public int countPage(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select COUNT(*) from EB.HA010M  where 1 = 1 " +	whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end countPage

/**
* Get one Record 
* @param String proj_no
* @return HA010MRec 
* @author besTeam 
* @date 2006-5-30
*/
public HA010MRec select(String proj_no) throws Exception{
    HA010MRec eb.ha010m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, PRF_PROJ_INDC, PROJ_NO_GRP, PROJ_DESC_KOR, PROJ_DESC_ENGL, PROD_ORD_NO, PROD_ORD_DATE, PROJ_CLS_DATE, ACCT_CLS_DATE, ACCT_CODE_NPP, SHIP_TYPE, SHIP_KIND, PROJ_ITTV_DIV, PROJ_ITTV_DEPT, PROJ_EXEC_DIV, PROJ_EXEC_DEPT, ACCT_ID_MGNT_PROJ, SHIP_BDTH_ACTL, SHIP_LOA_ACTL, SHIP_DPTH_ACTL, SHIP_LBP_ACTL, SHIP_SPD, STL_NET_WT, GROS_WT, SHIP_DWT_ACTL, SHIP_CAPA_SIZE, SD_PLN, SD_ACTL, SC_DATE_PLN, SC_DATE_ACTL, KL_DATE_PLN, KL_DATE_ACTL, LNCG_DATE_PLN, LNCG_DATE_ACTL, STRL_DATE_PLN, STRL_DATE_ACTL, CMPL_DATE_PLN, CMPL_DATE_ACTL, DLVY_DATE_PLN, DLVY_DATE_ACTL, MAIN_ENGN_EREC_DT_PLN, MAIN_ENGN_EREC_DT_ACTL, MAIN_PROJ_NO, TRST_MAIN_PROJ_NO, ASST_TRNFR_DATE, CNSM_MH, BDGT_MH, TAGT_MH, PROJ_SALE, PROJ_BDGT, PROJ_NO_RGDT, PROJ_CLS_RGDT, PROJ_PO_TYPE, COST_CNTR, CAD_UNON_APLY_INDC, CAD_UNON_APLY_INDC_RGDT, CAD_UNON_APLY_EMP_NO FROM EB.HA010M "

		+ " where proj_no = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,proj_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            eb.ha010m = new HA010MRec(); // HA010MRec Constructor
                     eb.ha010m.setProj_no(rs.getString("proj_no"));
                     eb.ha010m.setPrf_proj_indc(rs.getString("prf_proj_indc"));
                     eb.ha010m.setProj_no_grp(rs.getString("proj_no_grp"));
                     eb.ha010m.setProj_desc_kor(rs.getString("proj_desc_kor"));
                     eb.ha010m.setProj_desc_engl(rs.getString("proj_desc_engl"));
                     eb.ha010m.setProd_ord_no(rs.getString("prod_ord_no"));
                     eb.ha010m.setProd_ord_date(rs.getString("prod_ord_date"));
                     eb.ha010m.setProj_cls_date(rs.getString("proj_cls_date"));
                     eb.ha010m.setAcct_cls_date(rs.getString("acct_cls_date"));
                     eb.ha010m.setAcct_code_npp(rs.getString("acct_code_npp"));
                     eb.ha010m.setShip_type(rs.getString("ship_type"));
                     eb.ha010m.setShip_kind(rs.getString("ship_kind"));
                     eb.ha010m.setProj_ittv_div(rs.getString("proj_ittv_div"));
                     eb.ha010m.setProj_ittv_dept(rs.getString("proj_ittv_dept"));
                     eb.ha010m.setProj_exec_div(rs.getString("proj_exec_div"));
                     eb.ha010m.setProj_exec_dept(rs.getString("proj_exec_dept"));
                     eb.ha010m.setAcct_id_mgnt_proj(rs.getString("acct_id_mgnt_proj"));
                     eb.ha010m.setShip_bdth_actl(rs.getDouble("ship_bdth_actl"));
                     eb.ha010m.setShip_loa_actl(rs.getDouble("ship_loa_actl"));
                     eb.ha010m.setShip_dpth_actl(rs.getDouble("ship_dpth_actl"));
                     eb.ha010m.setShip_lbp_actl(rs.getDouble("ship_lbp_actl"));
                     eb.ha010m.setShip_spd(rs.getDouble("ship_spd"));
                     eb.ha010m.setStl_net_wt(rs.getDouble("stl_net_wt"));
                     eb.ha010m.setGros_wt(rs.getDouble("gros_wt"));
                     eb.ha010m.setShip_dwt_actl(rs.getDouble("ship_dwt_actl"));
                     eb.ha010m.setShip_capa_size(rs.getString("ship_capa_size"));
                     eb.ha010m.setSd_pln(rs.getString("sd_pln"));
                     eb.ha010m.setSd_actl(rs.getString("sd_actl"));
                     eb.ha010m.setSc_date_pln(rs.getString("sc_date_pln"));
                     eb.ha010m.setSc_date_actl(rs.getString("sc_date_actl"));
                     eb.ha010m.setKl_date_pln(rs.getString("kl_date_pln"));
                     eb.ha010m.setKl_date_actl(rs.getString("kl_date_actl"));
                     eb.ha010m.setLncg_date_pln(rs.getString("lncg_date_pln"));
                     eb.ha010m.setLncg_date_actl(rs.getString("lncg_date_actl"));
                     eb.ha010m.setStrl_date_pln(rs.getString("strl_date_pln"));
                     eb.ha010m.setStrl_date_actl(rs.getString("strl_date_actl"));
                     eb.ha010m.setCmpl_date_pln(rs.getString("cmpl_date_pln"));
                     eb.ha010m.setCmpl_date_actl(rs.getString("cmpl_date_actl"));
                     eb.ha010m.setDlvy_date_pln(rs.getString("dlvy_date_pln"));
                     eb.ha010m.setDlvy_date_actl(rs.getString("dlvy_date_actl"));
                     eb.ha010m.setMain_engn_erec_dt_pln(rs.getString("main_engn_erec_dt_pln"));
                     eb.ha010m.setMain_engn_erec_dt_actl(rs.getString("main_engn_erec_dt_actl"));
                     eb.ha010m.setMain_proj_no(rs.getString("main_proj_no"));
                     eb.ha010m.setTrst_main_proj_no(rs.getString("trst_main_proj_no"));
                     eb.ha010m.setAsst_trnfr_date(rs.getString("asst_trnfr_date"));
                     eb.ha010m.setCnsm_mh(rs.getDouble("cnsm_mh"));
                     eb.ha010m.setBdgt_mh(rs.getDouble("bdgt_mh"));
                     eb.ha010m.setTagt_mh(rs.getDouble("tagt_mh"));
                     eb.ha010m.setProj_sale(rs.getDouble("proj_sale"));
                     eb.ha010m.setProj_bdgt(rs.getDouble("proj_bdgt"));
                     eb.ha010m.setProj_no_rgdt(rs.getString("proj_no_rgdt"));
                     eb.ha010m.setProj_cls_rgdt(rs.getString("proj_cls_rgdt"));
                     eb.ha010m.setProj_po_type(rs.getString("proj_po_type"));
                     eb.ha010m.setCost_cntr(rs.getString("cost_cntr"));
                     eb.ha010m.setCad_unon_aply_indc(rs.getString("cad_unon_aply_indc"));
                     eb.ha010m.setCad_unon_aply_indc_rgdt(rs.getString("cad_unon_aply_indc_rgdt"));
                     eb.ha010m.setCad_unon_aply_emp_no(rs.getString("cad_unon_aply_emp_no"));
        } else {
            throw new DataNotFoundException();
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return eb.ha010m;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-30
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector eb.ha010mV = new java.util.Vector();
    HA010MRec eb.ha010m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, PRF_PROJ_INDC, PROJ_NO_GRP, PROJ_DESC_KOR, PROJ_DESC_ENGL, PROD_ORD_NO, PROD_ORD_DATE, PROJ_CLS_DATE, ACCT_CLS_DATE, ACCT_CODE_NPP, SHIP_TYPE, SHIP_KIND, PROJ_ITTV_DIV, PROJ_ITTV_DEPT, PROJ_EXEC_DIV, PROJ_EXEC_DEPT, ACCT_ID_MGNT_PROJ, SHIP_BDTH_ACTL, SHIP_LOA_ACTL, SHIP_DPTH_ACTL, SHIP_LBP_ACTL, SHIP_SPD, STL_NET_WT, GROS_WT, SHIP_DWT_ACTL, SHIP_CAPA_SIZE, SD_PLN, SD_ACTL, SC_DATE_PLN, SC_DATE_ACTL, KL_DATE_PLN, KL_DATE_ACTL, LNCG_DATE_PLN, LNCG_DATE_ACTL, STRL_DATE_PLN, STRL_DATE_ACTL, CMPL_DATE_PLN, CMPL_DATE_ACTL, DLVY_DATE_PLN, DLVY_DATE_ACTL, MAIN_ENGN_EREC_DT_PLN, MAIN_ENGN_EREC_DT_ACTL, MAIN_PROJ_NO, TRST_MAIN_PROJ_NO, ASST_TRNFR_DATE, CNSM_MH, BDGT_MH, TAGT_MH, PROJ_SALE, PROJ_BDGT, PROJ_NO_RGDT, PROJ_CLS_RGDT, PROJ_PO_TYPE, COST_CNTR, CAD_UNON_APLY_INDC, CAD_UNON_APLY_INDC_RGDT, CAD_UNON_APLY_EMP_NO FROM EB.HA010M "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            eb.ha010m = new HA010MRec(); // HA010MRec Constructor
                     eb.ha010m.setProj_no(rs.getString("proj_no"));
                     eb.ha010m.setPrf_proj_indc(rs.getString("prf_proj_indc"));
                     eb.ha010m.setProj_no_grp(rs.getString("proj_no_grp"));
                     eb.ha010m.setProj_desc_kor(rs.getString("proj_desc_kor"));
                     eb.ha010m.setProj_desc_engl(rs.getString("proj_desc_engl"));
                     eb.ha010m.setProd_ord_no(rs.getString("prod_ord_no"));
                     eb.ha010m.setProd_ord_date(rs.getString("prod_ord_date"));
                     eb.ha010m.setProj_cls_date(rs.getString("proj_cls_date"));
                     eb.ha010m.setAcct_cls_date(rs.getString("acct_cls_date"));
                     eb.ha010m.setAcct_code_npp(rs.getString("acct_code_npp"));
                     eb.ha010m.setShip_type(rs.getString("ship_type"));
                     eb.ha010m.setShip_kind(rs.getString("ship_kind"));
                     eb.ha010m.setProj_ittv_div(rs.getString("proj_ittv_div"));
                     eb.ha010m.setProj_ittv_dept(rs.getString("proj_ittv_dept"));
                     eb.ha010m.setProj_exec_div(rs.getString("proj_exec_div"));
                     eb.ha010m.setProj_exec_dept(rs.getString("proj_exec_dept"));
                     eb.ha010m.setAcct_id_mgnt_proj(rs.getString("acct_id_mgnt_proj"));
                     eb.ha010m.setShip_bdth_actl(rs.getDouble("ship_bdth_actl"));
                     eb.ha010m.setShip_loa_actl(rs.getDouble("ship_loa_actl"));
                     eb.ha010m.setShip_dpth_actl(rs.getDouble("ship_dpth_actl"));
                     eb.ha010m.setShip_lbp_actl(rs.getDouble("ship_lbp_actl"));
                     eb.ha010m.setShip_spd(rs.getDouble("ship_spd"));
                     eb.ha010m.setStl_net_wt(rs.getDouble("stl_net_wt"));
                     eb.ha010m.setGros_wt(rs.getDouble("gros_wt"));
                     eb.ha010m.setShip_dwt_actl(rs.getDouble("ship_dwt_actl"));
                     eb.ha010m.setShip_capa_size(rs.getString("ship_capa_size"));
                     eb.ha010m.setSd_pln(rs.getString("sd_pln"));
                     eb.ha010m.setSd_actl(rs.getString("sd_actl"));
                     eb.ha010m.setSc_date_pln(rs.getString("sc_date_pln"));
                     eb.ha010m.setSc_date_actl(rs.getString("sc_date_actl"));
                     eb.ha010m.setKl_date_pln(rs.getString("kl_date_pln"));
                     eb.ha010m.setKl_date_actl(rs.getString("kl_date_actl"));
                     eb.ha010m.setLncg_date_pln(rs.getString("lncg_date_pln"));
                     eb.ha010m.setLncg_date_actl(rs.getString("lncg_date_actl"));
                     eb.ha010m.setStrl_date_pln(rs.getString("strl_date_pln"));
                     eb.ha010m.setStrl_date_actl(rs.getString("strl_date_actl"));
                     eb.ha010m.setCmpl_date_pln(rs.getString("cmpl_date_pln"));
                     eb.ha010m.setCmpl_date_actl(rs.getString("cmpl_date_actl"));
                     eb.ha010m.setDlvy_date_pln(rs.getString("dlvy_date_pln"));
                     eb.ha010m.setDlvy_date_actl(rs.getString("dlvy_date_actl"));
                     eb.ha010m.setMain_engn_erec_dt_pln(rs.getString("main_engn_erec_dt_pln"));
                     eb.ha010m.setMain_engn_erec_dt_actl(rs.getString("main_engn_erec_dt_actl"));
                     eb.ha010m.setMain_proj_no(rs.getString("main_proj_no"));
                     eb.ha010m.setTrst_main_proj_no(rs.getString("trst_main_proj_no"));
                     eb.ha010m.setAsst_trnfr_date(rs.getString("asst_trnfr_date"));
                     eb.ha010m.setCnsm_mh(rs.getDouble("cnsm_mh"));
                     eb.ha010m.setBdgt_mh(rs.getDouble("bdgt_mh"));
                     eb.ha010m.setTagt_mh(rs.getDouble("tagt_mh"));
                     eb.ha010m.setProj_sale(rs.getDouble("proj_sale"));
                     eb.ha010m.setProj_bdgt(rs.getDouble("proj_bdgt"));
                     eb.ha010m.setProj_no_rgdt(rs.getString("proj_no_rgdt"));
                     eb.ha010m.setProj_cls_rgdt(rs.getString("proj_cls_rgdt"));
                     eb.ha010m.setProj_po_type(rs.getString("proj_po_type"));
                     eb.ha010m.setCost_cntr(rs.getString("cost_cntr"));
                     eb.ha010m.setCad_unon_aply_indc(rs.getString("cad_unon_aply_indc"));
                     eb.ha010m.setCad_unon_aply_indc_rgdt(rs.getString("cad_unon_aply_indc_rgdt"));
                     eb.ha010m.setCad_unon_aply_emp_no(rs.getString("cad_unon_aply_emp_no"));
            eb.ha010mV.addElement(eb.ha010m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return eb.ha010mV;
} // end selectAll

/**
* Get selectWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-30
*/
public java.util.Vector selectWhere(String whereOption) throws Exception{
    java.util.Vector eb.ha010mV = new java.util.Vector();
    HA010MRec eb.ha010m = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, PRF_PROJ_INDC, PROJ_NO_GRP, PROJ_DESC_KOR, PROJ_DESC_ENGL, PROD_ORD_NO, PROD_ORD_DATE, PROJ_CLS_DATE, ACCT_CLS_DATE, ACCT_CODE_NPP, SHIP_TYPE, SHIP_KIND, PROJ_ITTV_DIV, PROJ_ITTV_DEPT, PROJ_EXEC_DIV, PROJ_EXEC_DEPT, ACCT_ID_MGNT_PROJ, SHIP_BDTH_ACTL, SHIP_LOA_ACTL, SHIP_DPTH_ACTL, SHIP_LBP_ACTL, SHIP_SPD, STL_NET_WT, GROS_WT, SHIP_DWT_ACTL, SHIP_CAPA_SIZE, SD_PLN, SD_ACTL, SC_DATE_PLN, SC_DATE_ACTL, KL_DATE_PLN, KL_DATE_ACTL, LNCG_DATE_PLN, LNCG_DATE_ACTL, STRL_DATE_PLN, STRL_DATE_ACTL, CMPL_DATE_PLN, CMPL_DATE_ACTL, DLVY_DATE_PLN, DLVY_DATE_ACTL, MAIN_ENGN_EREC_DT_PLN, MAIN_ENGN_EREC_DT_ACTL, MAIN_PROJ_NO, TRST_MAIN_PROJ_NO, ASST_TRNFR_DATE, CNSM_MH, BDGT_MH, TAGT_MH, PROJ_SALE, PROJ_BDGT, PROJ_NO_RGDT, PROJ_CLS_RGDT, PROJ_PO_TYPE, COST_CNTR, CAD_UNON_APLY_INDC, CAD_UNON_APLY_INDC_RGDT, CAD_UNON_APLY_EMP_NO FROM EB.HA010M "

  + whereOption; 
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            eb.ha010m = new HA010MRec(); // HA010MRec Constructor
                     eb.ha010m.setProj_no(rs.getString("proj_no"));
                     eb.ha010m.setPrf_proj_indc(rs.getString("prf_proj_indc"));
                     eb.ha010m.setProj_no_grp(rs.getString("proj_no_grp"));
                     eb.ha010m.setProj_desc_kor(rs.getString("proj_desc_kor"));
                     eb.ha010m.setProj_desc_engl(rs.getString("proj_desc_engl"));
                     eb.ha010m.setProd_ord_no(rs.getString("prod_ord_no"));
                     eb.ha010m.setProd_ord_date(rs.getString("prod_ord_date"));
                     eb.ha010m.setProj_cls_date(rs.getString("proj_cls_date"));
                     eb.ha010m.setAcct_cls_date(rs.getString("acct_cls_date"));
                     eb.ha010m.setAcct_code_npp(rs.getString("acct_code_npp"));
                     eb.ha010m.setShip_type(rs.getString("ship_type"));
                     eb.ha010m.setShip_kind(rs.getString("ship_kind"));
                     eb.ha010m.setProj_ittv_div(rs.getString("proj_ittv_div"));
                     eb.ha010m.setProj_ittv_dept(rs.getString("proj_ittv_dept"));
                     eb.ha010m.setProj_exec_div(rs.getString("proj_exec_div"));
                     eb.ha010m.setProj_exec_dept(rs.getString("proj_exec_dept"));
                     eb.ha010m.setAcct_id_mgnt_proj(rs.getString("acct_id_mgnt_proj"));
                     eb.ha010m.setShip_bdth_actl(rs.getDouble("ship_bdth_actl"));
                     eb.ha010m.setShip_loa_actl(rs.getDouble("ship_loa_actl"));
                     eb.ha010m.setShip_dpth_actl(rs.getDouble("ship_dpth_actl"));
                     eb.ha010m.setShip_lbp_actl(rs.getDouble("ship_lbp_actl"));
                     eb.ha010m.setShip_spd(rs.getDouble("ship_spd"));
                     eb.ha010m.setStl_net_wt(rs.getDouble("stl_net_wt"));
                     eb.ha010m.setGros_wt(rs.getDouble("gros_wt"));
                     eb.ha010m.setShip_dwt_actl(rs.getDouble("ship_dwt_actl"));
                     eb.ha010m.setShip_capa_size(rs.getString("ship_capa_size"));
                     eb.ha010m.setSd_pln(rs.getString("sd_pln"));
                     eb.ha010m.setSd_actl(rs.getString("sd_actl"));
                     eb.ha010m.setSc_date_pln(rs.getString("sc_date_pln"));
                     eb.ha010m.setSc_date_actl(rs.getString("sc_date_actl"));
                     eb.ha010m.setKl_date_pln(rs.getString("kl_date_pln"));
                     eb.ha010m.setKl_date_actl(rs.getString("kl_date_actl"));
                     eb.ha010m.setLncg_date_pln(rs.getString("lncg_date_pln"));
                     eb.ha010m.setLncg_date_actl(rs.getString("lncg_date_actl"));
                     eb.ha010m.setStrl_date_pln(rs.getString("strl_date_pln"));
                     eb.ha010m.setStrl_date_actl(rs.getString("strl_date_actl"));
                     eb.ha010m.setCmpl_date_pln(rs.getString("cmpl_date_pln"));
                     eb.ha010m.setCmpl_date_actl(rs.getString("cmpl_date_actl"));
                     eb.ha010m.setDlvy_date_pln(rs.getString("dlvy_date_pln"));
                     eb.ha010m.setDlvy_date_actl(rs.getString("dlvy_date_actl"));
                     eb.ha010m.setMain_engn_erec_dt_pln(rs.getString("main_engn_erec_dt_pln"));
                     eb.ha010m.setMain_engn_erec_dt_actl(rs.getString("main_engn_erec_dt_actl"));
                     eb.ha010m.setMain_proj_no(rs.getString("main_proj_no"));
                     eb.ha010m.setTrst_main_proj_no(rs.getString("trst_main_proj_no"));
                     eb.ha010m.setAsst_trnfr_date(rs.getString("asst_trnfr_date"));
                     eb.ha010m.setCnsm_mh(rs.getDouble("cnsm_mh"));
                     eb.ha010m.setBdgt_mh(rs.getDouble("bdgt_mh"));
                     eb.ha010m.setTagt_mh(rs.getDouble("tagt_mh"));
                     eb.ha010m.setProj_sale(rs.getDouble("proj_sale"));
                     eb.ha010m.setProj_bdgt(rs.getDouble("proj_bdgt"));
                     eb.ha010m.setProj_no_rgdt(rs.getString("proj_no_rgdt"));
                     eb.ha010m.setProj_cls_rgdt(rs.getString("proj_cls_rgdt"));
                     eb.ha010m.setProj_po_type(rs.getString("proj_po_type"));
                     eb.ha010m.setCost_cntr(rs.getString("cost_cntr"));
                     eb.ha010m.setCad_unon_aply_indc(rs.getString("cad_unon_aply_indc"));
                     eb.ha010m.setCad_unon_aply_indc_rgdt(rs.getString("cad_unon_aply_indc_rgdt"));
                     eb.ha010m.setCad_unon_aply_emp_no(rs.getString("cad_unon_aply_emp_no"));
            eb.ha010mV.addElement(eb.ha010m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return eb.ha010mV;
} // end selectAll

/**
* Select Data Over the key value(s) and default return count(20) 
* @param String proj_no
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-30
*/
public java.util.Vector selectOver(String proj_no) throws Exception{
return selectOver(proj_no,20) ;
}// end selectOver
/**
* Select Data Over(Next) the key value(s) and return record count 
* @param String proj_no, int 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-30
*/
public java.util.Vector selectOver(String proj_no, int page) throws Exception{
    java.util.Vector eb.ha010mV = new java.util.Vector();
    HA010MRec eb.ha010m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, PRF_PROJ_INDC, PROJ_NO_GRP, PROJ_DESC_KOR, PROJ_DESC_ENGL, PROD_ORD_NO, PROD_ORD_DATE, PROJ_CLS_DATE, ACCT_CLS_DATE, ACCT_CODE_NPP, SHIP_TYPE, SHIP_KIND, PROJ_ITTV_DIV, PROJ_ITTV_DEPT, PROJ_EXEC_DIV, PROJ_EXEC_DEPT, ACCT_ID_MGNT_PROJ, SHIP_BDTH_ACTL, SHIP_LOA_ACTL, SHIP_DPTH_ACTL, SHIP_LBP_ACTL, SHIP_SPD, STL_NET_WT, GROS_WT, SHIP_DWT_ACTL, SHIP_CAPA_SIZE, SD_PLN, SD_ACTL, SC_DATE_PLN, SC_DATE_ACTL, KL_DATE_PLN, KL_DATE_ACTL, LNCG_DATE_PLN, LNCG_DATE_ACTL, STRL_DATE_PLN, STRL_DATE_ACTL, CMPL_DATE_PLN, CMPL_DATE_ACTL, DLVY_DATE_PLN, DLVY_DATE_ACTL, MAIN_ENGN_EREC_DT_PLN, MAIN_ENGN_EREC_DT_ACTL, MAIN_PROJ_NO, TRST_MAIN_PROJ_NO, ASST_TRNFR_DATE, CNSM_MH, BDGT_MH, TAGT_MH, PROJ_SALE, PROJ_BDGT, PROJ_NO_RGDT, PROJ_CLS_RGDT, PROJ_PO_TYPE, COST_CNTR, CAD_UNON_APLY_INDC, CAD_UNON_APLY_INDC_RGDT, CAD_UNON_APLY_EMP_NO FROM EB.HA010M "

		+ " where proj_no >= ? order by proj_no "; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,proj_no); 
        rs = pstmt.executeQuery();
        int count = 0;//??f??? SQL?????? Limit??? ????...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            eb.ha010m = new HA010MRec(); // HA010MRec Constructor
                     eb.ha010m.setProj_no(rs.getString("proj_no"));
                     eb.ha010m.setPrf_proj_indc(rs.getString("prf_proj_indc"));
                     eb.ha010m.setProj_no_grp(rs.getString("proj_no_grp"));
                     eb.ha010m.setProj_desc_kor(rs.getString("proj_desc_kor"));
                     eb.ha010m.setProj_desc_engl(rs.getString("proj_desc_engl"));
                     eb.ha010m.setProd_ord_no(rs.getString("prod_ord_no"));
                     eb.ha010m.setProd_ord_date(rs.getString("prod_ord_date"));
                     eb.ha010m.setProj_cls_date(rs.getString("proj_cls_date"));
                     eb.ha010m.setAcct_cls_date(rs.getString("acct_cls_date"));
                     eb.ha010m.setAcct_code_npp(rs.getString("acct_code_npp"));
                     eb.ha010m.setShip_type(rs.getString("ship_type"));
                     eb.ha010m.setShip_kind(rs.getString("ship_kind"));
                     eb.ha010m.setProj_ittv_div(rs.getString("proj_ittv_div"));
                     eb.ha010m.setProj_ittv_dept(rs.getString("proj_ittv_dept"));
                     eb.ha010m.setProj_exec_div(rs.getString("proj_exec_div"));
                     eb.ha010m.setProj_exec_dept(rs.getString("proj_exec_dept"));
                     eb.ha010m.setAcct_id_mgnt_proj(rs.getString("acct_id_mgnt_proj"));
                     eb.ha010m.setShip_bdth_actl(rs.getDouble("ship_bdth_actl"));
                     eb.ha010m.setShip_loa_actl(rs.getDouble("ship_loa_actl"));
                     eb.ha010m.setShip_dpth_actl(rs.getDouble("ship_dpth_actl"));
                     eb.ha010m.setShip_lbp_actl(rs.getDouble("ship_lbp_actl"));
                     eb.ha010m.setShip_spd(rs.getDouble("ship_spd"));
                     eb.ha010m.setStl_net_wt(rs.getDouble("stl_net_wt"));
                     eb.ha010m.setGros_wt(rs.getDouble("gros_wt"));
                     eb.ha010m.setShip_dwt_actl(rs.getDouble("ship_dwt_actl"));
                     eb.ha010m.setShip_capa_size(rs.getString("ship_capa_size"));
                     eb.ha010m.setSd_pln(rs.getString("sd_pln"));
                     eb.ha010m.setSd_actl(rs.getString("sd_actl"));
                     eb.ha010m.setSc_date_pln(rs.getString("sc_date_pln"));
                     eb.ha010m.setSc_date_actl(rs.getString("sc_date_actl"));
                     eb.ha010m.setKl_date_pln(rs.getString("kl_date_pln"));
                     eb.ha010m.setKl_date_actl(rs.getString("kl_date_actl"));
                     eb.ha010m.setLncg_date_pln(rs.getString("lncg_date_pln"));
                     eb.ha010m.setLncg_date_actl(rs.getString("lncg_date_actl"));
                     eb.ha010m.setStrl_date_pln(rs.getString("strl_date_pln"));
                     eb.ha010m.setStrl_date_actl(rs.getString("strl_date_actl"));
                     eb.ha010m.setCmpl_date_pln(rs.getString("cmpl_date_pln"));
                     eb.ha010m.setCmpl_date_actl(rs.getString("cmpl_date_actl"));
                     eb.ha010m.setDlvy_date_pln(rs.getString("dlvy_date_pln"));
                     eb.ha010m.setDlvy_date_actl(rs.getString("dlvy_date_actl"));
                     eb.ha010m.setMain_engn_erec_dt_pln(rs.getString("main_engn_erec_dt_pln"));
                     eb.ha010m.setMain_engn_erec_dt_actl(rs.getString("main_engn_erec_dt_actl"));
                     eb.ha010m.setMain_proj_no(rs.getString("main_proj_no"));
                     eb.ha010m.setTrst_main_proj_no(rs.getString("trst_main_proj_no"));
                     eb.ha010m.setAsst_trnfr_date(rs.getString("asst_trnfr_date"));
                     eb.ha010m.setCnsm_mh(rs.getDouble("cnsm_mh"));
                     eb.ha010m.setBdgt_mh(rs.getDouble("bdgt_mh"));
                     eb.ha010m.setTagt_mh(rs.getDouble("tagt_mh"));
                     eb.ha010m.setProj_sale(rs.getDouble("proj_sale"));
                     eb.ha010m.setProj_bdgt(rs.getDouble("proj_bdgt"));
                     eb.ha010m.setProj_no_rgdt(rs.getString("proj_no_rgdt"));
                     eb.ha010m.setProj_cls_rgdt(rs.getString("proj_cls_rgdt"));
                     eb.ha010m.setProj_po_type(rs.getString("proj_po_type"));
                     eb.ha010m.setCost_cntr(rs.getString("cost_cntr"));
                     eb.ha010m.setCad_unon_aply_indc(rs.getString("cad_unon_aply_indc"));
                     eb.ha010m.setCad_unon_aply_indc_rgdt(rs.getString("cad_unon_aply_indc_rgdt"));
                     eb.ha010m.setCad_unon_aply_emp_no(rs.getString("cad_unon_aply_emp_no"));
            eb.ha010mV.addElement(eb.ha010m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return eb.ha010mV;
} // end selectOver

/**
* Select Data Under(Previous) the key value(s) and default return count(20) 
* @param String proj_no
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-30
*/
public java.util.Vector selectUnder(String proj_no) throws Exception{
return selectUnder(proj_no,20) ;
}// end selectUnder
/**
* Select Data Under(Previous) the key value(s) and return record count 
* @param String proj_no, int
* @return java.util.Vector
* @author besTeam 
* @date 2006-5-30
*/
public java.util.Vector selectUnder(String proj_no, int page) throws Exception{
    java.util.Vector eb.ha010mV = new java.util.Vector();
    HA010MRec eb.ha010m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, PRF_PROJ_INDC, PROJ_NO_GRP, PROJ_DESC_KOR, PROJ_DESC_ENGL, PROD_ORD_NO, PROD_ORD_DATE, PROJ_CLS_DATE, ACCT_CLS_DATE, ACCT_CODE_NPP, SHIP_TYPE, SHIP_KIND, PROJ_ITTV_DIV, PROJ_ITTV_DEPT, PROJ_EXEC_DIV, PROJ_EXEC_DEPT, ACCT_ID_MGNT_PROJ, SHIP_BDTH_ACTL, SHIP_LOA_ACTL, SHIP_DPTH_ACTL, SHIP_LBP_ACTL, SHIP_SPD, STL_NET_WT, GROS_WT, SHIP_DWT_ACTL, SHIP_CAPA_SIZE, SD_PLN, SD_ACTL, SC_DATE_PLN, SC_DATE_ACTL, KL_DATE_PLN, KL_DATE_ACTL, LNCG_DATE_PLN, LNCG_DATE_ACTL, STRL_DATE_PLN, STRL_DATE_ACTL, CMPL_DATE_PLN, CMPL_DATE_ACTL, DLVY_DATE_PLN, DLVY_DATE_ACTL, MAIN_ENGN_EREC_DT_PLN, MAIN_ENGN_EREC_DT_ACTL, MAIN_PROJ_NO, TRST_MAIN_PROJ_NO, ASST_TRNFR_DATE, CNSM_MH, BDGT_MH, TAGT_MH, PROJ_SALE, PROJ_BDGT, PROJ_NO_RGDT, PROJ_CLS_RGDT, PROJ_PO_TYPE, COST_CNTR, CAD_UNON_APLY_INDC, CAD_UNON_APLY_INDC_RGDT, CAD_UNON_APLY_EMP_NO FROM EB.HA010M "

		+ " where proj_no <= ? order by proj_no desc" ; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,proj_no); 
        rs = pstmt.executeQuery();
        int count = 0;//??f??? SQL?????? Limit??? ????...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            eb.ha010m = new HA010MRec(); // HA010MRec Constructor
                     eb.ha010m.setProj_no(rs.getString("proj_no"));
                     eb.ha010m.setPrf_proj_indc(rs.getString("prf_proj_indc"));
                     eb.ha010m.setProj_no_grp(rs.getString("proj_no_grp"));
                     eb.ha010m.setProj_desc_kor(rs.getString("proj_desc_kor"));
                     eb.ha010m.setProj_desc_engl(rs.getString("proj_desc_engl"));
                     eb.ha010m.setProd_ord_no(rs.getString("prod_ord_no"));
                     eb.ha010m.setProd_ord_date(rs.getString("prod_ord_date"));
                     eb.ha010m.setProj_cls_date(rs.getString("proj_cls_date"));
                     eb.ha010m.setAcct_cls_date(rs.getString("acct_cls_date"));
                     eb.ha010m.setAcct_code_npp(rs.getString("acct_code_npp"));
                     eb.ha010m.setShip_type(rs.getString("ship_type"));
                     eb.ha010m.setShip_kind(rs.getString("ship_kind"));
                     eb.ha010m.setProj_ittv_div(rs.getString("proj_ittv_div"));
                     eb.ha010m.setProj_ittv_dept(rs.getString("proj_ittv_dept"));
                     eb.ha010m.setProj_exec_div(rs.getString("proj_exec_div"));
                     eb.ha010m.setProj_exec_dept(rs.getString("proj_exec_dept"));
                     eb.ha010m.setAcct_id_mgnt_proj(rs.getString("acct_id_mgnt_proj"));
                     eb.ha010m.setShip_bdth_actl(rs.getDouble("ship_bdth_actl"));
                     eb.ha010m.setShip_loa_actl(rs.getDouble("ship_loa_actl"));
                     eb.ha010m.setShip_dpth_actl(rs.getDouble("ship_dpth_actl"));
                     eb.ha010m.setShip_lbp_actl(rs.getDouble("ship_lbp_actl"));
                     eb.ha010m.setShip_spd(rs.getDouble("ship_spd"));
                     eb.ha010m.setStl_net_wt(rs.getDouble("stl_net_wt"));
                     eb.ha010m.setGros_wt(rs.getDouble("gros_wt"));
                     eb.ha010m.setShip_dwt_actl(rs.getDouble("ship_dwt_actl"));
                     eb.ha010m.setShip_capa_size(rs.getString("ship_capa_size"));
                     eb.ha010m.setSd_pln(rs.getString("sd_pln"));
                     eb.ha010m.setSd_actl(rs.getString("sd_actl"));
                     eb.ha010m.setSc_date_pln(rs.getString("sc_date_pln"));
                     eb.ha010m.setSc_date_actl(rs.getString("sc_date_actl"));
                     eb.ha010m.setKl_date_pln(rs.getString("kl_date_pln"));
                     eb.ha010m.setKl_date_actl(rs.getString("kl_date_actl"));
                     eb.ha010m.setLncg_date_pln(rs.getString("lncg_date_pln"));
                     eb.ha010m.setLncg_date_actl(rs.getString("lncg_date_actl"));
                     eb.ha010m.setStrl_date_pln(rs.getString("strl_date_pln"));
                     eb.ha010m.setStrl_date_actl(rs.getString("strl_date_actl"));
                     eb.ha010m.setCmpl_date_pln(rs.getString("cmpl_date_pln"));
                     eb.ha010m.setCmpl_date_actl(rs.getString("cmpl_date_actl"));
                     eb.ha010m.setDlvy_date_pln(rs.getString("dlvy_date_pln"));
                     eb.ha010m.setDlvy_date_actl(rs.getString("dlvy_date_actl"));
                     eb.ha010m.setMain_engn_erec_dt_pln(rs.getString("main_engn_erec_dt_pln"));
                     eb.ha010m.setMain_engn_erec_dt_actl(rs.getString("main_engn_erec_dt_actl"));
                     eb.ha010m.setMain_proj_no(rs.getString("main_proj_no"));
                     eb.ha010m.setTrst_main_proj_no(rs.getString("trst_main_proj_no"));
                     eb.ha010m.setAsst_trnfr_date(rs.getString("asst_trnfr_date"));
                     eb.ha010m.setCnsm_mh(rs.getDouble("cnsm_mh"));
                     eb.ha010m.setBdgt_mh(rs.getDouble("bdgt_mh"));
                     eb.ha010m.setTagt_mh(rs.getDouble("tagt_mh"));
                     eb.ha010m.setProj_sale(rs.getDouble("proj_sale"));
                     eb.ha010m.setProj_bdgt(rs.getDouble("proj_bdgt"));
                     eb.ha010m.setProj_no_rgdt(rs.getString("proj_no_rgdt"));
                     eb.ha010m.setProj_cls_rgdt(rs.getString("proj_cls_rgdt"));
                     eb.ha010m.setProj_po_type(rs.getString("proj_po_type"));
                     eb.ha010m.setCost_cntr(rs.getString("cost_cntr"));
                     eb.ha010m.setCad_unon_aply_indc(rs.getString("cad_unon_aply_indc"));
                     eb.ha010m.setCad_unon_aply_indc_rgdt(rs.getString("cad_unon_aply_indc_rgdt"));
                     eb.ha010m.setCad_unon_aply_emp_no(rs.getString("cad_unon_aply_emp_no"));
            eb.ha010mV.add(0,eb.ha010m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return eb.ha010mV;
} // end selectUnder
/**
* Get Rows Count 
* @param String proj_no
* @return int 
* @author besTeam 
* @date 2006-5-30
*/
public int count(String proj_no) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " EB.HA010M "

		+ " where proj_no = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,proj_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param void 
* @return int 
* @author besTeam 
* @date 2006-5-30
*/
public int count() throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " EB.HA010M "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}// end HA010MDBWrapBES class