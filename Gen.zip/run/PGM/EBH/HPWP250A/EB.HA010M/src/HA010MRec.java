package com.bes_line.mst.EBH ;

// Entity Class for EB.HA010M
/**
 *
 * @(#) HA010MRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-30
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class HA010MRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String proj_no; 		// (VARCHAR2, 12.0)
    public String prf_proj_indc; 		// (CHAR, 1.0)
    public String proj_no_grp; 		// (CHAR, 2.0)
    public String proj_desc_kor; 		// (VARCHAR2, 60.0)
    public String proj_desc_engl; 		// (VARCHAR2, 60.0)
    public String prod_ord_no; 		// (CHAR, 8.0)
    public String prod_ord_date; 		// (CHAR, 8.0)
    public String proj_cls_date; 		// (CHAR, 8.0)
    public String acct_cls_date; 		// (CHAR, 8.0)
    public String acct_code_npp; 		// (CHAR, 2.0)
    public String ship_type; 		// (CHAR, 5.0)
    public String ship_kind; 		// (CHAR, 5.0)
    public String proj_ittv_div; 		// (CHAR, 4.0)
    public String proj_ittv_dept; 		// (CHAR, 4.0)
    public String proj_exec_div; 		// (CHAR, 4.0)
    public String proj_exec_dept; 		// (CHAR, 4.0)
    public String acct_id_mgnt_proj; 		// (CHAR, 4.0)
    public double ship_bdth_actl; 		// (NUMBER, 8.4)
    public double ship_loa_actl; 		// (NUMBER, 8.4)
    public double ship_dpth_actl; 		// (NUMBER, 8.4)
    public double ship_lbp_actl; 		// (NUMBER, 8.4)
    public double ship_spd; 		// (NUMBER, 5.2)
    public double stl_net_wt; 		// (NUMBER, 12.2)
    public double gros_wt; 		// (NUMBER, 12.2)
    public double ship_dwt_actl; 		// (NUMBER, 12.2)
    public String ship_capa_size; 		// (VARCHAR2, 30.0)
    public String sd_pln; 		// (CHAR, 8.0)
    public String sd_actl; 		// (CHAR, 8.0)
    public String sc_date_pln; 		// (CHAR, 8.0)
    public String sc_date_actl; 		// (CHAR, 8.0)
    public String kl_date_pln; 		// (CHAR, 8.0)
    public String kl_date_actl; 		// (CHAR, 8.0)
    public String lncg_date_pln; 		// (CHAR, 8.0)
    public String lncg_date_actl; 		// (CHAR, 8.0)
    public String strl_date_pln; 		// (CHAR, 8.0)
    public String strl_date_actl; 		// (CHAR, 8.0)
    public String cmpl_date_pln; 		// (CHAR, 8.0)
    public String cmpl_date_actl; 		// (CHAR, 8.0)
    public String dlvy_date_pln; 		// (CHAR, 8.0)
    public String dlvy_date_actl; 		// (CHAR, 8.0)
    public String main_engn_erec_dt_pln; 		// (CHAR, 8.0)
    public String main_engn_erec_dt_actl; 		// (CHAR, 8.0)
    public String main_proj_no; 		// (VARCHAR2, 12.0)
    public String trst_main_proj_no; 		// (CHAR, 8.0)
    public String asst_trnfr_date; 		// (CHAR, 8.0)
    public double cnsm_mh; 		// (NUMBER, 14.2)
    public double bdgt_mh; 		// (NUMBER, 14.2)
    public double tagt_mh; 		// (NUMBER, 14.2)
    public double proj_sale; 		// (NUMBER, 20.2)
    public double proj_bdgt; 		// (NUMBER, 20.2)
    public String proj_no_rgdt; 		// (CHAR, 8.0)
    public String proj_cls_rgdt; 		// (CHAR, 8.0)
    public String proj_po_type; 		// (CHAR, 1.0)
    public String cost_cntr; 		// (CHAR, 4.0)
    public String cad_unon_aply_indc; 		// (CHAR, 1.0)
    public String cad_unon_aply_indc_rgdt; 		// (VARCHAR2, 12.0)
    public String cad_unon_aply_emp_no; 		// (VARCHAR2, 11.0)

public HA010MRec(){ } // default constructor

public HA010MRec(
       String proj_no, String prf_proj_indc, String proj_no_grp, String proj_desc_kor, String proj_desc_engl, String prod_ord_no, 
       String prod_ord_date, String proj_cls_date, String acct_cls_date, String acct_code_npp, String ship_type, String ship_kind, 
       String proj_ittv_div, String proj_ittv_dept, String proj_exec_div, String proj_exec_dept, String acct_id_mgnt_proj, double ship_bdth_actl, 
       double ship_loa_actl, double ship_dpth_actl, double ship_lbp_actl, double ship_spd, double stl_net_wt, double gros_wt, 
       double ship_dwt_actl, String ship_capa_size, String sd_pln, String sd_actl, String sc_date_pln, String sc_date_actl, 
       String kl_date_pln, String kl_date_actl, String lncg_date_pln, String lncg_date_actl, String strl_date_pln, String strl_date_actl, 
       String cmpl_date_pln, String cmpl_date_actl, String dlvy_date_pln, String dlvy_date_actl, String main_engn_erec_dt_pln, String main_engn_erec_dt_actl, 
       String main_proj_no, String trst_main_proj_no, String asst_trnfr_date, double cnsm_mh, double bdgt_mh, double tagt_mh, 
       double proj_sale, double proj_bdgt, String proj_no_rgdt, String proj_cls_rgdt, String proj_po_type, String cost_cntr, 
       String cad_unon_aply_indc, String cad_unon_aply_indc_rgdt, String cad_unon_aply_emp_no){
    this.proj_no = proj_no;
    this.prf_proj_indc = prf_proj_indc;
    this.proj_no_grp = proj_no_grp;
    this.proj_desc_kor = proj_desc_kor;
    this.proj_desc_engl = proj_desc_engl;
    this.prod_ord_no = prod_ord_no;
    this.prod_ord_date = prod_ord_date;
    this.proj_cls_date = proj_cls_date;
    this.acct_cls_date = acct_cls_date;
    this.acct_code_npp = acct_code_npp;
    this.ship_type = ship_type;
    this.ship_kind = ship_kind;
    this.proj_ittv_div = proj_ittv_div;
    this.proj_ittv_dept = proj_ittv_dept;
    this.proj_exec_div = proj_exec_div;
    this.proj_exec_dept = proj_exec_dept;
    this.acct_id_mgnt_proj = acct_id_mgnt_proj;
    this.ship_bdth_actl = ship_bdth_actl;
    this.ship_loa_actl = ship_loa_actl;
    this.ship_dpth_actl = ship_dpth_actl;
    this.ship_lbp_actl = ship_lbp_actl;
    this.ship_spd = ship_spd;
    this.stl_net_wt = stl_net_wt;
    this.gros_wt = gros_wt;
    this.ship_dwt_actl = ship_dwt_actl;
    this.ship_capa_size = ship_capa_size;
    this.sd_pln = sd_pln;
    this.sd_actl = sd_actl;
    this.sc_date_pln = sc_date_pln;
    this.sc_date_actl = sc_date_actl;
    this.kl_date_pln = kl_date_pln;
    this.kl_date_actl = kl_date_actl;
    this.lncg_date_pln = lncg_date_pln;
    this.lncg_date_actl = lncg_date_actl;
    this.strl_date_pln = strl_date_pln;
    this.strl_date_actl = strl_date_actl;
    this.cmpl_date_pln = cmpl_date_pln;
    this.cmpl_date_actl = cmpl_date_actl;
    this.dlvy_date_pln = dlvy_date_pln;
    this.dlvy_date_actl = dlvy_date_actl;
    this.main_engn_erec_dt_pln = main_engn_erec_dt_pln;
    this.main_engn_erec_dt_actl = main_engn_erec_dt_actl;
    this.main_proj_no = main_proj_no;
    this.trst_main_proj_no = trst_main_proj_no;
    this.asst_trnfr_date = asst_trnfr_date;
    this.cnsm_mh = cnsm_mh;
    this.bdgt_mh = bdgt_mh;
    this.tagt_mh = tagt_mh;
    this.proj_sale = proj_sale;
    this.proj_bdgt = proj_bdgt;
    this.proj_no_rgdt = proj_no_rgdt;
    this.proj_cls_rgdt = proj_cls_rgdt;
    this.proj_po_type = proj_po_type;
    this.cost_cntr = cost_cntr;
    this.cad_unon_aply_indc = cad_unon_aply_indc;
    this.cad_unon_aply_indc_rgdt = cad_unon_aply_indc_rgdt;
    this.cad_unon_aply_emp_no = cad_unon_aply_emp_no;
} // Constructor


// Getter 
public String getProj_no(){ return proj_no;}
public String getPrf_proj_indc(){ return prf_proj_indc;}
public String getProj_no_grp(){ return proj_no_grp;}
public String getProj_desc_kor(){ return proj_desc_kor;}
public String getProj_desc_engl(){ return proj_desc_engl;}
public String getProd_ord_no(){ return prod_ord_no;}
public String getProd_ord_date(){ return prod_ord_date;}
public String getProj_cls_date(){ return proj_cls_date;}
public String getAcct_cls_date(){ return acct_cls_date;}
public String getAcct_code_npp(){ return acct_code_npp;}
public String getShip_type(){ return ship_type;}
public String getShip_kind(){ return ship_kind;}
public String getProj_ittv_div(){ return proj_ittv_div;}
public String getProj_ittv_dept(){ return proj_ittv_dept;}
public String getProj_exec_div(){ return proj_exec_div;}
public String getProj_exec_dept(){ return proj_exec_dept;}
public String getAcct_id_mgnt_proj(){ return acct_id_mgnt_proj;}
public double getShip_bdth_actl(){ return ship_bdth_actl;}
public double getShip_loa_actl(){ return ship_loa_actl;}
public double getShip_dpth_actl(){ return ship_dpth_actl;}
public double getShip_lbp_actl(){ return ship_lbp_actl;}
public double getShip_spd(){ return ship_spd;}
public double getStl_net_wt(){ return stl_net_wt;}
public double getGros_wt(){ return gros_wt;}
public double getShip_dwt_actl(){ return ship_dwt_actl;}
public String getShip_capa_size(){ return ship_capa_size;}
public String getSd_pln(){ return sd_pln;}
public String getSd_actl(){ return sd_actl;}
public String getSc_date_pln(){ return sc_date_pln;}
public String getSc_date_actl(){ return sc_date_actl;}
public String getKl_date_pln(){ return kl_date_pln;}
public String getKl_date_actl(){ return kl_date_actl;}
public String getLncg_date_pln(){ return lncg_date_pln;}
public String getLncg_date_actl(){ return lncg_date_actl;}
public String getStrl_date_pln(){ return strl_date_pln;}
public String getStrl_date_actl(){ return strl_date_actl;}
public String getCmpl_date_pln(){ return cmpl_date_pln;}
public String getCmpl_date_actl(){ return cmpl_date_actl;}
public String getDlvy_date_pln(){ return dlvy_date_pln;}
public String getDlvy_date_actl(){ return dlvy_date_actl;}
public String getMain_engn_erec_dt_pln(){ return main_engn_erec_dt_pln;}
public String getMain_engn_erec_dt_actl(){ return main_engn_erec_dt_actl;}
public String getMain_proj_no(){ return main_proj_no;}
public String getTrst_main_proj_no(){ return trst_main_proj_no;}
public String getAsst_trnfr_date(){ return asst_trnfr_date;}
public double getCnsm_mh(){ return cnsm_mh;}
public double getBdgt_mh(){ return bdgt_mh;}
public double getTagt_mh(){ return tagt_mh;}
public double getProj_sale(){ return proj_sale;}
public double getProj_bdgt(){ return proj_bdgt;}
public String getProj_no_rgdt(){ return proj_no_rgdt;}
public String getProj_cls_rgdt(){ return proj_cls_rgdt;}
public String getProj_po_type(){ return proj_po_type;}
public String getCost_cntr(){ return cost_cntr;}
public String getCad_unon_aply_indc(){ return cad_unon_aply_indc;}
public String getCad_unon_aply_indc_rgdt(){ return cad_unon_aply_indc_rgdt;}
public String getCad_unon_aply_emp_no(){ return cad_unon_aply_emp_no;}

// Setter 
public void setProj_no(String proj_no){ this.proj_no = proj_no;}
public void setPrf_proj_indc(String prf_proj_indc){ this.prf_proj_indc = prf_proj_indc;}
public void setProj_no_grp(String proj_no_grp){ this.proj_no_grp = proj_no_grp;}
public void setProj_desc_kor(String proj_desc_kor){ this.proj_desc_kor = proj_desc_kor;}
public void setProj_desc_engl(String proj_desc_engl){ this.proj_desc_engl = proj_desc_engl;}
public void setProd_ord_no(String prod_ord_no){ this.prod_ord_no = prod_ord_no;}
public void setProd_ord_date(String prod_ord_date){ this.prod_ord_date = prod_ord_date;}
public void setProj_cls_date(String proj_cls_date){ this.proj_cls_date = proj_cls_date;}
public void setAcct_cls_date(String acct_cls_date){ this.acct_cls_date = acct_cls_date;}
public void setAcct_code_npp(String acct_code_npp){ this.acct_code_npp = acct_code_npp;}
public void setShip_type(String ship_type){ this.ship_type = ship_type;}
public void setShip_kind(String ship_kind){ this.ship_kind = ship_kind;}
public void setProj_ittv_div(String proj_ittv_div){ this.proj_ittv_div = proj_ittv_div;}
public void setProj_ittv_dept(String proj_ittv_dept){ this.proj_ittv_dept = proj_ittv_dept;}
public void setProj_exec_div(String proj_exec_div){ this.proj_exec_div = proj_exec_div;}
public void setProj_exec_dept(String proj_exec_dept){ this.proj_exec_dept = proj_exec_dept;}
public void setAcct_id_mgnt_proj(String acct_id_mgnt_proj){ this.acct_id_mgnt_proj = acct_id_mgnt_proj;}
public void setShip_bdth_actl(double ship_bdth_actl){ this.ship_bdth_actl = ship_bdth_actl;}
public void setShip_loa_actl(double ship_loa_actl){ this.ship_loa_actl = ship_loa_actl;}
public void setShip_dpth_actl(double ship_dpth_actl){ this.ship_dpth_actl = ship_dpth_actl;}
public void setShip_lbp_actl(double ship_lbp_actl){ this.ship_lbp_actl = ship_lbp_actl;}
public void setShip_spd(double ship_spd){ this.ship_spd = ship_spd;}
public void setStl_net_wt(double stl_net_wt){ this.stl_net_wt = stl_net_wt;}
public void setGros_wt(double gros_wt){ this.gros_wt = gros_wt;}
public void setShip_dwt_actl(double ship_dwt_actl){ this.ship_dwt_actl = ship_dwt_actl;}
public void setShip_capa_size(String ship_capa_size){ this.ship_capa_size = ship_capa_size;}
public void setSd_pln(String sd_pln){ this.sd_pln = sd_pln;}
public void setSd_actl(String sd_actl){ this.sd_actl = sd_actl;}
public void setSc_date_pln(String sc_date_pln){ this.sc_date_pln = sc_date_pln;}
public void setSc_date_actl(String sc_date_actl){ this.sc_date_actl = sc_date_actl;}
public void setKl_date_pln(String kl_date_pln){ this.kl_date_pln = kl_date_pln;}
public void setKl_date_actl(String kl_date_actl){ this.kl_date_actl = kl_date_actl;}
public void setLncg_date_pln(String lncg_date_pln){ this.lncg_date_pln = lncg_date_pln;}
public void setLncg_date_actl(String lncg_date_actl){ this.lncg_date_actl = lncg_date_actl;}
public void setStrl_date_pln(String strl_date_pln){ this.strl_date_pln = strl_date_pln;}
public void setStrl_date_actl(String strl_date_actl){ this.strl_date_actl = strl_date_actl;}
public void setCmpl_date_pln(String cmpl_date_pln){ this.cmpl_date_pln = cmpl_date_pln;}
public void setCmpl_date_actl(String cmpl_date_actl){ this.cmpl_date_actl = cmpl_date_actl;}
public void setDlvy_date_pln(String dlvy_date_pln){ this.dlvy_date_pln = dlvy_date_pln;}
public void setDlvy_date_actl(String dlvy_date_actl){ this.dlvy_date_actl = dlvy_date_actl;}
public void setMain_engn_erec_dt_pln(String main_engn_erec_dt_pln){ this.main_engn_erec_dt_pln = main_engn_erec_dt_pln;}
public void setMain_engn_erec_dt_actl(String main_engn_erec_dt_actl){ this.main_engn_erec_dt_actl = main_engn_erec_dt_actl;}
public void setMain_proj_no(String main_proj_no){ this.main_proj_no = main_proj_no;}
public void setTrst_main_proj_no(String trst_main_proj_no){ this.trst_main_proj_no = trst_main_proj_no;}
public void setAsst_trnfr_date(String asst_trnfr_date){ this.asst_trnfr_date = asst_trnfr_date;}
public void setCnsm_mh(double cnsm_mh){ this.cnsm_mh = cnsm_mh;}
public void setBdgt_mh(double bdgt_mh){ this.bdgt_mh = bdgt_mh;}
public void setTagt_mh(double tagt_mh){ this.tagt_mh = tagt_mh;}
public void setProj_sale(double proj_sale){ this.proj_sale = proj_sale;}
public void setProj_bdgt(double proj_bdgt){ this.proj_bdgt = proj_bdgt;}
public void setProj_no_rgdt(String proj_no_rgdt){ this.proj_no_rgdt = proj_no_rgdt;}
public void setProj_cls_rgdt(String proj_cls_rgdt){ this.proj_cls_rgdt = proj_cls_rgdt;}
public void setProj_po_type(String proj_po_type){ this.proj_po_type = proj_po_type;}
public void setCost_cntr(String cost_cntr){ this.cost_cntr = cost_cntr;}
public void setCad_unon_aply_indc(String cad_unon_aply_indc){ this.cad_unon_aply_indc = cad_unon_aply_indc;}
public void setCad_unon_aply_indc_rgdt(String cad_unon_aply_indc_rgdt){ this.cad_unon_aply_indc_rgdt = cad_unon_aply_indc_rgdt;}
public void setCad_unon_aply_emp_no(String cad_unon_aply_emp_no){ this.cad_unon_aply_emp_no = cad_unon_aply_emp_no;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = proj_no + "" ; break;
  case  2 : field = prf_proj_indc + "" ; break;
  case  3 : field = proj_no_grp + "" ; break;
  case  4 : field = proj_desc_kor + "" ; break;
  case  5 : field = proj_desc_engl + "" ; break;
  case  6 : field = prod_ord_no + "" ; break;
  case  7 : field = prod_ord_date + "" ; break;
  case  8 : field = proj_cls_date + "" ; break;
  case  9 : field = acct_cls_date + "" ; break;
  case  10 : field = acct_code_npp + "" ; break;
  case  11 : field = ship_type + "" ; break;
  case  12 : field = ship_kind + "" ; break;
  case  13 : field = proj_ittv_div + "" ; break;
  case  14 : field = proj_ittv_dept + "" ; break;
  case  15 : field = proj_exec_div + "" ; break;
  case  16 : field = proj_exec_dept + "" ; break;
  case  17 : field = acct_id_mgnt_proj + "" ; break;
  case  18 : field = ship_bdth_actl + "" ; break;
  case  19 : field = ship_loa_actl + "" ; break;
  case  20 : field = ship_dpth_actl + "" ; break;
  case  21 : field = ship_lbp_actl + "" ; break;
  case  22 : field = ship_spd + "" ; break;
  case  23 : field = stl_net_wt + "" ; break;
  case  24 : field = gros_wt + "" ; break;
  case  25 : field = ship_dwt_actl + "" ; break;
  case  26 : field = ship_capa_size + "" ; break;
  case  27 : field = sd_pln + "" ; break;
  case  28 : field = sd_actl + "" ; break;
  case  29 : field = sc_date_pln + "" ; break;
  case  30 : field = sc_date_actl + "" ; break;
  case  31 : field = kl_date_pln + "" ; break;
  case  32 : field = kl_date_actl + "" ; break;
  case  33 : field = lncg_date_pln + "" ; break;
  case  34 : field = lncg_date_actl + "" ; break;
  case  35 : field = strl_date_pln + "" ; break;
  case  36 : field = strl_date_actl + "" ; break;
  case  37 : field = cmpl_date_pln + "" ; break;
  case  38 : field = cmpl_date_actl + "" ; break;
  case  39 : field = dlvy_date_pln + "" ; break;
  case  40 : field = dlvy_date_actl + "" ; break;
  case  41 : field = main_engn_erec_dt_pln + "" ; break;
  case  42 : field = main_engn_erec_dt_actl + "" ; break;
  case  43 : field = main_proj_no + "" ; break;
  case  44 : field = trst_main_proj_no + "" ; break;
  case  45 : field = asst_trnfr_date + "" ; break;
  case  46 : field = cnsm_mh + "" ; break;
  case  47 : field = bdgt_mh + "" ; break;
  case  48 : field = tagt_mh + "" ; break;
  case  49 : field = proj_sale + "" ; break;
  case  50 : field = proj_bdgt + "" ; break;
  case  51 : field = proj_no_rgdt + "" ; break;
  case  52 : field = proj_cls_rgdt + "" ; break;
  case  53 : field = proj_po_type + "" ; break;
  case  54 : field = cost_cntr + "" ; break;
  case  55 : field = cad_unon_aply_indc + "" ; break;
  case  56 : field = cad_unon_aply_indc_rgdt + "" ; break;
  case  57 : field = cad_unon_aply_emp_no + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("proj_no")){ field = proj_no + "" ; 
     } else if(rec.equalsIgnoreCase("prf_proj_indc")){ field = prf_proj_indc + "" ; 
     } else if(rec.equalsIgnoreCase("proj_no_grp")){ field = proj_no_grp + "" ; 
     } else if(rec.equalsIgnoreCase("proj_desc_kor")){ field = proj_desc_kor + "" ; 
     } else if(rec.equalsIgnoreCase("proj_desc_engl")){ field = proj_desc_engl + "" ; 
     } else if(rec.equalsIgnoreCase("prod_ord_no")){ field = prod_ord_no + "" ; 
     } else if(rec.equalsIgnoreCase("prod_ord_date")){ field = prod_ord_date + "" ; 
     } else if(rec.equalsIgnoreCase("proj_cls_date")){ field = proj_cls_date + "" ; 
     } else if(rec.equalsIgnoreCase("acct_cls_date")){ field = acct_cls_date + "" ; 
     } else if(rec.equalsIgnoreCase("acct_code_npp")){ field = acct_code_npp + "" ; 
     } else if(rec.equalsIgnoreCase("ship_type")){ field = ship_type + "" ; 
     } else if(rec.equalsIgnoreCase("ship_kind")){ field = ship_kind + "" ; 
     } else if(rec.equalsIgnoreCase("proj_ittv_div")){ field = proj_ittv_div + "" ; 
     } else if(rec.equalsIgnoreCase("proj_ittv_dept")){ field = proj_ittv_dept + "" ; 
     } else if(rec.equalsIgnoreCase("proj_exec_div")){ field = proj_exec_div + "" ; 
     } else if(rec.equalsIgnoreCase("proj_exec_dept")){ field = proj_exec_dept + "" ; 
     } else if(rec.equalsIgnoreCase("acct_id_mgnt_proj")){ field = acct_id_mgnt_proj + "" ; 
     } else if(rec.equalsIgnoreCase("ship_bdth_actl")){ field = ship_bdth_actl + "" ; 
     } else if(rec.equalsIgnoreCase("ship_loa_actl")){ field = ship_loa_actl + "" ; 
     } else if(rec.equalsIgnoreCase("ship_dpth_actl")){ field = ship_dpth_actl + "" ; 
     } else if(rec.equalsIgnoreCase("ship_lbp_actl")){ field = ship_lbp_actl + "" ; 
     } else if(rec.equalsIgnoreCase("ship_spd")){ field = ship_spd + "" ; 
     } else if(rec.equalsIgnoreCase("stl_net_wt")){ field = stl_net_wt + "" ; 
     } else if(rec.equalsIgnoreCase("gros_wt")){ field = gros_wt + "" ; 
     } else if(rec.equalsIgnoreCase("ship_dwt_actl")){ field = ship_dwt_actl + "" ; 
     } else if(rec.equalsIgnoreCase("ship_capa_size")){ field = ship_capa_size + "" ; 
     } else if(rec.equalsIgnoreCase("sd_pln")){ field = sd_pln + "" ; 
     } else if(rec.equalsIgnoreCase("sd_actl")){ field = sd_actl + "" ; 
     } else if(rec.equalsIgnoreCase("sc_date_pln")){ field = sc_date_pln + "" ; 
     } else if(rec.equalsIgnoreCase("sc_date_actl")){ field = sc_date_actl + "" ; 
     } else if(rec.equalsIgnoreCase("kl_date_pln")){ field = kl_date_pln + "" ; 
     } else if(rec.equalsIgnoreCase("kl_date_actl")){ field = kl_date_actl + "" ; 
     } else if(rec.equalsIgnoreCase("lncg_date_pln")){ field = lncg_date_pln + "" ; 
     } else if(rec.equalsIgnoreCase("lncg_date_actl")){ field = lncg_date_actl + "" ; 
     } else if(rec.equalsIgnoreCase("strl_date_pln")){ field = strl_date_pln + "" ; 
     } else if(rec.equalsIgnoreCase("strl_date_actl")){ field = strl_date_actl + "" ; 
     } else if(rec.equalsIgnoreCase("cmpl_date_pln")){ field = cmpl_date_pln + "" ; 
     } else if(rec.equalsIgnoreCase("cmpl_date_actl")){ field = cmpl_date_actl + "" ; 
     } else if(rec.equalsIgnoreCase("dlvy_date_pln")){ field = dlvy_date_pln + "" ; 
     } else if(rec.equalsIgnoreCase("dlvy_date_actl")){ field = dlvy_date_actl + "" ; 
     } else if(rec.equalsIgnoreCase("main_engn_erec_dt_pln")){ field = main_engn_erec_dt_pln + "" ; 
     } else if(rec.equalsIgnoreCase("main_engn_erec_dt_actl")){ field = main_engn_erec_dt_actl + "" ; 
     } else if(rec.equalsIgnoreCase("main_proj_no")){ field = main_proj_no + "" ; 
     } else if(rec.equalsIgnoreCase("trst_main_proj_no")){ field = trst_main_proj_no + "" ; 
     } else if(rec.equalsIgnoreCase("asst_trnfr_date")){ field = asst_trnfr_date + "" ; 
     } else if(rec.equalsIgnoreCase("cnsm_mh")){ field = cnsm_mh + "" ; 
     } else if(rec.equalsIgnoreCase("bdgt_mh")){ field = bdgt_mh + "" ; 
     } else if(rec.equalsIgnoreCase("tagt_mh")){ field = tagt_mh + "" ; 
     } else if(rec.equalsIgnoreCase("proj_sale")){ field = proj_sale + "" ; 
     } else if(rec.equalsIgnoreCase("proj_bdgt")){ field = proj_bdgt + "" ; 
     } else if(rec.equalsIgnoreCase("proj_no_rgdt")){ field = proj_no_rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("proj_cls_rgdt")){ field = proj_cls_rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("proj_po_type")){ field = proj_po_type + "" ; 
     } else if(rec.equalsIgnoreCase("cost_cntr")){ field = cost_cntr + "" ; 
     } else if(rec.equalsIgnoreCase("cad_unon_aply_indc")){ field = cad_unon_aply_indc + "" ; 
     } else if(rec.equalsIgnoreCase("cad_unon_aply_indc_rgdt")){ field = cad_unon_aply_indc_rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("cad_unon_aply_emp_no")){ field = cad_unon_aply_emp_no + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "PROJ_NO", "PRF_PROJ_INDC", "PROJ_NO_GRP", "PROJ_DESC_KOR", "PROJ_DESC_ENGL", "PROD_ORD_NO", "PROD_ORD_DATE", 
       "PROJ_CLS_DATE", "ACCT_CLS_DATE", "ACCT_CODE_NPP", "SHIP_TYPE", "SHIP_KIND", "PROJ_ITTV_DIV", "PROJ_ITTV_DEPT", 
       "PROJ_EXEC_DIV", "PROJ_EXEC_DEPT", "ACCT_ID_MGNT_PROJ", "SHIP_BDTH_ACTL", "SHIP_LOA_ACTL", "SHIP_DPTH_ACTL", "SHIP_LBP_ACTL", 
       "SHIP_SPD", "STL_NET_WT", "GROS_WT", "SHIP_DWT_ACTL", "SHIP_CAPA_SIZE", "SD_PLN", "SD_ACTL", 
       "SC_DATE_PLN", "SC_DATE_ACTL", "KL_DATE_PLN", "KL_DATE_ACTL", "LNCG_DATE_PLN", "LNCG_DATE_ACTL", "STRL_DATE_PLN", 
       "STRL_DATE_ACTL", "CMPL_DATE_PLN", "CMPL_DATE_ACTL", "DLVY_DATE_PLN", "DLVY_DATE_ACTL", "MAIN_ENGN_EREC_DT_PLN", "MAIN_ENGN_EREC_DT_ACTL", 
       "MAIN_PROJ_NO", "TRST_MAIN_PROJ_NO", "ASST_TRNFR_DATE", "CNSM_MH", "BDGT_MH", "TAGT_MH", "PROJ_SALE", 
       "PROJ_BDGT", "PROJ_NO_RGDT", "PROJ_CLS_RGDT", "PROJ_PO_TYPE", "COST_CNTR", "CAD_UNON_APLY_INDC", "CAD_UNON_APLY_INDC_RGDT", 
       "CAD_UNON_APLY_EMP_NO"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "PROJ_NO"};
    return tempx;
}

}// end HA010MRec class