package com.bes_line.EEE;  
  
import org.jsn.jdf.*;  
import org.jsn.jdf.db.*;  
import org.jsn.jdf.jtx.*;  
import org.jsn.jdf.servlet.*;  
  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.io.*;  
import java.net.*;  
import java.util.Vector;  
  
import com.bes_line.mst.*;  
import com.bes_line.mst.EEE.*;  
import com.bes_line.base.*;  
  
public class Calendar extends HttpServlet{  
  
public void init(ServletConfig sc) throws ServletException {  
    super.init(sc);  
} // init  
  
public void destroy(){  
    super.destroy();  
}// destory  
  
public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e ) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
  } // end try                     
}//end doGet  
  
public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
    } // try-catch  
}//end doPost  
  
//=============================================================================  
protected void performTask (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
String cmd = request.getParameter("cmd");  
try {        if ( cmd.equals( "add1_ok" ) )     { insertEE.EZ012C(request, response);  
      } else if ( cmd.equals( "update1_ok" ) )  { updateEE.EZ012C(request, response);   
      } else if ( cmd.equals( "delete1_ok" ) )  { deleteEE.EZ012C(request, response);  
      } else if ( cmd.equals( "update1_list" ) )  { update1_list(request, response);  
      }  
 } catch(Throwable e ) {  
    e.printStackTrace(System.err);  
     System.err.flush();  
 } // end try  
}//end performTask  
  
//================================================================================  
public  void update1_list(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/EEE/Calendar/index.jsp" ;  
    String listJsp   = bu.HTTPSERVER + "/webpages/EEE/Calendar/list1.jsp" ;  
    String listCount = request.getParameter("listCount");   
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String trmid = request.getParameter("trmid");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	String work_regn_id = "";
	String work_date = "";
	String lbun_mbsp_jbl_id = "";
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
		EE.EZ012CRec ee.ez012c = new EE.EZ012CRec() ; 
		EE.EZ012CDBWrap ee.ez012cdbw = new EE.EZ012CDBWrap(resource); 
		for( int lc=1; lc<=Integer.parseInt(listCount); lc++ ) { 
			work_regn_id = request.getParameter("work_regn_id"+String.valueOf(lc)); 
			work_date = request.getParameter("work_date"+String.valueOf(lc)); 
			lbun_mbsp_jbl_id = request.getParameter("lbun_mbsp_jbl_id"+String.valueOf(lc)); 
			String check = request.getParameter("check__"+String.valueOf(lc));
			if(check == null || !check.equals("Y")) continue; 

			ee.ez012c = ee.ez012cdbw.select(work_regn_id, work_date, lbun_mbsp_jbl_id); 
			Utility.fixNullAndTrim(ee.ez012c); 
			ee.ez012c.setWork_regn_id(  request.getParameter("work_regn_id" + String.valueOf(lc))); 
			ee.ez012c.setWork_date(  request.getParameter("work_date" + String.valueOf(lc))); 
			ee.ez012cdbw.update(ee.ez012c); 
		}
		tx.commit(); 
    } catch(Exception e) {  
		tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(listJsp+"?posName="+URLEncoder.encode(posName,'utf-8')+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,'utf-8')+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen=" + screen + "&errMsg="+URLEncoder.encode(errMsg,'utf-8')+"&work_regn_id="+work_regn_id+"&work_date="+work_date+"&lbun_mbsp_jbl_id="+lbun_mbsp_jbl_id) ; 
  
} // end updateEE.EZ012C  
  
//================================================================================  
public  void insertEE.EZ012C(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/EEE/Calendar/index.jsp" ;  
    String work_regn_id = box.getString("work_regn_id"); 
    String work_date = box.getString("work_date"); 
    String lbun_mbsp_jbl_id = box.getString("lbun_mbsp_jbl_id"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	EE.EZ012CRec ee.ez012c = new EE.EZ012CRec() ; 
	box.copyToEntity(ee.ez012c); 
	Utility.fixNullAndTrim(ee.ez012c); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	BesInit bi = new BesInit();  
	UserInfo ui = bi.checkSession(request , response); 
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        EE.EZ012CDBWrap ee.ez012cdbw = new EE.EZ012CDBWrap(resource); 
/** 
 * ?????? ????? alert ?; ??? ??? ?? ?????? ???? 
 */ 
    int cnt = ee.ez012cdbw.count(work_regn_id,work_date,lbun_mbsp_jbl_id); 
	if(cnt == 0){ 
        // System Colulms.. 
        ee.ez012c.setAdate(curdate); 
        ee.ez012c.setAuser(usrid); 
        ee.ez012c.setMdate(curdate); 
        ee.ez012c.setMuser(usrid); 
		ee.ez012cdbw.insert(ee.ez012c); 
		tx.commit(); 
      response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,'utf-8')+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,'utf-8')+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,'utf-8')+"&work_regn_id="+work_regn_id+"&work_date="+work_date+"&lbun_mbsp_jbl_id="+lbun_mbsp_jbl_id) ; 
    }else{ 
      tx.rollback(); 
      out.println("<script language='javascript'>"); 
      out.println("  alert('" + BesDBUtil.getMessage("bsc128",ui) + "');"); 
      out.println("  history.back(-1);"); 
      out.println("</script>"); 
    } 
    } catch(Exception e) {  
        tx.rollback(); 
        out.println(e.getMessage()+"<br>"+e.toString());  
        e.printStackTrace();  
        out.println(box.toString());  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
} // end insertEE.EZ012C  
  
//================================================================================  
public  void updateEE.EZ012C(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/EEE/Calendar/index.jsp" ;  
    String work_regn_id = box.getString("work_regn_id"); 
    String work_date = box.getString("work_date"); 
    String lbun_mbsp_jbl_id = box.getString("lbun_mbsp_jbl_id"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
    EE.EZ012CRec ee.ez012cBox = new EE.EZ012CRec() ; 
    box.copyToEntity(ee.ez012cBox); 
    Utility.fixNullAndTrim(ee.ez012cBox); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        EE.EZ012CDBWrap ee.ez012cdbw = new EE.EZ012CDBWrap(resource); 
        EE.EZ012CRec ee.ez012c = ee.ez012cdbw.select(work_regn_id, work_date, lbun_mbsp_jbl_id);
         // System Colulms.. 
        ee.ez012c.setMdate(curdate); 
        ee.ez012c.setMuser(usrid); 
        // Editable Colulms.. 
        ee.ez012c.setWork_regn_id(ee.ez012cBox.getWork_regn_id()); 
        ee.ez012c.setWork_date(ee.ez012cBox.getWork_date()); 
        ee.ez012cdbw.update(ee.ez012c); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,'utf-8')+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,'utf-8')+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,'utf-8')+"&work_regn_id="+work_regn_id+"&work_date="+work_date+"&lbun_mbsp_jbl_id="+lbun_mbsp_jbl_id) ; 
  
} // end updateEE.EZ012C  
  
//================================================================================  
public  void deleteEE.EZ012C(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/EEE/Calendar/index.jsp" ;  
    String work_regn_id = box.getString("work_regn_id"); 
    String work_date = box.getString("work_date"); 
    String lbun_mbsp_jbl_id = box.getString("lbun_mbsp_jbl_id"); 
    String screen = "addscreen";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String callParameter = "";
    String errMsg = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
  
    EE.EZ012CRec ee.ez012c = new EE.EZ012CRec() ; 
    box.copyToEntity(ee.ez012c); 
    Utility.fixNullAndTrim(ee.ez012c); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        EE.EZ012CDBWrap ee.ez012cdbw = new EE.EZ012CDBWrap(resource); 
        ee.ez012cdbw.delete(ee.ez012c); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,'utf-8')+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,'utf-8')+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,'utf-8'));  
//================================================================================  
 } 
}// end Class  
