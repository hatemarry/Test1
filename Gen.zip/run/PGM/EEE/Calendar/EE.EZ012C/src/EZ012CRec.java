package com.bes_line.mst.EEE ;

// Entity Class for EZ012C
/**
 *
 * @(#) EZ012CRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-23
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class EZ012CRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String work_regn_id; 		// (CHAR, 1.0)
    public String work_date; 		// (CHAR, 8.0)
    public String lbun_mbsp_jbl_id; 		// (CHAR, 1.0)
    public String wtc_dur_id; 		// (CHAR, 1.0)
    public String work_day_type; 		// (CHAR, 2.0)
    public String work_date_desc; 		// (VARCHAR2, 45.0)
    public String hldy_dup_indc; 		// (CHAR, 1.0)
    public String trnf_vctn_prmt_indc; 		// (CHAR, 1.0)
    public String week_day_id; 		// (CHAR, 1.0)
    public String week_no; 		// (CHAR, 6.0)
    public int rdct_base_work_hour; 		// (NUMBER, 3.0)
    public int lnch_ovtm; 		// (NUMBER, 3.0)
    public String slry_week_no; 		// (CHAR, 6.0)
    public String hldy_nwk_code; 		// (CHAR, 1.0)

public EZ012CRec(){ } // default constructor

public EZ012CRec(
       String work_regn_id, String work_date, String lbun_mbsp_jbl_id, String wtc_dur_id, String work_day_type, String work_date_desc, 
       String hldy_dup_indc, String trnf_vctn_prmt_indc, String week_day_id, String week_no, int rdct_base_work_hour, int lnch_ovtm, 
       String slry_week_no, String hldy_nwk_code){
    this.work_regn_id = work_regn_id;
    this.work_date = work_date;
    this.lbun_mbsp_jbl_id = lbun_mbsp_jbl_id;
    this.wtc_dur_id = wtc_dur_id;
    this.work_day_type = work_day_type;
    this.work_date_desc = work_date_desc;
    this.hldy_dup_indc = hldy_dup_indc;
    this.trnf_vctn_prmt_indc = trnf_vctn_prmt_indc;
    this.week_day_id = week_day_id;
    this.week_no = week_no;
    this.rdct_base_work_hour = rdct_base_work_hour;
    this.lnch_ovtm = lnch_ovtm;
    this.slry_week_no = slry_week_no;
    this.hldy_nwk_code = hldy_nwk_code;
} // Constructor


// Getter 
public String getWork_regn_id(){ return work_regn_id;}
public String getWork_date(){ return work_date;}
public String getLbun_mbsp_jbl_id(){ return lbun_mbsp_jbl_id;}
public String getWtc_dur_id(){ return wtc_dur_id;}
public String getWork_day_type(){ return work_day_type;}
public String getWork_date_desc(){ return work_date_desc;}
public String getHldy_dup_indc(){ return hldy_dup_indc;}
public String getTrnf_vctn_prmt_indc(){ return trnf_vctn_prmt_indc;}
public String getWeek_day_id(){ return week_day_id;}
public String getWeek_no(){ return week_no;}
public int getRdct_base_work_hour(){ return rdct_base_work_hour;}
public int getLnch_ovtm(){ return lnch_ovtm;}
public String getSlry_week_no(){ return slry_week_no;}
public String getHldy_nwk_code(){ return hldy_nwk_code;}

// Setter 
public void setWork_regn_id(String work_regn_id){ this.work_regn_id = work_regn_id;}
public void setWork_date(String work_date){ this.work_date = work_date;}
public void setLbun_mbsp_jbl_id(String lbun_mbsp_jbl_id){ this.lbun_mbsp_jbl_id = lbun_mbsp_jbl_id;}
public void setWtc_dur_id(String wtc_dur_id){ this.wtc_dur_id = wtc_dur_id;}
public void setWork_day_type(String work_day_type){ this.work_day_type = work_day_type;}
public void setWork_date_desc(String work_date_desc){ this.work_date_desc = work_date_desc;}
public void setHldy_dup_indc(String hldy_dup_indc){ this.hldy_dup_indc = hldy_dup_indc;}
public void setTrnf_vctn_prmt_indc(String trnf_vctn_prmt_indc){ this.trnf_vctn_prmt_indc = trnf_vctn_prmt_indc;}
public void setWeek_day_id(String week_day_id){ this.week_day_id = week_day_id;}
public void setWeek_no(String week_no){ this.week_no = week_no;}
public void setRdct_base_work_hour(int rdct_base_work_hour){ this.rdct_base_work_hour = rdct_base_work_hour;}
public void setLnch_ovtm(int lnch_ovtm){ this.lnch_ovtm = lnch_ovtm;}
public void setSlry_week_no(String slry_week_no){ this.slry_week_no = slry_week_no;}
public void setHldy_nwk_code(String hldy_nwk_code){ this.hldy_nwk_code = hldy_nwk_code;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = work_regn_id + "" ; break;
  case  2 : field = work_date + "" ; break;
  case  3 : field = lbun_mbsp_jbl_id + "" ; break;
  case  4 : field = wtc_dur_id + "" ; break;
  case  5 : field = work_day_type + "" ; break;
  case  6 : field = work_date_desc + "" ; break;
  case  7 : field = hldy_dup_indc + "" ; break;
  case  8 : field = trnf_vctn_prmt_indc + "" ; break;
  case  9 : field = week_day_id + "" ; break;
  case  10 : field = week_no + "" ; break;
  case  11 : field = rdct_base_work_hour + "" ; break;
  case  12 : field = lnch_ovtm + "" ; break;
  case  13 : field = slry_week_no + "" ; break;
  case  14 : field = hldy_nwk_code + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("work_regn_id")){ field = work_regn_id + "" ; 
     } else if(rec.equalsIgnoreCase("work_date")){ field = work_date + "" ; 
     } else if(rec.equalsIgnoreCase("lbun_mbsp_jbl_id")){ field = lbun_mbsp_jbl_id + "" ; 
     } else if(rec.equalsIgnoreCase("wtc_dur_id")){ field = wtc_dur_id + "" ; 
     } else if(rec.equalsIgnoreCase("work_day_type")){ field = work_day_type + "" ; 
     } else if(rec.equalsIgnoreCase("work_date_desc")){ field = work_date_desc + "" ; 
     } else if(rec.equalsIgnoreCase("hldy_dup_indc")){ field = hldy_dup_indc + "" ; 
     } else if(rec.equalsIgnoreCase("trnf_vctn_prmt_indc")){ field = trnf_vctn_prmt_indc + "" ; 
     } else if(rec.equalsIgnoreCase("week_day_id")){ field = week_day_id + "" ; 
     } else if(rec.equalsIgnoreCase("week_no")){ field = week_no + "" ; 
     } else if(rec.equalsIgnoreCase("rdct_base_work_hour")){ field = rdct_base_work_hour + "" ; 
     } else if(rec.equalsIgnoreCase("lnch_ovtm")){ field = lnch_ovtm + "" ; 
     } else if(rec.equalsIgnoreCase("slry_week_no")){ field = slry_week_no + "" ; 
     } else if(rec.equalsIgnoreCase("hldy_nwk_code")){ field = hldy_nwk_code + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "WORK_REGN_ID", "WORK_DATE", "LBUN_MBSP_JBL_ID", "WTC_DUR_ID", "WORK_DAY_TYPE", "WORK_DATE_DESC", "HLDY_DUP_INDC", 
       "TRNF_VCTN_PRMT_INDC", "WEEK_DAY_ID", "WEEK_NO", "RDCT_BASE_WORK_HOUR", "LNCH_OVTM", "SLRY_WEEK_NO", "HLDY_NWK_CODE"
       };
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "WORK_REGN_ID", "WORK_DATE", "LBUN_MBSP_JBL_ID"};
    return tempx;
}

}// end EZ012CRec class