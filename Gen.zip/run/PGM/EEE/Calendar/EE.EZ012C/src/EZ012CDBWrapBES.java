package com.bes_line.mst.EEE;

// DBWrapper Class for EZ012C
/**
 *
 * @(#) EZ012CDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-23
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class EZ012CDBWrapBES extends DBWrapper{

public EZ012CDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Select Page
* @param String work_regn_id
* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectPage(String fldname, int page, int pagesize, String whereOption ) throws Exception{
return selectPage(fldname,page,pagesize, "Asc", whereOption) ;
}// end selectPage
/**
* Select Page
* @param String work_regn_id* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectPage(String fldname, int page, int pagesize, String keyorder, String whereOption) throws Exception{
    java.util.Vector ez012cV = new java.util.Vector();
    EZ012CRec ez012c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select work_regn_id, work_date, lbun_mbsp_jbl_id, wtc_dur_id, work_day_type, work_date_desc, hldy_dup_indc, trnf_vctn_prmt_indc, week_day_id, " +
                              "week_no, rdct_base_work_hour, lnch_ovtm, slry_week_no, hldy_nwk_code " +
                       "  from EE.EZ012C  where 1 = 1 " +   whereOption  +
                       "  order by "+fldname+" "+keyorder;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();
        int count = 0;
        while((count < (page-1)*pagesize ) && ( rs.next())){  count ++; } // page??? ??????
            count = 0;
        while(rs.next()){
            count ++;
            if(count > pagesize ) break;
            ez012c = new EZ012CRec(); // EZ012CRec Constructor
                     ez012c.setWork_regn_id(rs.getString("work_regn_id"));
                     ez012c.setWork_date(rs.getString("work_date"));
                     ez012c.setLbun_mbsp_jbl_id(rs.getString("lbun_mbsp_jbl_id"));
                     ez012c.setWtc_dur_id(rs.getString("wtc_dur_id"));
                     ez012c.setWork_day_type(rs.getString("work_day_type"));
                     ez012c.setWork_date_desc(rs.getString("work_date_desc"));
                     ez012c.setHldy_dup_indc(rs.getString("hldy_dup_indc"));
                     ez012c.setTrnf_vctn_prmt_indc(rs.getString("trnf_vctn_prmt_indc"));
                     ez012c.setWeek_day_id(rs.getString("week_day_id"));
                     ez012c.setWeek_no(rs.getString("week_no"));
                     ez012c.setRdct_base_work_hour(rs.getInt("rdct_base_work_hour"));
                     ez012c.setLnch_ovtm(rs.getInt("lnch_ovtm"));
                     ez012c.setSlry_week_no(rs.getString("slry_week_no"));
                     ez012c.setHldy_nwk_code(rs.getString("hldy_nwk_code"));
            ez012cV.addElement(ez012c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return ez012cV;
} // end selectPage

/**
* SelectWhere
* @param String work_regn_id
* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectWhere(String fldname, String whereOption ) throws Exception{
return selectWhere(fldname, "Asc", whereOption) ;
}// end selectWhere
/**
* SelectWhere
* @param String work_regn_id* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectWhere(String fldname, String keyorder, String whereOption) throws Exception{
    java.util.Vector ez012cV = new java.util.Vector();
    EZ012CRec ez012c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select work_regn_id, work_date, lbun_mbsp_jbl_id, wtc_dur_id, work_day_type, work_date_desc, hldy_dup_indc, trnf_vctn_prmt_indc, week_day_id, " +
                              "week_no, rdct_base_work_hour, lnch_ovtm, slry_week_no, hldy_nwk_code " +
                       "  from EE.EZ012C  where 1 = 1 " +   whereOption  +
                       "  order by "+fldname+" "+keyorder;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();
        while(rs.next()) {
            ez012c = new EZ012CRec(); // EZ012CRec Constructor
                     ez012c.setWork_regn_id(rs.getString("work_regn_id"));
                     ez012c.setWork_date(rs.getString("work_date"));
                     ez012c.setLbun_mbsp_jbl_id(rs.getString("lbun_mbsp_jbl_id"));
                     ez012c.setWtc_dur_id(rs.getString("wtc_dur_id"));
                     ez012c.setWork_day_type(rs.getString("work_day_type"));
                     ez012c.setWork_date_desc(rs.getString("work_date_desc"));
                     ez012c.setHldy_dup_indc(rs.getString("hldy_dup_indc"));
                     ez012c.setTrnf_vctn_prmt_indc(rs.getString("trnf_vctn_prmt_indc"));
                     ez012c.setWeek_day_id(rs.getString("week_day_id"));
                     ez012c.setWeek_no(rs.getString("week_no"));
                     ez012c.setRdct_base_work_hour(rs.getInt("rdct_base_work_hour"));
                     ez012c.setLnch_ovtm(rs.getInt("lnch_ovtm"));
                     ez012c.setSlry_week_no(rs.getString("slry_week_no"));
                     ez012c.setHldy_nwk_code(rs.getString("hldy_nwk_code"));
            ez012cV.addElement(ez012c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return ez012cV;
} // end selectWhere

/**
* Get Rows CountPage
* @param
* @return int
* @author besTeam
* @date 2006-5-23
*/
public int countPage(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select COUNT(*) from EE.EZ012C  where 1 = 1 " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end countPage

/**
* Get one Record
* @param String work_regn_id, String work_date, String lbun_mbsp_jbl_id
* @return EZ012CRec
* @author besTeam
* @date 2006-5-23
*/
public EZ012CRec select(String work_regn_id, String work_date, String lbun_mbsp_jbl_id) throws Exception {
    EZ012CRec ez012c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM EE.EZ012C "

        + " where work_regn_id = ? and work_date = ? and lbun_mbsp_jbl_id = ?";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,work_regn_id);
        pstmt.setString(2,work_date);
        pstmt.setString(3,lbun_mbsp_jbl_id);
        rs = pstmt.executeQuery();

        if(rs.next()){
            ez012c = new EZ012CRec(); // EZ012CRec Constructor
                     ez012c.setWork_regn_id(rs.getString("work_regn_id"));
                     ez012c.setWork_date(rs.getString("work_date"));
                     ez012c.setLbun_mbsp_jbl_id(rs.getString("lbun_mbsp_jbl_id"));
                     ez012c.setWtc_dur_id(rs.getString("wtc_dur_id"));
                     ez012c.setWork_day_type(rs.getString("work_day_type"));
                     ez012c.setWork_date_desc(rs.getString("work_date_desc"));
                     ez012c.setHldy_dup_indc(rs.getString("hldy_dup_indc"));
                     ez012c.setTrnf_vctn_prmt_indc(rs.getString("trnf_vctn_prmt_indc"));
                     ez012c.setWeek_day_id(rs.getString("week_day_id"));
                     ez012c.setWeek_no(rs.getString("week_no"));
                     ez012c.setRdct_base_work_hour(rs.getInt("rdct_base_work_hour"));
                     ez012c.setLnch_ovtm(rs.getInt("lnch_ovtm"));
                     ez012c.setSlry_week_no(rs.getString("slry_week_no"));
                     ez012c.setHldy_nwk_code(rs.getString("hldy_nwk_code"));
        } else {
            throw new DataNotFoundException();
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

    return ez012c;
} // end select

/**
* Get All Record
* @param  void
* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector ez012cV = new java.util.Vector();
    EZ012CRec ez012c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM EE.EZ012C ";

        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            ez012c = new EZ012CRec(); // EZ012CRec Constructor
                     ez012c.setWork_regn_id(rs.getString("work_regn_id"));
                     ez012c.setWork_date(rs.getString("work_date"));
                     ez012c.setLbun_mbsp_jbl_id(rs.getString("lbun_mbsp_jbl_id"));
                     ez012c.setWtc_dur_id(rs.getString("wtc_dur_id"));
                     ez012c.setWork_day_type(rs.getString("work_day_type"));
                     ez012c.setWork_date_desc(rs.getString("work_date_desc"));
                     ez012c.setHldy_dup_indc(rs.getString("hldy_dup_indc"));
                     ez012c.setTrnf_vctn_prmt_indc(rs.getString("trnf_vctn_prmt_indc"));
                     ez012c.setWeek_day_id(rs.getString("week_day_id"));
                     ez012c.setWeek_no(rs.getString("week_no"));
                     ez012c.setRdct_base_work_hour(rs.getInt("rdct_base_work_hour"));
                     ez012c.setLnch_ovtm(rs.getInt("lnch_ovtm"));
                     ez012c.setSlry_week_no(rs.getString("slry_week_no"));
                     ez012c.setHldy_nwk_code(rs.getString("hldy_nwk_code"));
            ez012cV.addElement(ez012c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return ez012cV;
} // end selectAll

/**
* Get selectWhere Record
* @param  String
* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectWhere(String whereOption) throws Exception{
    java.util.Vector ez012cV = new java.util.Vector();
    EZ012CRec ez012c = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM EE.EZ012C "

  + whereOption;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            ez012c = new EZ012CRec(); // EZ012CRec Constructor
                     ez012c.setWork_regn_id(rs.getString("work_regn_id"));
                     ez012c.setWork_date(rs.getString("work_date"));
                     ez012c.setLbun_mbsp_jbl_id(rs.getString("lbun_mbsp_jbl_id"));
                     ez012c.setWtc_dur_id(rs.getString("wtc_dur_id"));
                     ez012c.setWork_day_type(rs.getString("work_day_type"));
                     ez012c.setWork_date_desc(rs.getString("work_date_desc"));
                     ez012c.setHldy_dup_indc(rs.getString("hldy_dup_indc"));
                     ez012c.setTrnf_vctn_prmt_indc(rs.getString("trnf_vctn_prmt_indc"));
                     ez012c.setWeek_day_id(rs.getString("week_day_id"));
                     ez012c.setWeek_no(rs.getString("week_no"));
                     ez012c.setRdct_base_work_hour(rs.getInt("rdct_base_work_hour"));
                     ez012c.setLnch_ovtm(rs.getInt("lnch_ovtm"));
                     ez012c.setSlry_week_no(rs.getString("slry_week_no"));
                     ez012c.setHldy_nwk_code(rs.getString("hldy_nwk_code"));
            ez012cV.addElement(ez012c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return ez012cV;
} // end selectAll

/**
* Get All Record(condition : last Key except)
* @param String work_regn_id, String work_date
* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectAll(String work_regn_id, String work_date) throws Exception{
    java.util.Vector ez012cV = new java.util.Vector();
    EZ012CRec ez012c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM EE.EZ012C "

        + " where work_regn_id = ? and work_date = ?  " +
                       "  order by lbun_mbsp_jbl_id";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,work_regn_id);
        pstmt.setString(2,work_date);
        rs = pstmt.executeQuery();

        while(rs.next()){
            ez012c = new EZ012CRec(); // EZ012CRec Constructor
                     ez012c.setWork_regn_id(rs.getString("work_regn_id"));
                     ez012c.setWork_date(rs.getString("work_date"));
                     ez012c.setLbun_mbsp_jbl_id(rs.getString("lbun_mbsp_jbl_id"));
                     ez012c.setWtc_dur_id(rs.getString("wtc_dur_id"));
                     ez012c.setWork_day_type(rs.getString("work_day_type"));
                     ez012c.setWork_date_desc(rs.getString("work_date_desc"));
                     ez012c.setHldy_dup_indc(rs.getString("hldy_dup_indc"));
                     ez012c.setTrnf_vctn_prmt_indc(rs.getString("trnf_vctn_prmt_indc"));
                     ez012c.setWeek_day_id(rs.getString("week_day_id"));
                     ez012c.setWeek_no(rs.getString("week_no"));
                     ez012c.setRdct_base_work_hour(rs.getInt("rdct_base_work_hour"));
                     ez012c.setLnch_ovtm(rs.getInt("lnch_ovtm"));
                     ez012c.setSlry_week_no(rs.getString("slry_week_no"));
                     ez012c.setHldy_nwk_code(rs.getString("hldy_nwk_code"));
            ez012cV.addElement(ez012c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return ez012cV;
} // end selectAll

/**
* Get between Record(condition : last Key from - to)
* @param String work_regn_id, String work_date, String f_lbun_mbsp_jbl_id, String t_lbun_mbsp_jbl_id
* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectBetween(String work_regn_id, String work_date, String f_lbun_mbsp_jbl_id, String t_lbun_mbsp_jbl_id) throws Exception{
    return selectBetween(work_regn_id, work_date, f_lbun_mbsp_jbl_id, t_lbun_mbsp_jbl_id, 0);
} // end selectBetween

/**
* Get between Record(condition : last Key from - to)
* @param String work_regn_id, String work_date, String f_lbun_mbsp_jbl_id, String t_lbun_mbsp_jbl_id, int lastKeyOrder(0 : ASC-Default, 1 : DESC)
* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectBetween(String work_regn_id, String work_date, String f_lbun_mbsp_jbl_id, String t_lbun_mbsp_jbl_id, int lastKeyOrder) throws Exception{
    java.util.Vector ez012cV = new java.util.Vector();
    EZ012CRec ez012c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM EE.EZ012C "

        + " where work_regn_id = ? and work_date = ?  " +
                       "  and lbun_mbsp_jbl_id between ? and ?  ";
               if(lastKeyOrder == 1){
                   query += " order by lbun_mbsp_jbl_id DESC ";
               } else {
                   query += " order by lbun_mbsp_jbl_id";
               } // end if(lastKeyOrder == 1)
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,work_regn_id);
        pstmt.setString(2,work_date);
        pstmt.setString(3,f_lbun_mbsp_jbl_id);
        pstmt.setString(4,t_lbun_mbsp_jbl_id);
        rs = pstmt.executeQuery();

        while(rs.next()){
            ez012c = new EZ012CRec(); // EZ012CRec Constructor
                     ez012c.setWork_regn_id(rs.getString("work_regn_id"));
                     ez012c.setWork_date(rs.getString("work_date"));
                     ez012c.setLbun_mbsp_jbl_id(rs.getString("lbun_mbsp_jbl_id"));
                     ez012c.setWtc_dur_id(rs.getString("wtc_dur_id"));
                     ez012c.setWork_day_type(rs.getString("work_day_type"));
                     ez012c.setWork_date_desc(rs.getString("work_date_desc"));
                     ez012c.setHldy_dup_indc(rs.getString("hldy_dup_indc"));
                     ez012c.setTrnf_vctn_prmt_indc(rs.getString("trnf_vctn_prmt_indc"));
                     ez012c.setWeek_day_id(rs.getString("week_day_id"));
                     ez012c.setWeek_no(rs.getString("week_no"));
                     ez012c.setRdct_base_work_hour(rs.getInt("rdct_base_work_hour"));
                     ez012c.setLnch_ovtm(rs.getInt("lnch_ovtm"));
                     ez012c.setSlry_week_no(rs.getString("slry_week_no"));
                     ez012c.setHldy_nwk_code(rs.getString("hldy_nwk_code"));
            ez012cV.addElement(ez012c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return ez012cV;
} // end selectBetween

/**
* Select Data Over the key value(s) and default return count(20)
* @param String work_regn_id, String work_date, String lbun_mbsp_jbl_id
* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectOver(String work_regn_id, String work_date, String lbun_mbsp_jbl_id) throws Exception{
return selectOver(work_regn_id, work_date, lbun_mbsp_jbl_id,20) ;
}// end selectOver
/**
* Select Data Over(Next) the key value(s) and return record count
* @param String work_regn_id, String work_date, String lbun_mbsp_jbl_id, int
* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectOver(String work_regn_id, String work_date, String lbun_mbsp_jbl_id, int page) throws Exception{
    java.util.Vector ez012cV = new java.util.Vector();
    EZ012CRec ez012c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM EE.EZ012C "

        + " where work_regn_id = ?  and  work_date = ?  and  lbun_mbsp_jbl_id >= ? order by lbun_mbsp_jbl_id ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,work_regn_id);
        pstmt.setString(2,work_date);
        pstmt.setString(3,lbun_mbsp_jbl_id);
        rs = pstmt.executeQuery();
        int count = 0;//??f??? SQL?????? Limit??? ????...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            ez012c = new EZ012CRec(); // EZ012CRec Constructor
                     ez012c.setWork_regn_id(rs.getString("work_regn_id"));
                     ez012c.setWork_date(rs.getString("work_date"));
                     ez012c.setLbun_mbsp_jbl_id(rs.getString("lbun_mbsp_jbl_id"));
                     ez012c.setWtc_dur_id(rs.getString("wtc_dur_id"));
                     ez012c.setWork_day_type(rs.getString("work_day_type"));
                     ez012c.setWork_date_desc(rs.getString("work_date_desc"));
                     ez012c.setHldy_dup_indc(rs.getString("hldy_dup_indc"));
                     ez012c.setTrnf_vctn_prmt_indc(rs.getString("trnf_vctn_prmt_indc"));
                     ez012c.setWeek_day_id(rs.getString("week_day_id"));
                     ez012c.setWeek_no(rs.getString("week_no"));
                     ez012c.setRdct_base_work_hour(rs.getInt("rdct_base_work_hour"));
                     ez012c.setLnch_ovtm(rs.getInt("lnch_ovtm"));
                     ez012c.setSlry_week_no(rs.getString("slry_week_no"));
                     ez012c.setHldy_nwk_code(rs.getString("hldy_nwk_code"));
            ez012cV.addElement(ez012c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return ez012cV;
} // end selectOver

/**
* Select Data Under(Previous) the key value(s) and default return count(20)
* @param String work_regn_id, String work_date, String lbun_mbsp_jbl_id
* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectUnder(String work_regn_id, String work_date, String lbun_mbsp_jbl_id) throws Exception{
return selectUnder(work_regn_id, work_date, lbun_mbsp_jbl_id,20) ;
}// end selectUnder
/**
* Select Data Under(Previous) the key value(s) and return record count
* @param String work_regn_id, String work_date, String lbun_mbsp_jbl_id, int
* @return java.util.Vector
* @author besTeam
* @date 2006-5-23
*/
public java.util.Vector selectUnder(String work_regn_id, String work_date, String lbun_mbsp_jbl_id, int page) throws Exception{
    java.util.Vector ez012cV = new java.util.Vector();
    EZ012CRec ez012c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM EE.EZ012C "

        + " where work_regn_id = ?  and work_date = ?  and lbun_mbsp_jbl_id <= ? order by lbun_mbsp_jbl_id desc" ;
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,work_regn_id);
        pstmt.setString(2,work_date);
        pstmt.setString(3,lbun_mbsp_jbl_id);
        rs = pstmt.executeQuery();
        int count = 0;//??f??? SQL?????? Limit??? ????...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            ez012c = new EZ012CRec(); // EZ012CRec Constructor
                     ez012c.setWork_regn_id(rs.getString("work_regn_id"));
                     ez012c.setWork_date(rs.getString("work_date"));
                     ez012c.setLbun_mbsp_jbl_id(rs.getString("lbun_mbsp_jbl_id"));
                     ez012c.setWtc_dur_id(rs.getString("wtc_dur_id"));
                     ez012c.setWork_day_type(rs.getString("work_day_type"));
                     ez012c.setWork_date_desc(rs.getString("work_date_desc"));
                     ez012c.setHldy_dup_indc(rs.getString("hldy_dup_indc"));
                     ez012c.setTrnf_vctn_prmt_indc(rs.getString("trnf_vctn_prmt_indc"));
                     ez012c.setWeek_day_id(rs.getString("week_day_id"));
                     ez012c.setWeek_no(rs.getString("week_no"));
                     ez012c.setRdct_base_work_hour(rs.getInt("rdct_base_work_hour"));
                     ez012c.setLnch_ovtm(rs.getInt("lnch_ovtm"));
                     ez012c.setSlry_week_no(rs.getString("slry_week_no"));
                     ez012c.setHldy_nwk_code(rs.getString("hldy_nwk_code"));
            ez012cV.add(0,ez012c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return ez012cV;
} // end selectUnder
/**
* Get Rows Count
* @param String work_regn_id, String work_date, String lbun_mbsp_jbl_id
* @return int
* @author besTeam
* @date 2006-5-23
*/
public int count(String work_regn_id, String work_date, String lbun_mbsp_jbl_id) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " EE.EZ012C "

        + " where work_regn_id = ? and work_date = ? and lbun_mbsp_jbl_id = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,work_regn_id);
        pstmt.setString(2,work_date);
        pstmt.setString(3,lbun_mbsp_jbl_id);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count
* @param void
* @return int
* @author besTeam
* @date 2006-5-23
*/
public int count() throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " EE.EZ012C "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}// end EZ012CDBWrapBES class