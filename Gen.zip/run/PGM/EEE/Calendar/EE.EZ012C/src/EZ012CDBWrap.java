package com.bes_line.mst.EEE;

// DBWrapper's Wrapper  Class for EZ012C
/**
 *
 * @(#) EZ012CDBWrap.java
 * Copyright 1999-2001 by Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-23
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class EZ012CDBWrap extends EZ012CDBWrapBES{
public EZ012CDBWrap(ConnectionContext ctx){
    super(ctx);
} // Constructor



////////////////// User Define Code Start //////////////////

/**
 * �������� �о�´�.
 * 2006-05-24
 */
public Vector selectWorkDateOfMonth(String work_date, String work_day_type, String lbun_mbsp_jbl_id) throws Exception {
    java.util.Vector  Vez012 = new java.util.Vector(); 
    EZ012CRec         ez012c = null;
    PreparedStatement pstmt  = null;
    ResultSet         rs     = null;

    try {
        StringBuffer query = new StringBuffer();   //
                     query.append(" SELECT substr(work_date, 7, 2) as work_date FROM ee.ez012c ");
                     query.append(" where work_date like '");
                     query.append( work_date );                     //200605
                     query.append("%'");
                     query.append(" and work_day_type = '");
                     query.append( work_day_type );                 //31
                     query.append("' and lbun_mbsp_jbl_id = '");
                     query.append( lbun_mbsp_jbl_id );              //1
                     query.append("'");

        pstmt = connection.prepareStatement( query.toString() );
        rs    = pstmt.executeQuery();

        if(rs.next()){
            ez012c = new EZ012CRec(); // EZ012CRec Constructor
            ez012c.setWork_date(rs.getString("work_date"));
            Vez012.addElement(ez012c);
        } else {
            throw new DataNotFoundException();
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

    return Vez012;
} // end select


//****** You should delete this line when you edit this source ^&*%%^%%(*&%(^%(*^^

////////////////// User Define  Code  End //////////////////

}// end  class