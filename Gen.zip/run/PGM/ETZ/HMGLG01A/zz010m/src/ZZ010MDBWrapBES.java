package com.bes_line.mst.ETZ;

// DBWrapper Class for ZZ010M
/**
 *
 * @(#) ZZ010MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-9
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class ZZ010MDBWrapBES extends DBWrapper{

public ZZ010MDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String vndr_no
* @return ZZ010MRec 
* @author besTeam 
* @date 2006-6-9
*/
public ZZ010MRec select(String vndr_no) throws Exception{
    java.util.Vector ZZ010MV = new java.util.Vector();
    ZZ010MRec zz010m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select vndr_no, vndr_code, vndr_name_kor, vndr_name_engl, rpst_name_kor, rpst_name_engl, rpst_rr_no, vndr_zip_code, vndr_addr_kor, " +
                              "vndr_addr_engl, rpst_tel_no, rpst_fax_no, vndr_tlx_no, vndr_ho_zip_code, vndr_ho_addr, vndr_fcty_zip_code, vndr_fcty_addr, vndr_natn_code, " +
                              "co_type_code, ind_type_desc, ind_form_desc, vndr_type_code, co_open_date, list_date, crnt_list_indc, acct_sttl_mm, mgnt_emp_man_cnt, " +
                              "prod_emp_man_cnt, prod_per_sale_rate, affl_co_name, frgn_jnt_co_name, main_trad_bank_code, intl_prch_trad_date, prch_trad_prmt_indc, advc_pay_indc, prch_vndr_grd_code, " +
                              "prch_vndr_prod_item, prod_type_code, cmdy_code, adms_assc_name, othr_maj_deal_co_name, othr_deal_co_dpdc_rate, buyr_emp_no, prch_trad_rgsr_reqr, prch_trad_stop_reqr, " +
                              "prch_trad_stop_date, prch_trad_stop_rsn, bsns_chrg_name_1, bsns_chrg_grd_ds_1, bsns_chrg_tel_no_1, bsns_chrg_fax_no_1, bsns_chrg_name_2, bsns_chrg_grd_ds_2, bsns_chrg_tel_no_2, " +
                              "bsns_chrg_fax_no_2, prch_sys_vndr_id, van_sys_indc, van_sys_user_id, van_sys_pswd, intn_mail_id, sec_insp_rgsr_no, sec_insp_rgdt, sec_insp_fd, " +
                              "dept_code, comp_tel_no, ind_dstr_insr_type, cstr_vndr_grd_code, cstr_vndr_main_work, cstr_prmt_indc, inc_outc_id, rglr_once_id, cnrt_ogan_code, " +
                              "intl_cstr_date, note_acct_no, dpst_name_kor, othr_acct_no, firm_bank_id, cash_acct_no, acct_trad_cls_date, acct_vndr_grd_code, pay_cndn_type, " +
                              "expd_bank_code, rgsr_ogan_id, app_sys_user_type, prch_vndr_indc, cstr_vndr_indc, rgdt, rgsr_rsn, lmd, new_vndr_code, " +
                              "bank_desc, acct_vndr_indc, emp_no_updt, regn_id, vndr_home_page, tbcd_ccsn_date, tbcd_effc_date, tbcd_chrg_emp_no, wldr_vndr_indc, " +
                              "env_vndr_indc " +
                       "  from ET.ZZ010M  " +
                       "  where vndr_no = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,vndr_no); 
        rs = pstmt.executeQuery();
        while(rs.next()) { 
            zz010m = new ZZ010MRec(); // ZZ010MRec Constructor
                     zz010m.setVndr_no(rs.getString("vndr_no"));
                     zz010m.setVndr_code(rs.getString("vndr_code"));
                     zz010m.setVndr_name_kor(rs.getString("vndr_name_kor"));
                     zz010m.setVndr_name_engl(rs.getString("vndr_name_engl"));
                     zz010m.setRpst_name_kor(rs.getString("rpst_name_kor"));
                     zz010m.setRpst_name_engl(rs.getString("rpst_name_engl"));
                     zz010m.setRpst_rr_no(rs.getString("rpst_rr_no"));
                     zz010m.setVndr_zip_code(rs.getString("vndr_zip_code"));
                     zz010m.setVndr_addr_kor(rs.getString("vndr_addr_kor"));
                     zz010m.setVndr_addr_engl(rs.getString("vndr_addr_engl"));
                     zz010m.setRpst_tel_no(rs.getString("rpst_tel_no"));
                     zz010m.setRpst_fax_no(rs.getString("rpst_fax_no"));
                     zz010m.setVndr_tlx_no(rs.getString("vndr_tlx_no"));
                     zz010m.setVndr_ho_zip_code(rs.getString("vndr_ho_zip_code"));
                     zz010m.setVndr_ho_addr(rs.getString("vndr_ho_addr"));
                     zz010m.setVndr_fcty_zip_code(rs.getString("vndr_fcty_zip_code"));
                     zz010m.setVndr_fcty_addr(rs.getString("vndr_fcty_addr"));
                     zz010m.setVndr_natn_code(rs.getString("vndr_natn_code"));
                     zz010m.setCo_type_code(rs.getString("co_type_code"));
                     zz010m.setInd_type_desc(rs.getString("ind_type_desc"));
                     zz010m.setInd_form_desc(rs.getString("ind_form_desc"));
                     zz010m.setVndr_type_code(rs.getString("vndr_type_code"));
                     zz010m.setCo_open_date(rs.getString("co_open_date"));
                     zz010m.setList_date(rs.getString("list_date"));
                     zz010m.setCrnt_list_indc(rs.getString("crnt_list_indc"));
                     zz010m.setAcct_sttl_mm(rs.getString("acct_sttl_mm"));
                     zz010m.setMgnt_emp_man_cnt(rs.getInt("mgnt_emp_man_cnt"));
                     zz010m.setProd_emp_man_cnt(rs.getInt("prod_emp_man_cnt"));
                     zz010m.setProd_per_sale_rate(rs.getDouble("prod_per_sale_rate"));
                     zz010m.setAffl_co_name(rs.getString("affl_co_name"));
                     zz010m.setFrgn_jnt_co_name(rs.getString("frgn_jnt_co_name"));
                     zz010m.setMain_trad_bank_code(rs.getString("main_trad_bank_code"));
                     zz010m.setIntl_prch_trad_date(rs.getString("intl_prch_trad_date"));
                     zz010m.setPrch_trad_prmt_indc(rs.getString("prch_trad_prmt_indc"));
                     zz010m.setAdvc_pay_indc(rs.getString("advc_pay_indc"));
                     zz010m.setPrch_vndr_grd_code(rs.getString("prch_vndr_grd_code"));
                     zz010m.setPrch_vndr_prod_item(rs.getString("prch_vndr_prod_item"));
                     zz010m.setProd_type_code(rs.getString("prod_type_code"));
                     zz010m.setCmdy_code(rs.getString("cmdy_code"));
                     zz010m.setAdms_assc_name(rs.getString("adms_assc_name"));
                     zz010m.setOthr_maj_deal_co_name(rs.getString("othr_maj_deal_co_name"));
                     zz010m.setOthr_deal_co_dpdc_rate(rs.getDouble("othr_deal_co_dpdc_rate"));
                     zz010m.setBuyr_emp_no(rs.getString("buyr_emp_no"));
                     zz010m.setPrch_trad_rgsr_reqr(rs.getString("prch_trad_rgsr_reqr"));
                     zz010m.setPrch_trad_stop_reqr(rs.getString("prch_trad_stop_reqr"));
                     zz010m.setPrch_trad_stop_date(rs.getString("prch_trad_stop_date"));
                     zz010m.setPrch_trad_stop_rsn(rs.getString("prch_trad_stop_rsn"));
                     zz010m.setBsns_chrg_name_1(rs.getString("bsns_chrg_name_1"));
                     zz010m.setBsns_chrg_grd_ds_1(rs.getString("bsns_chrg_grd_ds_1"));
                     zz010m.setBsns_chrg_tel_no_1(rs.getString("bsns_chrg_tel_no_1"));
                     zz010m.setBsns_chrg_fax_no_1(rs.getString("bsns_chrg_fax_no_1"));
                     zz010m.setBsns_chrg_name_2(rs.getString("bsns_chrg_name_2"));
                     zz010m.setBsns_chrg_grd_ds_2(rs.getString("bsns_chrg_grd_ds_2"));
                     zz010m.setBsns_chrg_tel_no_2(rs.getString("bsns_chrg_tel_no_2"));
                     zz010m.setBsns_chrg_fax_no_2(rs.getString("bsns_chrg_fax_no_2"));
                     zz010m.setPrch_sys_vndr_id(rs.getString("prch_sys_vndr_id"));
                     zz010m.setVan_sys_indc(rs.getString("van_sys_indc"));
                     zz010m.setVan_sys_user_id(rs.getString("van_sys_user_id"));
                     zz010m.setVan_sys_pswd(rs.getString("van_sys_pswd"));
                     zz010m.setIntn_mail_id(rs.getString("intn_mail_id"));
                     zz010m.setSec_insp_rgsr_no(rs.getString("sec_insp_rgsr_no"));
                     zz010m.setSec_insp_rgdt(rs.getString("sec_insp_rgdt"));
                     zz010m.setSec_insp_fd(rs.getString("sec_insp_fd"));
                     zz010m.setDept_code(rs.getString("dept_code"));
                     zz010m.setComp_tel_no(rs.getString("comp_tel_no"));
                     zz010m.setInd_dstr_insr_type(rs.getString("ind_dstr_insr_type"));
                     zz010m.setCstr_vndr_grd_code(rs.getString("cstr_vndr_grd_code"));
                     zz010m.setCstr_vndr_main_work(rs.getString("cstr_vndr_main_work"));
                     zz010m.setCstr_prmt_indc(rs.getString("cstr_prmt_indc"));
                     zz010m.setInc_outc_id(rs.getString("inc_outc_id"));
                     zz010m.setRglr_once_id(rs.getString("rglr_once_id"));
                     zz010m.setCnrt_ogan_code(rs.getString("cnrt_ogan_code"));
                     zz010m.setIntl_cstr_date(rs.getString("intl_cstr_date"));
                     zz010m.setNote_acct_no(rs.getString("note_acct_no"));
                     zz010m.setDpst_name_kor(rs.getString("dpst_name_kor"));
                     zz010m.setOthr_acct_no(rs.getString("othr_acct_no"));
                     zz010m.setFirm_bank_id(rs.getString("firm_bank_id"));
                     zz010m.setCash_acct_no(rs.getString("cash_acct_no"));
                     zz010m.setAcct_trad_cls_date(rs.getString("acct_trad_cls_date"));
                     zz010m.setAcct_vndr_grd_code(rs.getString("acct_vndr_grd_code"));
                     zz010m.setPay_cndn_type(rs.getString("pay_cndn_type"));
                     zz010m.setExpd_bank_code(rs.getString("expd_bank_code"));
                     zz010m.setRgsr_ogan_id(rs.getString("rgsr_ogan_id"));
                     zz010m.setApp_sys_user_type(rs.getString("app_sys_user_type"));
                     zz010m.setPrch_vndr_indc(rs.getString("prch_vndr_indc"));
                     zz010m.setCstr_vndr_indc(rs.getString("cstr_vndr_indc"));
                     zz010m.setRgdt(rs.getString("rgdt"));
                     zz010m.setRgsr_rsn(rs.getString("rgsr_rsn"));
                     zz010m.setLmd(rs.getString("lmd"));
                     zz010m.setNew_vndr_code(rs.getString("new_vndr_code"));
                     zz010m.setBank_desc(rs.getString("bank_desc"));
                     zz010m.setAcct_vndr_indc(rs.getString("acct_vndr_indc"));
                     zz010m.setEmp_no_updt(rs.getString("emp_no_updt"));
                     zz010m.setRegn_id(rs.getString("regn_id"));
                     zz010m.setVndr_home_page(rs.getString("vndr_home_page"));
                     zz010m.setTbcd_ccsn_date(rs.getString("tbcd_ccsn_date"));
                     zz010m.setTbcd_effc_date(rs.getString("tbcd_effc_date"));
                     zz010m.setTbcd_chrg_emp_no(rs.getString("tbcd_chrg_emp_no"));
                     zz010m.setWldr_vndr_indc(rs.getString("wldr_vndr_indc"));
                     zz010m.setEnv_vndr_indc(rs.getString("env_vndr_indc"));
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return ZZ010M;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-9
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector ZZ010MV = new java.util.Vector();
    ZZ010MRec zz010m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM ET.ZZ010M "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            zz010m = new ZZ010MRec(); // ZZ010MRec Constructor
                     zz010m.setVndr_no(rs.getString("vndr_no"));
                     zz010m.setVndr_code(rs.getString("vndr_code"));
                     zz010m.setVndr_name_kor(rs.getString("vndr_name_kor"));
                     zz010m.setVndr_name_engl(rs.getString("vndr_name_engl"));
                     zz010m.setRpst_name_kor(rs.getString("rpst_name_kor"));
                     zz010m.setRpst_name_engl(rs.getString("rpst_name_engl"));
                     zz010m.setRpst_rr_no(rs.getString("rpst_rr_no"));
                     zz010m.setVndr_zip_code(rs.getString("vndr_zip_code"));
                     zz010m.setVndr_addr_kor(rs.getString("vndr_addr_kor"));
                     zz010m.setVndr_addr_engl(rs.getString("vndr_addr_engl"));
                     zz010m.setRpst_tel_no(rs.getString("rpst_tel_no"));
                     zz010m.setRpst_fax_no(rs.getString("rpst_fax_no"));
                     zz010m.setVndr_tlx_no(rs.getString("vndr_tlx_no"));
                     zz010m.setVndr_ho_zip_code(rs.getString("vndr_ho_zip_code"));
                     zz010m.setVndr_ho_addr(rs.getString("vndr_ho_addr"));
                     zz010m.setVndr_fcty_zip_code(rs.getString("vndr_fcty_zip_code"));
                     zz010m.setVndr_fcty_addr(rs.getString("vndr_fcty_addr"));
                     zz010m.setVndr_natn_code(rs.getString("vndr_natn_code"));
                     zz010m.setCo_type_code(rs.getString("co_type_code"));
                     zz010m.setInd_type_desc(rs.getString("ind_type_desc"));
                     zz010m.setInd_form_desc(rs.getString("ind_form_desc"));
                     zz010m.setVndr_type_code(rs.getString("vndr_type_code"));
                     zz010m.setCo_open_date(rs.getString("co_open_date"));
                     zz010m.setList_date(rs.getString("list_date"));
                     zz010m.setCrnt_list_indc(rs.getString("crnt_list_indc"));
                     zz010m.setAcct_sttl_mm(rs.getString("acct_sttl_mm"));
                     zz010m.setMgnt_emp_man_cnt(rs.getInt("mgnt_emp_man_cnt"));
                     zz010m.setProd_emp_man_cnt(rs.getInt("prod_emp_man_cnt"));
                     zz010m.setProd_per_sale_rate(rs.getDouble("prod_per_sale_rate"));
                     zz010m.setAffl_co_name(rs.getString("affl_co_name"));
                     zz010m.setFrgn_jnt_co_name(rs.getString("frgn_jnt_co_name"));
                     zz010m.setMain_trad_bank_code(rs.getString("main_trad_bank_code"));
                     zz010m.setIntl_prch_trad_date(rs.getString("intl_prch_trad_date"));
                     zz010m.setPrch_trad_prmt_indc(rs.getString("prch_trad_prmt_indc"));
                     zz010m.setAdvc_pay_indc(rs.getString("advc_pay_indc"));
                     zz010m.setPrch_vndr_grd_code(rs.getString("prch_vndr_grd_code"));
                     zz010m.setPrch_vndr_prod_item(rs.getString("prch_vndr_prod_item"));
                     zz010m.setProd_type_code(rs.getString("prod_type_code"));
                     zz010m.setCmdy_code(rs.getString("cmdy_code"));
                     zz010m.setAdms_assc_name(rs.getString("adms_assc_name"));
                     zz010m.setOthr_maj_deal_co_name(rs.getString("othr_maj_deal_co_name"));
                     zz010m.setOthr_deal_co_dpdc_rate(rs.getDouble("othr_deal_co_dpdc_rate"));
                     zz010m.setBuyr_emp_no(rs.getString("buyr_emp_no"));
                     zz010m.setPrch_trad_rgsr_reqr(rs.getString("prch_trad_rgsr_reqr"));
                     zz010m.setPrch_trad_stop_reqr(rs.getString("prch_trad_stop_reqr"));
                     zz010m.setPrch_trad_stop_date(rs.getString("prch_trad_stop_date"));
                     zz010m.setPrch_trad_stop_rsn(rs.getString("prch_trad_stop_rsn"));
                     zz010m.setBsns_chrg_name_1(rs.getString("bsns_chrg_name_1"));
                     zz010m.setBsns_chrg_grd_ds_1(rs.getString("bsns_chrg_grd_ds_1"));
                     zz010m.setBsns_chrg_tel_no_1(rs.getString("bsns_chrg_tel_no_1"));
                     zz010m.setBsns_chrg_fax_no_1(rs.getString("bsns_chrg_fax_no_1"));
                     zz010m.setBsns_chrg_name_2(rs.getString("bsns_chrg_name_2"));
                     zz010m.setBsns_chrg_grd_ds_2(rs.getString("bsns_chrg_grd_ds_2"));
                     zz010m.setBsns_chrg_tel_no_2(rs.getString("bsns_chrg_tel_no_2"));
                     zz010m.setBsns_chrg_fax_no_2(rs.getString("bsns_chrg_fax_no_2"));
                     zz010m.setPrch_sys_vndr_id(rs.getString("prch_sys_vndr_id"));
                     zz010m.setVan_sys_indc(rs.getString("van_sys_indc"));
                     zz010m.setVan_sys_user_id(rs.getString("van_sys_user_id"));
                     zz010m.setVan_sys_pswd(rs.getString("van_sys_pswd"));
                     zz010m.setIntn_mail_id(rs.getString("intn_mail_id"));
                     zz010m.setSec_insp_rgsr_no(rs.getString("sec_insp_rgsr_no"));
                     zz010m.setSec_insp_rgdt(rs.getString("sec_insp_rgdt"));
                     zz010m.setSec_insp_fd(rs.getString("sec_insp_fd"));
                     zz010m.setDept_code(rs.getString("dept_code"));
                     zz010m.setComp_tel_no(rs.getString("comp_tel_no"));
                     zz010m.setInd_dstr_insr_type(rs.getString("ind_dstr_insr_type"));
                     zz010m.setCstr_vndr_grd_code(rs.getString("cstr_vndr_grd_code"));
                     zz010m.setCstr_vndr_main_work(rs.getString("cstr_vndr_main_work"));
                     zz010m.setCstr_prmt_indc(rs.getString("cstr_prmt_indc"));
                     zz010m.setInc_outc_id(rs.getString("inc_outc_id"));
                     zz010m.setRglr_once_id(rs.getString("rglr_once_id"));
                     zz010m.setCnrt_ogan_code(rs.getString("cnrt_ogan_code"));
                     zz010m.setIntl_cstr_date(rs.getString("intl_cstr_date"));
                     zz010m.setNote_acct_no(rs.getString("note_acct_no"));
                     zz010m.setDpst_name_kor(rs.getString("dpst_name_kor"));
                     zz010m.setOthr_acct_no(rs.getString("othr_acct_no"));
                     zz010m.setFirm_bank_id(rs.getString("firm_bank_id"));
                     zz010m.setCash_acct_no(rs.getString("cash_acct_no"));
                     zz010m.setAcct_trad_cls_date(rs.getString("acct_trad_cls_date"));
                     zz010m.setAcct_vndr_grd_code(rs.getString("acct_vndr_grd_code"));
                     zz010m.setPay_cndn_type(rs.getString("pay_cndn_type"));
                     zz010m.setExpd_bank_code(rs.getString("expd_bank_code"));
                     zz010m.setRgsr_ogan_id(rs.getString("rgsr_ogan_id"));
                     zz010m.setApp_sys_user_type(rs.getString("app_sys_user_type"));
                     zz010m.setPrch_vndr_indc(rs.getString("prch_vndr_indc"));
                     zz010m.setCstr_vndr_indc(rs.getString("cstr_vndr_indc"));
                     zz010m.setRgdt(rs.getString("rgdt"));
                     zz010m.setRgsr_rsn(rs.getString("rgsr_rsn"));
                     zz010m.setLmd(rs.getString("lmd"));
                     zz010m.setNew_vndr_code(rs.getString("new_vndr_code"));
                     zz010m.setBank_desc(rs.getString("bank_desc"));
                     zz010m.setAcct_vndr_indc(rs.getString("acct_vndr_indc"));
                     zz010m.setEmp_no_updt(rs.getString("emp_no_updt"));
                     zz010m.setRegn_id(rs.getString("regn_id"));
                     zz010m.setVndr_home_page(rs.getString("vndr_home_page"));
                     zz010m.setTbcd_ccsn_date(rs.getString("tbcd_ccsn_date"));
                     zz010m.setTbcd_effc_date(rs.getString("tbcd_effc_date"));
                     zz010m.setTbcd_chrg_emp_no(rs.getString("tbcd_chrg_emp_no"));
                     zz010m.setWldr_vndr_indc(rs.getString("wldr_vndr_indc"));
                     zz010m.setEnv_vndr_indc(rs.getString("env_vndr_indc"));
            ZZ010MV.addElement(zz010m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return ZZ010MV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-9
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector ZZ010MV = new java.util.Vector();
    ZZ010MRec zz010m = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM ET.ZZ010M "

  + whereOption; 
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            zz010m = new ZZ010MRec(); // ZZ010MRec Constructor
                     zz010m.setVndr_no(rs.getString("vndr_no"));
                     zz010m.setVndr_code(rs.getString("vndr_code"));
                     zz010m.setVndr_name_kor(rs.getString("vndr_name_kor"));
                     zz010m.setVndr_name_engl(rs.getString("vndr_name_engl"));
                     zz010m.setRpst_name_kor(rs.getString("rpst_name_kor"));
                     zz010m.setRpst_name_engl(rs.getString("rpst_name_engl"));
                     zz010m.setRpst_rr_no(rs.getString("rpst_rr_no"));
                     zz010m.setVndr_zip_code(rs.getString("vndr_zip_code"));
                     zz010m.setVndr_addr_kor(rs.getString("vndr_addr_kor"));
                     zz010m.setVndr_addr_engl(rs.getString("vndr_addr_engl"));
                     zz010m.setRpst_tel_no(rs.getString("rpst_tel_no"));
                     zz010m.setRpst_fax_no(rs.getString("rpst_fax_no"));
                     zz010m.setVndr_tlx_no(rs.getString("vndr_tlx_no"));
                     zz010m.setVndr_ho_zip_code(rs.getString("vndr_ho_zip_code"));
                     zz010m.setVndr_ho_addr(rs.getString("vndr_ho_addr"));
                     zz010m.setVndr_fcty_zip_code(rs.getString("vndr_fcty_zip_code"));
                     zz010m.setVndr_fcty_addr(rs.getString("vndr_fcty_addr"));
                     zz010m.setVndr_natn_code(rs.getString("vndr_natn_code"));
                     zz010m.setCo_type_code(rs.getString("co_type_code"));
                     zz010m.setInd_type_desc(rs.getString("ind_type_desc"));
                     zz010m.setInd_form_desc(rs.getString("ind_form_desc"));
                     zz010m.setVndr_type_code(rs.getString("vndr_type_code"));
                     zz010m.setCo_open_date(rs.getString("co_open_date"));
                     zz010m.setList_date(rs.getString("list_date"));
                     zz010m.setCrnt_list_indc(rs.getString("crnt_list_indc"));
                     zz010m.setAcct_sttl_mm(rs.getString("acct_sttl_mm"));
                     zz010m.setMgnt_emp_man_cnt(rs.getInt("mgnt_emp_man_cnt"));
                     zz010m.setProd_emp_man_cnt(rs.getInt("prod_emp_man_cnt"));
                     zz010m.setProd_per_sale_rate(rs.getDouble("prod_per_sale_rate"));
                     zz010m.setAffl_co_name(rs.getString("affl_co_name"));
                     zz010m.setFrgn_jnt_co_name(rs.getString("frgn_jnt_co_name"));
                     zz010m.setMain_trad_bank_code(rs.getString("main_trad_bank_code"));
                     zz010m.setIntl_prch_trad_date(rs.getString("intl_prch_trad_date"));
                     zz010m.setPrch_trad_prmt_indc(rs.getString("prch_trad_prmt_indc"));
                     zz010m.setAdvc_pay_indc(rs.getString("advc_pay_indc"));
                     zz010m.setPrch_vndr_grd_code(rs.getString("prch_vndr_grd_code"));
                     zz010m.setPrch_vndr_prod_item(rs.getString("prch_vndr_prod_item"));
                     zz010m.setProd_type_code(rs.getString("prod_type_code"));
                     zz010m.setCmdy_code(rs.getString("cmdy_code"));
                     zz010m.setAdms_assc_name(rs.getString("adms_assc_name"));
                     zz010m.setOthr_maj_deal_co_name(rs.getString("othr_maj_deal_co_name"));
                     zz010m.setOthr_deal_co_dpdc_rate(rs.getDouble("othr_deal_co_dpdc_rate"));
                     zz010m.setBuyr_emp_no(rs.getString("buyr_emp_no"));
                     zz010m.setPrch_trad_rgsr_reqr(rs.getString("prch_trad_rgsr_reqr"));
                     zz010m.setPrch_trad_stop_reqr(rs.getString("prch_trad_stop_reqr"));
                     zz010m.setPrch_trad_stop_date(rs.getString("prch_trad_stop_date"));
                     zz010m.setPrch_trad_stop_rsn(rs.getString("prch_trad_stop_rsn"));
                     zz010m.setBsns_chrg_name_1(rs.getString("bsns_chrg_name_1"));
                     zz010m.setBsns_chrg_grd_ds_1(rs.getString("bsns_chrg_grd_ds_1"));
                     zz010m.setBsns_chrg_tel_no_1(rs.getString("bsns_chrg_tel_no_1"));
                     zz010m.setBsns_chrg_fax_no_1(rs.getString("bsns_chrg_fax_no_1"));
                     zz010m.setBsns_chrg_name_2(rs.getString("bsns_chrg_name_2"));
                     zz010m.setBsns_chrg_grd_ds_2(rs.getString("bsns_chrg_grd_ds_2"));
                     zz010m.setBsns_chrg_tel_no_2(rs.getString("bsns_chrg_tel_no_2"));
                     zz010m.setBsns_chrg_fax_no_2(rs.getString("bsns_chrg_fax_no_2"));
                     zz010m.setPrch_sys_vndr_id(rs.getString("prch_sys_vndr_id"));
                     zz010m.setVan_sys_indc(rs.getString("van_sys_indc"));
                     zz010m.setVan_sys_user_id(rs.getString("van_sys_user_id"));
                     zz010m.setVan_sys_pswd(rs.getString("van_sys_pswd"));
                     zz010m.setIntn_mail_id(rs.getString("intn_mail_id"));
                     zz010m.setSec_insp_rgsr_no(rs.getString("sec_insp_rgsr_no"));
                     zz010m.setSec_insp_rgdt(rs.getString("sec_insp_rgdt"));
                     zz010m.setSec_insp_fd(rs.getString("sec_insp_fd"));
                     zz010m.setDept_code(rs.getString("dept_code"));
                     zz010m.setComp_tel_no(rs.getString("comp_tel_no"));
                     zz010m.setInd_dstr_insr_type(rs.getString("ind_dstr_insr_type"));
                     zz010m.setCstr_vndr_grd_code(rs.getString("cstr_vndr_grd_code"));
                     zz010m.setCstr_vndr_main_work(rs.getString("cstr_vndr_main_work"));
                     zz010m.setCstr_prmt_indc(rs.getString("cstr_prmt_indc"));
                     zz010m.setInc_outc_id(rs.getString("inc_outc_id"));
                     zz010m.setRglr_once_id(rs.getString("rglr_once_id"));
                     zz010m.setCnrt_ogan_code(rs.getString("cnrt_ogan_code"));
                     zz010m.setIntl_cstr_date(rs.getString("intl_cstr_date"));
                     zz010m.setNote_acct_no(rs.getString("note_acct_no"));
                     zz010m.setDpst_name_kor(rs.getString("dpst_name_kor"));
                     zz010m.setOthr_acct_no(rs.getString("othr_acct_no"));
                     zz010m.setFirm_bank_id(rs.getString("firm_bank_id"));
                     zz010m.setCash_acct_no(rs.getString("cash_acct_no"));
                     zz010m.setAcct_trad_cls_date(rs.getString("acct_trad_cls_date"));
                     zz010m.setAcct_vndr_grd_code(rs.getString("acct_vndr_grd_code"));
                     zz010m.setPay_cndn_type(rs.getString("pay_cndn_type"));
                     zz010m.setExpd_bank_code(rs.getString("expd_bank_code"));
                     zz010m.setRgsr_ogan_id(rs.getString("rgsr_ogan_id"));
                     zz010m.setApp_sys_user_type(rs.getString("app_sys_user_type"));
                     zz010m.setPrch_vndr_indc(rs.getString("prch_vndr_indc"));
                     zz010m.setCstr_vndr_indc(rs.getString("cstr_vndr_indc"));
                     zz010m.setRgdt(rs.getString("rgdt"));
                     zz010m.setRgsr_rsn(rs.getString("rgsr_rsn"));
                     zz010m.setLmd(rs.getString("lmd"));
                     zz010m.setNew_vndr_code(rs.getString("new_vndr_code"));
                     zz010m.setBank_desc(rs.getString("bank_desc"));
                     zz010m.setAcct_vndr_indc(rs.getString("acct_vndr_indc"));
                     zz010m.setEmp_no_updt(rs.getString("emp_no_updt"));
                     zz010m.setRegn_id(rs.getString("regn_id"));
                     zz010m.setVndr_home_page(rs.getString("vndr_home_page"));
                     zz010m.setTbcd_ccsn_date(rs.getString("tbcd_ccsn_date"));
                     zz010m.setTbcd_effc_date(rs.getString("tbcd_effc_date"));
                     zz010m.setTbcd_chrg_emp_no(rs.getString("tbcd_chrg_emp_no"));
                     zz010m.setWldr_vndr_indc(rs.getString("wldr_vndr_indc"));
                     zz010m.setEnv_vndr_indc(rs.getString("env_vndr_indc"));
            ZZ010MV.addElement(zz010m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return ZZ010MV;
} // end selectAll

/**
* Get Rows Count 
* @param String vndr_no
* @return int 
* @author besTeam 
* @date 2006-6-9
*/
public int count(String vndr_no) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " ET.ZZ010M "

		+ " where vndr_no = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,vndr_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-9
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " ET.ZZ010M "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}// end ZZ010MDBWrapBES class