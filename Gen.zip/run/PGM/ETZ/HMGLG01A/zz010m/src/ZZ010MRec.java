package com.bes_line.mst.ETZ ;

// Entity Class for ZZ010M
/**
 *
 * @(#) ZZ010MRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-9
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class ZZ010MRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String vndr_no; 		// (VARCHAR2, 15.0)
    public String vndr_code; 		// (CHAR, 4.0)
    public String vndr_name_kor; 		// (VARCHAR2, 100.0)
    public String vndr_name_engl; 		// (VARCHAR2, 100.0)
    public String rpst_name_kor; 		// (VARCHAR2, 20.0)
    public String rpst_name_engl; 		// (VARCHAR2, 30.0)
    public String rpst_rr_no; 		// (VARCHAR2, 18.0)
    public String vndr_zip_code; 		// (VARCHAR2, 10.0)
    public String vndr_addr_kor; 		// (VARCHAR2, 200.0)
    public String vndr_addr_engl; 		// (VARCHAR2, 200.0)
    public String rpst_tel_no; 		// (VARCHAR2, 15.0)
    public String rpst_fax_no; 		// (VARCHAR2, 15.0)
    public String vndr_tlx_no; 		// (VARCHAR2, 15.0)
    public String vndr_ho_zip_code; 		// (VARCHAR2, 6.0)
    public String vndr_ho_addr; 		// (VARCHAR2, 200.0)
    public String vndr_fcty_zip_code; 		// (VARCHAR2, 6.0)
    public String vndr_fcty_addr; 		// (VARCHAR2, 200.0)
    public String vndr_natn_code; 		// (VARCHAR2, 3.0)
    public String co_type_code; 		// (VARCHAR2, 2.0)
    public String ind_type_desc; 		// (VARCHAR2, 40.0)
    public String ind_form_desc; 		// (VARCHAR2, 40.0)
    public String vndr_type_code; 		// (CHAR, 1.0)
    public String co_open_date; 		// (VARCHAR2, 8.0)
    public String list_date; 		// (VARCHAR2, 8.0)
    public String crnt_list_indc; 		// (VARCHAR2, 1.0)
    public String acct_sttl_mm; 		// (VARCHAR2, 2.0)
    public int mgnt_emp_man_cnt; 		// (NUMBER, 7.0)
    public int prod_emp_man_cnt; 		// (NUMBER, 7.0)
    public double prod_per_sale_rate; 		// (NUMBER, 5.2)
    public String affl_co_name; 		// (VARCHAR2, 30.0)
    public String frgn_jnt_co_name; 		// (VARCHAR2, 40.0)
    public String main_trad_bank_code; 		// (VARCHAR2, 5.0)
    public String intl_prch_trad_date; 		// (VARCHAR2, 8.0)
    public String prch_trad_prmt_indc; 		// (VARCHAR2, 1.0)
    public String advc_pay_indc; 		// (CHAR, 1.0)
    public String prch_vndr_grd_code; 		// (VARCHAR2, 2.0)
    public String prch_vndr_prod_item; 		// (VARCHAR2, 1000.0)
    public String prod_type_code; 		// (CHAR, 1.0)
    public String cmdy_code; 		// (CHAR, 2.0)
    public String adms_assc_name; 		// (VARCHAR2, 30.0)
    public String othr_maj_deal_co_name; 		// (VARCHAR2, 40.0)
    public double othr_deal_co_dpdc_rate; 		// (NUMBER, 5.2)
    public String buyr_emp_no; 		// (VARCHAR2, 7.0)
    public String prch_trad_rgsr_reqr; 		// (VARCHAR2, 10.0)
    public String prch_trad_stop_reqr; 		// (VARCHAR2, 10.0)
    public String prch_trad_stop_date; 		// (VARCHAR2, 8.0)
    public String prch_trad_stop_rsn; 		// (VARCHAR2, 40.0)
    public String bsns_chrg_name_1; 		// (VARCHAR2, 10.0)
    public String bsns_chrg_grd_ds_1; 		// (VARCHAR2, 20.0)
    public String bsns_chrg_tel_no_1; 		// (VARCHAR2, 15.0)
    public String bsns_chrg_fax_no_1; 		// (VARCHAR2, 15.0)
    public String bsns_chrg_name_2; 		// (VARCHAR2, 10.0)
    public String bsns_chrg_grd_ds_2; 		// (VARCHAR2, 20.0)
    public String bsns_chrg_tel_no_2; 		// (VARCHAR2, 15.0)
    public String bsns_chrg_fax_no_2; 		// (VARCHAR2, 15.0)
    public String prch_sys_vndr_id; 		// (VARCHAR2, 2.0)
    public String van_sys_indc; 		// (CHAR, 1.0)
    public String van_sys_user_id; 		// (VARCHAR2, 8.0)
    public String van_sys_pswd; 		// (CHAR, 10.0)
    public String intn_mail_id; 		// (VARCHAR2, 30.0)
    public String sec_insp_rgsr_no; 		// (CHAR, 15.0)
    public String sec_insp_rgdt; 		// (VARCHAR2, 8.0)
    public String sec_insp_fd; 		// (VARCHAR2, 8.0)
    public String dept_code; 		// (CHAR, 4.0)
    public String comp_tel_no; 		// (VARCHAR2, 8.0)
    public String ind_dstr_insr_type; 		// (CHAR, 1.0)
    public String cstr_vndr_grd_code; 		// (VARCHAR2, 2.0)
    public String cstr_vndr_main_work; 		// (VARCHAR2, 30.0)
    public String cstr_prmt_indc; 		// (VARCHAR2, 1.0)
    public String inc_outc_id; 		// (VARCHAR2, 1.0)
    public String rglr_once_id; 		// (VARCHAR2, 1.0)
    public String cnrt_ogan_code; 		// (CHAR, 6.0)
    public String intl_cstr_date; 		// (VARCHAR2, 8.0)
    public String note_acct_no; 		// (CHAR, 20.0)
    public String dpst_name_kor; 		// (VARCHAR2, 30.0)
    public String othr_acct_no; 		// (VARCHAR2, 20.0)
    public String firm_bank_id; 		// (CHAR, 1.0)
    public String cash_acct_no; 		// (VARCHAR2, 20.0)
    public String acct_trad_cls_date; 		// (VARCHAR2, 8.0)
    public String acct_vndr_grd_code; 		// (VARCHAR2, 2.0)
    public String pay_cndn_type; 		// (VARCHAR2, 1.0)
    public String expd_bank_code; 		// (CHAR, 2.0)
    public String rgsr_ogan_id; 		// (VARCHAR2, 1.0)
    public String app_sys_user_type; 		// (VARCHAR2, 1.0)
    public String prch_vndr_indc; 		// (VARCHAR2, 1.0)
    public String cstr_vndr_indc; 		// (VARCHAR2, 1.0)
    public String rgdt; 		// (CHAR, 8.0)
    public String rgsr_rsn; 		// (VARCHAR2, 120.0)
    public String lmd; 		// (CHAR, 8.0)
    public String new_vndr_code; 		// (VARCHAR2, 4.0)
    public String bank_desc; 		// (VARCHAR2, 80.0)
    public String acct_vndr_indc; 		// (VARCHAR2, 1.0)
    public String emp_no_updt; 		// (VARCHAR2, 7.0)
    public String regn_id; 		// (CHAR, 1.0)
    public String vndr_home_page; 		// (VARCHAR2, 100.0)
    public String tbcd_ccsn_date; 		// (VARCHAR2, 8.0)
    public String tbcd_effc_date; 		// (VARCHAR2, 8.0)
    public String tbcd_chrg_emp_no; 		// (VARCHAR2, 7.0)
    public String wldr_vndr_indc; 		// (CHAR, 1.0)
    public String env_vndr_indc; 		// (VARCHAR2, 1.0)

public ZZ010MRec(){ } // default constructor

public ZZ010MRec(
       String vndr_no, String vndr_code, String vndr_name_kor, String vndr_name_engl, String rpst_name_kor, String rpst_name_engl, 
       String rpst_rr_no, String vndr_zip_code, String vndr_addr_kor, String vndr_addr_engl, String rpst_tel_no, String rpst_fax_no, 
       String vndr_tlx_no, String vndr_ho_zip_code, String vndr_ho_addr, String vndr_fcty_zip_code, String vndr_fcty_addr, String vndr_natn_code, 
       String co_type_code, String ind_type_desc, String ind_form_desc, String vndr_type_code, String co_open_date, String list_date, 
       String crnt_list_indc, String acct_sttl_mm, int mgnt_emp_man_cnt, int prod_emp_man_cnt, double prod_per_sale_rate, String affl_co_name, 
       String frgn_jnt_co_name, String main_trad_bank_code, String intl_prch_trad_date, String prch_trad_prmt_indc, String advc_pay_indc, String prch_vndr_grd_code, 
       String prch_vndr_prod_item, String prod_type_code, String cmdy_code, String adms_assc_name, String othr_maj_deal_co_name, double othr_deal_co_dpdc_rate, 
       String buyr_emp_no, String prch_trad_rgsr_reqr, String prch_trad_stop_reqr, String prch_trad_stop_date, String prch_trad_stop_rsn, String bsns_chrg_name_1, 
       String bsns_chrg_grd_ds_1, String bsns_chrg_tel_no_1, String bsns_chrg_fax_no_1, String bsns_chrg_name_2, String bsns_chrg_grd_ds_2, String bsns_chrg_tel_no_2, 
       String bsns_chrg_fax_no_2, String prch_sys_vndr_id, String van_sys_indc, String van_sys_user_id, String van_sys_pswd, String intn_mail_id, 
       String sec_insp_rgsr_no, String sec_insp_rgdt, String sec_insp_fd, String dept_code, String comp_tel_no, String ind_dstr_insr_type, 
       String cstr_vndr_grd_code, String cstr_vndr_main_work, String cstr_prmt_indc, String inc_outc_id, String rglr_once_id, String cnrt_ogan_code, 
       String intl_cstr_date, String note_acct_no, String dpst_name_kor, String othr_acct_no, String firm_bank_id, String cash_acct_no, 
       String acct_trad_cls_date, String acct_vndr_grd_code, String pay_cndn_type, String expd_bank_code, String rgsr_ogan_id, String app_sys_user_type, 
       String prch_vndr_indc, String cstr_vndr_indc, String rgdt, String rgsr_rsn, String lmd, String new_vndr_code, 
       String bank_desc, String acct_vndr_indc, String emp_no_updt, String regn_id, String vndr_home_page, String tbcd_ccsn_date, 
       String tbcd_effc_date, String tbcd_chrg_emp_no, String wldr_vndr_indc, String env_vndr_indc){
    this.vndr_no = vndr_no;
    this.vndr_code = vndr_code;
    this.vndr_name_kor = vndr_name_kor;
    this.vndr_name_engl = vndr_name_engl;
    this.rpst_name_kor = rpst_name_kor;
    this.rpst_name_engl = rpst_name_engl;
    this.rpst_rr_no = rpst_rr_no;
    this.vndr_zip_code = vndr_zip_code;
    this.vndr_addr_kor = vndr_addr_kor;
    this.vndr_addr_engl = vndr_addr_engl;
    this.rpst_tel_no = rpst_tel_no;
    this.rpst_fax_no = rpst_fax_no;
    this.vndr_tlx_no = vndr_tlx_no;
    this.vndr_ho_zip_code = vndr_ho_zip_code;
    this.vndr_ho_addr = vndr_ho_addr;
    this.vndr_fcty_zip_code = vndr_fcty_zip_code;
    this.vndr_fcty_addr = vndr_fcty_addr;
    this.vndr_natn_code = vndr_natn_code;
    this.co_type_code = co_type_code;
    this.ind_type_desc = ind_type_desc;
    this.ind_form_desc = ind_form_desc;
    this.vndr_type_code = vndr_type_code;
    this.co_open_date = co_open_date;
    this.list_date = list_date;
    this.crnt_list_indc = crnt_list_indc;
    this.acct_sttl_mm = acct_sttl_mm;
    this.mgnt_emp_man_cnt = mgnt_emp_man_cnt;
    this.prod_emp_man_cnt = prod_emp_man_cnt;
    this.prod_per_sale_rate = prod_per_sale_rate;
    this.affl_co_name = affl_co_name;
    this.frgn_jnt_co_name = frgn_jnt_co_name;
    this.main_trad_bank_code = main_trad_bank_code;
    this.intl_prch_trad_date = intl_prch_trad_date;
    this.prch_trad_prmt_indc = prch_trad_prmt_indc;
    this.advc_pay_indc = advc_pay_indc;
    this.prch_vndr_grd_code = prch_vndr_grd_code;
    this.prch_vndr_prod_item = prch_vndr_prod_item;
    this.prod_type_code = prod_type_code;
    this.cmdy_code = cmdy_code;
    this.adms_assc_name = adms_assc_name;
    this.othr_maj_deal_co_name = othr_maj_deal_co_name;
    this.othr_deal_co_dpdc_rate = othr_deal_co_dpdc_rate;
    this.buyr_emp_no = buyr_emp_no;
    this.prch_trad_rgsr_reqr = prch_trad_rgsr_reqr;
    this.prch_trad_stop_reqr = prch_trad_stop_reqr;
    this.prch_trad_stop_date = prch_trad_stop_date;
    this.prch_trad_stop_rsn = prch_trad_stop_rsn;
    this.bsns_chrg_name_1 = bsns_chrg_name_1;
    this.bsns_chrg_grd_ds_1 = bsns_chrg_grd_ds_1;
    this.bsns_chrg_tel_no_1 = bsns_chrg_tel_no_1;
    this.bsns_chrg_fax_no_1 = bsns_chrg_fax_no_1;
    this.bsns_chrg_name_2 = bsns_chrg_name_2;
    this.bsns_chrg_grd_ds_2 = bsns_chrg_grd_ds_2;
    this.bsns_chrg_tel_no_2 = bsns_chrg_tel_no_2;
    this.bsns_chrg_fax_no_2 = bsns_chrg_fax_no_2;
    this.prch_sys_vndr_id = prch_sys_vndr_id;
    this.van_sys_indc = van_sys_indc;
    this.van_sys_user_id = van_sys_user_id;
    this.van_sys_pswd = van_sys_pswd;
    this.intn_mail_id = intn_mail_id;
    this.sec_insp_rgsr_no = sec_insp_rgsr_no;
    this.sec_insp_rgdt = sec_insp_rgdt;
    this.sec_insp_fd = sec_insp_fd;
    this.dept_code = dept_code;
    this.comp_tel_no = comp_tel_no;
    this.ind_dstr_insr_type = ind_dstr_insr_type;
    this.cstr_vndr_grd_code = cstr_vndr_grd_code;
    this.cstr_vndr_main_work = cstr_vndr_main_work;
    this.cstr_prmt_indc = cstr_prmt_indc;
    this.inc_outc_id = inc_outc_id;
    this.rglr_once_id = rglr_once_id;
    this.cnrt_ogan_code = cnrt_ogan_code;
    this.intl_cstr_date = intl_cstr_date;
    this.note_acct_no = note_acct_no;
    this.dpst_name_kor = dpst_name_kor;
    this.othr_acct_no = othr_acct_no;
    this.firm_bank_id = firm_bank_id;
    this.cash_acct_no = cash_acct_no;
    this.acct_trad_cls_date = acct_trad_cls_date;
    this.acct_vndr_grd_code = acct_vndr_grd_code;
    this.pay_cndn_type = pay_cndn_type;
    this.expd_bank_code = expd_bank_code;
    this.rgsr_ogan_id = rgsr_ogan_id;
    this.app_sys_user_type = app_sys_user_type;
    this.prch_vndr_indc = prch_vndr_indc;
    this.cstr_vndr_indc = cstr_vndr_indc;
    this.rgdt = rgdt;
    this.rgsr_rsn = rgsr_rsn;
    this.lmd = lmd;
    this.new_vndr_code = new_vndr_code;
    this.bank_desc = bank_desc;
    this.acct_vndr_indc = acct_vndr_indc;
    this.emp_no_updt = emp_no_updt;
    this.regn_id = regn_id;
    this.vndr_home_page = vndr_home_page;
    this.tbcd_ccsn_date = tbcd_ccsn_date;
    this.tbcd_effc_date = tbcd_effc_date;
    this.tbcd_chrg_emp_no = tbcd_chrg_emp_no;
    this.wldr_vndr_indc = wldr_vndr_indc;
    this.env_vndr_indc = env_vndr_indc;
} // Constructor


// Getter 
public String getVndr_no(){ return vndr_no;}
public String getVndr_code(){ return vndr_code;}
public String getVndr_name_kor(){ return vndr_name_kor;}
public String getVndr_name_engl(){ return vndr_name_engl;}
public String getRpst_name_kor(){ return rpst_name_kor;}
public String getRpst_name_engl(){ return rpst_name_engl;}
public String getRpst_rr_no(){ return rpst_rr_no;}
public String getVndr_zip_code(){ return vndr_zip_code;}
public String getVndr_addr_kor(){ return vndr_addr_kor;}
public String getVndr_addr_engl(){ return vndr_addr_engl;}
public String getRpst_tel_no(){ return rpst_tel_no;}
public String getRpst_fax_no(){ return rpst_fax_no;}
public String getVndr_tlx_no(){ return vndr_tlx_no;}
public String getVndr_ho_zip_code(){ return vndr_ho_zip_code;}
public String getVndr_ho_addr(){ return vndr_ho_addr;}
public String getVndr_fcty_zip_code(){ return vndr_fcty_zip_code;}
public String getVndr_fcty_addr(){ return vndr_fcty_addr;}
public String getVndr_natn_code(){ return vndr_natn_code;}
public String getCo_type_code(){ return co_type_code;}
public String getInd_type_desc(){ return ind_type_desc;}
public String getInd_form_desc(){ return ind_form_desc;}
public String getVndr_type_code(){ return vndr_type_code;}
public String getCo_open_date(){ return co_open_date;}
public String getList_date(){ return list_date;}
public String getCrnt_list_indc(){ return crnt_list_indc;}
public String getAcct_sttl_mm(){ return acct_sttl_mm;}
public int getMgnt_emp_man_cnt(){ return mgnt_emp_man_cnt;}
public int getProd_emp_man_cnt(){ return prod_emp_man_cnt;}
public double getProd_per_sale_rate(){ return prod_per_sale_rate;}
public String getAffl_co_name(){ return affl_co_name;}
public String getFrgn_jnt_co_name(){ return frgn_jnt_co_name;}
public String getMain_trad_bank_code(){ return main_trad_bank_code;}
public String getIntl_prch_trad_date(){ return intl_prch_trad_date;}
public String getPrch_trad_prmt_indc(){ return prch_trad_prmt_indc;}
public String getAdvc_pay_indc(){ return advc_pay_indc;}
public String getPrch_vndr_grd_code(){ return prch_vndr_grd_code;}
public String getPrch_vndr_prod_item(){ return prch_vndr_prod_item;}
public String getProd_type_code(){ return prod_type_code;}
public String getCmdy_code(){ return cmdy_code;}
public String getAdms_assc_name(){ return adms_assc_name;}
public String getOthr_maj_deal_co_name(){ return othr_maj_deal_co_name;}
public double getOthr_deal_co_dpdc_rate(){ return othr_deal_co_dpdc_rate;}
public String getBuyr_emp_no(){ return buyr_emp_no;}
public String getPrch_trad_rgsr_reqr(){ return prch_trad_rgsr_reqr;}
public String getPrch_trad_stop_reqr(){ return prch_trad_stop_reqr;}
public String getPrch_trad_stop_date(){ return prch_trad_stop_date;}
public String getPrch_trad_stop_rsn(){ return prch_trad_stop_rsn;}
public String getBsns_chrg_name_1(){ return bsns_chrg_name_1;}
public String getBsns_chrg_grd_ds_1(){ return bsns_chrg_grd_ds_1;}
public String getBsns_chrg_tel_no_1(){ return bsns_chrg_tel_no_1;}
public String getBsns_chrg_fax_no_1(){ return bsns_chrg_fax_no_1;}
public String getBsns_chrg_name_2(){ return bsns_chrg_name_2;}
public String getBsns_chrg_grd_ds_2(){ return bsns_chrg_grd_ds_2;}
public String getBsns_chrg_tel_no_2(){ return bsns_chrg_tel_no_2;}
public String getBsns_chrg_fax_no_2(){ return bsns_chrg_fax_no_2;}
public String getPrch_sys_vndr_id(){ return prch_sys_vndr_id;}
public String getVan_sys_indc(){ return van_sys_indc;}
public String getVan_sys_user_id(){ return van_sys_user_id;}
public String getVan_sys_pswd(){ return van_sys_pswd;}
public String getIntn_mail_id(){ return intn_mail_id;}
public String getSec_insp_rgsr_no(){ return sec_insp_rgsr_no;}
public String getSec_insp_rgdt(){ return sec_insp_rgdt;}
public String getSec_insp_fd(){ return sec_insp_fd;}
public String getDept_code(){ return dept_code;}
public String getComp_tel_no(){ return comp_tel_no;}
public String getInd_dstr_insr_type(){ return ind_dstr_insr_type;}
public String getCstr_vndr_grd_code(){ return cstr_vndr_grd_code;}
public String getCstr_vndr_main_work(){ return cstr_vndr_main_work;}
public String getCstr_prmt_indc(){ return cstr_prmt_indc;}
public String getInc_outc_id(){ return inc_outc_id;}
public String getRglr_once_id(){ return rglr_once_id;}
public String getCnrt_ogan_code(){ return cnrt_ogan_code;}
public String getIntl_cstr_date(){ return intl_cstr_date;}
public String getNote_acct_no(){ return note_acct_no;}
public String getDpst_name_kor(){ return dpst_name_kor;}
public String getOthr_acct_no(){ return othr_acct_no;}
public String getFirm_bank_id(){ return firm_bank_id;}
public String getCash_acct_no(){ return cash_acct_no;}
public String getAcct_trad_cls_date(){ return acct_trad_cls_date;}
public String getAcct_vndr_grd_code(){ return acct_vndr_grd_code;}
public String getPay_cndn_type(){ return pay_cndn_type;}
public String getExpd_bank_code(){ return expd_bank_code;}
public String getRgsr_ogan_id(){ return rgsr_ogan_id;}
public String getApp_sys_user_type(){ return app_sys_user_type;}
public String getPrch_vndr_indc(){ return prch_vndr_indc;}
public String getCstr_vndr_indc(){ return cstr_vndr_indc;}
public String getRgdt(){ return rgdt;}
public String getRgsr_rsn(){ return rgsr_rsn;}
public String getLmd(){ return lmd;}
public String getNew_vndr_code(){ return new_vndr_code;}
public String getBank_desc(){ return bank_desc;}
public String getAcct_vndr_indc(){ return acct_vndr_indc;}
public String getEmp_no_updt(){ return emp_no_updt;}
public String getRegn_id(){ return regn_id;}
public String getVndr_home_page(){ return vndr_home_page;}
public String getTbcd_ccsn_date(){ return tbcd_ccsn_date;}
public String getTbcd_effc_date(){ return tbcd_effc_date;}
public String getTbcd_chrg_emp_no(){ return tbcd_chrg_emp_no;}
public String getWldr_vndr_indc(){ return wldr_vndr_indc;}
public String getEnv_vndr_indc(){ return env_vndr_indc;}

// Setter 
public void setVndr_no(String vndr_no){ this.vndr_no = vndr_no;}
public void setVndr_code(String vndr_code){ this.vndr_code = vndr_code;}
public void setVndr_name_kor(String vndr_name_kor){ this.vndr_name_kor = vndr_name_kor;}
public void setVndr_name_engl(String vndr_name_engl){ this.vndr_name_engl = vndr_name_engl;}
public void setRpst_name_kor(String rpst_name_kor){ this.rpst_name_kor = rpst_name_kor;}
public void setRpst_name_engl(String rpst_name_engl){ this.rpst_name_engl = rpst_name_engl;}
public void setRpst_rr_no(String rpst_rr_no){ this.rpst_rr_no = rpst_rr_no;}
public void setVndr_zip_code(String vndr_zip_code){ this.vndr_zip_code = vndr_zip_code;}
public void setVndr_addr_kor(String vndr_addr_kor){ this.vndr_addr_kor = vndr_addr_kor;}
public void setVndr_addr_engl(String vndr_addr_engl){ this.vndr_addr_engl = vndr_addr_engl;}
public void setRpst_tel_no(String rpst_tel_no){ this.rpst_tel_no = rpst_tel_no;}
public void setRpst_fax_no(String rpst_fax_no){ this.rpst_fax_no = rpst_fax_no;}
public void setVndr_tlx_no(String vndr_tlx_no){ this.vndr_tlx_no = vndr_tlx_no;}
public void setVndr_ho_zip_code(String vndr_ho_zip_code){ this.vndr_ho_zip_code = vndr_ho_zip_code;}
public void setVndr_ho_addr(String vndr_ho_addr){ this.vndr_ho_addr = vndr_ho_addr;}
public void setVndr_fcty_zip_code(String vndr_fcty_zip_code){ this.vndr_fcty_zip_code = vndr_fcty_zip_code;}
public void setVndr_fcty_addr(String vndr_fcty_addr){ this.vndr_fcty_addr = vndr_fcty_addr;}
public void setVndr_natn_code(String vndr_natn_code){ this.vndr_natn_code = vndr_natn_code;}
public void setCo_type_code(String co_type_code){ this.co_type_code = co_type_code;}
public void setInd_type_desc(String ind_type_desc){ this.ind_type_desc = ind_type_desc;}
public void setInd_form_desc(String ind_form_desc){ this.ind_form_desc = ind_form_desc;}
public void setVndr_type_code(String vndr_type_code){ this.vndr_type_code = vndr_type_code;}
public void setCo_open_date(String co_open_date){ this.co_open_date = co_open_date;}
public void setList_date(String list_date){ this.list_date = list_date;}
public void setCrnt_list_indc(String crnt_list_indc){ this.crnt_list_indc = crnt_list_indc;}
public void setAcct_sttl_mm(String acct_sttl_mm){ this.acct_sttl_mm = acct_sttl_mm;}
public void setMgnt_emp_man_cnt(int mgnt_emp_man_cnt){ this.mgnt_emp_man_cnt = mgnt_emp_man_cnt;}
public void setProd_emp_man_cnt(int prod_emp_man_cnt){ this.prod_emp_man_cnt = prod_emp_man_cnt;}
public void setProd_per_sale_rate(double prod_per_sale_rate){ this.prod_per_sale_rate = prod_per_sale_rate;}
public void setAffl_co_name(String affl_co_name){ this.affl_co_name = affl_co_name;}
public void setFrgn_jnt_co_name(String frgn_jnt_co_name){ this.frgn_jnt_co_name = frgn_jnt_co_name;}
public void setMain_trad_bank_code(String main_trad_bank_code){ this.main_trad_bank_code = main_trad_bank_code;}
public void setIntl_prch_trad_date(String intl_prch_trad_date){ this.intl_prch_trad_date = intl_prch_trad_date;}
public void setPrch_trad_prmt_indc(String prch_trad_prmt_indc){ this.prch_trad_prmt_indc = prch_trad_prmt_indc;}
public void setAdvc_pay_indc(String advc_pay_indc){ this.advc_pay_indc = advc_pay_indc;}
public void setPrch_vndr_grd_code(String prch_vndr_grd_code){ this.prch_vndr_grd_code = prch_vndr_grd_code;}
public void setPrch_vndr_prod_item(String prch_vndr_prod_item){ this.prch_vndr_prod_item = prch_vndr_prod_item;}
public void setProd_type_code(String prod_type_code){ this.prod_type_code = prod_type_code;}
public void setCmdy_code(String cmdy_code){ this.cmdy_code = cmdy_code;}
public void setAdms_assc_name(String adms_assc_name){ this.adms_assc_name = adms_assc_name;}
public void setOthr_maj_deal_co_name(String othr_maj_deal_co_name){ this.othr_maj_deal_co_name = othr_maj_deal_co_name;}
public void setOthr_deal_co_dpdc_rate(double othr_deal_co_dpdc_rate){ this.othr_deal_co_dpdc_rate = othr_deal_co_dpdc_rate;}
public void setBuyr_emp_no(String buyr_emp_no){ this.buyr_emp_no = buyr_emp_no;}
public void setPrch_trad_rgsr_reqr(String prch_trad_rgsr_reqr){ this.prch_trad_rgsr_reqr = prch_trad_rgsr_reqr;}
public void setPrch_trad_stop_reqr(String prch_trad_stop_reqr){ this.prch_trad_stop_reqr = prch_trad_stop_reqr;}
public void setPrch_trad_stop_date(String prch_trad_stop_date){ this.prch_trad_stop_date = prch_trad_stop_date;}
public void setPrch_trad_stop_rsn(String prch_trad_stop_rsn){ this.prch_trad_stop_rsn = prch_trad_stop_rsn;}
public void setBsns_chrg_name_1(String bsns_chrg_name_1){ this.bsns_chrg_name_1 = bsns_chrg_name_1;}
public void setBsns_chrg_grd_ds_1(String bsns_chrg_grd_ds_1){ this.bsns_chrg_grd_ds_1 = bsns_chrg_grd_ds_1;}
public void setBsns_chrg_tel_no_1(String bsns_chrg_tel_no_1){ this.bsns_chrg_tel_no_1 = bsns_chrg_tel_no_1;}
public void setBsns_chrg_fax_no_1(String bsns_chrg_fax_no_1){ this.bsns_chrg_fax_no_1 = bsns_chrg_fax_no_1;}
public void setBsns_chrg_name_2(String bsns_chrg_name_2){ this.bsns_chrg_name_2 = bsns_chrg_name_2;}
public void setBsns_chrg_grd_ds_2(String bsns_chrg_grd_ds_2){ this.bsns_chrg_grd_ds_2 = bsns_chrg_grd_ds_2;}
public void setBsns_chrg_tel_no_2(String bsns_chrg_tel_no_2){ this.bsns_chrg_tel_no_2 = bsns_chrg_tel_no_2;}
public void setBsns_chrg_fax_no_2(String bsns_chrg_fax_no_2){ this.bsns_chrg_fax_no_2 = bsns_chrg_fax_no_2;}
public void setPrch_sys_vndr_id(String prch_sys_vndr_id){ this.prch_sys_vndr_id = prch_sys_vndr_id;}
public void setVan_sys_indc(String van_sys_indc){ this.van_sys_indc = van_sys_indc;}
public void setVan_sys_user_id(String van_sys_user_id){ this.van_sys_user_id = van_sys_user_id;}
public void setVan_sys_pswd(String van_sys_pswd){ this.van_sys_pswd = van_sys_pswd;}
public void setIntn_mail_id(String intn_mail_id){ this.intn_mail_id = intn_mail_id;}
public void setSec_insp_rgsr_no(String sec_insp_rgsr_no){ this.sec_insp_rgsr_no = sec_insp_rgsr_no;}
public void setSec_insp_rgdt(String sec_insp_rgdt){ this.sec_insp_rgdt = sec_insp_rgdt;}
public void setSec_insp_fd(String sec_insp_fd){ this.sec_insp_fd = sec_insp_fd;}
public void setDept_code(String dept_code){ this.dept_code = dept_code;}
public void setComp_tel_no(String comp_tel_no){ this.comp_tel_no = comp_tel_no;}
public void setInd_dstr_insr_type(String ind_dstr_insr_type){ this.ind_dstr_insr_type = ind_dstr_insr_type;}
public void setCstr_vndr_grd_code(String cstr_vndr_grd_code){ this.cstr_vndr_grd_code = cstr_vndr_grd_code;}
public void setCstr_vndr_main_work(String cstr_vndr_main_work){ this.cstr_vndr_main_work = cstr_vndr_main_work;}
public void setCstr_prmt_indc(String cstr_prmt_indc){ this.cstr_prmt_indc = cstr_prmt_indc;}
public void setInc_outc_id(String inc_outc_id){ this.inc_outc_id = inc_outc_id;}
public void setRglr_once_id(String rglr_once_id){ this.rglr_once_id = rglr_once_id;}
public void setCnrt_ogan_code(String cnrt_ogan_code){ this.cnrt_ogan_code = cnrt_ogan_code;}
public void setIntl_cstr_date(String intl_cstr_date){ this.intl_cstr_date = intl_cstr_date;}
public void setNote_acct_no(String note_acct_no){ this.note_acct_no = note_acct_no;}
public void setDpst_name_kor(String dpst_name_kor){ this.dpst_name_kor = dpst_name_kor;}
public void setOthr_acct_no(String othr_acct_no){ this.othr_acct_no = othr_acct_no;}
public void setFirm_bank_id(String firm_bank_id){ this.firm_bank_id = firm_bank_id;}
public void setCash_acct_no(String cash_acct_no){ this.cash_acct_no = cash_acct_no;}
public void setAcct_trad_cls_date(String acct_trad_cls_date){ this.acct_trad_cls_date = acct_trad_cls_date;}
public void setAcct_vndr_grd_code(String acct_vndr_grd_code){ this.acct_vndr_grd_code = acct_vndr_grd_code;}
public void setPay_cndn_type(String pay_cndn_type){ this.pay_cndn_type = pay_cndn_type;}
public void setExpd_bank_code(String expd_bank_code){ this.expd_bank_code = expd_bank_code;}
public void setRgsr_ogan_id(String rgsr_ogan_id){ this.rgsr_ogan_id = rgsr_ogan_id;}
public void setApp_sys_user_type(String app_sys_user_type){ this.app_sys_user_type = app_sys_user_type;}
public void setPrch_vndr_indc(String prch_vndr_indc){ this.prch_vndr_indc = prch_vndr_indc;}
public void setCstr_vndr_indc(String cstr_vndr_indc){ this.cstr_vndr_indc = cstr_vndr_indc;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}
public void setRgsr_rsn(String rgsr_rsn){ this.rgsr_rsn = rgsr_rsn;}
public void setLmd(String lmd){ this.lmd = lmd;}
public void setNew_vndr_code(String new_vndr_code){ this.new_vndr_code = new_vndr_code;}
public void setBank_desc(String bank_desc){ this.bank_desc = bank_desc;}
public void setAcct_vndr_indc(String acct_vndr_indc){ this.acct_vndr_indc = acct_vndr_indc;}
public void setEmp_no_updt(String emp_no_updt){ this.emp_no_updt = emp_no_updt;}
public void setRegn_id(String regn_id){ this.regn_id = regn_id;}
public void setVndr_home_page(String vndr_home_page){ this.vndr_home_page = vndr_home_page;}
public void setTbcd_ccsn_date(String tbcd_ccsn_date){ this.tbcd_ccsn_date = tbcd_ccsn_date;}
public void setTbcd_effc_date(String tbcd_effc_date){ this.tbcd_effc_date = tbcd_effc_date;}
public void setTbcd_chrg_emp_no(String tbcd_chrg_emp_no){ this.tbcd_chrg_emp_no = tbcd_chrg_emp_no;}
public void setWldr_vndr_indc(String wldr_vndr_indc){ this.wldr_vndr_indc = wldr_vndr_indc;}
public void setEnv_vndr_indc(String env_vndr_indc){ this.env_vndr_indc = env_vndr_indc;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = vndr_no + "" ; break;
  case  2 : field = vndr_code + "" ; break;
  case  3 : field = vndr_name_kor + "" ; break;
  case  4 : field = vndr_name_engl + "" ; break;
  case  5 : field = rpst_name_kor + "" ; break;
  case  6 : field = rpst_name_engl + "" ; break;
  case  7 : field = rpst_rr_no + "" ; break;
  case  8 : field = vndr_zip_code + "" ; break;
  case  9 : field = vndr_addr_kor + "" ; break;
  case  10 : field = vndr_addr_engl + "" ; break;
  case  11 : field = rpst_tel_no + "" ; break;
  case  12 : field = rpst_fax_no + "" ; break;
  case  13 : field = vndr_tlx_no + "" ; break;
  case  14 : field = vndr_ho_zip_code + "" ; break;
  case  15 : field = vndr_ho_addr + "" ; break;
  case  16 : field = vndr_fcty_zip_code + "" ; break;
  case  17 : field = vndr_fcty_addr + "" ; break;
  case  18 : field = vndr_natn_code + "" ; break;
  case  19 : field = co_type_code + "" ; break;
  case  20 : field = ind_type_desc + "" ; break;
  case  21 : field = ind_form_desc + "" ; break;
  case  22 : field = vndr_type_code + "" ; break;
  case  23 : field = co_open_date + "" ; break;
  case  24 : field = list_date + "" ; break;
  case  25 : field = crnt_list_indc + "" ; break;
  case  26 : field = acct_sttl_mm + "" ; break;
  case  27 : field = mgnt_emp_man_cnt + "" ; break;
  case  28 : field = prod_emp_man_cnt + "" ; break;
  case  29 : field = prod_per_sale_rate + "" ; break;
  case  30 : field = affl_co_name + "" ; break;
  case  31 : field = frgn_jnt_co_name + "" ; break;
  case  32 : field = main_trad_bank_code + "" ; break;
  case  33 : field = intl_prch_trad_date + "" ; break;
  case  34 : field = prch_trad_prmt_indc + "" ; break;
  case  35 : field = advc_pay_indc + "" ; break;
  case  36 : field = prch_vndr_grd_code + "" ; break;
  case  37 : field = prch_vndr_prod_item + "" ; break;
  case  38 : field = prod_type_code + "" ; break;
  case  39 : field = cmdy_code + "" ; break;
  case  40 : field = adms_assc_name + "" ; break;
  case  41 : field = othr_maj_deal_co_name + "" ; break;
  case  42 : field = othr_deal_co_dpdc_rate + "" ; break;
  case  43 : field = buyr_emp_no + "" ; break;
  case  44 : field = prch_trad_rgsr_reqr + "" ; break;
  case  45 : field = prch_trad_stop_reqr + "" ; break;
  case  46 : field = prch_trad_stop_date + "" ; break;
  case  47 : field = prch_trad_stop_rsn + "" ; break;
  case  48 : field = bsns_chrg_name_1 + "" ; break;
  case  49 : field = bsns_chrg_grd_ds_1 + "" ; break;
  case  50 : field = bsns_chrg_tel_no_1 + "" ; break;
  case  51 : field = bsns_chrg_fax_no_1 + "" ; break;
  case  52 : field = bsns_chrg_name_2 + "" ; break;
  case  53 : field = bsns_chrg_grd_ds_2 + "" ; break;
  case  54 : field = bsns_chrg_tel_no_2 + "" ; break;
  case  55 : field = bsns_chrg_fax_no_2 + "" ; break;
  case  56 : field = prch_sys_vndr_id + "" ; break;
  case  57 : field = van_sys_indc + "" ; break;
  case  58 : field = van_sys_user_id + "" ; break;
  case  59 : field = van_sys_pswd + "" ; break;
  case  60 : field = intn_mail_id + "" ; break;
  case  61 : field = sec_insp_rgsr_no + "" ; break;
  case  62 : field = sec_insp_rgdt + "" ; break;
  case  63 : field = sec_insp_fd + "" ; break;
  case  64 : field = dept_code + "" ; break;
  case  65 : field = comp_tel_no + "" ; break;
  case  66 : field = ind_dstr_insr_type + "" ; break;
  case  67 : field = cstr_vndr_grd_code + "" ; break;
  case  68 : field = cstr_vndr_main_work + "" ; break;
  case  69 : field = cstr_prmt_indc + "" ; break;
  case  70 : field = inc_outc_id + "" ; break;
  case  71 : field = rglr_once_id + "" ; break;
  case  72 : field = cnrt_ogan_code + "" ; break;
  case  73 : field = intl_cstr_date + "" ; break;
  case  74 : field = note_acct_no + "" ; break;
  case  75 : field = dpst_name_kor + "" ; break;
  case  76 : field = othr_acct_no + "" ; break;
  case  77 : field = firm_bank_id + "" ; break;
  case  78 : field = cash_acct_no + "" ; break;
  case  79 : field = acct_trad_cls_date + "" ; break;
  case  80 : field = acct_vndr_grd_code + "" ; break;
  case  81 : field = pay_cndn_type + "" ; break;
  case  82 : field = expd_bank_code + "" ; break;
  case  83 : field = rgsr_ogan_id + "" ; break;
  case  84 : field = app_sys_user_type + "" ; break;
  case  85 : field = prch_vndr_indc + "" ; break;
  case  86 : field = cstr_vndr_indc + "" ; break;
  case  87 : field = rgdt + "" ; break;
  case  88 : field = rgsr_rsn + "" ; break;
  case  89 : field = lmd + "" ; break;
  case  90 : field = new_vndr_code + "" ; break;
  case  91 : field = bank_desc + "" ; break;
  case  92 : field = acct_vndr_indc + "" ; break;
  case  93 : field = emp_no_updt + "" ; break;
  case  94 : field = regn_id + "" ; break;
  case  95 : field = vndr_home_page + "" ; break;
  case  96 : field = tbcd_ccsn_date + "" ; break;
  case  97 : field = tbcd_effc_date + "" ; break;
  case  98 : field = tbcd_chrg_emp_no + "" ; break;
  case  99 : field = wldr_vndr_indc + "" ; break;
  case  100 : field = env_vndr_indc + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("vndr_no")){ field = vndr_no + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_code")){ field = vndr_code + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_name_kor")){ field = vndr_name_kor + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_name_engl")){ field = vndr_name_engl + "" ; 
     } else if(rec.equalsIgnoreCase("rpst_name_kor")){ field = rpst_name_kor + "" ; 
     } else if(rec.equalsIgnoreCase("rpst_name_engl")){ field = rpst_name_engl + "" ; 
     } else if(rec.equalsIgnoreCase("rpst_rr_no")){ field = rpst_rr_no + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_zip_code")){ field = vndr_zip_code + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_addr_kor")){ field = vndr_addr_kor + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_addr_engl")){ field = vndr_addr_engl + "" ; 
     } else if(rec.equalsIgnoreCase("rpst_tel_no")){ field = rpst_tel_no + "" ; 
     } else if(rec.equalsIgnoreCase("rpst_fax_no")){ field = rpst_fax_no + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_tlx_no")){ field = vndr_tlx_no + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_ho_zip_code")){ field = vndr_ho_zip_code + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_ho_addr")){ field = vndr_ho_addr + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_fcty_zip_code")){ field = vndr_fcty_zip_code + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_fcty_addr")){ field = vndr_fcty_addr + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_natn_code")){ field = vndr_natn_code + "" ; 
     } else if(rec.equalsIgnoreCase("co_type_code")){ field = co_type_code + "" ; 
     } else if(rec.equalsIgnoreCase("ind_type_desc")){ field = ind_type_desc + "" ; 
     } else if(rec.equalsIgnoreCase("ind_form_desc")){ field = ind_form_desc + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_type_code")){ field = vndr_type_code + "" ; 
     } else if(rec.equalsIgnoreCase("co_open_date")){ field = co_open_date + "" ; 
     } else if(rec.equalsIgnoreCase("list_date")){ field = list_date + "" ; 
     } else if(rec.equalsIgnoreCase("crnt_list_indc")){ field = crnt_list_indc + "" ; 
     } else if(rec.equalsIgnoreCase("acct_sttl_mm")){ field = acct_sttl_mm + "" ; 
     } else if(rec.equalsIgnoreCase("mgnt_emp_man_cnt")){ field = mgnt_emp_man_cnt + "" ; 
     } else if(rec.equalsIgnoreCase("prod_emp_man_cnt")){ field = prod_emp_man_cnt + "" ; 
     } else if(rec.equalsIgnoreCase("prod_per_sale_rate")){ field = prod_per_sale_rate + "" ; 
     } else if(rec.equalsIgnoreCase("affl_co_name")){ field = affl_co_name + "" ; 
     } else if(rec.equalsIgnoreCase("frgn_jnt_co_name")){ field = frgn_jnt_co_name + "" ; 
     } else if(rec.equalsIgnoreCase("main_trad_bank_code")){ field = main_trad_bank_code + "" ; 
     } else if(rec.equalsIgnoreCase("intl_prch_trad_date")){ field = intl_prch_trad_date + "" ; 
     } else if(rec.equalsIgnoreCase("prch_trad_prmt_indc")){ field = prch_trad_prmt_indc + "" ; 
     } else if(rec.equalsIgnoreCase("advc_pay_indc")){ field = advc_pay_indc + "" ; 
     } else if(rec.equalsIgnoreCase("prch_vndr_grd_code")){ field = prch_vndr_grd_code + "" ; 
     } else if(rec.equalsIgnoreCase("prch_vndr_prod_item")){ field = prch_vndr_prod_item + "" ; 
     } else if(rec.equalsIgnoreCase("prod_type_code")){ field = prod_type_code + "" ; 
     } else if(rec.equalsIgnoreCase("cmdy_code")){ field = cmdy_code + "" ; 
     } else if(rec.equalsIgnoreCase("adms_assc_name")){ field = adms_assc_name + "" ; 
     } else if(rec.equalsIgnoreCase("othr_maj_deal_co_name")){ field = othr_maj_deal_co_name + "" ; 
     } else if(rec.equalsIgnoreCase("othr_deal_co_dpdc_rate")){ field = othr_deal_co_dpdc_rate + "" ; 
     } else if(rec.equalsIgnoreCase("buyr_emp_no")){ field = buyr_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("prch_trad_rgsr_reqr")){ field = prch_trad_rgsr_reqr + "" ; 
     } else if(rec.equalsIgnoreCase("prch_trad_stop_reqr")){ field = prch_trad_stop_reqr + "" ; 
     } else if(rec.equalsIgnoreCase("prch_trad_stop_date")){ field = prch_trad_stop_date + "" ; 
     } else if(rec.equalsIgnoreCase("prch_trad_stop_rsn")){ field = prch_trad_stop_rsn + "" ; 
     } else if(rec.equalsIgnoreCase("bsns_chrg_name_1")){ field = bsns_chrg_name_1 + "" ; 
     } else if(rec.equalsIgnoreCase("bsns_chrg_grd_ds_1")){ field = bsns_chrg_grd_ds_1 + "" ; 
     } else if(rec.equalsIgnoreCase("bsns_chrg_tel_no_1")){ field = bsns_chrg_tel_no_1 + "" ; 
     } else if(rec.equalsIgnoreCase("bsns_chrg_fax_no_1")){ field = bsns_chrg_fax_no_1 + "" ; 
     } else if(rec.equalsIgnoreCase("bsns_chrg_name_2")){ field = bsns_chrg_name_2 + "" ; 
     } else if(rec.equalsIgnoreCase("bsns_chrg_grd_ds_2")){ field = bsns_chrg_grd_ds_2 + "" ; 
     } else if(rec.equalsIgnoreCase("bsns_chrg_tel_no_2")){ field = bsns_chrg_tel_no_2 + "" ; 
     } else if(rec.equalsIgnoreCase("bsns_chrg_fax_no_2")){ field = bsns_chrg_fax_no_2 + "" ; 
     } else if(rec.equalsIgnoreCase("prch_sys_vndr_id")){ field = prch_sys_vndr_id + "" ; 
     } else if(rec.equalsIgnoreCase("van_sys_indc")){ field = van_sys_indc + "" ; 
     } else if(rec.equalsIgnoreCase("van_sys_user_id")){ field = van_sys_user_id + "" ; 
     } else if(rec.equalsIgnoreCase("van_sys_pswd")){ field = van_sys_pswd + "" ; 
     } else if(rec.equalsIgnoreCase("intn_mail_id")){ field = intn_mail_id + "" ; 
     } else if(rec.equalsIgnoreCase("sec_insp_rgsr_no")){ field = sec_insp_rgsr_no + "" ; 
     } else if(rec.equalsIgnoreCase("sec_insp_rgdt")){ field = sec_insp_rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("sec_insp_fd")){ field = sec_insp_fd + "" ; 
     } else if(rec.equalsIgnoreCase("dept_code")){ field = dept_code + "" ; 
     } else if(rec.equalsIgnoreCase("comp_tel_no")){ field = comp_tel_no + "" ; 
     } else if(rec.equalsIgnoreCase("ind_dstr_insr_type")){ field = ind_dstr_insr_type + "" ; 
     } else if(rec.equalsIgnoreCase("cstr_vndr_grd_code")){ field = cstr_vndr_grd_code + "" ; 
     } else if(rec.equalsIgnoreCase("cstr_vndr_main_work")){ field = cstr_vndr_main_work + "" ; 
     } else if(rec.equalsIgnoreCase("cstr_prmt_indc")){ field = cstr_prmt_indc + "" ; 
     } else if(rec.equalsIgnoreCase("inc_outc_id")){ field = inc_outc_id + "" ; 
     } else if(rec.equalsIgnoreCase("rglr_once_id")){ field = rglr_once_id + "" ; 
     } else if(rec.equalsIgnoreCase("cnrt_ogan_code")){ field = cnrt_ogan_code + "" ; 
     } else if(rec.equalsIgnoreCase("intl_cstr_date")){ field = intl_cstr_date + "" ; 
     } else if(rec.equalsIgnoreCase("note_acct_no")){ field = note_acct_no + "" ; 
     } else if(rec.equalsIgnoreCase("dpst_name_kor")){ field = dpst_name_kor + "" ; 
     } else if(rec.equalsIgnoreCase("othr_acct_no")){ field = othr_acct_no + "" ; 
     } else if(rec.equalsIgnoreCase("firm_bank_id")){ field = firm_bank_id + "" ; 
     } else if(rec.equalsIgnoreCase("cash_acct_no")){ field = cash_acct_no + "" ; 
     } else if(rec.equalsIgnoreCase("acct_trad_cls_date")){ field = acct_trad_cls_date + "" ; 
     } else if(rec.equalsIgnoreCase("acct_vndr_grd_code")){ field = acct_vndr_grd_code + "" ; 
     } else if(rec.equalsIgnoreCase("pay_cndn_type")){ field = pay_cndn_type + "" ; 
     } else if(rec.equalsIgnoreCase("expd_bank_code")){ field = expd_bank_code + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_ogan_id")){ field = rgsr_ogan_id + "" ; 
     } else if(rec.equalsIgnoreCase("app_sys_user_type")){ field = app_sys_user_type + "" ; 
     } else if(rec.equalsIgnoreCase("prch_vndr_indc")){ field = prch_vndr_indc + "" ; 
     } else if(rec.equalsIgnoreCase("cstr_vndr_indc")){ field = cstr_vndr_indc + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_rsn")){ field = rgsr_rsn + "" ; 
     } else if(rec.equalsIgnoreCase("lmd")){ field = lmd + "" ; 
     } else if(rec.equalsIgnoreCase("new_vndr_code")){ field = new_vndr_code + "" ; 
     } else if(rec.equalsIgnoreCase("bank_desc")){ field = bank_desc + "" ; 
     } else if(rec.equalsIgnoreCase("acct_vndr_indc")){ field = acct_vndr_indc + "" ; 
     } else if(rec.equalsIgnoreCase("emp_no_updt")){ field = emp_no_updt + "" ; 
     } else if(rec.equalsIgnoreCase("regn_id")){ field = regn_id + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_home_page")){ field = vndr_home_page + "" ; 
     } else if(rec.equalsIgnoreCase("tbcd_ccsn_date")){ field = tbcd_ccsn_date + "" ; 
     } else if(rec.equalsIgnoreCase("tbcd_effc_date")){ field = tbcd_effc_date + "" ; 
     } else if(rec.equalsIgnoreCase("tbcd_chrg_emp_no")){ field = tbcd_chrg_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("wldr_vndr_indc")){ field = wldr_vndr_indc + "" ; 
     } else if(rec.equalsIgnoreCase("env_vndr_indc")){ field = env_vndr_indc + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "VNDR_NO", "VNDR_CODE", "VNDR_NAME_KOR", "VNDR_NAME_ENGL", "RPST_NAME_KOR", "RPST_NAME_ENGL", "RPST_RR_NO", 
       "VNDR_ZIP_CODE", "VNDR_ADDR_KOR", "VNDR_ADDR_ENGL", "RPST_TEL_NO", "RPST_FAX_NO", "VNDR_TLX_NO", "VNDR_HO_ZIP_CODE", 
       "VNDR_HO_ADDR", "VNDR_FCTY_ZIP_CODE", "VNDR_FCTY_ADDR", "VNDR_NATN_CODE", "CO_TYPE_CODE", "IND_TYPE_DESC", "IND_FORM_DESC", 
       "VNDR_TYPE_CODE", "CO_OPEN_DATE", "LIST_DATE", "CRNT_LIST_INDC", "ACCT_STTL_MM", "MGNT_EMP_MAN_CNT", "PROD_EMP_MAN_CNT", 
       "PROD_PER_SALE_RATE", "AFFL_CO_NAME", "FRGN_JNT_CO_NAME", "MAIN_TRAD_BANK_CODE", "INTL_PRCH_TRAD_DATE", "PRCH_TRAD_PRMT_INDC", "ADVC_PAY_INDC", 
       "PRCH_VNDR_GRD_CODE", "PRCH_VNDR_PROD_ITEM", "PROD_TYPE_CODE", "CMDY_CODE", "ADMS_ASSC_NAME", "OTHR_MAJ_DEAL_CO_NAME", "OTHR_DEAL_CO_DPDC_RATE", 
       "BUYR_EMP_NO", "PRCH_TRAD_RGSR_REQR", "PRCH_TRAD_STOP_REQR", "PRCH_TRAD_STOP_DATE", "PRCH_TRAD_STOP_RSN", "BSNS_CHRG_NAME_1", "BSNS_CHRG_GRD_DS_1", 
       "BSNS_CHRG_TEL_NO_1", "BSNS_CHRG_FAX_NO_1", "BSNS_CHRG_NAME_2", "BSNS_CHRG_GRD_DS_2", "BSNS_CHRG_TEL_NO_2", "BSNS_CHRG_FAX_NO_2", "PRCH_SYS_VNDR_ID", 
       "VAN_SYS_INDC", "VAN_SYS_USER_ID", "VAN_SYS_PSWD", "INTN_MAIL_ID", "SEC_INSP_RGSR_NO", "SEC_INSP_RGDT", "SEC_INSP_FD", 
       "DEPT_CODE", "COMP_TEL_NO", "IND_DSTR_INSR_TYPE", "CSTR_VNDR_GRD_CODE", "CSTR_VNDR_MAIN_WORK", "CSTR_PRMT_INDC", "INC_OUTC_ID", 
       "RGLR_ONCE_ID", "CNRT_OGAN_CODE", "INTL_CSTR_DATE", "NOTE_ACCT_NO", "DPST_NAME_KOR", "OTHR_ACCT_NO", "FIRM_BANK_ID", 
       "CASH_ACCT_NO", "ACCT_TRAD_CLS_DATE", "ACCT_VNDR_GRD_CODE", "PAY_CNDN_TYPE", "EXPD_BANK_CODE", "RGSR_OGAN_ID", "APP_SYS_USER_TYPE", 
       "PRCH_VNDR_INDC", "CSTR_VNDR_INDC", "RGDT", "RGSR_RSN", "LMD", "NEW_VNDR_CODE", "BANK_DESC", 
       "ACCT_VNDR_INDC", "EMP_NO_UPDT", "REGN_ID", "VNDR_HOME_PAGE", "TBCD_CCSN_DATE", "TBCD_EFFC_DATE", "TBCD_CHRG_EMP_NO", 
       "WLDR_VNDR_INDC", "ENV_VNDR_INDC"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "VNDR_NO"};
    return tempx;
}

}// end ZZ010MRec class