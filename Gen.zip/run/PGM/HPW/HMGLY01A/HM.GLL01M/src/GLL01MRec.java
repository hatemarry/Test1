package com.bes_line.mst.HPW ;

// Entity Class for HM.GLL01M
/**
 *
 * @(#) GLL01MRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-19
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLL01MRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String part_no; 		// (VARCHAR2, 18.0)
    public String part_proj_no; 		// (VARCHAR2, 4.0)
    public String part_flag; 		// (VARCHAR2, 1.0)
    public String part_mat_code; 		// (VARCHAR2, 13.0)
    public String uom; 		// (VARCHAR2, 2.0)
    public String cmdy_code; 		// (VARCHAR2, 2.0)
    public String src_code; 		// (VARCHAR2, 1.0)
    public double unit_wt; 		// (NUMBER, 10.3)
    public String part_desc; 		// (VARCHAR2, 56.0)
    public int ofe_due_qty; 		// (NUMBER, 7.0)
    public int oh_qty; 		// (NUMBER, 7.0)
    public int rsv_qty; 		// (NUMBER, 7.0)
    public String clsf_scty_code_1; 		// (VARCHAR2, 4.0)
    public String clsf_scty_code_2; 		// (VARCHAR2, 4.0)
    public String clsf_scty_code_3; 		// (VARCHAR2, 4.0)
    public String sys_id; 		// (VARCHAR2, 1.0)
    public int awat_qty; 		// (NUMBER, 7.0)
    public String buyr_id; 		// (VARCHAR2, 4.0)
    public String stor_id; 		// (VARCHAR2, 4.0)
    public String mat_maj_grp_code; 		// (VARCHAR2, 2.0)
    public String mat_grp_code; 		// (VARCHAR2, 9.0)
    public String mat_name_item; 		// (VARCHAR2, 11.0)
    public String mtl_mat_grd; 		// (VARCHAR2, 11.0)
    public double stl_thck_1; 		// (NUMBER, 5.1)
    public double stl_thck_2; 		// (NUMBER, 5.1)
    public int stl_bdth_1; 		// (NUMBER, 5.0)
    public int stl_bdth_2; 		// (NUMBER, 5.0)
    public int stl_lnth; 		// (NUMBER, 5.0)
    public String matl_clss; 		// (VARCHAR2, 1.0)
    public String rgdt; 		// (VARCHAR2, 8.0)
    public String lmd; 		// (VARCHAR2, 8.0)

public GLL01MRec(){ } // default constructor

public GLL01MRec(
       String part_no, String part_proj_no, String part_flag, String part_mat_code, String uom, String cmdy_code, 
       String src_code, double unit_wt, String part_desc, int ofe_due_qty, int oh_qty, int rsv_qty, 
       String clsf_scty_code_1, String clsf_scty_code_2, String clsf_scty_code_3, String sys_id, int awat_qty, String buyr_id, 
       String stor_id, String mat_maj_grp_code, String mat_grp_code, String mat_name_item, String mtl_mat_grd, double stl_thck_1, 
       double stl_thck_2, int stl_bdth_1, int stl_bdth_2, int stl_lnth, String matl_clss, String rgdt, 
       String lmd){
    this.part_no = part_no;
    this.part_proj_no = part_proj_no;
    this.part_flag = part_flag;
    this.part_mat_code = part_mat_code;
    this.uom = uom;
    this.cmdy_code = cmdy_code;
    this.src_code = src_code;
    this.unit_wt = unit_wt;
    this.part_desc = part_desc;
    this.ofe_due_qty = ofe_due_qty;
    this.oh_qty = oh_qty;
    this.rsv_qty = rsv_qty;
    this.clsf_scty_code_1 = clsf_scty_code_1;
    this.clsf_scty_code_2 = clsf_scty_code_2;
    this.clsf_scty_code_3 = clsf_scty_code_3;
    this.sys_id = sys_id;
    this.awat_qty = awat_qty;
    this.buyr_id = buyr_id;
    this.stor_id = stor_id;
    this.mat_maj_grp_code = mat_maj_grp_code;
    this.mat_grp_code = mat_grp_code;
    this.mat_name_item = mat_name_item;
    this.mtl_mat_grd = mtl_mat_grd;
    this.stl_thck_1 = stl_thck_1;
    this.stl_thck_2 = stl_thck_2;
    this.stl_bdth_1 = stl_bdth_1;
    this.stl_bdth_2 = stl_bdth_2;
    this.stl_lnth = stl_lnth;
    this.matl_clss = matl_clss;
    this.rgdt = rgdt;
    this.lmd = lmd;
} // Constructor


// Getter 
public String getPart_no(){ return part_no;}
public String getPart_proj_no(){ return part_proj_no;}
public String getPart_flag(){ return part_flag;}
public String getPart_mat_code(){ return part_mat_code;}
public String getUom(){ return uom;}
public String getCmdy_code(){ return cmdy_code;}
public String getSrc_code(){ return src_code;}
public double getUnit_wt(){ return unit_wt;}
public String getPart_desc(){ return part_desc;}
public int getOfe_due_qty(){ return ofe_due_qty;}
public int getOh_qty(){ return oh_qty;}
public int getRsv_qty(){ return rsv_qty;}
public String getClsf_scty_code_1(){ return clsf_scty_code_1;}
public String getClsf_scty_code_2(){ return clsf_scty_code_2;}
public String getClsf_scty_code_3(){ return clsf_scty_code_3;}
public String getSys_id(){ return sys_id;}
public int getAwat_qty(){ return awat_qty;}
public String getBuyr_id(){ return buyr_id;}
public String getStor_id(){ return stor_id;}
public String getMat_maj_grp_code(){ return mat_maj_grp_code;}
public String getMat_grp_code(){ return mat_grp_code;}
public String getMat_name_item(){ return mat_name_item;}
public String getMtl_mat_grd(){ return mtl_mat_grd;}
public double getStl_thck_1(){ return stl_thck_1;}
public double getStl_thck_2(){ return stl_thck_2;}
public int getStl_bdth_1(){ return stl_bdth_1;}
public int getStl_bdth_2(){ return stl_bdth_2;}
public int getStl_lnth(){ return stl_lnth;}
public String getMatl_clss(){ return matl_clss;}
public String getRgdt(){ return rgdt;}
public String getLmd(){ return lmd;}

// Setter 
public void setPart_no(String part_no){ this.part_no = part_no;}
public void setPart_proj_no(String part_proj_no){ this.part_proj_no = part_proj_no;}
public void setPart_flag(String part_flag){ this.part_flag = part_flag;}
public void setPart_mat_code(String part_mat_code){ this.part_mat_code = part_mat_code;}
public void setUom(String uom){ this.uom = uom;}
public void setCmdy_code(String cmdy_code){ this.cmdy_code = cmdy_code;}
public void setSrc_code(String src_code){ this.src_code = src_code;}
public void setUnit_wt(double unit_wt){ this.unit_wt = unit_wt;}
public void setPart_desc(String part_desc){ this.part_desc = part_desc;}
public void setOfe_due_qty(int ofe_due_qty){ this.ofe_due_qty = ofe_due_qty;}
public void setOh_qty(int oh_qty){ this.oh_qty = oh_qty;}
public void setRsv_qty(int rsv_qty){ this.rsv_qty = rsv_qty;}
public void setClsf_scty_code_1(String clsf_scty_code_1){ this.clsf_scty_code_1 = clsf_scty_code_1;}
public void setClsf_scty_code_2(String clsf_scty_code_2){ this.clsf_scty_code_2 = clsf_scty_code_2;}
public void setClsf_scty_code_3(String clsf_scty_code_3){ this.clsf_scty_code_3 = clsf_scty_code_3;}
public void setSys_id(String sys_id){ this.sys_id = sys_id;}
public void setAwat_qty(int awat_qty){ this.awat_qty = awat_qty;}
public void setBuyr_id(String buyr_id){ this.buyr_id = buyr_id;}
public void setStor_id(String stor_id){ this.stor_id = stor_id;}
public void setMat_maj_grp_code(String mat_maj_grp_code){ this.mat_maj_grp_code = mat_maj_grp_code;}
public void setMat_grp_code(String mat_grp_code){ this.mat_grp_code = mat_grp_code;}
public void setMat_name_item(String mat_name_item){ this.mat_name_item = mat_name_item;}
public void setMtl_mat_grd(String mtl_mat_grd){ this.mtl_mat_grd = mtl_mat_grd;}
public void setStl_thck_1(double stl_thck_1){ this.stl_thck_1 = stl_thck_1;}
public void setStl_thck_2(double stl_thck_2){ this.stl_thck_2 = stl_thck_2;}
public void setStl_bdth_1(int stl_bdth_1){ this.stl_bdth_1 = stl_bdth_1;}
public void setStl_bdth_2(int stl_bdth_2){ this.stl_bdth_2 = stl_bdth_2;}
public void setStl_lnth(int stl_lnth){ this.stl_lnth = stl_lnth;}
public void setMatl_clss(String matl_clss){ this.matl_clss = matl_clss;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}
public void setLmd(String lmd){ this.lmd = lmd;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = part_no + "" ; break;
  case  2 : field = part_proj_no + "" ; break;
  case  3 : field = part_flag + "" ; break;
  case  4 : field = part_mat_code + "" ; break;
  case  5 : field = uom + "" ; break;
  case  6 : field = cmdy_code + "" ; break;
  case  7 : field = src_code + "" ; break;
  case  8 : field = unit_wt + "" ; break;
  case  9 : field = part_desc + "" ; break;
  case  10 : field = ofe_due_qty + "" ; break;
  case  11 : field = oh_qty + "" ; break;
  case  12 : field = rsv_qty + "" ; break;
  case  13 : field = clsf_scty_code_1 + "" ; break;
  case  14 : field = clsf_scty_code_2 + "" ; break;
  case  15 : field = clsf_scty_code_3 + "" ; break;
  case  16 : field = sys_id + "" ; break;
  case  17 : field = awat_qty + "" ; break;
  case  18 : field = buyr_id + "" ; break;
  case  19 : field = stor_id + "" ; break;
  case  20 : field = mat_maj_grp_code + "" ; break;
  case  21 : field = mat_grp_code + "" ; break;
  case  22 : field = mat_name_item + "" ; break;
  case  23 : field = mtl_mat_grd + "" ; break;
  case  24 : field = stl_thck_1 + "" ; break;
  case  25 : field = stl_thck_2 + "" ; break;
  case  26 : field = stl_bdth_1 + "" ; break;
  case  27 : field = stl_bdth_2 + "" ; break;
  case  28 : field = stl_lnth + "" ; break;
  case  29 : field = matl_clss + "" ; break;
  case  30 : field = rgdt + "" ; break;
  case  31 : field = lmd + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("part_no")){ field = part_no + "" ; 
     } else if(rec.equalsIgnoreCase("part_proj_no")){ field = part_proj_no + "" ; 
     } else if(rec.equalsIgnoreCase("part_flag")){ field = part_flag + "" ; 
     } else if(rec.equalsIgnoreCase("part_mat_code")){ field = part_mat_code + "" ; 
     } else if(rec.equalsIgnoreCase("uom")){ field = uom + "" ; 
     } else if(rec.equalsIgnoreCase("cmdy_code")){ field = cmdy_code + "" ; 
     } else if(rec.equalsIgnoreCase("src_code")){ field = src_code + "" ; 
     } else if(rec.equalsIgnoreCase("unit_wt")){ field = unit_wt + "" ; 
     } else if(rec.equalsIgnoreCase("part_desc")){ field = part_desc + "" ; 
     } else if(rec.equalsIgnoreCase("ofe_due_qty")){ field = ofe_due_qty + "" ; 
     } else if(rec.equalsIgnoreCase("oh_qty")){ field = oh_qty + "" ; 
     } else if(rec.equalsIgnoreCase("rsv_qty")){ field = rsv_qty + "" ; 
     } else if(rec.equalsIgnoreCase("clsf_scty_code_1")){ field = clsf_scty_code_1 + "" ; 
     } else if(rec.equalsIgnoreCase("clsf_scty_code_2")){ field = clsf_scty_code_2 + "" ; 
     } else if(rec.equalsIgnoreCase("clsf_scty_code_3")){ field = clsf_scty_code_3 + "" ; 
     } else if(rec.equalsIgnoreCase("sys_id")){ field = sys_id + "" ; 
     } else if(rec.equalsIgnoreCase("awat_qty")){ field = awat_qty + "" ; 
     } else if(rec.equalsIgnoreCase("buyr_id")){ field = buyr_id + "" ; 
     } else if(rec.equalsIgnoreCase("stor_id")){ field = stor_id + "" ; 
     } else if(rec.equalsIgnoreCase("mat_maj_grp_code")){ field = mat_maj_grp_code + "" ; 
     } else if(rec.equalsIgnoreCase("mat_grp_code")){ field = mat_grp_code + "" ; 
     } else if(rec.equalsIgnoreCase("mat_name_item")){ field = mat_name_item + "" ; 
     } else if(rec.equalsIgnoreCase("mtl_mat_grd")){ field = mtl_mat_grd + "" ; 
     } else if(rec.equalsIgnoreCase("stl_thck_1")){ field = stl_thck_1 + "" ; 
     } else if(rec.equalsIgnoreCase("stl_thck_2")){ field = stl_thck_2 + "" ; 
     } else if(rec.equalsIgnoreCase("stl_bdth_1")){ field = stl_bdth_1 + "" ; 
     } else if(rec.equalsIgnoreCase("stl_bdth_2")){ field = stl_bdth_2 + "" ; 
     } else if(rec.equalsIgnoreCase("stl_lnth")){ field = stl_lnth + "" ; 
     } else if(rec.equalsIgnoreCase("matl_clss")){ field = matl_clss + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("lmd")){ field = lmd + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "PART_NO", "PART_PROJ_NO", "PART_FLAG", "PART_MAT_CODE", "UOM", "CMDY_CODE", "SRC_CODE", 
       "UNIT_WT", "PART_DESC", "OFE_DUE_QTY", "OH_QTY", "RSV_QTY", "CLSF_SCTY_CODE_1", "CLSF_SCTY_CODE_2", 
       "CLSF_SCTY_CODE_3", "SYS_ID", "AWAT_QTY", "BUYR_ID", "STOR_ID", "MAT_MAJ_GRP_CODE", "MAT_GRP_CODE", 
       "MAT_NAME_ITEM", "MTL_MAT_GRD", "STL_THCK_1", "STL_THCK_2", "STL_BDTH_1", "STL_BDTH_2", "STL_LNTH", 
       "MATL_CLSS", "RGDT", "LMD"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "PART_NO"};
    return tempx;
}

}// end GLL01MRec class