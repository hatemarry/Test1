package com.bes_line.HPW;  
  
import org.jsn.jdf.*;  
import org.jsn.jdf.db.*;  
import org.jsn.jdf.jtx.*;  
import org.jsn.jdf.servlet.*;  
  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.io.*;  
import java.net.*;  
import java.util.Vector;  
  
import com.bes_line.mst.*;  
import com.bes_line.mst.HPW.*;  
import com.bes_line.base.*;  
  
public class HMGLY01A extends HttpServlet{  
  
public void init(ServletConfig sc) throws ServletException {  
    super.init(sc);  
} // init  
  
public void destroy(){  
    super.destroy();  
}// destory  
  
public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e ) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
  } // end try                     
}//end doGet  
  
public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
    } // try-catch  
}//end doPost  
  
//=============================================================================  
protected void performTask (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
String cmd = request.getParameter("cmd");  
try {        if ( cmd.equals( "add1_ok" ) )     { insertHM.GLL01M(request, response);  
      } else if ( cmd.equals( "update1_ok" ) )  { updateHM.GLL01M(request, response);   
      } else if ( cmd.equals( "delete1_ok" ) )  { deleteHM.GLL01M(request, response);  
      } else if ( cmd.equals( "update1_list" ) )  { update1_list(request, response);  
      }  
 } catch(Throwable e ) {  
    e.printStackTrace(System.err);  
     System.err.flush();  
 } // end try  
}//end performTask  
  
//================================================================================  
public  void update1_list(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HPW/HMGLY01A/index.jsp" ;  
    String listJsp   = bu.HTTPSERVER + "/webpages/HPW/HMGLY01A/list1.jsp" ;  
    String listCount = request.getParameter("listCount");   
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String trmid = request.getParameter("trmid");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	String part_no = "";
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
		HM.GLL01MRec hm.gll01m = new HM.GLL01MRec() ; 
		HM.GLL01MDBWrap hm.gll01mdbw = new HM.GLL01MDBWrap(resource); 
		for( int lc=1; lc<=Integer.parseInt(listCount); lc++ ) { 
			part_no = request.getParameter("part_no"+String.valueOf(lc)); 
			String check = request.getParameter("check__"+String.valueOf(lc));
			if(check == null || !check.equals("Y")) continue; 

			hm.gll01m = hm.gll01mdbw.select(part_no); 
			Utility.fixNullAndTrim(hm.gll01m); 
			hm.gll01m.setPart_no(  request.getParameter("part_no" + String.valueOf(lc))); 
			hm.gll01mdbw.update(hm.gll01m); 
		}
		tx.commit(); 
    } catch(Exception e) {  
		tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(listJsp+"?posName="+URLEncoder.encode(posName,'utf-8')+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,'utf-8')+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen=" + screen + "&errMsg="+URLEncoder.encode(errMsg,'utf-8')+"&part_no="+part_no) ; 
  
} // end updateHM.GLL01M  
  
//================================================================================  
public  void insertHM.GLL01M(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HPW/HMGLY01A/index.jsp" ;  
    String part_no = box.getString("part_no"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	HM.GLL01MRec hm.gll01m = new HM.GLL01MRec() ; 
	box.copyToEntity(hm.gll01m); 
	Utility.fixNullAndTrim(hm.gll01m); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	BesInit bi = new BesInit();  
	UserInfo ui = bi.checkSession(request , response); 
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        HM.GLL01MDBWrap hm.gll01mdbw = new HM.GLL01MDBWrap(resource); 
/** 
 * ?????? ????? alert ?; ??? ??? ?? ?????? ???? 
 */ 
    int cnt = hm.gll01mdbw.count(part_no); 
	if(cnt == 0){ 
        // System Colulms.. 
        hm.gll01m.setAdate(curdate); 
        hm.gll01m.setAuser(usrid); 
        hm.gll01m.setMdate(curdate); 
        hm.gll01m.setMuser(usrid); 
		hm.gll01mdbw.insert(hm.gll01m); 
		tx.commit(); 
      response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,'utf-8')+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,'utf-8')+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,'utf-8')+"&part_no="+part_no) ; 
    }else{ 
      tx.rollback(); 
      out.println("<script language='javascript'>"); 
      out.println("  alert('" + BesDBUtil.getMessage("bsc128",ui) + "');"); 
      out.println("  history.back(-1);"); 
      out.println("</script>"); 
    } 
    } catch(Exception e) {  
        tx.rollback(); 
        out.println(e.getMessage()+"<br>"+e.toString());  
        e.printStackTrace();  
        out.println(box.toString());  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
} // end insertHM.GLL01M  
  
//================================================================================  
public  void updateHM.GLL01M(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HPW/HMGLY01A/index.jsp" ;  
    String part_no = box.getString("part_no"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
    HM.GLL01MRec hm.gll01mBox = new HM.GLL01MRec() ; 
    box.copyToEntity(hm.gll01mBox); 
    Utility.fixNullAndTrim(hm.gll01mBox); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        HM.GLL01MDBWrap hm.gll01mdbw = new HM.GLL01MDBWrap(resource); 
        HM.GLL01MRec hm.gll01m = hm.gll01mdbw.select(part_no);
         // System Colulms.. 
        hm.gll01m.setMdate(curdate); 
        hm.gll01m.setMuser(usrid); 
        // Editable Colulms.. 
        hm.gll01m.setPart_no(hm.gll01mBox.getPart_no()); 
        hm.gll01mdbw.update(hm.gll01m); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,'utf-8')+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,'utf-8')+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,'utf-8')+"&part_no="+part_no) ; 
  
} // end updateHM.GLL01M  
  
//================================================================================  
public  void deleteHM.GLL01M(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HPW/HMGLY01A/index.jsp" ;  
    String part_no = box.getString("part_no"); 
    String screen = "addscreen";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String callParameter = "";
    String errMsg = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
  
    HM.GLL01MRec hm.gll01m = new HM.GLL01MRec() ; 
    box.copyToEntity(hm.gll01m); 
    Utility.fixNullAndTrim(hm.gll01m); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        HM.GLL01MDBWrap hm.gll01mdbw = new HM.GLL01MDBWrap(resource); 
        hm.gll01mdbw.delete(hm.gll01m); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,'utf-8')+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,'utf-8')+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,'utf-8'));  
//================================================================================  
 } 
}// end Class  
