package com.bes_line.mst.HPW;

// DBWrapper Class for GLL01M
/**
 *
 * @(#) HM.GLL01MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-19
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLL01MDBWrapBES extends DBWrapper{

public GLL01MDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Select Page 
* @param String part_no
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-19
*/
public java.util.Vector selectPage(String fldname, int page, int pagesize, String whereOption ) throws Exception{
return selectPage(fldname,page,pagesize, "Asc", whereOption) ;
}// end selectPage
/**
* Select Page
* @param String part_no* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-19
*/
public java.util.Vector selectPage(String fldname, int page, int pagesize, String keyorder, String whereOption) throws Exception{
    java.util.Vector gll01mV = new java.util.Vector();
    GLL01MRec gll01m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select part_no, part_proj_no, part_flag, part_mat_code, uom, cmdy_code, src_code, unit_wt, part_desc, " +
                              "ofe_due_qty, oh_qty, rsv_qty, clsf_scty_code_1, clsf_scty_code_2, clsf_scty_code_3, sys_id, awat_qty, buyr_id, " +
                              "stor_id, mat_maj_grp_code, mat_grp_code, mat_name_item, mtl_mat_grd, stl_thck_1, stl_thck_2, stl_bdth_1, stl_bdth_2, " +
                              "stl_lnth, matl_clss, rgdt, lmd " +
                       "  from HM.GLL01M  where 1 = 1 " +	whereOption  +
                       "  order by "+fldname+" "+keyorder; 
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();
        int count = 0;
        while((count < (page-1)*pagesize ) && ( rs.next())){  count ++; } // page??? ??????
            count = 0;
        while(rs.next()){
            count ++;
            if(count > pagesize ) break;
            gll01m = new GLL01MRec(); // GLL01MRec Constructor
                     gll01m.setPart_no(rs.getString("part_no"));
                     gll01m.setPart_proj_no(rs.getString("part_proj_no"));
                     gll01m.setPart_flag(rs.getString("part_flag"));
                     gll01m.setPart_mat_code(rs.getString("part_mat_code"));
                     gll01m.setUom(rs.getString("uom"));
                     gll01m.setCmdy_code(rs.getString("cmdy_code"));
                     gll01m.setSrc_code(rs.getString("src_code"));
                     gll01m.setUnit_wt(rs.getDouble("unit_wt"));
                     gll01m.setPart_desc(rs.getString("part_desc"));
                     gll01m.setOfe_due_qty(rs.getInt("ofe_due_qty"));
                     gll01m.setOh_qty(rs.getInt("oh_qty"));
                     gll01m.setRsv_qty(rs.getInt("rsv_qty"));
                     gll01m.setClsf_scty_code_1(rs.getString("clsf_scty_code_1"));
                     gll01m.setClsf_scty_code_2(rs.getString("clsf_scty_code_2"));
                     gll01m.setClsf_scty_code_3(rs.getString("clsf_scty_code_3"));
                     gll01m.setSys_id(rs.getString("sys_id"));
                     gll01m.setAwat_qty(rs.getInt("awat_qty"));
                     gll01m.setBuyr_id(rs.getString("buyr_id"));
                     gll01m.setStor_id(rs.getString("stor_id"));
                     gll01m.setMat_maj_grp_code(rs.getString("mat_maj_grp_code"));
                     gll01m.setMat_grp_code(rs.getString("mat_grp_code"));
                     gll01m.setMat_name_item(rs.getString("mat_name_item"));
                     gll01m.setMtl_mat_grd(rs.getString("mtl_mat_grd"));
                     gll01m.setStl_thck_1(rs.getDouble("stl_thck_1"));
                     gll01m.setStl_thck_2(rs.getDouble("stl_thck_2"));
                     gll01m.setStl_bdth_1(rs.getInt("stl_bdth_1"));
                     gll01m.setStl_bdth_2(rs.getInt("stl_bdth_2"));
                     gll01m.setStl_lnth(rs.getInt("stl_lnth"));
                     gll01m.setMatl_clss(rs.getString("matl_clss"));
                     gll01m.setRgdt(rs.getString("rgdt"));
                     gll01m.setLmd(rs.getString("lmd"));
            gll01mV.addElement(gll01m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gll01mV;
} // end selectPage

/**
* SelectWhere 
* @param String part_no
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-19
*/
public java.util.Vector selectWhere(String fldname, String whereOption ) throws Exception{
return selectWhere(fldname, "Asc", whereOption) ;
}// end selectWhere
/**
* SelectWhere
* @param String part_no* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-19
*/
public java.util.Vector selectWhere(String fldname, String keyorder, String whereOption) throws Exception{
    java.util.Vector gll01mV = new java.util.Vector();
    GLL01MRec gll01m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select part_no, part_proj_no, part_flag, part_mat_code, uom, cmdy_code, src_code, unit_wt, part_desc, " +
                              "ofe_due_qty, oh_qty, rsv_qty, clsf_scty_code_1, clsf_scty_code_2, clsf_scty_code_3, sys_id, awat_qty, buyr_id, " +
                              "stor_id, mat_maj_grp_code, mat_grp_code, mat_name_item, mtl_mat_grd, stl_thck_1, stl_thck_2, stl_bdth_1, stl_bdth_2, " +
                              "stl_lnth, matl_clss, rgdt, lmd " +
                       "  from HM.GLL01M  where 1 = 1 " +	whereOption  +
                       "  order by "+fldname+" "+keyorder; 
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();
        while(rs.next()) { 
            gll01m = new GLL01MRec(); // GLL01MRec Constructor
                     gll01m.setPart_no(rs.getString("part_no"));
                     gll01m.setPart_proj_no(rs.getString("part_proj_no"));
                     gll01m.setPart_flag(rs.getString("part_flag"));
                     gll01m.setPart_mat_code(rs.getString("part_mat_code"));
                     gll01m.setUom(rs.getString("uom"));
                     gll01m.setCmdy_code(rs.getString("cmdy_code"));
                     gll01m.setSrc_code(rs.getString("src_code"));
                     gll01m.setUnit_wt(rs.getDouble("unit_wt"));
                     gll01m.setPart_desc(rs.getString("part_desc"));
                     gll01m.setOfe_due_qty(rs.getInt("ofe_due_qty"));
                     gll01m.setOh_qty(rs.getInt("oh_qty"));
                     gll01m.setRsv_qty(rs.getInt("rsv_qty"));
                     gll01m.setClsf_scty_code_1(rs.getString("clsf_scty_code_1"));
                     gll01m.setClsf_scty_code_2(rs.getString("clsf_scty_code_2"));
                     gll01m.setClsf_scty_code_3(rs.getString("clsf_scty_code_3"));
                     gll01m.setSys_id(rs.getString("sys_id"));
                     gll01m.setAwat_qty(rs.getInt("awat_qty"));
                     gll01m.setBuyr_id(rs.getString("buyr_id"));
                     gll01m.setStor_id(rs.getString("stor_id"));
                     gll01m.setMat_maj_grp_code(rs.getString("mat_maj_grp_code"));
                     gll01m.setMat_grp_code(rs.getString("mat_grp_code"));
                     gll01m.setMat_name_item(rs.getString("mat_name_item"));
                     gll01m.setMtl_mat_grd(rs.getString("mtl_mat_grd"));
                     gll01m.setStl_thck_1(rs.getDouble("stl_thck_1"));
                     gll01m.setStl_thck_2(rs.getDouble("stl_thck_2"));
                     gll01m.setStl_bdth_1(rs.getInt("stl_bdth_1"));
                     gll01m.setStl_bdth_2(rs.getInt("stl_bdth_2"));
                     gll01m.setStl_lnth(rs.getInt("stl_lnth"));
                     gll01m.setMatl_clss(rs.getString("matl_clss"));
                     gll01m.setRgdt(rs.getString("rgdt"));
                     gll01m.setLmd(rs.getString("lmd"));
            gll01mV.addElement(gll01m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gll01mV;
} // end selectWhere

/**
* Get Rows CountPage 
* @param 
* @return int 
* @author besTeam 
* @date 2006-5-19
*/
public int countPage(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select COUNT(*) from HM.GLL01M  where 1 = 1 " +	whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end countPage

/**
* Get one Record 
* @param String part_no
* @return GLL01MRec 
* @author besTeam 
* @date 2006-5-19
*/
public GLL01MRec select(String part_no) throws Exception{
    GLL01MRec gll01m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM HM.GLL01M "

		+ " where part_no = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,part_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            gll01m = new GLL01MRec(); // GLL01MRec Constructor
                     gll01m.setPart_no(rs.getString("part_no"));
                     gll01m.setPart_proj_no(rs.getString("part_proj_no"));
                     gll01m.setPart_flag(rs.getString("part_flag"));
                     gll01m.setPart_mat_code(rs.getString("part_mat_code"));
                     gll01m.setUom(rs.getString("uom"));
                     gll01m.setCmdy_code(rs.getString("cmdy_code"));
                     gll01m.setSrc_code(rs.getString("src_code"));
                     gll01m.setUnit_wt(rs.getDouble("unit_wt"));
                     gll01m.setPart_desc(rs.getString("part_desc"));
                     gll01m.setOfe_due_qty(rs.getInt("ofe_due_qty"));
                     gll01m.setOh_qty(rs.getInt("oh_qty"));
                     gll01m.setRsv_qty(rs.getInt("rsv_qty"));
                     gll01m.setClsf_scty_code_1(rs.getString("clsf_scty_code_1"));
                     gll01m.setClsf_scty_code_2(rs.getString("clsf_scty_code_2"));
                     gll01m.setClsf_scty_code_3(rs.getString("clsf_scty_code_3"));
                     gll01m.setSys_id(rs.getString("sys_id"));
                     gll01m.setAwat_qty(rs.getInt("awat_qty"));
                     gll01m.setBuyr_id(rs.getString("buyr_id"));
                     gll01m.setStor_id(rs.getString("stor_id"));
                     gll01m.setMat_maj_grp_code(rs.getString("mat_maj_grp_code"));
                     gll01m.setMat_grp_code(rs.getString("mat_grp_code"));
                     gll01m.setMat_name_item(rs.getString("mat_name_item"));
                     gll01m.setMtl_mat_grd(rs.getString("mtl_mat_grd"));
                     gll01m.setStl_thck_1(rs.getDouble("stl_thck_1"));
                     gll01m.setStl_thck_2(rs.getDouble("stl_thck_2"));
                     gll01m.setStl_bdth_1(rs.getInt("stl_bdth_1"));
                     gll01m.setStl_bdth_2(rs.getInt("stl_bdth_2"));
                     gll01m.setStl_lnth(rs.getInt("stl_lnth"));
                     gll01m.setMatl_clss(rs.getString("matl_clss"));
                     gll01m.setRgdt(rs.getString("rgdt"));
                     gll01m.setLmd(rs.getString("lmd"));
        } else {
            throw new DataNotFoundException();
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gll01m;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-19
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector gll01mV = new java.util.Vector();
    GLL01MRec gll01m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM HM.GLL01M "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            gll01m = new GLL01MRec(); // GLL01MRec Constructor
                     gll01m.setPart_no(rs.getString("part_no"));
                     gll01m.setPart_proj_no(rs.getString("part_proj_no"));
                     gll01m.setPart_flag(rs.getString("part_flag"));
                     gll01m.setPart_mat_code(rs.getString("part_mat_code"));
                     gll01m.setUom(rs.getString("uom"));
                     gll01m.setCmdy_code(rs.getString("cmdy_code"));
                     gll01m.setSrc_code(rs.getString("src_code"));
                     gll01m.setUnit_wt(rs.getDouble("unit_wt"));
                     gll01m.setPart_desc(rs.getString("part_desc"));
                     gll01m.setOfe_due_qty(rs.getInt("ofe_due_qty"));
                     gll01m.setOh_qty(rs.getInt("oh_qty"));
                     gll01m.setRsv_qty(rs.getInt("rsv_qty"));
                     gll01m.setClsf_scty_code_1(rs.getString("clsf_scty_code_1"));
                     gll01m.setClsf_scty_code_2(rs.getString("clsf_scty_code_2"));
                     gll01m.setClsf_scty_code_3(rs.getString("clsf_scty_code_3"));
                     gll01m.setSys_id(rs.getString("sys_id"));
                     gll01m.setAwat_qty(rs.getInt("awat_qty"));
                     gll01m.setBuyr_id(rs.getString("buyr_id"));
                     gll01m.setStor_id(rs.getString("stor_id"));
                     gll01m.setMat_maj_grp_code(rs.getString("mat_maj_grp_code"));
                     gll01m.setMat_grp_code(rs.getString("mat_grp_code"));
                     gll01m.setMat_name_item(rs.getString("mat_name_item"));
                     gll01m.setMtl_mat_grd(rs.getString("mtl_mat_grd"));
                     gll01m.setStl_thck_1(rs.getDouble("stl_thck_1"));
                     gll01m.setStl_thck_2(rs.getDouble("stl_thck_2"));
                     gll01m.setStl_bdth_1(rs.getInt("stl_bdth_1"));
                     gll01m.setStl_bdth_2(rs.getInt("stl_bdth_2"));
                     gll01m.setStl_lnth(rs.getInt("stl_lnth"));
                     gll01m.setMatl_clss(rs.getString("matl_clss"));
                     gll01m.setRgdt(rs.getString("rgdt"));
                     gll01m.setLmd(rs.getString("lmd"));
            gll01mV.addElement(gll01m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gll01mV;
} // end selectAll

/**
* Get selectWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-19
*/
public java.util.Vector selectWhere(String whereOption) throws Exception{
    java.util.Vector gll01mV = new java.util.Vector();
    GLL01MRec gll01m = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM HM.GLL01M "

  + whereOption; 
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            gll01m = new GLL01MRec(); // GLL01MRec Constructor
                     gll01m.setPart_no(rs.getString("part_no"));
                     gll01m.setPart_proj_no(rs.getString("part_proj_no"));
                     gll01m.setPart_flag(rs.getString("part_flag"));
                     gll01m.setPart_mat_code(rs.getString("part_mat_code"));
                     gll01m.setUom(rs.getString("uom"));
                     gll01m.setCmdy_code(rs.getString("cmdy_code"));
                     gll01m.setSrc_code(rs.getString("src_code"));
                     gll01m.setUnit_wt(rs.getDouble("unit_wt"));
                     gll01m.setPart_desc(rs.getString("part_desc"));
                     gll01m.setOfe_due_qty(rs.getInt("ofe_due_qty"));
                     gll01m.setOh_qty(rs.getInt("oh_qty"));
                     gll01m.setRsv_qty(rs.getInt("rsv_qty"));
                     gll01m.setClsf_scty_code_1(rs.getString("clsf_scty_code_1"));
                     gll01m.setClsf_scty_code_2(rs.getString("clsf_scty_code_2"));
                     gll01m.setClsf_scty_code_3(rs.getString("clsf_scty_code_3"));
                     gll01m.setSys_id(rs.getString("sys_id"));
                     gll01m.setAwat_qty(rs.getInt("awat_qty"));
                     gll01m.setBuyr_id(rs.getString("buyr_id"));
                     gll01m.setStor_id(rs.getString("stor_id"));
                     gll01m.setMat_maj_grp_code(rs.getString("mat_maj_grp_code"));
                     gll01m.setMat_grp_code(rs.getString("mat_grp_code"));
                     gll01m.setMat_name_item(rs.getString("mat_name_item"));
                     gll01m.setMtl_mat_grd(rs.getString("mtl_mat_grd"));
                     gll01m.setStl_thck_1(rs.getDouble("stl_thck_1"));
                     gll01m.setStl_thck_2(rs.getDouble("stl_thck_2"));
                     gll01m.setStl_bdth_1(rs.getInt("stl_bdth_1"));
                     gll01m.setStl_bdth_2(rs.getInt("stl_bdth_2"));
                     gll01m.setStl_lnth(rs.getInt("stl_lnth"));
                     gll01m.setMatl_clss(rs.getString("matl_clss"));
                     gll01m.setRgdt(rs.getString("rgdt"));
                     gll01m.setLmd(rs.getString("lmd"));
            gll01mV.addElement(gll01m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gll01mV;
} // end selectAll

/**
* Select Data Over the key value(s) and default return count(20) 
* @param String part_no
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-19
*/
public java.util.Vector selectOver(String part_no) throws Exception{
return selectOver(part_no,20) ;
}// end selectOver
/**
* Select Data Over(Next) the key value(s) and return record count 
* @param String part_no, int 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-19
*/
public java.util.Vector selectOver(String part_no, int page) throws Exception{
    java.util.Vector gll01mV = new java.util.Vector();
    GLL01MRec gll01m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM HM.GLL01M "

		+ " where part_no >= ? order by part_no "; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,part_no); 
        rs = pstmt.executeQuery();
        int count = 0;//??f??? SQL?????? Limit??? ????...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            gll01m = new GLL01MRec(); // GLL01MRec Constructor
                     gll01m.setPart_no(rs.getString("part_no"));
                     gll01m.setPart_proj_no(rs.getString("part_proj_no"));
                     gll01m.setPart_flag(rs.getString("part_flag"));
                     gll01m.setPart_mat_code(rs.getString("part_mat_code"));
                     gll01m.setUom(rs.getString("uom"));
                     gll01m.setCmdy_code(rs.getString("cmdy_code"));
                     gll01m.setSrc_code(rs.getString("src_code"));
                     gll01m.setUnit_wt(rs.getDouble("unit_wt"));
                     gll01m.setPart_desc(rs.getString("part_desc"));
                     gll01m.setOfe_due_qty(rs.getInt("ofe_due_qty"));
                     gll01m.setOh_qty(rs.getInt("oh_qty"));
                     gll01m.setRsv_qty(rs.getInt("rsv_qty"));
                     gll01m.setClsf_scty_code_1(rs.getString("clsf_scty_code_1"));
                     gll01m.setClsf_scty_code_2(rs.getString("clsf_scty_code_2"));
                     gll01m.setClsf_scty_code_3(rs.getString("clsf_scty_code_3"));
                     gll01m.setSys_id(rs.getString("sys_id"));
                     gll01m.setAwat_qty(rs.getInt("awat_qty"));
                     gll01m.setBuyr_id(rs.getString("buyr_id"));
                     gll01m.setStor_id(rs.getString("stor_id"));
                     gll01m.setMat_maj_grp_code(rs.getString("mat_maj_grp_code"));
                     gll01m.setMat_grp_code(rs.getString("mat_grp_code"));
                     gll01m.setMat_name_item(rs.getString("mat_name_item"));
                     gll01m.setMtl_mat_grd(rs.getString("mtl_mat_grd"));
                     gll01m.setStl_thck_1(rs.getDouble("stl_thck_1"));
                     gll01m.setStl_thck_2(rs.getDouble("stl_thck_2"));
                     gll01m.setStl_bdth_1(rs.getInt("stl_bdth_1"));
                     gll01m.setStl_bdth_2(rs.getInt("stl_bdth_2"));
                     gll01m.setStl_lnth(rs.getInt("stl_lnth"));
                     gll01m.setMatl_clss(rs.getString("matl_clss"));
                     gll01m.setRgdt(rs.getString("rgdt"));
                     gll01m.setLmd(rs.getString("lmd"));
            gll01mV.addElement(gll01m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gll01mV;
} // end selectOver

/**
* Select Data Under(Previous) the key value(s) and default return count(20) 
* @param String part_no
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-19
*/
public java.util.Vector selectUnder(String part_no) throws Exception{
return selectUnder(part_no,20) ;
}// end selectUnder
/**
* Select Data Under(Previous) the key value(s) and return record count 
* @param String part_no, int
* @return java.util.Vector
* @author besTeam 
* @date 2006-5-19
*/
public java.util.Vector selectUnder(String part_no, int page) throws Exception{
    java.util.Vector gll01mV = new java.util.Vector();
    GLL01MRec gll01m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM HM.GLL01M "

		+ " where part_no <= ? order by part_no desc" ; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,part_no); 
        rs = pstmt.executeQuery();
        int count = 0;//??f??? SQL?????? Limit??? ????...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            gll01m = new GLL01MRec(); // GLL01MRec Constructor
                     gll01m.setPart_no(rs.getString("part_no"));
                     gll01m.setPart_proj_no(rs.getString("part_proj_no"));
                     gll01m.setPart_flag(rs.getString("part_flag"));
                     gll01m.setPart_mat_code(rs.getString("part_mat_code"));
                     gll01m.setUom(rs.getString("uom"));
                     gll01m.setCmdy_code(rs.getString("cmdy_code"));
                     gll01m.setSrc_code(rs.getString("src_code"));
                     gll01m.setUnit_wt(rs.getDouble("unit_wt"));
                     gll01m.setPart_desc(rs.getString("part_desc"));
                     gll01m.setOfe_due_qty(rs.getInt("ofe_due_qty"));
                     gll01m.setOh_qty(rs.getInt("oh_qty"));
                     gll01m.setRsv_qty(rs.getInt("rsv_qty"));
                     gll01m.setClsf_scty_code_1(rs.getString("clsf_scty_code_1"));
                     gll01m.setClsf_scty_code_2(rs.getString("clsf_scty_code_2"));
                     gll01m.setClsf_scty_code_3(rs.getString("clsf_scty_code_3"));
                     gll01m.setSys_id(rs.getString("sys_id"));
                     gll01m.setAwat_qty(rs.getInt("awat_qty"));
                     gll01m.setBuyr_id(rs.getString("buyr_id"));
                     gll01m.setStor_id(rs.getString("stor_id"));
                     gll01m.setMat_maj_grp_code(rs.getString("mat_maj_grp_code"));
                     gll01m.setMat_grp_code(rs.getString("mat_grp_code"));
                     gll01m.setMat_name_item(rs.getString("mat_name_item"));
                     gll01m.setMtl_mat_grd(rs.getString("mtl_mat_grd"));
                     gll01m.setStl_thck_1(rs.getDouble("stl_thck_1"));
                     gll01m.setStl_thck_2(rs.getDouble("stl_thck_2"));
                     gll01m.setStl_bdth_1(rs.getInt("stl_bdth_1"));
                     gll01m.setStl_bdth_2(rs.getInt("stl_bdth_2"));
                     gll01m.setStl_lnth(rs.getInt("stl_lnth"));
                     gll01m.setMatl_clss(rs.getString("matl_clss"));
                     gll01m.setRgdt(rs.getString("rgdt"));
                     gll01m.setLmd(rs.getString("lmd"));
            gll01mV.add(0,gll01m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gll01mV;
} // end selectUnder
/**
* Get Rows Count 
* @param String part_no
* @return int 
* @author besTeam 
* @date 2006-5-19
*/
public int count(String part_no) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " HM.GLL01M "

		+ " where part_no = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,part_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param void 
* @return int 
* @author besTeam 
* @date 2006-5-19
*/
public int count() throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " HM.GLL01M "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}// end HM.GLL01MDBWrapBES class