package com.bes_line.HPW;  
  
import org.jsn.jdf.*;  
import org.jsn.jdf.db.*;  
import org.jsn.jdf.jtx.*;  
import org.jsn.jdf.servlet.*;  
  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.io.*;  
import java.net.*;  
import java.util.Vector;  
  
import com.bes_line.mst.*;  
import com.bes_line.mst.HPW.*;  
import com.bes_line.base.*;  
  
public class HPWP280A extends HttpServlet{  
  
public void init(ServletConfig sc) throws ServletException {  
    super.init(sc);  
} // init  
  
public void destroy(){  
    super.destroy();  
}// destory  
  
public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e ) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
  } // end try                     
}//end doGet  
  
public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
    } // try-catch  
}//end doPost  
  
//=============================================================================  
protected void performTask (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
String cmd = request.getParameter("cmd");  
try {        if ( cmd.equals( "add1_ok" ) )     { insertWGP10M(request, response);  
      } else if ( cmd.equals( "update1_ok" ) )  { updateWGP10M(request, response);   
      } else if ( cmd.equals( "delete1_ok" ) )  { deleteWGP10M(request, response);  
      } else if ( cmd.equals( "update1_list" ) )  { update1_list(request, response);  
      }  
 } catch(Throwable e ) {  
    e.printStackTrace(System.err);  
     System.err.flush();  
 } // end try  
}//end performTask  
  
//================================================================================  
public  void update1_list(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HPW/HPWP280A/index.jsp" ;  
    String listJsp   = bu.HTTPSERVER + "/webpages/HPW/HPWP280A/list1.jsp" ;  
    String listCount = request.getParameter("listCount");   
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String trmid = request.getParameter("trmid");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	String proj_no = "";
	String flag = "";
	String blk_no = "";
	String mp = "";
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
		WGP10MRec wgp10m = new WGP10MRec() ; 
		WGP10MDBWrap wgp10mdbw = new WGP10MDBWrap(resource); 
		for( int lc=1; lc<=Integer.parseInt(listCount); lc++ ) { 
			proj_no = request.getParameter("proj_no"+String.valueOf(lc)); 
			flag = request.getParameter("flag"+String.valueOf(lc)); 
			blk_no = request.getParameter("blk_no"+String.valueOf(lc)); 
			mp = request.getParameter("mp"+String.valueOf(lc)); 
			String check = request.getParameter("check__"+String.valueOf(lc));
			if(check == null || !check.equals("Y")) continue; 

			wgp10m = wgp10mdbw.select(proj_no, flag, blk_no, mp); 
			Utility.fixNullAndTrim(wgp10m); 
			wgp10m.setProj_no(  request.getParameter("proj_no" + String.valueOf(lc))); 
			wgp10m.setFlag(  request.getParameter("flag" + String.valueOf(lc))); 
			wgp10m.setBlk_no(  request.getParameter("blk_no" + String.valueOf(lc))); 
			wgp10mdbw.update(wgp10m); 
		}
		tx.commit(); 
    } catch(Exception e) {  
		tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(listJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen=" + screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&proj_no="+proj_no+"&flag="+flag+"&blk_no="+blk_no+"&mp="+mp) ; 
  
} // end updateWGP10M  
  
//================================================================================  
public  void insertWGP10M(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HPW/HPWP280A/index.jsp" ;  
    String proj_no = box.getString("proj_no"); 
    String flag = box.getString("flag"); 
    String blk_no = box.getString("blk_no"); 
    String mp = box.getString("mp"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	WGP10MRec wgp10m = new WGP10MRec() ; 
	box.copyToEntity(wgp10m); 
	Utility.fixNullAndTrim(wgp10m); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	BesInit bi = new BesInit();  
	UserInfo ui = bi.checkSession(request , response); 
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        WGP10MDBWrap wgp10mdbw = new WGP10MDBWrap(resource); 
/** 
 * ?????? ????? alert ?; ??? ??? ?? ?????? ???? 
 */ 
    int cnt = wgp10mdbw.count(proj_no,flag,blk_no,mp); 
	if(cnt == 0){ 
        // System Colulms.. 
        wgp10m.setAdate(curdate); 
        wgp10m.setAuser(usrid); 
        wgp10m.setMdate(curdate); 
        wgp10m.setMuser(usrid); 
		wgp10mdbw.insert(wgp10m); 
		tx.commit(); 
      response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&proj_no="+proj_no+"&flag="+flag+"&blk_no="+blk_no+"&mp="+mp) ; 
    }else{ 
      tx.rollback(); 
      out.println("<script language='javascript'>"); 
      out.println("  alert('" + BesDBUtil.getMessage("bsc128",ui) + "');"); 
      out.println("  history.back(-1);"); 
      out.println("</script>"); 
    } 
    } catch(Exception e) {  
        tx.rollback(); 
        out.println(e.getMessage()+"<br>"+e.toString());  
        e.printStackTrace();  
        out.println(box.toString());  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
} // end insertWGP10M  
  
//================================================================================  
public  void updateWGP10M(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HPW/HPWP280A/index.jsp" ;  
    String proj_no = box.getString("proj_no"); 
    String flag = box.getString("flag"); 
    String blk_no = box.getString("blk_no"); 
    String mp = box.getString("mp"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
    WGP10MRec wgp10mBox = new WGP10MRec() ; 
    box.copyToEntity(wgp10mBox); 
    Utility.fixNullAndTrim(wgp10mBox); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        WGP10MDBWrap wgp10mdbw = new WGP10MDBWrap(resource); 
        WGP10MRec wgp10m = wgp10mdbw.select(proj_no, flag, blk_no, mp);
         // System Colulms.. 
        wgp10m.setMdate(curdate); 
        wgp10m.setMuser(usrid); 
        // Editable Colulms.. 
        wgp10m.setProj_no(wgp10mBox.getProj_no()); 
        wgp10m.setFlag(wgp10mBox.getFlag()); 
        wgp10m.setBlk_no(wgp10mBox.getBlk_no()); 
        wgp10mdbw.update(wgp10m); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&proj_no="+proj_no+"&flag="+flag+"&blk_no="+blk_no+"&mp="+mp) ; 
  
} // end updateWGP10M  
  
//================================================================================  
public  void deleteWGP10M(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HPW/HPWP280A/index.jsp" ;  
    String proj_no = box.getString("proj_no"); 
    String flag = box.getString("flag"); 
    String blk_no = box.getString("blk_no"); 
    String mp = box.getString("mp"); 
    String screen = "addscreen";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String callParameter = "";
    String errMsg = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
  
    WGP10MRec wgp10m = new WGP10MRec() ; 
    box.copyToEntity(wgp10m); 
    Utility.fixNullAndTrim(wgp10m); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        WGP10MDBWrap wgp10mdbw = new WGP10MDBWrap(resource); 
        wgp10mdbw.delete(wgp10m); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8"));  
//================================================================================  
 } 
}// end Class  
