package com.bes_line.mst.HPW ;

// Entity Class for WG912C
/**
 *
 * @(#) WG912CRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class WG912CRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String flag; 		// (VARCHAR2, 1.0)
    public String flag_name; 		// (VARCHAR2, 100.0)
    public String rgsr_emp_no; 		// (VARCHAR2, 7.0)
    public String rgsr_date; 		// (VARCHAR2, 8.0)
    public String rgsr_time; 		// (VARCHAR2, 6.0)
    public String mnt_emp_no; 		// (VARCHAR2, 7.0)
    public String mnt_date; 		// (VARCHAR2, 8.0)
    public String mnt_time; 		// (VARCHAR2, 6.0)

public WG912CRec(){ } // default constructor

public WG912CRec(
       String flag, String flag_name, String rgsr_emp_no, String rgsr_date, String rgsr_time, String mnt_emp_no, 
       String mnt_date, String mnt_time){
    this.flag = flag;
    this.flag_name = flag_name;
    this.rgsr_emp_no = rgsr_emp_no;
    this.rgsr_date = rgsr_date;
    this.rgsr_time = rgsr_time;
    this.mnt_emp_no = mnt_emp_no;
    this.mnt_date = mnt_date;
    this.mnt_time = mnt_time;
} // Constructor


// Getter 
public String getFlag(){ return flag;}
public String getFlag_name(){ return flag_name;}
public String getRgsr_emp_no(){ return rgsr_emp_no;}
public String getRgsr_date(){ return rgsr_date;}
public String getRgsr_time(){ return rgsr_time;}
public String getMnt_emp_no(){ return mnt_emp_no;}
public String getMnt_date(){ return mnt_date;}
public String getMnt_time(){ return mnt_time;}

// Setter 
public void setFlag(String flag){ this.flag = flag;}
public void setFlag_name(String flag_name){ this.flag_name = flag_name;}
public void setRgsr_emp_no(String rgsr_emp_no){ this.rgsr_emp_no = rgsr_emp_no;}
public void setRgsr_date(String rgsr_date){ this.rgsr_date = rgsr_date;}
public void setRgsr_time(String rgsr_time){ this.rgsr_time = rgsr_time;}
public void setMnt_emp_no(String mnt_emp_no){ this.mnt_emp_no = mnt_emp_no;}
public void setMnt_date(String mnt_date){ this.mnt_date = mnt_date;}
public void setMnt_time(String mnt_time){ this.mnt_time = mnt_time;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = flag + "" ; break;
  case  2 : field = flag_name + "" ; break;
  case  3 : field = rgsr_emp_no + "" ; break;
  case  4 : field = rgsr_date + "" ; break;
  case  5 : field = rgsr_time + "" ; break;
  case  6 : field = mnt_emp_no + "" ; break;
  case  7 : field = mnt_date + "" ; break;
  case  8 : field = mnt_time + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("flag")){ field = flag + "" ; 
     } else if(rec.equalsIgnoreCase("flag_name")){ field = flag_name + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_emp_no")){ field = rgsr_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_date")){ field = rgsr_date + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_time")){ field = rgsr_time + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_emp_no")){ field = mnt_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_date")){ field = mnt_date + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_time")){ field = mnt_time + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "FLAG", "FLAG_NAME", "RGSR_EMP_NO", "RGSR_DATE", "RGSR_TIME", "MNT_EMP_NO", "MNT_DATE", 
       "MNT_TIME"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "FLAG"};
    return tempx;
}

}// end WG912CRec class