package com.bes_line.mst.HPW ;

// Entity Class for HP.WG916C
/**
 *
 * @(#) HP.WG916CRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-17
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class HP.WG916CRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String shop_code; 		// (VARCHAR2, 4.0)
    public String intc_outc_clsf_code; 		// (VARCHAR2, 1.0)
    public String cut_shop_indc; 		// (VARCHAR2, 1.0)
    public String assy_shop_indc; 		// (VARCHAR2, 1.0)
    public String oft_shop_indc; 		// (VARCHAR2, 1.0)
    public String pnt_shop_indc; 		// (VARCHAR2, 1.0)
    public String erec_shop_indc; 		// (VARCHAR2, 1.0)
    public String dstn_clsf_code; 		// (VARCHAR2, 3.0)
    public String rgsr_emp_no; 		// (VARCHAR2, 7.0)
    public String rgsr_date; 		// (VARCHAR2, 8.0)
    public String rgsr_time; 		// (VARCHAR2, 6.0)
    public String mnt_emp_no; 		// (VARCHAR2, 7.0)
    public String mnt_date; 		// (VARCHAR2, 8.0)
    public String mnt_time; 		// (VARCHAR2, 6.0)
    public String shop_code_desc; 		// (VARCHAR2, 100.0)

public HP.WG916CRec(){ } // default constructor

public HP.WG916CRec(
       String shop_code, String intc_outc_clsf_code, String cut_shop_indc, String assy_shop_indc, String oft_shop_indc, String pnt_shop_indc, 
       String erec_shop_indc, String dstn_clsf_code, String rgsr_emp_no, String rgsr_date, String rgsr_time, String mnt_emp_no, 
       String mnt_date, String mnt_time, String shop_code_desc){
    this.shop_code = shop_code;
    this.intc_outc_clsf_code = intc_outc_clsf_code;
    this.cut_shop_indc = cut_shop_indc;
    this.assy_shop_indc = assy_shop_indc;
    this.oft_shop_indc = oft_shop_indc;
    this.pnt_shop_indc = pnt_shop_indc;
    this.erec_shop_indc = erec_shop_indc;
    this.dstn_clsf_code = dstn_clsf_code;
    this.rgsr_emp_no = rgsr_emp_no;
    this.rgsr_date = rgsr_date;
    this.rgsr_time = rgsr_time;
    this.mnt_emp_no = mnt_emp_no;
    this.mnt_date = mnt_date;
    this.mnt_time = mnt_time;
    this.shop_code_desc = shop_code_desc;
} // Constructor


// Getter 
public String getShop_code(){ return shop_code;}
public String getIntc_outc_clsf_code(){ return intc_outc_clsf_code;}
public String getCut_shop_indc(){ return cut_shop_indc;}
public String getAssy_shop_indc(){ return assy_shop_indc;}
public String getOft_shop_indc(){ return oft_shop_indc;}
public String getPnt_shop_indc(){ return pnt_shop_indc;}
public String getErec_shop_indc(){ return erec_shop_indc;}
public String getDstn_clsf_code(){ return dstn_clsf_code;}
public String getRgsr_emp_no(){ return rgsr_emp_no;}
public String getRgsr_date(){ return rgsr_date;}
public String getRgsr_time(){ return rgsr_time;}
public String getMnt_emp_no(){ return mnt_emp_no;}
public String getMnt_date(){ return mnt_date;}
public String getMnt_time(){ return mnt_time;}
public String getShop_code_desc(){ return shop_code_desc;}

// Setter 
public void setShop_code(String shop_code){ this.shop_code = shop_code;}
public void setIntc_outc_clsf_code(String intc_outc_clsf_code){ this.intc_outc_clsf_code = intc_outc_clsf_code;}
public void setCut_shop_indc(String cut_shop_indc){ this.cut_shop_indc = cut_shop_indc;}
public void setAssy_shop_indc(String assy_shop_indc){ this.assy_shop_indc = assy_shop_indc;}
public void setOft_shop_indc(String oft_shop_indc){ this.oft_shop_indc = oft_shop_indc;}
public void setPnt_shop_indc(String pnt_shop_indc){ this.pnt_shop_indc = pnt_shop_indc;}
public void setErec_shop_indc(String erec_shop_indc){ this.erec_shop_indc = erec_shop_indc;}
public void setDstn_clsf_code(String dstn_clsf_code){ this.dstn_clsf_code = dstn_clsf_code;}
public void setRgsr_emp_no(String rgsr_emp_no){ this.rgsr_emp_no = rgsr_emp_no;}
public void setRgsr_date(String rgsr_date){ this.rgsr_date = rgsr_date;}
public void setRgsr_time(String rgsr_time){ this.rgsr_time = rgsr_time;}
public void setMnt_emp_no(String mnt_emp_no){ this.mnt_emp_no = mnt_emp_no;}
public void setMnt_date(String mnt_date){ this.mnt_date = mnt_date;}
public void setMnt_time(String mnt_time){ this.mnt_time = mnt_time;}
public void setShop_code_desc(String shop_code_desc){ this.shop_code_desc = shop_code_desc;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = shop_code + "" ; break;
  case  2 : field = intc_outc_clsf_code + "" ; break;
  case  3 : field = cut_shop_indc + "" ; break;
  case  4 : field = assy_shop_indc + "" ; break;
  case  5 : field = oft_shop_indc + "" ; break;
  case  6 : field = pnt_shop_indc + "" ; break;
  case  7 : field = erec_shop_indc + "" ; break;
  case  8 : field = dstn_clsf_code + "" ; break;
  case  9 : field = rgsr_emp_no + "" ; break;
  case  10 : field = rgsr_date + "" ; break;
  case  11 : field = rgsr_time + "" ; break;
  case  12 : field = mnt_emp_no + "" ; break;
  case  13 : field = mnt_date + "" ; break;
  case  14 : field = mnt_time + "" ; break;
  case  15 : field = shop_code_desc + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("shop_code")){ field = shop_code + "" ; 
     } else if(rec.equalsIgnoreCase("intc_outc_clsf_code")){ field = intc_outc_clsf_code + "" ; 
     } else if(rec.equalsIgnoreCase("cut_shop_indc")){ field = cut_shop_indc + "" ; 
     } else if(rec.equalsIgnoreCase("assy_shop_indc")){ field = assy_shop_indc + "" ; 
     } else if(rec.equalsIgnoreCase("oft_shop_indc")){ field = oft_shop_indc + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_shop_indc")){ field = pnt_shop_indc + "" ; 
     } else if(rec.equalsIgnoreCase("erec_shop_indc")){ field = erec_shop_indc + "" ; 
     } else if(rec.equalsIgnoreCase("dstn_clsf_code")){ field = dstn_clsf_code + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_emp_no")){ field = rgsr_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_date")){ field = rgsr_date + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_time")){ field = rgsr_time + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_emp_no")){ field = mnt_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_date")){ field = mnt_date + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_time")){ field = mnt_time + "" ; 
     } else if(rec.equalsIgnoreCase("shop_code_desc")){ field = shop_code_desc + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "SHOP_CODE", "INTC_OUTC_CLSF_CODE", "CUT_SHOP_INDC", "ASSY_SHOP_INDC", "OFT_SHOP_INDC", "PNT_SHOP_INDC", "EREC_SHOP_INDC", 
       "DSTN_CLSF_CODE", "RGSR_EMP_NO", "RGSR_DATE", "RGSR_TIME", "MNT_EMP_NO", "MNT_DATE", "MNT_TIME", 
       "SHOP_CODE_DESC"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "SHOP_CODE"};
    return tempx;
}

}// end HP.WG916CRec class