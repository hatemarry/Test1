package com.bes_line.mst.HPW;

// DBWrapper Class for HP.WG916C
/**
 *
 * @(#) HP.WG916CDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-17
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class WG916CDBWrapBES extends DBWrapper{

public WG916CDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Select Page 
* @param String shop_code
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-17
*/
public java.util.Vector selectPage(String fldname, int page, int pagesize, String whereOption ) throws Exception{
return selectPage(fldname,page,pagesize, "Asc", whereOption) ;
}// end selectPage
/**
* Select Page
* @param String shop_code* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-17
*/
public java.util.Vector selectPage(String fldname, int page, int pagesize, String keyorder, String whereOption) throws Exception{
    java.util.Vector hp.wg916cV = new java.util.Vector();
    HP.WG916CRec hp.wg916c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select shop_code, intc_outc_clsf_code, cut_shop_indc, assy_shop_indc, oft_shop_indc, pnt_shop_indc, erec_shop_indc, dstn_clsf_code, rgsr_emp_no, " +
                              "rgsr_date, rgsr_time, mnt_emp_no, mnt_date, mnt_time, shop_code_desc " +
                       "  from HP.WG916C  where 1 = 1 " +	whereOption  +
                       "  order by "+fldname+" "+keyorder; 
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();
        int count = 0;
        while((count < (page-1)*pagesize ) && ( rs.next())){  count ++; } // page??? ??????
            count = 0;
        while(rs.next()){
            count ++;
            if(count > pagesize ) break;
            hp.wg916c = new HP.WG916CRec(); // HP.WG916CRec Constructor
                     hp.wg916c.setShop_code(rs.getString("shop_code"));
                     hp.wg916c.setIntc_outc_clsf_code(rs.getString("intc_outc_clsf_code"));
                     hp.wg916c.setCut_shop_indc(rs.getString("cut_shop_indc"));
                     hp.wg916c.setAssy_shop_indc(rs.getString("assy_shop_indc"));
                     hp.wg916c.setOft_shop_indc(rs.getString("oft_shop_indc"));
                     hp.wg916c.setPnt_shop_indc(rs.getString("pnt_shop_indc"));
                     hp.wg916c.setErec_shop_indc(rs.getString("erec_shop_indc"));
                     hp.wg916c.setDstn_clsf_code(rs.getString("dstn_clsf_code"));
                     hp.wg916c.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     hp.wg916c.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg916c.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg916c.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     hp.wg916c.setMnt_date(rs.getString("mnt_date"));
                     hp.wg916c.setMnt_time(rs.getString("mnt_time"));
                     hp.wg916c.setShop_code_desc(rs.getString("shop_code_desc"));
            hp.wg916cV.addElement(hp.wg916c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg916cV;
} // end selectPage

/**
* SelectWhere 
* @param String shop_code
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-17
*/
public java.util.Vector selectWhere(String fldname, String whereOption ) throws Exception{
return selectWhere(fldname, "Asc", whereOption) ;
}// end selectWhere
/**
* SelectWhere
* @param String shop_code* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-17
*/
public java.util.Vector selectWhere(String fldname, String keyorder, String whereOption) throws Exception{
    java.util.Vector hp.wg916cV = new java.util.Vector();
    HP.WG916CRec hp.wg916c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select shop_code, intc_outc_clsf_code, cut_shop_indc, assy_shop_indc, oft_shop_indc, pnt_shop_indc, erec_shop_indc, dstn_clsf_code, rgsr_emp_no, " +
                              "rgsr_date, rgsr_time, mnt_emp_no, mnt_date, mnt_time, shop_code_desc " +
                       "  from HP.WG916C  where 1 = 1 " +	whereOption  +
                       "  order by "+fldname+" "+keyorder; 
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();
        while(rs.next()) { 
            hp.wg916c = new HP.WG916CRec(); // HP.WG916CRec Constructor
                     hp.wg916c.setShop_code(rs.getString("shop_code"));
                     hp.wg916c.setIntc_outc_clsf_code(rs.getString("intc_outc_clsf_code"));
                     hp.wg916c.setCut_shop_indc(rs.getString("cut_shop_indc"));
                     hp.wg916c.setAssy_shop_indc(rs.getString("assy_shop_indc"));
                     hp.wg916c.setOft_shop_indc(rs.getString("oft_shop_indc"));
                     hp.wg916c.setPnt_shop_indc(rs.getString("pnt_shop_indc"));
                     hp.wg916c.setErec_shop_indc(rs.getString("erec_shop_indc"));
                     hp.wg916c.setDstn_clsf_code(rs.getString("dstn_clsf_code"));
                     hp.wg916c.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     hp.wg916c.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg916c.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg916c.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     hp.wg916c.setMnt_date(rs.getString("mnt_date"));
                     hp.wg916c.setMnt_time(rs.getString("mnt_time"));
                     hp.wg916c.setShop_code_desc(rs.getString("shop_code_desc"));
            hp.wg916cV.addElement(hp.wg916c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg916cV;
} // end selectWhere

/**
* Get Rows CountPage 
* @param 
* @return int 
* @author besTeam 
* @date 2006-5-17
*/
public int countPage(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select COUNT(*) from HP.WG916C  where 1 = 1 " +	whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end countPage

/**
* Get one Record 
* @param String shop_code
* @return HP.WG916CRec 
* @author besTeam 
* @date 2006-5-17
*/
public HP.WG916CRec select(String shop_code) throws Exception{
    HP.WG916CRec hp.wg916c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM HP.WG916C "

		+ " where shop_code = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,shop_code); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            hp.wg916c = new HP.WG916CRec(); // HP.WG916CRec Constructor
                     hp.wg916c.setShop_code(rs.getString("shop_code"));
                     hp.wg916c.setIntc_outc_clsf_code(rs.getString("intc_outc_clsf_code"));
                     hp.wg916c.setCut_shop_indc(rs.getString("cut_shop_indc"));
                     hp.wg916c.setAssy_shop_indc(rs.getString("assy_shop_indc"));
                     hp.wg916c.setOft_shop_indc(rs.getString("oft_shop_indc"));
                     hp.wg916c.setPnt_shop_indc(rs.getString("pnt_shop_indc"));
                     hp.wg916c.setErec_shop_indc(rs.getString("erec_shop_indc"));
                     hp.wg916c.setDstn_clsf_code(rs.getString("dstn_clsf_code"));
                     hp.wg916c.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     hp.wg916c.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg916c.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg916c.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     hp.wg916c.setMnt_date(rs.getString("mnt_date"));
                     hp.wg916c.setMnt_time(rs.getString("mnt_time"));
                     hp.wg916c.setShop_code_desc(rs.getString("shop_code_desc"));
        } else {
            throw new DataNotFoundException();
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg916c;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-17
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector hp.wg916cV = new java.util.Vector();
    HP.WG916CRec hp.wg916c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM HP.WG916C "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            hp.wg916c = new HP.WG916CRec(); // HP.WG916CRec Constructor
                     hp.wg916c.setShop_code(rs.getString("shop_code"));
                     hp.wg916c.setIntc_outc_clsf_code(rs.getString("intc_outc_clsf_code"));
                     hp.wg916c.setCut_shop_indc(rs.getString("cut_shop_indc"));
                     hp.wg916c.setAssy_shop_indc(rs.getString("assy_shop_indc"));
                     hp.wg916c.setOft_shop_indc(rs.getString("oft_shop_indc"));
                     hp.wg916c.setPnt_shop_indc(rs.getString("pnt_shop_indc"));
                     hp.wg916c.setErec_shop_indc(rs.getString("erec_shop_indc"));
                     hp.wg916c.setDstn_clsf_code(rs.getString("dstn_clsf_code"));
                     hp.wg916c.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     hp.wg916c.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg916c.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg916c.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     hp.wg916c.setMnt_date(rs.getString("mnt_date"));
                     hp.wg916c.setMnt_time(rs.getString("mnt_time"));
                     hp.wg916c.setShop_code_desc(rs.getString("shop_code_desc"));
            hp.wg916cV.addElement(hp.wg916c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg916cV;
} // end selectAll

/**
* Get selectWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-17
*/
public java.util.Vector selectWhere(String whereOption) throws Exception{
    java.util.Vector hp.wg916cV = new java.util.Vector();
    HP.WG916CRec hp.wg916c = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM HP.WG916C "

  + whereOption; 
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            hp.wg916c = new HP.WG916CRec(); // HP.WG916CRec Constructor
                     hp.wg916c.setShop_code(rs.getString("shop_code"));
                     hp.wg916c.setIntc_outc_clsf_code(rs.getString("intc_outc_clsf_code"));
                     hp.wg916c.setCut_shop_indc(rs.getString("cut_shop_indc"));
                     hp.wg916c.setAssy_shop_indc(rs.getString("assy_shop_indc"));
                     hp.wg916c.setOft_shop_indc(rs.getString("oft_shop_indc"));
                     hp.wg916c.setPnt_shop_indc(rs.getString("pnt_shop_indc"));
                     hp.wg916c.setErec_shop_indc(rs.getString("erec_shop_indc"));
                     hp.wg916c.setDstn_clsf_code(rs.getString("dstn_clsf_code"));
                     hp.wg916c.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     hp.wg916c.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg916c.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg916c.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     hp.wg916c.setMnt_date(rs.getString("mnt_date"));
                     hp.wg916c.setMnt_time(rs.getString("mnt_time"));
                     hp.wg916c.setShop_code_desc(rs.getString("shop_code_desc"));
            hp.wg916cV.addElement(hp.wg916c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg916cV;
} // end selectAll

/**
* Select Data Over the key value(s) and default return count(20) 
* @param String shop_code
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-17
*/
public java.util.Vector selectOver(String shop_code) throws Exception{
return selectOver(shop_code,20) ;
}// end selectOver
/**
* Select Data Over(Next) the key value(s) and return record count 
* @param String shop_code, int 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-17
*/
public java.util.Vector selectOver(String shop_code, int page) throws Exception{
    java.util.Vector hp.wg916cV = new java.util.Vector();
    HP.WG916CRec hp.wg916c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM HP.WG916C "

		+ " where shop_code >= ? order by shop_code "; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,shop_code); 
        rs = pstmt.executeQuery();
        int count = 0;//??f??? SQL?????? Limit??? ????...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            hp.wg916c = new HP.WG916CRec(); // HP.WG916CRec Constructor
                     hp.wg916c.setShop_code(rs.getString("shop_code"));
                     hp.wg916c.setIntc_outc_clsf_code(rs.getString("intc_outc_clsf_code"));
                     hp.wg916c.setCut_shop_indc(rs.getString("cut_shop_indc"));
                     hp.wg916c.setAssy_shop_indc(rs.getString("assy_shop_indc"));
                     hp.wg916c.setOft_shop_indc(rs.getString("oft_shop_indc"));
                     hp.wg916c.setPnt_shop_indc(rs.getString("pnt_shop_indc"));
                     hp.wg916c.setErec_shop_indc(rs.getString("erec_shop_indc"));
                     hp.wg916c.setDstn_clsf_code(rs.getString("dstn_clsf_code"));
                     hp.wg916c.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     hp.wg916c.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg916c.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg916c.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     hp.wg916c.setMnt_date(rs.getString("mnt_date"));
                     hp.wg916c.setMnt_time(rs.getString("mnt_time"));
                     hp.wg916c.setShop_code_desc(rs.getString("shop_code_desc"));
            hp.wg916cV.addElement(hp.wg916c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg916cV;
} // end selectOver

/**
* Select Data Under(Previous) the key value(s) and default return count(20) 
* @param String shop_code
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-17
*/
public java.util.Vector selectUnder(String shop_code) throws Exception{
return selectUnder(shop_code,20) ;
}// end selectUnder
/**
* Select Data Under(Previous) the key value(s) and return record count 
* @param String shop_code, int
* @return java.util.Vector
* @author besTeam 
* @date 2006-5-17
*/
public java.util.Vector selectUnder(String shop_code, int page) throws Exception{
    java.util.Vector hp.wg916cV = new java.util.Vector();
    HP.WG916CRec hp.wg916c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT * FROM HP.WG916C "

		+ " where shop_code <= ? order by shop_code desc" ; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,shop_code); 
        rs = pstmt.executeQuery();
        int count = 0;//??f??? SQL?????? Limit??? ????...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            hp.wg916c = new HP.WG916CRec(); // HP.WG916CRec Constructor
                     hp.wg916c.setShop_code(rs.getString("shop_code"));
                     hp.wg916c.setIntc_outc_clsf_code(rs.getString("intc_outc_clsf_code"));
                     hp.wg916c.setCut_shop_indc(rs.getString("cut_shop_indc"));
                     hp.wg916c.setAssy_shop_indc(rs.getString("assy_shop_indc"));
                     hp.wg916c.setOft_shop_indc(rs.getString("oft_shop_indc"));
                     hp.wg916c.setPnt_shop_indc(rs.getString("pnt_shop_indc"));
                     hp.wg916c.setErec_shop_indc(rs.getString("erec_shop_indc"));
                     hp.wg916c.setDstn_clsf_code(rs.getString("dstn_clsf_code"));
                     hp.wg916c.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     hp.wg916c.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg916c.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg916c.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     hp.wg916c.setMnt_date(rs.getString("mnt_date"));
                     hp.wg916c.setMnt_time(rs.getString("mnt_time"));
                     hp.wg916c.setShop_code_desc(rs.getString("shop_code_desc"));
            hp.wg916cV.add(0,hp.wg916c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg916cV;
} // end selectUnder
/**
* Get Rows Count 
* @param String shop_code
* @return int 
* @author besTeam 
* @date 2006-5-17
*/
public int count(String shop_code) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " HP.WG916C "

		+ " where shop_code = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,shop_code); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param void 
* @return int 
* @author besTeam 
* @date 2006-5-17
*/
public int count() throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " HP.WG916C "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}// end HP.WG916CDBWrapBES class