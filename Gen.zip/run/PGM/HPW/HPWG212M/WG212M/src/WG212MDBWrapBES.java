package com.bes_line.mst.HPW;

// DBWrapper Class for WG212M
/**
 *
 * @(#) WG212MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-7
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class WG212MDBWrapBES extends DBWrapper{

public WG212MDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String bdgt_pln_acty
* @return WG212MRec 
* @author besTeam 
* @date 2006-6-7
*/
public WG212MRec select(String bdgt_pln_acty) throws Exception{
    java.util.Vector wg212mV = new java.util.Vector();
    WG212MRec wg212m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select bdgt_pln_acty, base_pln_acty, proj_no, flag, blk_zone_no, mp, bdpa_detl_clsf_code, ord_type, dtbn_stus_code, " +
                              "sch_fix_indc, work_stus_code, wcg_code, work_stge_code, pln_wv, wv_unit, dsme_std_mh, tagt_mh, pln_sd, " +
                              "pln_fd, actl_sd, actl_fd, assy_shop, last_mgnt_pgm_name, wstg_code, assy_jl, assy_wl, assy_gl, " +
                              "fit_tagt_mh, weld_tagt_mh, grd_tagt_mh, jig_code, cut_ssch_assy_base_date, cut_ssch_cnfm_date, rgsr_emp_no, rgsr_date, rgsr_time, " +
                              "mnt_emp_no, mnt_date, mnt_time, acty_desc " +
                       "  from HP.WG212M  " +
                       "  where bdgt_pln_acty = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,bdgt_pln_acty); 
        rs = pstmt.executeQuery();
        while(rs.next()) { 
            wg212m = new WG212MRec(); // WG212MRec Constructor
                     wg212m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     wg212m.setBase_pln_acty(rs.getString("base_pln_acty"));
                     wg212m.setProj_no(rs.getString("proj_no"));
                     wg212m.setFlag(rs.getString("flag"));
                     wg212m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     wg212m.setMp(rs.getString("mp"));
                     wg212m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     wg212m.setOrd_type(rs.getString("ord_type"));
                     wg212m.setDtbn_stus_code(rs.getString("dtbn_stus_code"));
                     wg212m.setSch_fix_indc(rs.getString("sch_fix_indc"));
                     wg212m.setWork_stus_code(rs.getString("work_stus_code"));
                     wg212m.setWcg_code(rs.getString("wcg_code"));
                     wg212m.setWork_stge_code(rs.getString("work_stge_code"));
                     wg212m.setPln_wv(rs.getDouble("pln_wv"));
                     wg212m.setWv_unit(rs.getString("wv_unit"));
                     wg212m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     wg212m.setTagt_mh(rs.getDouble("tagt_mh"));
                     wg212m.setPln_sd(rs.getString("pln_sd"));
                     wg212m.setPln_fd(rs.getString("pln_fd"));
                     wg212m.setActl_sd(rs.getString("actl_sd"));
                     wg212m.setActl_fd(rs.getString("actl_fd"));
                     wg212m.setAssy_shop(rs.getString("assy_shop"));
                     wg212m.setLast_mgnt_pgm_name(rs.getString("last_mgnt_pgm_name"));
                     wg212m.setWstg_code(rs.getString("wstg_code"));
                     wg212m.setAssy_jl(rs.getDouble("assy_jl"));
                     wg212m.setAssy_wl(rs.getDouble("assy_wl"));
                     wg212m.setAssy_gl(rs.getDouble("assy_gl"));
                     wg212m.setFit_tagt_mh(rs.getDouble("fit_tagt_mh"));
                     wg212m.setWeld_tagt_mh(rs.getDouble("weld_tagt_mh"));
                     wg212m.setGrd_tagt_mh(rs.getDouble("grd_tagt_mh"));
                     wg212m.setJig_code(rs.getString("jig_code"));
                     wg212m.setCut_ssch_assy_base_date(rs.getString("cut_ssch_assy_base_date"));
                     wg212m.setCut_ssch_cnfm_date(rs.getString("cut_ssch_cnfm_date"));
                     wg212m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     wg212m.setRgsr_date(rs.getString("rgsr_date"));
                     wg212m.setRgsr_time(rs.getString("rgsr_time"));
                     wg212m.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     wg212m.setMnt_date(rs.getString("mnt_date"));
                     wg212m.setMnt_time(rs.getString("mnt_time"));
                     wg212m.setActy_desc(rs.getString("acty_desc"));
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return wg212m;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-7
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector wg212mV = new java.util.Vector();
    WG212MRec wg212m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select bdgt_pln_acty, base_pln_acty, proj_no, flag, blk_zone_no, mp, bdpa_detl_clsf_code, ord_type, dtbn_stus_code, " +
                              "sch_fix_indc, work_stus_code, wcg_code, work_stge_code, pln_wv, wv_unit, dsme_std_mh, tagt_mh, pln_sd, " +
                              "pln_fd, actl_sd, actl_fd, assy_shop, last_mgnt_pgm_name, wstg_code, assy_jl, assy_wl, assy_gl, " +
                              "fit_tagt_mh, weld_tagt_mh, grd_tagt_mh, jig_code, cut_ssch_assy_base_date, cut_ssch_cnfm_date, rgsr_emp_no, rgsr_date, rgsr_time, " +
                              "mnt_emp_no, mnt_date, mnt_time, acty_desc " +
                       "  from HP.WG212M "+
                       "  order by bdgt_pln_acty ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            wg212m = new WG212MRec(); // WG212MRec Constructor
                     wg212m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     wg212m.setBase_pln_acty(rs.getString("base_pln_acty"));
                     wg212m.setProj_no(rs.getString("proj_no"));
                     wg212m.setFlag(rs.getString("flag"));
                     wg212m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     wg212m.setMp(rs.getString("mp"));
                     wg212m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     wg212m.setOrd_type(rs.getString("ord_type"));
                     wg212m.setDtbn_stus_code(rs.getString("dtbn_stus_code"));
                     wg212m.setSch_fix_indc(rs.getString("sch_fix_indc"));
                     wg212m.setWork_stus_code(rs.getString("work_stus_code"));
                     wg212m.setWcg_code(rs.getString("wcg_code"));
                     wg212m.setWork_stge_code(rs.getString("work_stge_code"));
                     wg212m.setPln_wv(rs.getDouble("pln_wv"));
                     wg212m.setWv_unit(rs.getString("wv_unit"));
                     wg212m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     wg212m.setTagt_mh(rs.getDouble("tagt_mh"));
                     wg212m.setPln_sd(rs.getString("pln_sd"));
                     wg212m.setPln_fd(rs.getString("pln_fd"));
                     wg212m.setActl_sd(rs.getString("actl_sd"));
                     wg212m.setActl_fd(rs.getString("actl_fd"));
                     wg212m.setAssy_shop(rs.getString("assy_shop"));
                     wg212m.setLast_mgnt_pgm_name(rs.getString("last_mgnt_pgm_name"));
                     wg212m.setWstg_code(rs.getString("wstg_code"));
                     wg212m.setAssy_jl(rs.getDouble("assy_jl"));
                     wg212m.setAssy_wl(rs.getDouble("assy_wl"));
                     wg212m.setAssy_gl(rs.getDouble("assy_gl"));
                     wg212m.setFit_tagt_mh(rs.getDouble("fit_tagt_mh"));
                     wg212m.setWeld_tagt_mh(rs.getDouble("weld_tagt_mh"));
                     wg212m.setGrd_tagt_mh(rs.getDouble("grd_tagt_mh"));
                     wg212m.setJig_code(rs.getString("jig_code"));
                     wg212m.setCut_ssch_assy_base_date(rs.getString("cut_ssch_assy_base_date"));
                     wg212m.setCut_ssch_cnfm_date(rs.getString("cut_ssch_cnfm_date"));
                     wg212m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     wg212m.setRgsr_date(rs.getString("rgsr_date"));
                     wg212m.setRgsr_time(rs.getString("rgsr_time"));
                     wg212m.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     wg212m.setMnt_date(rs.getString("mnt_date"));
                     wg212m.setMnt_time(rs.getString("mnt_time"));
                     wg212m.setActy_desc(rs.getString("acty_desc"));
            wg212mV.addElement(wg212m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return wg212mV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-7
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector wg212mV = new java.util.Vector();
    WG212MRec wg212m = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select bdgt_pln_acty, base_pln_acty, proj_no, flag, blk_zone_no, mp, bdpa_detl_clsf_code, ord_type, dtbn_stus_code, " +
                              "sch_fix_indc, work_stus_code, wcg_code, work_stge_code, pln_wv, wv_unit, dsme_std_mh, tagt_mh, pln_sd, " +
                              "pln_fd, actl_sd, actl_fd, assy_shop, last_mgnt_pgm_name, wstg_code, assy_jl, assy_wl, assy_gl, " +
                              "fit_tagt_mh, weld_tagt_mh, grd_tagt_mh, jig_code, cut_ssch_assy_base_date, cut_ssch_cnfm_date, rgsr_emp_no, rgsr_date, rgsr_time, " +
                              "mnt_emp_no, mnt_date, mnt_time, acty_desc " +
                       "  from HP.WG212M  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  bdgt_pln_acty " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            wg212m = new WG212MRec(); // WG212MRec Constructor
                     wg212m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     wg212m.setBase_pln_acty(rs.getString("base_pln_acty"));
                     wg212m.setProj_no(rs.getString("proj_no"));
                     wg212m.setFlag(rs.getString("flag"));
                     wg212m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     wg212m.setMp(rs.getString("mp"));
                     wg212m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     wg212m.setOrd_type(rs.getString("ord_type"));
                     wg212m.setDtbn_stus_code(rs.getString("dtbn_stus_code"));
                     wg212m.setSch_fix_indc(rs.getString("sch_fix_indc"));
                     wg212m.setWork_stus_code(rs.getString("work_stus_code"));
                     wg212m.setWcg_code(rs.getString("wcg_code"));
                     wg212m.setWork_stge_code(rs.getString("work_stge_code"));
                     wg212m.setPln_wv(rs.getDouble("pln_wv"));
                     wg212m.setWv_unit(rs.getString("wv_unit"));
                     wg212m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     wg212m.setTagt_mh(rs.getDouble("tagt_mh"));
                     wg212m.setPln_sd(rs.getString("pln_sd"));
                     wg212m.setPln_fd(rs.getString("pln_fd"));
                     wg212m.setActl_sd(rs.getString("actl_sd"));
                     wg212m.setActl_fd(rs.getString("actl_fd"));
                     wg212m.setAssy_shop(rs.getString("assy_shop"));
                     wg212m.setLast_mgnt_pgm_name(rs.getString("last_mgnt_pgm_name"));
                     wg212m.setWstg_code(rs.getString("wstg_code"));
                     wg212m.setAssy_jl(rs.getDouble("assy_jl"));
                     wg212m.setAssy_wl(rs.getDouble("assy_wl"));
                     wg212m.setAssy_gl(rs.getDouble("assy_gl"));
                     wg212m.setFit_tagt_mh(rs.getDouble("fit_tagt_mh"));
                     wg212m.setWeld_tagt_mh(rs.getDouble("weld_tagt_mh"));
                     wg212m.setGrd_tagt_mh(rs.getDouble("grd_tagt_mh"));
                     wg212m.setJig_code(rs.getString("jig_code"));
                     wg212m.setCut_ssch_assy_base_date(rs.getString("cut_ssch_assy_base_date"));
                     wg212m.setCut_ssch_cnfm_date(rs.getString("cut_ssch_cnfm_date"));
                     wg212m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     wg212m.setRgsr_date(rs.getString("rgsr_date"));
                     wg212m.setRgsr_time(rs.getString("rgsr_time"));
                     wg212m.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     wg212m.setMnt_date(rs.getString("mnt_date"));
                     wg212m.setMnt_time(rs.getString("mnt_time"));
                     wg212m.setActy_desc(rs.getString("acty_desc"));
            wg212mV.addElement(wg212m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return wg212mV;
} // end selectAll

/**
* Get Rows Count 
* @param String bdgt_pln_acty
* @return int 
* @author besTeam 
* @date 2006-6-7
*/
public int count(String bdgt_pln_acty) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HP.WG212M " +
                       " where bdgt_pln_acty = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,bdgt_pln_acty); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-7
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HP.WG212M  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param WG212MRec 
* @return void 
* @author besTeam 
* @date 2006-6-7
*/
public void insert(WG212MRec wg212m) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HP.WG212M( " +
                              "bdgt_pln_acty, base_pln_acty, proj_no, flag, blk_zone_no, mp, bdpa_detl_clsf_code, ord_type, dtbn_stus_code, " +
                              "sch_fix_indc, work_stus_code, wcg_code, work_stge_code, pln_wv, wv_unit, dsme_std_mh, tagt_mh, pln_sd, " +
                              "pln_fd, actl_sd, actl_fd, assy_shop, last_mgnt_pgm_name, wstg_code, assy_jl, assy_wl, assy_gl, " +
                              "fit_tagt_mh, weld_tagt_mh, grd_tagt_mh, jig_code, cut_ssch_assy_base_date, cut_ssch_cnfm_date, rgsr_emp_no, rgsr_date, rgsr_time, " +
                              "mnt_emp_no, mnt_date, mnt_time, acty_desc"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, wg212m.getBdgt_pln_acty());
        pstmt.setString(2, wg212m.getBase_pln_acty());
        pstmt.setString(3, wg212m.getProj_no());
        pstmt.setString(4, wg212m.getFlag());
        pstmt.setString(5, wg212m.getBlk_zone_no());
        pstmt.setString(6, wg212m.getMp());
        pstmt.setString(7, wg212m.getBdpa_detl_clsf_code());
        pstmt.setString(8, wg212m.getOrd_type());
        pstmt.setString(9, wg212m.getDtbn_stus_code());
        pstmt.setString(10, wg212m.getSch_fix_indc());
        pstmt.setString(11, wg212m.getWork_stus_code());
        pstmt.setString(12, wg212m.getWcg_code());
        pstmt.setString(13, wg212m.getWork_stge_code());
        pstmt.setDouble(14, wg212m.getPln_wv());
        pstmt.setString(15, wg212m.getWv_unit());
        pstmt.setDouble(16, wg212m.getDsme_std_mh());
        pstmt.setDouble(17, wg212m.getTagt_mh());
        pstmt.setString(18, wg212m.getPln_sd());
        pstmt.setString(19, wg212m.getPln_fd());
        pstmt.setString(20, wg212m.getActl_sd());
        pstmt.setString(21, wg212m.getActl_fd());
        pstmt.setString(22, wg212m.getAssy_shop());
        pstmt.setString(23, wg212m.getLast_mgnt_pgm_name());
        pstmt.setString(24, wg212m.getWstg_code());
        pstmt.setDouble(25, wg212m.getAssy_jl());
        pstmt.setDouble(26, wg212m.getAssy_wl());
        pstmt.setDouble(27, wg212m.getAssy_gl());
        pstmt.setDouble(28, wg212m.getFit_tagt_mh());
        pstmt.setDouble(29, wg212m.getWeld_tagt_mh());
        pstmt.setDouble(30, wg212m.getGrd_tagt_mh());
        pstmt.setString(31, wg212m.getJig_code());
        pstmt.setString(32, wg212m.getCut_ssch_assy_base_date());
        pstmt.setString(33, wg212m.getCut_ssch_cnfm_date());
        pstmt.setString(34, wg212m.getRgsr_emp_no());
        pstmt.setString(35, wg212m.getRgsr_date());
        pstmt.setString(36, wg212m.getRgsr_time());
        pstmt.setString(37, wg212m.getMnt_emp_no());
        pstmt.setString(38, wg212m.getMnt_date());
        pstmt.setString(39, wg212m.getMnt_time());
        pstmt.setString(40, wg212m.getActy_desc());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param WG212MRec 
* @return void 
* @author besTeam 
* @date 2006-6-7
*/
public void update(WG212MRec wg212m) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HP.WG212M SET "+
                        "bdgt_pln_acty = ?, base_pln_acty = ?, proj_no = ?, flag = ?, blk_zone_no = ?, mp = ?, bdpa_detl_clsf_code = ?, ord_type = ?, dtbn_stus_code = ?, sch_fix_indc = ?, " +
                              "work_stus_code = ?, wcg_code = ?, work_stge_code = ?, pln_wv = ?, wv_unit = ?, dsme_std_mh = ?, tagt_mh = ?, pln_sd = ?, pln_fd = ?, " +
                              "actl_sd = ?, actl_fd = ?, assy_shop = ?, last_mgnt_pgm_name = ?, wstg_code = ?, assy_jl = ?, assy_wl = ?, assy_gl = ?, fit_tagt_mh = ?, " +
                              "weld_tagt_mh = ?, grd_tagt_mh = ?, jig_code = ?, cut_ssch_assy_base_date = ?, cut_ssch_cnfm_date = ?, mnt_emp_no = ?, " +
                              "mnt_date = ?, mnt_time = ?, acty_desc = ?"+
                        " where bdgt_pln_acty = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, wg212m.getBdgt_pln_acty());
        pstmt.setString(2, wg212m.getBase_pln_acty());
        pstmt.setString(3, wg212m.getProj_no());
        pstmt.setString(4, wg212m.getFlag());
        pstmt.setString(5, wg212m.getBlk_zone_no());
        pstmt.setString(6, wg212m.getMp());
        pstmt.setString(7, wg212m.getBdpa_detl_clsf_code());
        pstmt.setString(8, wg212m.getOrd_type());
        pstmt.setString(9, wg212m.getDtbn_stus_code());
        pstmt.setString(10, wg212m.getSch_fix_indc());
        pstmt.setString(11, wg212m.getWork_stus_code());
        pstmt.setString(12, wg212m.getWcg_code());
        pstmt.setString(13, wg212m.getWork_stge_code());
        pstmt.setDouble(14, wg212m.getPln_wv());
        pstmt.setString(15, wg212m.getWv_unit());
        pstmt.setDouble(16, wg212m.getDsme_std_mh());
        pstmt.setDouble(17, wg212m.getTagt_mh());
        pstmt.setString(18, wg212m.getPln_sd());
        pstmt.setString(19, wg212m.getPln_fd());
        pstmt.setString(20, wg212m.getActl_sd());
        pstmt.setString(21, wg212m.getActl_fd());
        pstmt.setString(22, wg212m.getAssy_shop());
        pstmt.setString(23, wg212m.getLast_mgnt_pgm_name());
        pstmt.setString(24, wg212m.getWstg_code());
        pstmt.setDouble(25, wg212m.getAssy_jl());
        pstmt.setDouble(26, wg212m.getAssy_wl());
        pstmt.setDouble(27, wg212m.getAssy_gl());
        pstmt.setDouble(28, wg212m.getFit_tagt_mh());
        pstmt.setDouble(29, wg212m.getWeld_tagt_mh());
        pstmt.setDouble(30, wg212m.getGrd_tagt_mh());
        pstmt.setString(31, wg212m.getJig_code());
        pstmt.setString(32, wg212m.getCut_ssch_assy_base_date());
        pstmt.setString(33, wg212m.getCut_ssch_cnfm_date());
        pstmt.setString(34, wg212m.getMnt_emp_no());
        pstmt.setString(35, wg212m.getMnt_date());
        pstmt.setString(36, wg212m.getMnt_time());
        pstmt.setString(37, wg212m.getActy_desc());
        // Key
        pstmt.setString(38, wg212m.getBdgt_pln_acty());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String bdgt_pln_acty
* @return void 
* @author besTeam 
* @date 2006-6-7
*/
public void delete(String bdgt_pln_acty) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HP.WG212M "+
                       "where bdgt_pln_acty = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,bdgt_pln_acty); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param WG212MRec 
* @return void 
* @author besTeam 
* @date 2006-6-7
*/
public void delete(WG212MRec wg212m) throws Exception{
     delete(wg212m.getBdgt_pln_acty());
} // end Delete

}// end WG212MDBWrapBES class