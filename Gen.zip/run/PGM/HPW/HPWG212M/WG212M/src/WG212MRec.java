package com.bes_line.mst.HPW ;

// Entity Class for WG212M
/**
 *
 * @(#) WG212MRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-7
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class WG212MRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String bdgt_pln_acty; 		// (VARCHAR2, 20.0)
    public String base_pln_acty; 		// (VARCHAR2, 20.0)
    public String proj_no; 		// (VARCHAR2, 8.0)
    public String flag; 		// (VARCHAR2, 1.0)
    public String blk_zone_no; 		// (VARCHAR2, 3.0)
    public String mp; 		// (VARCHAR2, 1.0)
    public String bdpa_detl_clsf_code; 		// (VARCHAR2, 6.0)
    public String ord_type; 		// (VARCHAR2, 4.0)
    public String dtbn_stus_code; 		// (VARCHAR2, 1.0)
    public String sch_fix_indc; 		// (VARCHAR2, 1.0)
    public String work_stus_code; 		// (VARCHAR2, 3.0)
    public String wcg_code; 		// (VARCHAR2, 4.0)
    public String work_stge_code; 		// (VARCHAR2, 1.0)
    public double pln_wv; 		// (NUMBER, 9.1)
    public String wv_unit; 		// (VARCHAR2, 10.0)
    public double dsme_std_mh; 		// (NUMBER, 10.3)
    public double tagt_mh; 		// (NUMBER, 10.3)
    public String pln_sd; 		// (VARCHAR2, 8.0)
    public String pln_fd; 		// (VARCHAR2, 8.0)
    public String actl_sd; 		// (VARCHAR2, 8.0)
    public String actl_fd; 		// (VARCHAR2, 8.0)
    public String assy_shop; 		// (VARCHAR2, 3.0)
    public String last_mgnt_pgm_name; 		// (VARCHAR2, 10.0)
    public String wstg_code; 		// (VARCHAR2, 6.0)
    public double assy_jl; 		// (NUMBER, 9.1)
    public double assy_wl; 		// (NUMBER, 9.1)
    public double assy_gl; 		// (NUMBER, 9.1)
    public double fit_tagt_mh; 		// (NUMBER, 10.3)
    public double weld_tagt_mh; 		// (NUMBER, 10.3)
    public double grd_tagt_mh; 		// (NUMBER, 10.3)
    public String jig_code; 		// (VARCHAR2, 6.0)
    public String cut_ssch_assy_base_date; 		// (VARCHAR2, 8.0)
    public String cut_ssch_cnfm_date; 		// (VARCHAR2, 8.0)
    public String rgsr_emp_no; 		// (VARCHAR2, 7.0)
    public String rgsr_date; 		// (VARCHAR2, 8.0)
    public String rgsr_time; 		// (VARCHAR2, 6.0)
    public String mnt_emp_no; 		// (VARCHAR2, 7.0)
    public String mnt_date; 		// (VARCHAR2, 8.0)
    public String mnt_time; 		// (VARCHAR2, 6.0)
    public String acty_desc; 		// (VARCHAR2, 200.0)

public WG212MRec(){ } // default constructor

public WG212MRec(
       String bdgt_pln_acty, String base_pln_acty, String proj_no, String flag, String blk_zone_no, String mp, 
       String bdpa_detl_clsf_code, String ord_type, String dtbn_stus_code, String sch_fix_indc, String work_stus_code, String wcg_code, 
       String work_stge_code, double pln_wv, String wv_unit, double dsme_std_mh, double tagt_mh, String pln_sd, 
       String pln_fd, String actl_sd, String actl_fd, String assy_shop, String last_mgnt_pgm_name, String wstg_code, 
       double assy_jl, double assy_wl, double assy_gl, double fit_tagt_mh, double weld_tagt_mh, double grd_tagt_mh, 
       String jig_code, String cut_ssch_assy_base_date, String cut_ssch_cnfm_date, String rgsr_emp_no, String rgsr_date, String rgsr_time, 
       String mnt_emp_no, String mnt_date, String mnt_time, String acty_desc){
    this.bdgt_pln_acty = bdgt_pln_acty;
    this.base_pln_acty = base_pln_acty;
    this.proj_no = proj_no;
    this.flag = flag;
    this.blk_zone_no = blk_zone_no;
    this.mp = mp;
    this.bdpa_detl_clsf_code = bdpa_detl_clsf_code;
    this.ord_type = ord_type;
    this.dtbn_stus_code = dtbn_stus_code;
    this.sch_fix_indc = sch_fix_indc;
    this.work_stus_code = work_stus_code;
    this.wcg_code = wcg_code;
    this.work_stge_code = work_stge_code;
    this.pln_wv = pln_wv;
    this.wv_unit = wv_unit;
    this.dsme_std_mh = dsme_std_mh;
    this.tagt_mh = tagt_mh;
    this.pln_sd = pln_sd;
    this.pln_fd = pln_fd;
    this.actl_sd = actl_sd;
    this.actl_fd = actl_fd;
    this.assy_shop = assy_shop;
    this.last_mgnt_pgm_name = last_mgnt_pgm_name;
    this.wstg_code = wstg_code;
    this.assy_jl = assy_jl;
    this.assy_wl = assy_wl;
    this.assy_gl = assy_gl;
    this.fit_tagt_mh = fit_tagt_mh;
    this.weld_tagt_mh = weld_tagt_mh;
    this.grd_tagt_mh = grd_tagt_mh;
    this.jig_code = jig_code;
    this.cut_ssch_assy_base_date = cut_ssch_assy_base_date;
    this.cut_ssch_cnfm_date = cut_ssch_cnfm_date;
    this.rgsr_emp_no = rgsr_emp_no;
    this.rgsr_date = rgsr_date;
    this.rgsr_time = rgsr_time;
    this.mnt_emp_no = mnt_emp_no;
    this.mnt_date = mnt_date;
    this.mnt_time = mnt_time;
    this.acty_desc = acty_desc;
} // Constructor


// Getter 
public String getBdgt_pln_acty(){ return bdgt_pln_acty;}
public String getBase_pln_acty(){ return base_pln_acty;}
public String getProj_no(){ return proj_no;}
public String getFlag(){ return flag;}
public String getBlk_zone_no(){ return blk_zone_no;}
public String getMp(){ return mp;}
public String getBdpa_detl_clsf_code(){ return bdpa_detl_clsf_code;}
public String getOrd_type(){ return ord_type;}
public String getDtbn_stus_code(){ return dtbn_stus_code;}
public String getSch_fix_indc(){ return sch_fix_indc;}
public String getWork_stus_code(){ return work_stus_code;}
public String getWcg_code(){ return wcg_code;}
public String getWork_stge_code(){ return work_stge_code;}
public double getPln_wv(){ return pln_wv;}
public String getWv_unit(){ return wv_unit;}
public double getDsme_std_mh(){ return dsme_std_mh;}
public double getTagt_mh(){ return tagt_mh;}
public String getPln_sd(){ return pln_sd;}
public String getPln_fd(){ return pln_fd;}
public String getActl_sd(){ return actl_sd;}
public String getActl_fd(){ return actl_fd;}
public String getAssy_shop(){ return assy_shop;}
public String getLast_mgnt_pgm_name(){ return last_mgnt_pgm_name;}
public String getWstg_code(){ return wstg_code;}
public double getAssy_jl(){ return assy_jl;}
public double getAssy_wl(){ return assy_wl;}
public double getAssy_gl(){ return assy_gl;}
public double getFit_tagt_mh(){ return fit_tagt_mh;}
public double getWeld_tagt_mh(){ return weld_tagt_mh;}
public double getGrd_tagt_mh(){ return grd_tagt_mh;}
public String getJig_code(){ return jig_code;}
public String getCut_ssch_assy_base_date(){ return cut_ssch_assy_base_date;}
public String getCut_ssch_cnfm_date(){ return cut_ssch_cnfm_date;}
public String getRgsr_emp_no(){ return rgsr_emp_no;}
public String getRgsr_date(){ return rgsr_date;}
public String getRgsr_time(){ return rgsr_time;}
public String getMnt_emp_no(){ return mnt_emp_no;}
public String getMnt_date(){ return mnt_date;}
public String getMnt_time(){ return mnt_time;}
public String getActy_desc(){ return acty_desc;}

// Setter 
public void setBdgt_pln_acty(String bdgt_pln_acty){ this.bdgt_pln_acty = bdgt_pln_acty;}
public void setBase_pln_acty(String base_pln_acty){ this.base_pln_acty = base_pln_acty;}
public void setProj_no(String proj_no){ this.proj_no = proj_no;}
public void setFlag(String flag){ this.flag = flag;}
public void setBlk_zone_no(String blk_zone_no){ this.blk_zone_no = blk_zone_no;}
public void setMp(String mp){ this.mp = mp;}
public void setBdpa_detl_clsf_code(String bdpa_detl_clsf_code){ this.bdpa_detl_clsf_code = bdpa_detl_clsf_code;}
public void setOrd_type(String ord_type){ this.ord_type = ord_type;}
public void setDtbn_stus_code(String dtbn_stus_code){ this.dtbn_stus_code = dtbn_stus_code;}
public void setSch_fix_indc(String sch_fix_indc){ this.sch_fix_indc = sch_fix_indc;}
public void setWork_stus_code(String work_stus_code){ this.work_stus_code = work_stus_code;}
public void setWcg_code(String wcg_code){ this.wcg_code = wcg_code;}
public void setWork_stge_code(String work_stge_code){ this.work_stge_code = work_stge_code;}
public void setPln_wv(double pln_wv){ this.pln_wv = pln_wv;}
public void setWv_unit(String wv_unit){ this.wv_unit = wv_unit;}
public void setDsme_std_mh(double dsme_std_mh){ this.dsme_std_mh = dsme_std_mh;}
public void setTagt_mh(double tagt_mh){ this.tagt_mh = tagt_mh;}
public void setPln_sd(String pln_sd){ this.pln_sd = pln_sd;}
public void setPln_fd(String pln_fd){ this.pln_fd = pln_fd;}
public void setActl_sd(String actl_sd){ this.actl_sd = actl_sd;}
public void setActl_fd(String actl_fd){ this.actl_fd = actl_fd;}
public void setAssy_shop(String assy_shop){ this.assy_shop = assy_shop;}
public void setLast_mgnt_pgm_name(String last_mgnt_pgm_name){ this.last_mgnt_pgm_name = last_mgnt_pgm_name;}
public void setWstg_code(String wstg_code){ this.wstg_code = wstg_code;}
public void setAssy_jl(double assy_jl){ this.assy_jl = assy_jl;}
public void setAssy_wl(double assy_wl){ this.assy_wl = assy_wl;}
public void setAssy_gl(double assy_gl){ this.assy_gl = assy_gl;}
public void setFit_tagt_mh(double fit_tagt_mh){ this.fit_tagt_mh = fit_tagt_mh;}
public void setWeld_tagt_mh(double weld_tagt_mh){ this.weld_tagt_mh = weld_tagt_mh;}
public void setGrd_tagt_mh(double grd_tagt_mh){ this.grd_tagt_mh = grd_tagt_mh;}
public void setJig_code(String jig_code){ this.jig_code = jig_code;}
public void setCut_ssch_assy_base_date(String cut_ssch_assy_base_date){ this.cut_ssch_assy_base_date = cut_ssch_assy_base_date;}
public void setCut_ssch_cnfm_date(String cut_ssch_cnfm_date){ this.cut_ssch_cnfm_date = cut_ssch_cnfm_date;}
public void setRgsr_emp_no(String rgsr_emp_no){ this.rgsr_emp_no = rgsr_emp_no;}
public void setRgsr_date(String rgsr_date){ this.rgsr_date = rgsr_date;}
public void setRgsr_time(String rgsr_time){ this.rgsr_time = rgsr_time;}
public void setMnt_emp_no(String mnt_emp_no){ this.mnt_emp_no = mnt_emp_no;}
public void setMnt_date(String mnt_date){ this.mnt_date = mnt_date;}
public void setMnt_time(String mnt_time){ this.mnt_time = mnt_time;}
public void setActy_desc(String acty_desc){ this.acty_desc = acty_desc;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = bdgt_pln_acty + "" ; break;
  case  2 : field = base_pln_acty + "" ; break;
  case  3 : field = proj_no + "" ; break;
  case  4 : field = flag + "" ; break;
  case  5 : field = blk_zone_no + "" ; break;
  case  6 : field = mp + "" ; break;
  case  7 : field = bdpa_detl_clsf_code + "" ; break;
  case  8 : field = ord_type + "" ; break;
  case  9 : field = dtbn_stus_code + "" ; break;
  case  10 : field = sch_fix_indc + "" ; break;
  case  11 : field = work_stus_code + "" ; break;
  case  12 : field = wcg_code + "" ; break;
  case  13 : field = work_stge_code + "" ; break;
  case  14 : field = pln_wv + "" ; break;
  case  15 : field = wv_unit + "" ; break;
  case  16 : field = dsme_std_mh + "" ; break;
  case  17 : field = tagt_mh + "" ; break;
  case  18 : field = pln_sd + "" ; break;
  case  19 : field = pln_fd + "" ; break;
  case  20 : field = actl_sd + "" ; break;
  case  21 : field = actl_fd + "" ; break;
  case  22 : field = assy_shop + "" ; break;
  case  23 : field = last_mgnt_pgm_name + "" ; break;
  case  24 : field = wstg_code + "" ; break;
  case  25 : field = assy_jl + "" ; break;
  case  26 : field = assy_wl + "" ; break;
  case  27 : field = assy_gl + "" ; break;
  case  28 : field = fit_tagt_mh + "" ; break;
  case  29 : field = weld_tagt_mh + "" ; break;
  case  30 : field = grd_tagt_mh + "" ; break;
  case  31 : field = jig_code + "" ; break;
  case  32 : field = cut_ssch_assy_base_date + "" ; break;
  case  33 : field = cut_ssch_cnfm_date + "" ; break;
  case  34 : field = rgsr_emp_no + "" ; break;
  case  35 : field = rgsr_date + "" ; break;
  case  36 : field = rgsr_time + "" ; break;
  case  37 : field = mnt_emp_no + "" ; break;
  case  38 : field = mnt_date + "" ; break;
  case  39 : field = mnt_time + "" ; break;
  case  40 : field = acty_desc + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("bdgt_pln_acty")){ field = bdgt_pln_acty + "" ; 
     } else if(rec.equalsIgnoreCase("base_pln_acty")){ field = base_pln_acty + "" ; 
     } else if(rec.equalsIgnoreCase("proj_no")){ field = proj_no + "" ; 
     } else if(rec.equalsIgnoreCase("flag")){ field = flag + "" ; 
     } else if(rec.equalsIgnoreCase("blk_zone_no")){ field = blk_zone_no + "" ; 
     } else if(rec.equalsIgnoreCase("mp")){ field = mp + "" ; 
     } else if(rec.equalsIgnoreCase("bdpa_detl_clsf_code")){ field = bdpa_detl_clsf_code + "" ; 
     } else if(rec.equalsIgnoreCase("ord_type")){ field = ord_type + "" ; 
     } else if(rec.equalsIgnoreCase("dtbn_stus_code")){ field = dtbn_stus_code + "" ; 
     } else if(rec.equalsIgnoreCase("sch_fix_indc")){ field = sch_fix_indc + "" ; 
     } else if(rec.equalsIgnoreCase("work_stus_code")){ field = work_stus_code + "" ; 
     } else if(rec.equalsIgnoreCase("wcg_code")){ field = wcg_code + "" ; 
     } else if(rec.equalsIgnoreCase("work_stge_code")){ field = work_stge_code + "" ; 
     } else if(rec.equalsIgnoreCase("pln_wv")){ field = pln_wv + "" ; 
     } else if(rec.equalsIgnoreCase("wv_unit")){ field = wv_unit + "" ; 
     } else if(rec.equalsIgnoreCase("dsme_std_mh")){ field = dsme_std_mh + "" ; 
     } else if(rec.equalsIgnoreCase("tagt_mh")){ field = tagt_mh + "" ; 
     } else if(rec.equalsIgnoreCase("pln_sd")){ field = pln_sd + "" ; 
     } else if(rec.equalsIgnoreCase("pln_fd")){ field = pln_fd + "" ; 
     } else if(rec.equalsIgnoreCase("actl_sd")){ field = actl_sd + "" ; 
     } else if(rec.equalsIgnoreCase("actl_fd")){ field = actl_fd + "" ; 
     } else if(rec.equalsIgnoreCase("assy_shop")){ field = assy_shop + "" ; 
     } else if(rec.equalsIgnoreCase("last_mgnt_pgm_name")){ field = last_mgnt_pgm_name + "" ; 
     } else if(rec.equalsIgnoreCase("wstg_code")){ field = wstg_code + "" ; 
     } else if(rec.equalsIgnoreCase("assy_jl")){ field = assy_jl + "" ; 
     } else if(rec.equalsIgnoreCase("assy_wl")){ field = assy_wl + "" ; 
     } else if(rec.equalsIgnoreCase("assy_gl")){ field = assy_gl + "" ; 
     } else if(rec.equalsIgnoreCase("fit_tagt_mh")){ field = fit_tagt_mh + "" ; 
     } else if(rec.equalsIgnoreCase("weld_tagt_mh")){ field = weld_tagt_mh + "" ; 
     } else if(rec.equalsIgnoreCase("grd_tagt_mh")){ field = grd_tagt_mh + "" ; 
     } else if(rec.equalsIgnoreCase("jig_code")){ field = jig_code + "" ; 
     } else if(rec.equalsIgnoreCase("cut_ssch_assy_base_date")){ field = cut_ssch_assy_base_date + "" ; 
     } else if(rec.equalsIgnoreCase("cut_ssch_cnfm_date")){ field = cut_ssch_cnfm_date + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_emp_no")){ field = rgsr_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_date")){ field = rgsr_date + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_time")){ field = rgsr_time + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_emp_no")){ field = mnt_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_date")){ field = mnt_date + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_time")){ field = mnt_time + "" ; 
     } else if(rec.equalsIgnoreCase("acty_desc")){ field = acty_desc + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "BDGT_PLN_ACTY", "BASE_PLN_ACTY", "PROJ_NO", "FLAG", "BLK_ZONE_NO", "MP", "BDPA_DETL_CLSF_CODE", 
       "ORD_TYPE", "DTBN_STUS_CODE", "SCH_FIX_INDC", "WORK_STUS_CODE", "WCG_CODE", "WORK_STGE_CODE", "PLN_WV", 
       "WV_UNIT", "DSME_STD_MH", "TAGT_MH", "PLN_SD", "PLN_FD", "ACTL_SD", "ACTL_FD", 
       "ASSY_SHOP", "LAST_MGNT_PGM_NAME", "WSTG_CODE", "ASSY_JL", "ASSY_WL", "ASSY_GL", "FIT_TAGT_MH", 
       "WELD_TAGT_MH", "GRD_TAGT_MH", "JIG_CODE", "CUT_SSCH_ASSY_BASE_DATE", "CUT_SSCH_CNFM_DATE", "RGSR_EMP_NO", "RGSR_DATE", 
       "RGSR_TIME", "MNT_EMP_NO", "MNT_DATE", "MNT_TIME", "ACTY_DESC"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "BDGT_PLN_ACTY"};
    return tempx;
}

}// end WG212MRec class