package com.bes_line.mst.HPW;

// DBWrapper Class for HP.WGP10M
/**
 *
 * @(#) HP.WGP10MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-7
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class HP.WGP10MDBWrapBES extends DBWrapper{

public HP.WGP10MDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String proj_no, String flag
* @return HP.WGP10MRec
* @author besTeam
* @date 2006-6-7
*/
public HP.WGP10MRec select(String proj_no, String flag) throws Exception{
    java.util.Vector hp.wgp10mV = new java.util.Vector();
    HP.WGP10MRec hp.wgp10m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select proj_no, flag, blk_no, mp, bdpa_detl_clsf_code, dsme_std_mh, tagt_mh, pln_wv, bdgt_pln_acty, " +
                              "sap_prod_ord_no, work_detl_desc, rgdt, rgsr_emp_no, mnt_date, mnt_time, mnt_emp_no, wcd_code, st_kpnt, " +
                              "fin_kpnt, factor, rgsr_emp_name, mnt_emp_name " +
                       "  from DS.HP.WGP10M  " +
                       "  where proj_no = ? and flag = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,proj_no);
        pstmt.setString(2,flag);
        rs = pstmt.executeQuery();
        while(rs.next()) {
            hp.wgp10m = new HP.WGP10MRec(); // HP.WGP10MRec Constructor
                     hp.wgp10m.setProj_no(rs.getString("proj_no"));
                     hp.wgp10m.setFlag(rs.getString("flag"));
                     hp.wgp10m.setBlk_no(rs.getString("blk_no"));
                     hp.wgp10m.setMp(rs.getString("mp"));
                     hp.wgp10m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     hp.wgp10m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     hp.wgp10m.setTagt_mh(rs.getInt("tagt_mh"));
                     hp.wgp10m.setPln_wv(rs.getInt("pln_wv"));
                     hp.wgp10m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     hp.wgp10m.setSap_prod_ord_no(rs.getString("sap_prod_ord_no"));
                     hp.wgp10m.setWork_detl_desc(rs.getString("work_detl_desc"));
                     hp.wgp10m.setRgdt(rs.getString("rgdt"));
                     hp.wgp10m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     hp.wgp10m.setMnt_date(rs.getString("mnt_date"));
                     hp.wgp10m.setMnt_time(rs.getString("mnt_time"));
                     hp.wgp10m.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     hp.wgp10m.setWcd_code(rs.getString("wcd_code"));
                     hp.wgp10m.setSt_kpnt(rs.getInt("st_kpnt"));
                     hp.wgp10m.setFin_kpnt(rs.getInt("fin_kpnt"));
                     hp.wgp10m.setFactor(rs.getInt("factor"));
                     hp.wgp10m.setRgsr_emp_name(rs.getString("rgsr_emp_name"));
                     hp.wgp10m.setMnt_emp_name(rs.getString("mnt_emp_name"));
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wgp10m;
} // end select

/**
* Get All Record
* @param  void
* @return java.util.Vector
* @author besTeam
* @date 2006-6-7
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector hp.wgp10mV = new java.util.Vector();
    HP.WGP10MRec hp.wgp10m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, FLAG, BLK_NO, MP, BDPA_DETL_CLSF_CODE, DSME_STD_MH, TAGT_MH, PLN_WV, BDGT_PLN_ACTY "
        + " , SAP_PROD_ORD_NO, WORK_DETL_DESC, RGDT, RGSR_EMP_NO, MNT_DATE, MNT_TIME, MNT_EMP_NO "
        + " , ( SELECT WCG_CODE FROM HP.WG231M WHERE PROJ_NO = A.PROJ_NO AND BLK_NO = A.BLK_NO AND BDPA_DETL_CLSF_CODE = A.BDPA_DETL_CLSF_CODE ) AS WCD_CODE "
        + " , ( SELECT ST_KPNT FROM HP.WG231M WHERE PROJ_NO = A.PROJ_NO AND BLK_NO = A.BLK_NO AND BDPA_DETL_CLSF_CODE = A.BDPA_DETL_CLSF_CODE ) AS ST_KPNT "
        + " , ( SELECT FIN_KPNT FROM HP.WG231M WHERE PROJ_NO = A.PROJ_NO AND BLK_NO = A.BLK_NO AND BDPA_DETL_CLSF_CODE = A.BDPA_DETL_CLSF_CODE ) AS FIN_KPNT "
        + " , ( SELECT BASE_UNIT_WF FROM HP.WGW22M WHERE FLAG = A.FLAG ) AS FACTOR "
        + " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
        + " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
        + " FROM HP.WGP10M A";

        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            hp.wgp10m = new HP.WGP10MRec(); // HP.WGP10MRec Constructor
                     hp.wgp10m.setProj_no(rs.getString("proj_no"));
                     hp.wgp10m.setFlag(rs.getString("flag"));
                     hp.wgp10m.setBlk_no(rs.getString("blk_no"));
                     hp.wgp10m.setMp(rs.getString("mp"));
                     hp.wgp10m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     hp.wgp10m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     hp.wgp10m.setTagt_mh(rs.getInt("tagt_mh"));
                     hp.wgp10m.setPln_wv(rs.getInt("pln_wv"));
                     hp.wgp10m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     hp.wgp10m.setSap_prod_ord_no(rs.getString("sap_prod_ord_no"));
                     hp.wgp10m.setWork_detl_desc(rs.getString("work_detl_desc"));
                     hp.wgp10m.setRgdt(rs.getString("rgdt"));
                     hp.wgp10m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     hp.wgp10m.setMnt_date(rs.getString("mnt_date"));
                     hp.wgp10m.setMnt_time(rs.getString("mnt_time"));
                     hp.wgp10m.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     hp.wgp10m.setWcd_code(rs.getString("wcd_code"));
                     hp.wgp10m.setSt_kpnt(rs.getInt("st_kpnt"));
                     hp.wgp10m.setFin_kpnt(rs.getInt("fin_kpnt"));
                     hp.wgp10m.setFactor(rs.getInt("factor"));
                     hp.wgp10m.setRgsr_emp_name(rs.getString("rgsr_emp_name"));
                     hp.wgp10m.setMnt_emp_name(rs.getString("mnt_emp_name"));
            hp.wgp10mV.addElement(hp.wgp10m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wgp10mV;
} // end selectAll

/**
* Get selectAllWhere Record
* @param  String
* @return java.util.Vector
* @author besTeam
* @date 2006-6-7
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector hp.wgp10mV = new java.util.Vector();
    HP.WGP10MRec hp.wgp10m = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, FLAG, BLK_NO, MP, BDPA_DETL_CLSF_CODE, DSME_STD_MH, TAGT_MH, PLN_WV, BDGT_PLN_ACTY "
        + " , SAP_PROD_ORD_NO, WORK_DETL_DESC, RGDT, RGSR_EMP_NO, MNT_DATE, MNT_TIME, MNT_EMP_NO "
        + " , ( SELECT WCG_CODE FROM HP.WG231M WHERE PROJ_NO = A.PROJ_NO AND BLK_NO = A.BLK_NO AND BDPA_DETL_CLSF_CODE = A.BDPA_DETL_CLSF_CODE ) AS WCD_CODE "
        + " , ( SELECT ST_KPNT FROM HP.WG231M WHERE PROJ_NO = A.PROJ_NO AND BLK_NO = A.BLK_NO AND BDPA_DETL_CLSF_CODE = A.BDPA_DETL_CLSF_CODE ) AS ST_KPNT "
        + " , ( SELECT FIN_KPNT FROM HP.WG231M WHERE PROJ_NO = A.PROJ_NO AND BLK_NO = A.BLK_NO AND BDPA_DETL_CLSF_CODE = A.BDPA_DETL_CLSF_CODE ) AS FIN_KPNT "
        + " , ( SELECT BASE_UNIT_WF FROM HP.WGW22M WHERE FLAG = A.FLAG ) AS FACTOR "
        + " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
        + " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
        + " FROM HP.WGP10M A "

  + whereOption;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            hp.wgp10m = new HP.WGP10MRec(); // HP.WGP10MRec Constructor
                     hp.wgp10m.setProj_no(rs.getString("proj_no"));
                     hp.wgp10m.setFlag(rs.getString("flag"));
                     hp.wgp10m.setBlk_no(rs.getString("blk_no"));
                     hp.wgp10m.setMp(rs.getString("mp"));
                     hp.wgp10m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     hp.wgp10m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     hp.wgp10m.setTagt_mh(rs.getInt("tagt_mh"));
                     hp.wgp10m.setPln_wv(rs.getInt("pln_wv"));
                     hp.wgp10m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     hp.wgp10m.setSap_prod_ord_no(rs.getString("sap_prod_ord_no"));
                     hp.wgp10m.setWork_detl_desc(rs.getString("work_detl_desc"));
                     hp.wgp10m.setRgdt(rs.getString("rgdt"));
                     hp.wgp10m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     hp.wgp10m.setMnt_date(rs.getString("mnt_date"));
                     hp.wgp10m.setMnt_time(rs.getString("mnt_time"));
                     hp.wgp10m.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     hp.wgp10m.setWcd_code(rs.getString("wcd_code"));
                     hp.wgp10m.setSt_kpnt(rs.getInt("st_kpnt"));
                     hp.wgp10m.setFin_kpnt(rs.getInt("fin_kpnt"));
                     hp.wgp10m.setFactor(rs.getInt("factor"));
                     hp.wgp10m.setRgsr_emp_name(rs.getString("rgsr_emp_name"));
                     hp.wgp10m.setMnt_emp_name(rs.getString("mnt_emp_name"));
            hp.wgp10mV.addElement(hp.wgp10m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wgp10mV;
} // end selectAll

/**
* Get Rows Count
* @param String proj_no, String flag
* @return int
* @author besTeam
* @date 2006-6-7
*/
public int count(String proj_no, String flag) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " HP.WG231M WHERE PROJ_NO = A.PROJ_NO AND BLK_NO = A.BLK_NO AND BDPA_DETL_CLSF_CODE = A.BDPA_DETL_CLSF_CODE ) AS WCD_CODE "
        + " , ( SELECT ST_KPNT FROM HP.WG231M WHERE PROJ_NO = A.PROJ_NO AND BLK_NO = A.BLK_NO AND BDPA_DETL_CLSF_CODE = A.BDPA_DETL_CLSF_CODE ) AS ST_KPNT "
        + " , ( SELECT FIN_KPNT FROM HP.WG231M WHERE PROJ_NO = A.PROJ_NO AND BLK_NO = A.BLK_NO AND BDPA_DETL_CLSF_CODE = A.BDPA_DETL_CLSF_CODE ) AS FIN_KPNT "
        + " , ( SELECT BASE_UNIT_WF FROM HP.WGW22M WHERE FLAG = A.FLAG ) AS FACTOR "
        + " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
        + " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
        + " FROM HP.WGP10M A "

        + " where proj_no = ? and flag = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,proj_no);
        pstmt.setString(2,flag);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count
* @param String whereOption
* @return int
* @author besTeam
* @date 2006-6-7
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " HP.WG231M WHERE PROJ_NO = A.PROJ_NO AND BLK_NO = A.BLK_NO AND BDPA_DETL_CLSF_CODE = A.BDPA_DETL_CLSF_CODE ) AS WCD_CODE "
        + " , ( SELECT ST_KPNT FROM HP.WG231M WHERE PROJ_NO = A.PROJ_NO AND BLK_NO = A.BLK_NO AND BDPA_DETL_CLSF_CODE = A.BDPA_DETL_CLSF_CODE ) AS ST_KPNT "
        + " , ( SELECT FIN_KPNT FROM HP.WG231M WHERE PROJ_NO = A.PROJ_NO AND BLK_NO = A.BLK_NO AND BDPA_DETL_CLSF_CODE = A.BDPA_DETL_CLSF_CODE ) AS FIN_KPNT "
        + " , ( SELECT BASE_UNIT_WF FROM HP.WGW22M WHERE FLAG = A.FLAG ) AS FACTOR "
        + " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
        + " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
        + " FROM HP.WGP10M A "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}// end HP.WGP10MDBWrapBES class