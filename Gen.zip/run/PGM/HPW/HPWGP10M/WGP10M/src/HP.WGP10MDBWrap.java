package com.bes_line.mst.HPW;

// DBWrapper's Wrapper  Class for HP.WGP10M
/**
 *
 * @(#) HP.WGP10MDBWrap.java
 * Copyright 1999-2001 by Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-7
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class HP.WGP10MDBWrap extends HP.WGP10MDBWrapBES{
public HP.WGP10MDBWrap(ConnectionContext ctx){
    super(ctx);
} // Constructor



////////////////// User Define Code Start //////////////////


//****** You should delete this line when you edit this source ^&*%%^%%(*&%(^%(*^^ 

////////////////// User Define  Code  End //////////////////

}// end  class