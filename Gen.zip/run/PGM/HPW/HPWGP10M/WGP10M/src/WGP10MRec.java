package com.bes_line.mst.HPW ;

// Entity Class for WGP10M
/**
 *
 * @(#) WGP10MRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-7
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class WGP10MRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String proj_no; 		// (VARCHAR2, 8.0)
    public String flag; 		// (VARCHAR2, 1.0)
    public String blk_no; 		// (VARCHAR2, 3.0)
    public String mp; 		// (VARCHAR2, 1.0)
    public String bdpa_detl_clsf_code; 		// (VARCHAR2, 6.0)
    public double dsme_std_mh; 		// (NUMBER, 10.3)
    public int tagt_mh; 		// (NUMBER, 9.0)
    public int pln_wv; 		// (NUMBER, 5.0)
    public String bdgt_pln_acty; 		// (VARCHAR2, 20.0)
    public String sap_prod_ord_no; 		// (VARCHAR2, 12.0)
    public String work_detl_desc; 		// (VARCHAR2, 500.0)
    public String rgdt; 		// (VARCHAR2, 8.0)
    public String rgsr_emp_no; 		// (VARCHAR2, 7.0)
    public String mnt_date; 		// (VARCHAR2, 8.0)
    public String mnt_time; 		// (VARCHAR2, 6.0)
    public String mnt_emp_no; 		// (VARCHAR2, 7.0)
    public String wcd_code; 		// (VARCHAR2, 4.0)
    public int st_kpnt; 		// (NUMBER, 0.0)
    public int fin_kpnt; 		// (NUMBER, 0.0)
    public int factor; 		// (NUMBER, 0.0)
    public String rgsr_emp_name; 		// (VARCHAR2, 45.0)
    public String mnt_emp_name; 		// (VARCHAR2, 45.0)

public WGP10MRec(){ } // default constructor

public WGP10MRec(
       String proj_no, String flag, String blk_no, String mp, String bdpa_detl_clsf_code, double dsme_std_mh, 
       int tagt_mh, int pln_wv, String bdgt_pln_acty, String sap_prod_ord_no, String work_detl_desc, String rgdt, 
       String rgsr_emp_no, String mnt_date, String mnt_time, String mnt_emp_no, String wcd_code, int st_kpnt, 
       int fin_kpnt, int factor, String rgsr_emp_name, String mnt_emp_name){
    this.proj_no = proj_no;
    this.flag = flag;
    this.blk_no = blk_no;
    this.mp = mp;
    this.bdpa_detl_clsf_code = bdpa_detl_clsf_code;
    this.dsme_std_mh = dsme_std_mh;
    this.tagt_mh = tagt_mh;
    this.pln_wv = pln_wv;
    this.bdgt_pln_acty = bdgt_pln_acty;
    this.sap_prod_ord_no = sap_prod_ord_no;
    this.work_detl_desc = work_detl_desc;
    this.rgdt = rgdt;
    this.rgsr_emp_no = rgsr_emp_no;
    this.mnt_date = mnt_date;
    this.mnt_time = mnt_time;
    this.mnt_emp_no = mnt_emp_no;
    this.wcd_code = wcd_code;
    this.st_kpnt = st_kpnt;
    this.fin_kpnt = fin_kpnt;
    this.factor = factor;
    this.rgsr_emp_name = rgsr_emp_name;
    this.mnt_emp_name = mnt_emp_name;
} // Constructor


// Getter 
public String getProj_no(){ return proj_no;}
public String getFlag(){ return flag;}
public String getBlk_no(){ return blk_no;}
public String getMp(){ return mp;}
public String getBdpa_detl_clsf_code(){ return bdpa_detl_clsf_code;}
public double getDsme_std_mh(){ return dsme_std_mh;}
public int getTagt_mh(){ return tagt_mh;}
public int getPln_wv(){ return pln_wv;}
public String getBdgt_pln_acty(){ return bdgt_pln_acty;}
public String getSap_prod_ord_no(){ return sap_prod_ord_no;}
public String getWork_detl_desc(){ return work_detl_desc;}
public String getRgdt(){ return rgdt;}
public String getRgsr_emp_no(){ return rgsr_emp_no;}
public String getMnt_date(){ return mnt_date;}
public String getMnt_time(){ return mnt_time;}
public String getMnt_emp_no(){ return mnt_emp_no;}
public String getWcd_code(){ return wcd_code;}
public int getSt_kpnt(){ return st_kpnt;}
public int getFin_kpnt(){ return fin_kpnt;}
public int getFactor(){ return factor;}
public String getRgsr_emp_name(){ return rgsr_emp_name;}
public String getMnt_emp_name(){ return mnt_emp_name;}

// Setter 
public void setProj_no(String proj_no){ this.proj_no = proj_no;}
public void setFlag(String flag){ this.flag = flag;}
public void setBlk_no(String blk_no){ this.blk_no = blk_no;}
public void setMp(String mp){ this.mp = mp;}
public void setBdpa_detl_clsf_code(String bdpa_detl_clsf_code){ this.bdpa_detl_clsf_code = bdpa_detl_clsf_code;}
public void setDsme_std_mh(double dsme_std_mh){ this.dsme_std_mh = dsme_std_mh;}
public void setTagt_mh(int tagt_mh){ this.tagt_mh = tagt_mh;}
public void setPln_wv(int pln_wv){ this.pln_wv = pln_wv;}
public void setBdgt_pln_acty(String bdgt_pln_acty){ this.bdgt_pln_acty = bdgt_pln_acty;}
public void setSap_prod_ord_no(String sap_prod_ord_no){ this.sap_prod_ord_no = sap_prod_ord_no;}
public void setWork_detl_desc(String work_detl_desc){ this.work_detl_desc = work_detl_desc;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}
public void setRgsr_emp_no(String rgsr_emp_no){ this.rgsr_emp_no = rgsr_emp_no;}
public void setMnt_date(String mnt_date){ this.mnt_date = mnt_date;}
public void setMnt_time(String mnt_time){ this.mnt_time = mnt_time;}
public void setMnt_emp_no(String mnt_emp_no){ this.mnt_emp_no = mnt_emp_no;}
public void setWcd_code(String wcd_code){ this.wcd_code = wcd_code;}
public void setSt_kpnt(int st_kpnt){ this.st_kpnt = st_kpnt;}
public void setFin_kpnt(int fin_kpnt){ this.fin_kpnt = fin_kpnt;}
public void setFactor(int factor){ this.factor = factor;}
public void setRgsr_emp_name(String rgsr_emp_name){ this.rgsr_emp_name = rgsr_emp_name;}
public void setMnt_emp_name(String mnt_emp_name){ this.mnt_emp_name = mnt_emp_name;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = proj_no + "" ; break;
  case  2 : field = flag + "" ; break;
  case  3 : field = blk_no + "" ; break;
  case  4 : field = mp + "" ; break;
  case  5 : field = bdpa_detl_clsf_code + "" ; break;
  case  6 : field = dsme_std_mh + "" ; break;
  case  7 : field = tagt_mh + "" ; break;
  case  8 : field = pln_wv + "" ; break;
  case  9 : field = bdgt_pln_acty + "" ; break;
  case  10 : field = sap_prod_ord_no + "" ; break;
  case  11 : field = work_detl_desc + "" ; break;
  case  12 : field = rgdt + "" ; break;
  case  13 : field = rgsr_emp_no + "" ; break;
  case  14 : field = mnt_date + "" ; break;
  case  15 : field = mnt_time + "" ; break;
  case  16 : field = mnt_emp_no + "" ; break;
  case  17 : field = wcd_code + "" ; break;
  case  18 : field = st_kpnt + "" ; break;
  case  19 : field = fin_kpnt + "" ; break;
  case  20 : field = factor + "" ; break;
  case  21 : field = rgsr_emp_name + "" ; break;
  case  22 : field = mnt_emp_name + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("proj_no")){ field = proj_no + "" ; 
     } else if(rec.equalsIgnoreCase("flag")){ field = flag + "" ; 
     } else if(rec.equalsIgnoreCase("blk_no")){ field = blk_no + "" ; 
     } else if(rec.equalsIgnoreCase("mp")){ field = mp + "" ; 
     } else if(rec.equalsIgnoreCase("bdpa_detl_clsf_code")){ field = bdpa_detl_clsf_code + "" ; 
     } else if(rec.equalsIgnoreCase("dsme_std_mh")){ field = dsme_std_mh + "" ; 
     } else if(rec.equalsIgnoreCase("tagt_mh")){ field = tagt_mh + "" ; 
     } else if(rec.equalsIgnoreCase("pln_wv")){ field = pln_wv + "" ; 
     } else if(rec.equalsIgnoreCase("bdgt_pln_acty")){ field = bdgt_pln_acty + "" ; 
     } else if(rec.equalsIgnoreCase("sap_prod_ord_no")){ field = sap_prod_ord_no + "" ; 
     } else if(rec.equalsIgnoreCase("work_detl_desc")){ field = work_detl_desc + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_emp_no")){ field = rgsr_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_date")){ field = mnt_date + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_time")){ field = mnt_time + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_emp_no")){ field = mnt_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("wcd_code")){ field = wcd_code + "" ; 
     } else if(rec.equalsIgnoreCase("st_kpnt")){ field = st_kpnt + "" ; 
     } else if(rec.equalsIgnoreCase("fin_kpnt")){ field = fin_kpnt + "" ; 
     } else if(rec.equalsIgnoreCase("factor")){ field = factor + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_emp_name")){ field = rgsr_emp_name + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_emp_name")){ field = mnt_emp_name + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "PROJ_NO", "FLAG", "BLK_NO", "MP", "BDPA_DETL_CLSF_CODE", "DSME_STD_MH", "TAGT_MH", 
       "PLN_WV", "BDGT_PLN_ACTY", "SAP_PROD_ORD_NO", "WORK_DETL_DESC", "RGDT", "RGSR_EMP_NO", "MNT_DATE", 
       "MNT_TIME", "MNT_EMP_NO", "WCD_CODE", "ST_KPNT", "FIN_KPNT", "FACTOR", "RGSR_EMP_NAME", 
       "MNT_EMP_NAME"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "PROJ_NO", "FLAG"};
    return tempx;
}

}// end WGP10MRec class