package com.bes_line.mst.HPW;

// DBWrapper Class for WGP10M
/**
 *
 * @(#) WGP10MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-30
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class WGP10MDBWrapBES extends DBWrapper{

public WGP10MDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Select Page
* @param String proj_no
* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectPage(String fldname, int page, int pagesize, String whereOption ) throws Exception{
return selectPage(fldname,page,pagesize, "Asc", whereOption) ;
}// end selectPage
/**
* Select Page
* @param String proj_no* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectPage(String fldname, int page, int pagesize, String keyorder, String whereOption) throws Exception{
    java.util.Vector wgp10mV = new java.util.Vector();
    WGP10MRec wgp10m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select proj_no, flag, blk_no, mp, bdpa_detl_clsf_code, dsme_std_mh, tagt_mh, pln_wv, bdgt_pln_acty, " +
                              "sap_prod_ord_no, work_detl_desc, rgdt, rgsr_emp_no, mnt_date, mnt_time, mnt_emp_no " +
                       "  from HP.WGP10M  where 1 = 1 " +   whereOption  +
                       "  order by "+fldname+" "+keyorder;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();
        int count = 0;
        while((count < (page-1)*pagesize ) && ( rs.next())){  count ++; } // page??? ??????
            count = 0;
        while(rs.next()){
            count ++;
            if(count > pagesize ) break;
            wgp10m = new WGP10MRec(); // WGP10MRec Constructor
                     wgp10m.setProj_no(rs.getString("proj_no"));
                     wgp10m.setFlag(rs.getString("flag"));
                     wgp10m.setBlk_no(rs.getString("blk_no"));
                     wgp10m.setMp(rs.getString("mp"));
                     wgp10m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     wgp10m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     wgp10m.setTagt_mh(rs.getInt("tagt_mh"));
                     wgp10m.setPln_wv(rs.getInt("pln_wv"));
                     wgp10m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     wgp10m.setSap_prod_ord_no(rs.getString("sap_prod_ord_no"));
                     wgp10m.setWork_detl_desc(rs.getString("work_detl_desc"));
                     wgp10m.setRgdt(rs.getString("rgdt"));
                     wgp10m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     wgp10m.setMnt_date(rs.getString("mnt_date"));
                     wgp10m.setMnt_time(rs.getString("mnt_time"));
                     wgp10m.setMnt_emp_no(rs.getString("mnt_emp_no"));
            wgp10mV.addElement(wgp10m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return wgp10mV;
} // end selectPage

/**
* SelectWhere
* @param String proj_no
* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectWhere(String fldname, String whereOption ) throws Exception{
return selectWhere(fldname, "Asc", whereOption) ;
}// end selectWhere
/**
* SelectWhere
* @param String proj_no* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectWhere(String fldname, String keyorder, String whereOption) throws Exception{
    java.util.Vector wgp10mV = new java.util.Vector();
    WGP10MRec wgp10m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select proj_no, flag, blk_no, mp, bdpa_detl_clsf_code, dsme_std_mh, tagt_mh, pln_wv, bdgt_pln_acty, " +
                              "sap_prod_ord_no, work_detl_desc, rgdt, rgsr_emp_no, mnt_date, mnt_time, mnt_emp_no " +
                       "  from HP.WGP10M  where 1 = 1 " +   whereOption  +
                       "  order by "+fldname+" "+keyorder;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();
        while(rs.next()) {
            wgp10m = new WGP10MRec(); // WGP10MRec Constructor
                     wgp10m.setProj_no(rs.getString("proj_no"));
                     wgp10m.setFlag(rs.getString("flag"));
                     wgp10m.setBlk_no(rs.getString("blk_no"));
                     wgp10m.setMp(rs.getString("mp"));
                     wgp10m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     wgp10m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     wgp10m.setTagt_mh(rs.getInt("tagt_mh"));
                     wgp10m.setPln_wv(rs.getInt("pln_wv"));
                     wgp10m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     wgp10m.setSap_prod_ord_no(rs.getString("sap_prod_ord_no"));
                     wgp10m.setWork_detl_desc(rs.getString("work_detl_desc"));
                     wgp10m.setRgdt(rs.getString("rgdt"));
                     wgp10m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     wgp10m.setMnt_date(rs.getString("mnt_date"));
                     wgp10m.setMnt_time(rs.getString("mnt_time"));
                     wgp10m.setMnt_emp_no(rs.getString("mnt_emp_no"));
            wgp10mV.addElement(wgp10m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return wgp10mV;
} // end selectWhere

/**
* Get Rows CountPage
* @param
* @return int
* @author besTeam
* @date 2006-5-30
*/
public int countPage(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select COUNT(*) from HP.WGP10M  where 1 = 1 " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end countPage

/**
* Get one Record
* @param String proj_no, String flag, String blk_no, String mp
* @return WGP10MRec
* @author besTeam
* @date 2006-5-30
*/
public WGP10MRec select(String proj_no, String flag, String blk_no, String mp) throws Exception{
    WGP10MRec wgp10m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, FLAG, BLK_NO, MP, BDPA_DETL_CLSF_CODE, DSME_STD_MH, TAGT_MH, PLN_WV, BDGT_PLN_ACTY, SAP_PROD_ORD_NO, WORK_DETL_DESC, RGDT, RGSR_EMP_NO, MNT_DATE, MNT_TIME, MNT_EMP_NO FROM HP.WGP10M "

        + " where proj_no = ? and flag = ? and blk_no = ? and mp = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,proj_no);
        pstmt.setString(2,flag);
        pstmt.setString(3,blk_no);
        pstmt.setString(4,mp);
        rs = pstmt.executeQuery();

        if(rs.next()){
            wgp10m = new WGP10MRec(); // WGP10MRec Constructor
                     wgp10m.setProj_no(rs.getString("proj_no"));
                     wgp10m.setFlag(rs.getString("flag"));
                     wgp10m.setBlk_no(rs.getString("blk_no"));
                     wgp10m.setMp(rs.getString("mp"));
                     wgp10m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     wgp10m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     wgp10m.setTagt_mh(rs.getInt("tagt_mh"));
                     wgp10m.setPln_wv(rs.getInt("pln_wv"));
                     wgp10m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     wgp10m.setSap_prod_ord_no(rs.getString("sap_prod_ord_no"));
                     wgp10m.setWork_detl_desc(rs.getString("work_detl_desc"));
                     wgp10m.setRgdt(rs.getString("rgdt"));
                     wgp10m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     wgp10m.setMnt_date(rs.getString("mnt_date"));
                     wgp10m.setMnt_time(rs.getString("mnt_time"));
                     wgp10m.setMnt_emp_no(rs.getString("mnt_emp_no"));
        } else {
            throw new DataNotFoundException();
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return wgp10m;
} // end select

/**
* Get All Record
* @param  void
* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector wgp10mV = new java.util.Vector();
    WGP10MRec wgp10m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, FLAG, BLK_NO, MP, BDPA_DETL_CLSF_CODE, DSME_STD_MH, TAGT_MH, PLN_WV, BDGT_PLN_ACTY, SAP_PROD_ORD_NO, WORK_DETL_DESC, RGDT, RGSR_EMP_NO, MNT_DATE, MNT_TIME, MNT_EMP_NO FROM HP.WGP10M "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            wgp10m = new WGP10MRec(); // WGP10MRec Constructor
                     wgp10m.setProj_no(rs.getString("proj_no"));
                     wgp10m.setFlag(rs.getString("flag"));
                     wgp10m.setBlk_no(rs.getString("blk_no"));
                     wgp10m.setMp(rs.getString("mp"));
                     wgp10m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     wgp10m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     wgp10m.setTagt_mh(rs.getInt("tagt_mh"));
                     wgp10m.setPln_wv(rs.getInt("pln_wv"));
                     wgp10m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     wgp10m.setSap_prod_ord_no(rs.getString("sap_prod_ord_no"));
                     wgp10m.setWork_detl_desc(rs.getString("work_detl_desc"));
                     wgp10m.setRgdt(rs.getString("rgdt"));
                     wgp10m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     wgp10m.setMnt_date(rs.getString("mnt_date"));
                     wgp10m.setMnt_time(rs.getString("mnt_time"));
                     wgp10m.setMnt_emp_no(rs.getString("mnt_emp_no"));
            wgp10mV.addElement(wgp10m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return wgp10mV;
} // end selectAll

/**
* Get selectWhere Record
* @param  String
* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectWhere(String whereOption) throws Exception{
    java.util.Vector wgp10mV = new java.util.Vector();
    WGP10MRec wgp10m = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, FLAG, BLK_NO, MP, BDPA_DETL_CLSF_CODE, DSME_STD_MH, TAGT_MH, PLN_WV, BDGT_PLN_ACTY, SAP_PROD_ORD_NO, WORK_DETL_DESC, RGDT, RGSR_EMP_NO, MNT_DATE, MNT_TIME, MNT_EMP_NO FROM HP.WGP10M "

  + whereOption;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            wgp10m = new WGP10MRec(); // WGP10MRec Constructor
                     wgp10m.setProj_no(rs.getString("proj_no"));
                     wgp10m.setFlag(rs.getString("flag"));
                     wgp10m.setBlk_no(rs.getString("blk_no"));
                     wgp10m.setMp(rs.getString("mp"));
                     wgp10m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     wgp10m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     wgp10m.setTagt_mh(rs.getInt("tagt_mh"));
                     wgp10m.setPln_wv(rs.getInt("pln_wv"));
                     wgp10m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     wgp10m.setSap_prod_ord_no(rs.getString("sap_prod_ord_no"));
                     wgp10m.setWork_detl_desc(rs.getString("work_detl_desc"));
                     wgp10m.setRgdt(rs.getString("rgdt"));
                     wgp10m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     wgp10m.setMnt_date(rs.getString("mnt_date"));
                     wgp10m.setMnt_time(rs.getString("mnt_time"));
                     wgp10m.setMnt_emp_no(rs.getString("mnt_emp_no"));
            wgp10mV.addElement(wgp10m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return wgp10mV;
} // end selectAll

/**
* Get All Record(condition : last Key except)
* @param String proj_no, String flag, String blk_no
* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectAll(String proj_no, String flag, String blk_no) throws Exception{
    java.util.Vector wgp10mV = new java.util.Vector();
    WGP10MRec wgp10m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, FLAG, BLK_NO, MP, BDPA_DETL_CLSF_CODE, DSME_STD_MH, TAGT_MH, PLN_WV, BDGT_PLN_ACTY, SAP_PROD_ORD_NO, WORK_DETL_DESC, RGDT, RGSR_EMP_NO, MNT_DATE, MNT_TIME, MNT_EMP_NO FROM HP.WGP10M "

        + " where proj_no = ? and flag = ? and blk_no = ?  " +
                       "  order by mp";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,proj_no);
        pstmt.setString(2,flag);
        pstmt.setString(3,blk_no);
        rs = pstmt.executeQuery();

        while(rs.next()){
            wgp10m = new WGP10MRec(); // WGP10MRec Constructor
                     wgp10m.setProj_no(rs.getString("proj_no"));
                     wgp10m.setFlag(rs.getString("flag"));
                     wgp10m.setBlk_no(rs.getString("blk_no"));
                     wgp10m.setMp(rs.getString("mp"));
                     wgp10m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     wgp10m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     wgp10m.setTagt_mh(rs.getInt("tagt_mh"));
                     wgp10m.setPln_wv(rs.getInt("pln_wv"));
                     wgp10m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     wgp10m.setSap_prod_ord_no(rs.getString("sap_prod_ord_no"));
                     wgp10m.setWork_detl_desc(rs.getString("work_detl_desc"));
                     wgp10m.setRgdt(rs.getString("rgdt"));
                     wgp10m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     wgp10m.setMnt_date(rs.getString("mnt_date"));
                     wgp10m.setMnt_time(rs.getString("mnt_time"));
                     wgp10m.setMnt_emp_no(rs.getString("mnt_emp_no"));
            wgp10mV.addElement(wgp10m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return wgp10mV;
} // end selectAll

/**
* Get between Record(condition : last Key from - to)
* @param String proj_no, String flag, String blk_no, String f_mp, String t_mp
* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectBetween(String proj_no, String flag, String blk_no, String f_mp, String t_mp) throws Exception{
    return selectBetween(proj_no, flag, blk_no, f_mp, t_mp, 0);
} // end selectBetween

/**
* Get between Record(condition : last Key from - to)
* @param String proj_no, String flag, String blk_no, String f_mp, String t_mp, int lastKeyOrder(0 : ASC-Default, 1 : DESC)
* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectBetween(String proj_no, String flag, String blk_no, String f_mp, String t_mp, int lastKeyOrder) throws Exception{
    java.util.Vector wgp10mV = new java.util.Vector();
    WGP10MRec wgp10m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, FLAG, BLK_NO, MP, BDPA_DETL_CLSF_CODE, DSME_STD_MH, TAGT_MH, PLN_WV, BDGT_PLN_ACTY, SAP_PROD_ORD_NO, WORK_DETL_DESC, RGDT, RGSR_EMP_NO, MNT_DATE, MNT_TIME, MNT_EMP_NO FROM HP.WGP10M "

        + " where proj_no = ? and flag = ? and blk_no = ?  " +
                       "  and mp between ? and ?  ";
               if(lastKeyOrder == 1){
                   query += " order by mp DESC ";
               } else {
                   query += " order by mp";
               } // end if(lastKeyOrder == 1)
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,proj_no);
        pstmt.setString(2,flag);
        pstmt.setString(3,blk_no);
        pstmt.setString(4,f_mp);
        pstmt.setString(5,t_mp);
        rs = pstmt.executeQuery();

        while(rs.next()){
            wgp10m = new WGP10MRec(); // WGP10MRec Constructor
                     wgp10m.setProj_no(rs.getString("proj_no"));
                     wgp10m.setFlag(rs.getString("flag"));
                     wgp10m.setBlk_no(rs.getString("blk_no"));
                     wgp10m.setMp(rs.getString("mp"));
                     wgp10m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     wgp10m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     wgp10m.setTagt_mh(rs.getInt("tagt_mh"));
                     wgp10m.setPln_wv(rs.getInt("pln_wv"));
                     wgp10m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     wgp10m.setSap_prod_ord_no(rs.getString("sap_prod_ord_no"));
                     wgp10m.setWork_detl_desc(rs.getString("work_detl_desc"));
                     wgp10m.setRgdt(rs.getString("rgdt"));
                     wgp10m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     wgp10m.setMnt_date(rs.getString("mnt_date"));
                     wgp10m.setMnt_time(rs.getString("mnt_time"));
                     wgp10m.setMnt_emp_no(rs.getString("mnt_emp_no"));
            wgp10mV.addElement(wgp10m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return wgp10mV;
} // end selectBetween

/**
* Select Data Over the key value(s) and default return count(20)
* @param String proj_no, String flag, String blk_no, String mp
* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectOver(String proj_no, String flag, String blk_no, String mp) throws Exception{
return selectOver(proj_no, flag, blk_no, mp,20) ;
}// end selectOver
/**
* Select Data Over(Next) the key value(s) and return record count
* @param String proj_no, String flag, String blk_no, String mp, int
* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectOver(String proj_no, String flag, String blk_no, String mp, int page) throws Exception{
    java.util.Vector wgp10mV = new java.util.Vector();
    WGP10MRec wgp10m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, FLAG, BLK_NO, MP, BDPA_DETL_CLSF_CODE, DSME_STD_MH, TAGT_MH, PLN_WV, BDGT_PLN_ACTY, SAP_PROD_ORD_NO, WORK_DETL_DESC, RGDT, RGSR_EMP_NO, MNT_DATE, MNT_TIME, MNT_EMP_NO FROM HP.WGP10M "
        + " where proj_no = ?  and  flag = ?  and  blk_no = ?  and  mp >= ? order by mp ";

        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,proj_no);
        pstmt.setString(2,flag);
        pstmt.setString(3,blk_no);
        pstmt.setString(4,mp);
        rs = pstmt.executeQuery();
        int count = 0;//??f??? SQL?????? Limit??? ????...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            wgp10m = new WGP10MRec(); // WGP10MRec Constructor
                     wgp10m.setProj_no(rs.getString("proj_no"));
                     wgp10m.setFlag(rs.getString("flag"));
                     wgp10m.setBlk_no(rs.getString("blk_no"));
                     wgp10m.setMp(rs.getString("mp"));
                     wgp10m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     wgp10m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     wgp10m.setTagt_mh(rs.getInt("tagt_mh"));
                     wgp10m.setPln_wv(rs.getInt("pln_wv"));
                     wgp10m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     wgp10m.setSap_prod_ord_no(rs.getString("sap_prod_ord_no"));
                     wgp10m.setWork_detl_desc(rs.getString("work_detl_desc"));
                     wgp10m.setRgdt(rs.getString("rgdt"));
                     wgp10m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     wgp10m.setMnt_date(rs.getString("mnt_date"));
                     wgp10m.setMnt_time(rs.getString("mnt_time"));
                     wgp10m.setMnt_emp_no(rs.getString("mnt_emp_no"));
            wgp10mV.addElement(wgp10m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return wgp10mV;
} // end selectOver

/**
* Select Data Under(Previous) the key value(s) and default return count(20)
* @param String proj_no, String flag, String blk_no, String mp
* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectUnder(String proj_no, String flag, String blk_no, String mp) throws Exception{
return selectUnder(proj_no, flag, blk_no, mp,20) ;
}// end selectUnder
/**
* Select Data Under(Previous) the key value(s) and return record count
* @param String proj_no, String flag, String blk_no, String mp, int
* @return java.util.Vector
* @author besTeam
* @date 2006-5-30
*/
public java.util.Vector selectUnder(String proj_no, String flag, String blk_no, String mp, int page) throws Exception{
    java.util.Vector wgp10mV = new java.util.Vector();
    WGP10MRec wgp10m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PROJ_NO, FLAG, BLK_NO, MP, BDPA_DETL_CLSF_CODE, DSME_STD_MH, TAGT_MH, PLN_WV, BDGT_PLN_ACTY, SAP_PROD_ORD_NO, WORK_DETL_DESC, RGDT, RGSR_EMP_NO, MNT_DATE, MNT_TIME, MNT_EMP_NO FROM HP.WGP10M "
        + " where proj_no = ?  and flag = ?  and blk_no = ?  and mp <= ? order by mp desc" ;

        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,proj_no);
        pstmt.setString(2,flag);
        pstmt.setString(3,blk_no);
        pstmt.setString(4,mp);
        rs = pstmt.executeQuery();
        int count = 0;//??f??? SQL?????? Limit??? ????...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            wgp10m = new WGP10MRec(); // WGP10MRec Constructor
                     wgp10m.setProj_no(rs.getString("proj_no"));
                     wgp10m.setFlag(rs.getString("flag"));
                     wgp10m.setBlk_no(rs.getString("blk_no"));
                     wgp10m.setMp(rs.getString("mp"));
                     wgp10m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     wgp10m.setDsme_std_mh(rs.getDouble("dsme_std_mh"));
                     wgp10m.setTagt_mh(rs.getInt("tagt_mh"));
                     wgp10m.setPln_wv(rs.getInt("pln_wv"));
                     wgp10m.setBdgt_pln_acty(rs.getString("bdgt_pln_acty"));
                     wgp10m.setSap_prod_ord_no(rs.getString("sap_prod_ord_no"));
                     wgp10m.setWork_detl_desc(rs.getString("work_detl_desc"));
                     wgp10m.setRgdt(rs.getString("rgdt"));
                     wgp10m.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     wgp10m.setMnt_date(rs.getString("mnt_date"));
                     wgp10m.setMnt_time(rs.getString("mnt_time"));
                     wgp10m.setMnt_emp_no(rs.getString("mnt_emp_no"));
            wgp10mV.add(0,wgp10m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return wgp10mV;
} // end selectUnder
/**
* Get Rows Count
* @param String proj_no, String flag, String blk_no, String mp
* @return int
* @author besTeam
* @date 2006-5-30
*/
public int count(String proj_no, String flag, String blk_no, String mp) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM HP.WGP10M where proj_no = ? and flag = ? and blk_no = ? and mp = ?";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,proj_no);
        pstmt.setString(2,flag);
        pstmt.setString(3,blk_no);
        pstmt.setString(4,mp);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count
* @param void
* @return int
* @author besTeam
* @date 2006-5-30
*/
public int count() throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM HP.WGP10M"

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count










public void insert( WGP10MRec wgp10m ) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HP.WG914C ("
                       +" PROJ_NO, FLAG, BLK_NO, MP, BDPA_DETL_CLSF_CODE, DSME_STD_MH, TAGT_MH, PLN_WV, BDGT_PLN_ACTY, SAP_PROD_ORD_NO"
                       +", WORK_DETL_DESC, RGDT, RGSR_EMP_NO, MNT_DATE, MNT_TIME, MNT_EMP_NO"
                       " ) values ( "+
                       "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";

        pstmt = connection.prepareStatement(query);

        pstmt.setString( 1, Proj_no() );
        pstmt.setString( 2, Flag() );
        pstmt.setString( 3, Blk_no() );
        pstmt.setString( 4, Mp() );
        pstmt.setString( 5, Bdpa_detl_clsf_code() );
        pstmt.setString( 6, Dsme_std_mh() );
        pstmt.setString( 7, Tagt_mh() );
        pstmt.setString( 8, Pln_wv() );
        pstmt.setString( 9, Bdgt_pln_acty() );
        pstmt.setString( 10, Sap_prod_ord_no() );
        pstmt.setString( 11, Work_detl_desc() );
        pstmt.setString( 12, Rgdt() );
        pstmt.setString( 13, Rgsr_emp_no() );
        pstmt.setString( 14, Mnt_date() );
        pstmt.setString( 15, Mnt_time() );
        pstmt.setString( 16, Mnt_emp_no() );

        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert




public void update( WGP10MRec wgp10m ) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HP.WG914C SET "
                       +" BDPA_DETL_CLSF_CODE, DSME_STD_MH, TAGT_MH, PLN_WV, BDGT_PLN_ACTY, SAP_PROD_ORD_NO"
                       +", WORK_DETL_DESC, RGDT, RGSR_EMP_NO, MNT_DATE, MNT_TIME, MNT_EMP_NO"
                       +" WHERE PROJ_NO = ? and FLAG = ? and BLK_NO = ? and MP = ? ";

        pstmt = connection.prepareStatement(query);

        pstmt.setString( 1, wgp10m.getBdpa_detl_clsf_code() );
        pstmt.setInt   ( 2, wgp10m.getDsme_std_mh() );
        pstmt.setString( 3, wgp10m.getTagt_mh() );
        pstmt.setString( 4, wgp10m.getPln_wv() );
        pstmt.setString( 5, wgp10m.getBdgt_pln_acty() );
        pstmt.setString( 6, wgp10m.getSap_prod_ord_no() );
        pstmt.setString( 7, wgp10m.getWork_detl_desc() );
        pstmt.setString( 7, wgp10m.getRgdt() );
        pstmt.setString( 8, wgp10m.getRgsr_emp_no() );
        pstmt.setString( 10, wgp10m.getMnt_date() );
        pstmt.setString( 11, wgp10m.getMnt_time() );
        pstmt.setString( 12, wgp10m.getMnt_emp_no() );
        // Key
        pstmt.setString( 13, wgp10m.getProj_no() );
        pstmt.setString( 14, wgp10m.getFlag() );
        pstmt.setString( 15, wgp10m.getBlk_no() );
        pstmt.setString( 16, wgp10m.getMp() );

        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update





public void delete( String proj_no, String flag, String blk_no, String mp ) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HP.WG914C where pron_no = ? and flag = ? and blk_no = ? and mp = ?";

        pstmt = connection.prepareStatement(query);

        pstmt.setString( 1, proj_no );
        pstmt.setString( 2, flag );
        pstmt.setString( 3, blk_no );
        pstmt.setString( 4, mp );

        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete



public void delete( WGP10MRec wgp10m ) throws Exception{
     delete( wgp10m.getProj_no(), wgp10m.getFlag(), wgp10m.getBlk_no(), wgp10m.getMp() );
} // end Delete








}// end WGP10MDBWrapBES class