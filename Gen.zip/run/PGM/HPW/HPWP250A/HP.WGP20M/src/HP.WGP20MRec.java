package com.bes_line.mst.HPW ;

// Entity Class for HP.WGP20M
/**
 *
 * @(#) HP.WGP20MRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-30
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class HP.WGP20MRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String proj_no; 		// (VARCHAR2, 8.0)
    public String blk_no; 		// (VARCHAR2, 3.0)
    public String work_kind; 		// (VARCHAR2, 1.0)
    public String pnt_zone_code; 		// (VARCHAR2, 5.0)
    public String pnt_seq; 		// (VARCHAR2, 2.0)
    public String pnt_mat_code; 		// (VARCHAR2, 11.0)
    public double pnt_tot_area; 		// (NUMBER, 8.2)
    public double pnt_area; 		// (NUMBER, 10.3)
    public double estm_pnt_mat_vol; 		// (NUMBER, 9.3)
    public double cstr_pnt_mat_vol; 		// (NUMBER, 7.1)
    public String pnt_zone_desc; 		// (VARCHAR2, 60.0)
    public String blk_srfc_grd; 		// (VARCHAR2, 5.0)
    public int pnt_mat_dft; 		// (NUMBER, 4.0)
    public int pnt_mat_wft; 		// (NUMBER, 4.0)
    public double pnt_mat_tsr; 		// (NUMBER, 6.2)
    public String pnt_mat_desc; 		// (VARCHAR2, 80.0)
    public String thnr_mat_code; 		// (VARCHAR2, 11.0)
    public int thnr_rate; 		// (NUMBER, 3.0)
    public int pnt_mat_unit_pr; 		// (NUMBER, 9.0)
    public int pnt_mat_unit_pr_amt; 		// (NUMBER, 9.0)
    public int thnr_mat_unit_pr; 		// (NUMBER, 9.0)
    public int thnr_mat_unit_pr_amt; 		// (NUMBER, 9.0)
    public String sply_req_date; 		// (VARCHAR2, 8.0)
    public String insp_req_date; 		// (VARCHAR2, 8.0)
    public String work_ord_no; 		// (VARCHAR2, 20.0)
    public double estm_mh; 		// (NUMBER, 7.1)
    public double wo_mh; 		// (NUMBER, 8.1)
    public String rgsr_emp_no; 		// (VARCHAR2, 7.0)
    public String rgdt; 		// (VARCHAR2, 8.0)
    public String mnt_emp_no; 		// (VARCHAR2, 7.0)
    public String mnt_date; 		// (VARCHAR2, 8.0)
    public String mnt_time; 		// (VARCHAR2, 6.0)
    public String rmrk; 		// (VARCHAR2, 2000.0)

public HP.WGP20MRec(){ } // default constructor

public HP.WGP20MRec(
       String proj_no, String blk_no, String work_kind, String pnt_zone_code, String pnt_seq, String pnt_mat_code, 
       double pnt_tot_area, double pnt_area, double estm_pnt_mat_vol, double cstr_pnt_mat_vol, String pnt_zone_desc, String blk_srfc_grd, 
       int pnt_mat_dft, int pnt_mat_wft, double pnt_mat_tsr, String pnt_mat_desc, String thnr_mat_code, int thnr_rate, 
       int pnt_mat_unit_pr, int pnt_mat_unit_pr_amt, int thnr_mat_unit_pr, int thnr_mat_unit_pr_amt, String sply_req_date, String insp_req_date, 
       String work_ord_no, double estm_mh, double wo_mh, String rgsr_emp_no, String rgdt, String mnt_emp_no, 
       String mnt_date, String mnt_time, String rmrk){
    this.proj_no = proj_no;
    this.blk_no = blk_no;
    this.work_kind = work_kind;
    this.pnt_zone_code = pnt_zone_code;
    this.pnt_seq = pnt_seq;
    this.pnt_mat_code = pnt_mat_code;
    this.pnt_tot_area = pnt_tot_area;
    this.pnt_area = pnt_area;
    this.estm_pnt_mat_vol = estm_pnt_mat_vol;
    this.cstr_pnt_mat_vol = cstr_pnt_mat_vol;
    this.pnt_zone_desc = pnt_zone_desc;
    this.blk_srfc_grd = blk_srfc_grd;
    this.pnt_mat_dft = pnt_mat_dft;
    this.pnt_mat_wft = pnt_mat_wft;
    this.pnt_mat_tsr = pnt_mat_tsr;
    this.pnt_mat_desc = pnt_mat_desc;
    this.thnr_mat_code = thnr_mat_code;
    this.thnr_rate = thnr_rate;
    this.pnt_mat_unit_pr = pnt_mat_unit_pr;
    this.pnt_mat_unit_pr_amt = pnt_mat_unit_pr_amt;
    this.thnr_mat_unit_pr = thnr_mat_unit_pr;
    this.thnr_mat_unit_pr_amt = thnr_mat_unit_pr_amt;
    this.sply_req_date = sply_req_date;
    this.insp_req_date = insp_req_date;
    this.work_ord_no = work_ord_no;
    this.estm_mh = estm_mh;
    this.wo_mh = wo_mh;
    this.rgsr_emp_no = rgsr_emp_no;
    this.rgdt = rgdt;
    this.mnt_emp_no = mnt_emp_no;
    this.mnt_date = mnt_date;
    this.mnt_time = mnt_time;
    this.rmrk = rmrk;
} // Constructor


// Getter 
public String getProj_no(){ return proj_no;}
public String getBlk_no(){ return blk_no;}
public String getWork_kind(){ return work_kind;}
public String getPnt_zone_code(){ return pnt_zone_code;}
public String getPnt_seq(){ return pnt_seq;}
public String getPnt_mat_code(){ return pnt_mat_code;}
public double getPnt_tot_area(){ return pnt_tot_area;}
public double getPnt_area(){ return pnt_area;}
public double getEstm_pnt_mat_vol(){ return estm_pnt_mat_vol;}
public double getCstr_pnt_mat_vol(){ return cstr_pnt_mat_vol;}
public String getPnt_zone_desc(){ return pnt_zone_desc;}
public String getBlk_srfc_grd(){ return blk_srfc_grd;}
public int getPnt_mat_dft(){ return pnt_mat_dft;}
public int getPnt_mat_wft(){ return pnt_mat_wft;}
public double getPnt_mat_tsr(){ return pnt_mat_tsr;}
public String getPnt_mat_desc(){ return pnt_mat_desc;}
public String getThnr_mat_code(){ return thnr_mat_code;}
public int getThnr_rate(){ return thnr_rate;}
public int getPnt_mat_unit_pr(){ return pnt_mat_unit_pr;}
public int getPnt_mat_unit_pr_amt(){ return pnt_mat_unit_pr_amt;}
public int getThnr_mat_unit_pr(){ return thnr_mat_unit_pr;}
public int getThnr_mat_unit_pr_amt(){ return thnr_mat_unit_pr_amt;}
public String getSply_req_date(){ return sply_req_date;}
public String getInsp_req_date(){ return insp_req_date;}
public String getWork_ord_no(){ return work_ord_no;}
public double getEstm_mh(){ return estm_mh;}
public double getWo_mh(){ return wo_mh;}
public String getRgsr_emp_no(){ return rgsr_emp_no;}
public String getRgdt(){ return rgdt;}
public String getMnt_emp_no(){ return mnt_emp_no;}
public String getMnt_date(){ return mnt_date;}
public String getMnt_time(){ return mnt_time;}
public String getRmrk(){ return rmrk;}

// Setter 
public void setProj_no(String proj_no){ this.proj_no = proj_no;}
public void setBlk_no(String blk_no){ this.blk_no = blk_no;}
public void setWork_kind(String work_kind){ this.work_kind = work_kind;}
public void setPnt_zone_code(String pnt_zone_code){ this.pnt_zone_code = pnt_zone_code;}
public void setPnt_seq(String pnt_seq){ this.pnt_seq = pnt_seq;}
public void setPnt_mat_code(String pnt_mat_code){ this.pnt_mat_code = pnt_mat_code;}
public void setPnt_tot_area(double pnt_tot_area){ this.pnt_tot_area = pnt_tot_area;}
public void setPnt_area(double pnt_area){ this.pnt_area = pnt_area;}
public void setEstm_pnt_mat_vol(double estm_pnt_mat_vol){ this.estm_pnt_mat_vol = estm_pnt_mat_vol;}
public void setCstr_pnt_mat_vol(double cstr_pnt_mat_vol){ this.cstr_pnt_mat_vol = cstr_pnt_mat_vol;}
public void setPnt_zone_desc(String pnt_zone_desc){ this.pnt_zone_desc = pnt_zone_desc;}
public void setBlk_srfc_grd(String blk_srfc_grd){ this.blk_srfc_grd = blk_srfc_grd;}
public void setPnt_mat_dft(int pnt_mat_dft){ this.pnt_mat_dft = pnt_mat_dft;}
public void setPnt_mat_wft(int pnt_mat_wft){ this.pnt_mat_wft = pnt_mat_wft;}
public void setPnt_mat_tsr(double pnt_mat_tsr){ this.pnt_mat_tsr = pnt_mat_tsr;}
public void setPnt_mat_desc(String pnt_mat_desc){ this.pnt_mat_desc = pnt_mat_desc;}
public void setThnr_mat_code(String thnr_mat_code){ this.thnr_mat_code = thnr_mat_code;}
public void setThnr_rate(int thnr_rate){ this.thnr_rate = thnr_rate;}
public void setPnt_mat_unit_pr(int pnt_mat_unit_pr){ this.pnt_mat_unit_pr = pnt_mat_unit_pr;}
public void setPnt_mat_unit_pr_amt(int pnt_mat_unit_pr_amt){ this.pnt_mat_unit_pr_amt = pnt_mat_unit_pr_amt;}
public void setThnr_mat_unit_pr(int thnr_mat_unit_pr){ this.thnr_mat_unit_pr = thnr_mat_unit_pr;}
public void setThnr_mat_unit_pr_amt(int thnr_mat_unit_pr_amt){ this.thnr_mat_unit_pr_amt = thnr_mat_unit_pr_amt;}
public void setSply_req_date(String sply_req_date){ this.sply_req_date = sply_req_date;}
public void setInsp_req_date(String insp_req_date){ this.insp_req_date = insp_req_date;}
public void setWork_ord_no(String work_ord_no){ this.work_ord_no = work_ord_no;}
public void setEstm_mh(double estm_mh){ this.estm_mh = estm_mh;}
public void setWo_mh(double wo_mh){ this.wo_mh = wo_mh;}
public void setRgsr_emp_no(String rgsr_emp_no){ this.rgsr_emp_no = rgsr_emp_no;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}
public void setMnt_emp_no(String mnt_emp_no){ this.mnt_emp_no = mnt_emp_no;}
public void setMnt_date(String mnt_date){ this.mnt_date = mnt_date;}
public void setMnt_time(String mnt_time){ this.mnt_time = mnt_time;}
public void setRmrk(String rmrk){ this.rmrk = rmrk;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = proj_no + "" ; break;
  case  2 : field = blk_no + "" ; break;
  case  3 : field = work_kind + "" ; break;
  case  4 : field = pnt_zone_code + "" ; break;
  case  5 : field = pnt_seq + "" ; break;
  case  6 : field = pnt_mat_code + "" ; break;
  case  7 : field = pnt_tot_area + "" ; break;
  case  8 : field = pnt_area + "" ; break;
  case  9 : field = estm_pnt_mat_vol + "" ; break;
  case  10 : field = cstr_pnt_mat_vol + "" ; break;
  case  11 : field = pnt_zone_desc + "" ; break;
  case  12 : field = blk_srfc_grd + "" ; break;
  case  13 : field = pnt_mat_dft + "" ; break;
  case  14 : field = pnt_mat_wft + "" ; break;
  case  15 : field = pnt_mat_tsr + "" ; break;
  case  16 : field = pnt_mat_desc + "" ; break;
  case  17 : field = thnr_mat_code + "" ; break;
  case  18 : field = thnr_rate + "" ; break;
  case  19 : field = pnt_mat_unit_pr + "" ; break;
  case  20 : field = pnt_mat_unit_pr_amt + "" ; break;
  case  21 : field = thnr_mat_unit_pr + "" ; break;
  case  22 : field = thnr_mat_unit_pr_amt + "" ; break;
  case  23 : field = sply_req_date + "" ; break;
  case  24 : field = insp_req_date + "" ; break;
  case  25 : field = work_ord_no + "" ; break;
  case  26 : field = estm_mh + "" ; break;
  case  27 : field = wo_mh + "" ; break;
  case  28 : field = rgsr_emp_no + "" ; break;
  case  29 : field = rgdt + "" ; break;
  case  30 : field = mnt_emp_no + "" ; break;
  case  31 : field = mnt_date + "" ; break;
  case  32 : field = mnt_time + "" ; break;
  case  33 : field = rmrk + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("proj_no")){ field = proj_no + "" ; 
     } else if(rec.equalsIgnoreCase("blk_no")){ field = blk_no + "" ; 
     } else if(rec.equalsIgnoreCase("work_kind")){ field = work_kind + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_zone_code")){ field = pnt_zone_code + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_seq")){ field = pnt_seq + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_mat_code")){ field = pnt_mat_code + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_tot_area")){ field = pnt_tot_area + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_area")){ field = pnt_area + "" ; 
     } else if(rec.equalsIgnoreCase("estm_pnt_mat_vol")){ field = estm_pnt_mat_vol + "" ; 
     } else if(rec.equalsIgnoreCase("cstr_pnt_mat_vol")){ field = cstr_pnt_mat_vol + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_zone_desc")){ field = pnt_zone_desc + "" ; 
     } else if(rec.equalsIgnoreCase("blk_srfc_grd")){ field = blk_srfc_grd + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_mat_dft")){ field = pnt_mat_dft + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_mat_wft")){ field = pnt_mat_wft + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_mat_tsr")){ field = pnt_mat_tsr + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_mat_desc")){ field = pnt_mat_desc + "" ; 
     } else if(rec.equalsIgnoreCase("thnr_mat_code")){ field = thnr_mat_code + "" ; 
     } else if(rec.equalsIgnoreCase("thnr_rate")){ field = thnr_rate + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_mat_unit_pr")){ field = pnt_mat_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_mat_unit_pr_amt")){ field = pnt_mat_unit_pr_amt + "" ; 
     } else if(rec.equalsIgnoreCase("thnr_mat_unit_pr")){ field = thnr_mat_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("thnr_mat_unit_pr_amt")){ field = thnr_mat_unit_pr_amt + "" ; 
     } else if(rec.equalsIgnoreCase("sply_req_date")){ field = sply_req_date + "" ; 
     } else if(rec.equalsIgnoreCase("insp_req_date")){ field = insp_req_date + "" ; 
     } else if(rec.equalsIgnoreCase("work_ord_no")){ field = work_ord_no + "" ; 
     } else if(rec.equalsIgnoreCase("estm_mh")){ field = estm_mh + "" ; 
     } else if(rec.equalsIgnoreCase("wo_mh")){ field = wo_mh + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_emp_no")){ field = rgsr_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_emp_no")){ field = mnt_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_date")){ field = mnt_date + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_time")){ field = mnt_time + "" ; 
     } else if(rec.equalsIgnoreCase("rmrk")){ field = rmrk + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "PROJ_NO", "BLK_NO", "WORK_KIND", "PNT_ZONE_CODE", "PNT_SEQ", "PNT_MAT_CODE", "PNT_TOT_AREA", 
       "PNT_AREA", "ESTM_PNT_MAT_VOL", "CSTR_PNT_MAT_VOL", "PNT_ZONE_DESC", "BLK_SRFC_GRD", "PNT_MAT_DFT", "PNT_MAT_WFT", 
       "PNT_MAT_TSR", "PNT_MAT_DESC", "THNR_MAT_CODE", "THNR_RATE", "PNT_MAT_UNIT_PR", "PNT_MAT_UNIT_PR_AMT", "THNR_MAT_UNIT_PR", 
       "THNR_MAT_UNIT_PR_AMT", "SPLY_REQ_DATE", "INSP_REQ_DATE", "WORK_ORD_NO", "ESTM_MH", "WO_MH", "RGSR_EMP_NO", 
       "RGDT", "MNT_EMP_NO", "MNT_DATE", "MNT_TIME", "RMRK"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "PROJ_NO", "BLK_NO", "WORK_KIND", "PNT_ZONE_CODE", "PNT_SEQ"};
    return tempx;
}

}// end HP.WGP20MRec class