package com.bes_line.mst.HPW;

// DBWrapper Class for HP.WG231M
/**
 *
 * @(#) HP.WG231MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-25
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class HP.WG231MDBWrapBES extends DBWrapper{

public HP.WG231MDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Select Page 
* @param String blk_zone_no
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectPage(String fldname, int page, int pagesize, String whereOption ) throws Exception{
return selectPage(fldname,page,pagesize, "Asc", whereOption) ;
}// end selectPage
/**
* Select Page
* @param String blk_zone_no* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectPage(String fldname, int page, int pagesize, String keyorder, String whereOption) throws Exception{
    java.util.Vector hp.wg231mV = new java.util.Vector();
    HP.WG231MRec hp.wg231m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select blk_zone_no, bdpa_detl_clsf_code, wcg_code, st_kpnt, ele_dur, rgsr_emp_name, rgsr_date, rgsr_time, mnt_emp_name, " +
                              "mnt_date, mnt_time " +
                       "  from HP.WG231M  where 1 = 1 " +	whereOption  +
                       "  order by "+fldname+" "+keyorder; 
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();
        int count = 0;
        while((count < (page-1)*pagesize ) && ( rs.next())){  count ++; } // page??? ??????
            count = 0;
        while(rs.next()){
            count ++;
            if(count > pagesize ) break;
            hp.wg231m = new HP.WG231MRec(); // HP.WG231MRec Constructor
                     hp.wg231m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     hp.wg231m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     hp.wg231m.setWcg_code(rs.getString("wcg_code"));
                     hp.wg231m.setSt_kpnt(rs.getInt("st_kpnt"));
                     hp.wg231m.setEle_dur(rs.getInt("ele_dur"));
                     hp.wg231m.setRgsr_emp_name(rs.getString("rgsr_emp_name"));
                     hp.wg231m.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg231m.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg231m.setMnt_emp_name(rs.getString("mnt_emp_name"));
                     hp.wg231m.setMnt_date(rs.getString("mnt_date"));
                     hp.wg231m.setMnt_time(rs.getString("mnt_time"));
            hp.wg231mV.addElement(hp.wg231m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg231mV;
} // end selectPage

/**
* SelectWhere 
* @param String blk_zone_no
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectWhere(String fldname, String whereOption ) throws Exception{
return selectWhere(fldname, "Asc", whereOption) ;
}// end selectWhere
/**
* SelectWhere
* @param String blk_zone_no* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectWhere(String fldname, String keyorder, String whereOption) throws Exception{
    java.util.Vector hp.wg231mV = new java.util.Vector();
    HP.WG231MRec hp.wg231m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select blk_zone_no, bdpa_detl_clsf_code, wcg_code, st_kpnt, ele_dur, rgsr_emp_name, rgsr_date, rgsr_time, mnt_emp_name, " +
                              "mnt_date, mnt_time " +
                       "  from HP.WG231M  where 1 = 1 " +	whereOption  +
                       "  order by "+fldname+" "+keyorder; 
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();
        while(rs.next()) { 
            hp.wg231m = new HP.WG231MRec(); // HP.WG231MRec Constructor
                     hp.wg231m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     hp.wg231m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     hp.wg231m.setWcg_code(rs.getString("wcg_code"));
                     hp.wg231m.setSt_kpnt(rs.getInt("st_kpnt"));
                     hp.wg231m.setEle_dur(rs.getInt("ele_dur"));
                     hp.wg231m.setRgsr_emp_name(rs.getString("rgsr_emp_name"));
                     hp.wg231m.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg231m.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg231m.setMnt_emp_name(rs.getString("mnt_emp_name"));
                     hp.wg231m.setMnt_date(rs.getString("mnt_date"));
                     hp.wg231m.setMnt_time(rs.getString("mnt_time"));
            hp.wg231mV.addElement(hp.wg231m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg231mV;
} // end selectWhere

/**
* Get Rows CountPage 
* @param 
* @return int 
* @author besTeam 
* @date 2006-5-25
*/
public int countPage(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select COUNT(*) from HP.WG231M  where 1 = 1 " +	whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end countPage

/**
* Get one Record 
* @param String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur
* @return HP.WG231MRec 
* @author besTeam 
* @date 2006-5-25
*/
public HP.WG231MRec select(String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur) throws Exception{
    HP.WG231MRec hp.wg231m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT BLK_ZONE_NO, BDPA_DETL_CLSF_CODE, WCG_CODE, ST_KPNT, (FIN_KPNT - ST_KPNT + 1) AS ELE_DUR "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
		+ " , RGSR_DATE, RGSR_TIME "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
		+ " , MNT_DATE, MNT_TIME "
		+ " FROM HP.WG231M A "

		+ " where blk_zone_no = ? and bdpa_detl_clsf_code = ? and wcg_code = ? and st_kpnt = ? and ele_dur = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,blk_zone_no); 
        pstmt.setString(2,bdpa_detl_clsf_code); 
        pstmt.setString(3,wcg_code); 
        pstmt.setInt(4,st_kpnt); 
        pstmt.setInt(5,ele_dur); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            hp.wg231m = new HP.WG231MRec(); // HP.WG231MRec Constructor
                     hp.wg231m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     hp.wg231m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     hp.wg231m.setWcg_code(rs.getString("wcg_code"));
                     hp.wg231m.setSt_kpnt(rs.getInt("st_kpnt"));
                     hp.wg231m.setEle_dur(rs.getInt("ele_dur"));
                     hp.wg231m.setRgsr_emp_name(rs.getString("rgsr_emp_name"));
                     hp.wg231m.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg231m.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg231m.setMnt_emp_name(rs.getString("mnt_emp_name"));
                     hp.wg231m.setMnt_date(rs.getString("mnt_date"));
                     hp.wg231m.setMnt_time(rs.getString("mnt_time"));
        } else {
            throw new DataNotFoundException();
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg231m;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector hp.wg231mV = new java.util.Vector();
    HP.WG231MRec hp.wg231m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT BLK_ZONE_NO, BDPA_DETL_CLSF_CODE, WCG_CODE, ST_KPNT, (FIN_KPNT - ST_KPNT + 1) AS ELE_DUR "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
		+ " , RGSR_DATE, RGSR_TIME "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
		+ " , MNT_DATE, MNT_TIME "
		+ " FROM HP.WG231M A "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            hp.wg231m = new HP.WG231MRec(); // HP.WG231MRec Constructor
                     hp.wg231m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     hp.wg231m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     hp.wg231m.setWcg_code(rs.getString("wcg_code"));
                     hp.wg231m.setSt_kpnt(rs.getInt("st_kpnt"));
                     hp.wg231m.setEle_dur(rs.getInt("ele_dur"));
                     hp.wg231m.setRgsr_emp_name(rs.getString("rgsr_emp_name"));
                     hp.wg231m.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg231m.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg231m.setMnt_emp_name(rs.getString("mnt_emp_name"));
                     hp.wg231m.setMnt_date(rs.getString("mnt_date"));
                     hp.wg231m.setMnt_time(rs.getString("mnt_time"));
            hp.wg231mV.addElement(hp.wg231m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg231mV;
} // end selectAll

/**
* Get selectWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectWhere(String whereOption) throws Exception{
    java.util.Vector hp.wg231mV = new java.util.Vector();
    HP.WG231MRec hp.wg231m = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = " SELECT BLK_ZONE_NO, BDPA_DETL_CLSF_CODE, WCG_CODE, ST_KPNT, (FIN_KPNT - ST_KPNT + 1) AS ELE_DUR "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
		+ " , RGSR_DATE, RGSR_TIME "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
		+ " , MNT_DATE, MNT_TIME "
		+ " FROM HP.WG231M A "

  + whereOption; 
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            hp.wg231m = new HP.WG231MRec(); // HP.WG231MRec Constructor
                     hp.wg231m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     hp.wg231m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     hp.wg231m.setWcg_code(rs.getString("wcg_code"));
                     hp.wg231m.setSt_kpnt(rs.getInt("st_kpnt"));
                     hp.wg231m.setEle_dur(rs.getInt("ele_dur"));
                     hp.wg231m.setRgsr_emp_name(rs.getString("rgsr_emp_name"));
                     hp.wg231m.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg231m.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg231m.setMnt_emp_name(rs.getString("mnt_emp_name"));
                     hp.wg231m.setMnt_date(rs.getString("mnt_date"));
                     hp.wg231m.setMnt_time(rs.getString("mnt_time"));
            hp.wg231mV.addElement(hp.wg231m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg231mV;
} // end selectAll

/**
* Get All Record(condition : last Key except) 
* @param String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectAll(String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt) throws Exception{
    java.util.Vector hp.wg231mV = new java.util.Vector();
    HP.WG231MRec hp.wg231m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT BLK_ZONE_NO, BDPA_DETL_CLSF_CODE, WCG_CODE, ST_KPNT, (FIN_KPNT - ST_KPNT + 1) AS ELE_DUR "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
		+ " , RGSR_DATE, RGSR_TIME "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
		+ " , MNT_DATE, MNT_TIME "
		+ " FROM HP.WG231M A "

		+ " where blk_zone_no = ? and bdpa_detl_clsf_code = ? and wcg_code = ? and st_kpnt = ?  " +
                       "  order by ele_dur"; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,blk_zone_no); 
        pstmt.setString(2,bdpa_detl_clsf_code); 
        pstmt.setString(3,wcg_code); 
        pstmt.setInt(4,st_kpnt); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            hp.wg231m = new HP.WG231MRec(); // HP.WG231MRec Constructor
                     hp.wg231m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     hp.wg231m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     hp.wg231m.setWcg_code(rs.getString("wcg_code"));
                     hp.wg231m.setSt_kpnt(rs.getInt("st_kpnt"));
                     hp.wg231m.setEle_dur(rs.getInt("ele_dur"));
                     hp.wg231m.setRgsr_emp_name(rs.getString("rgsr_emp_name"));
                     hp.wg231m.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg231m.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg231m.setMnt_emp_name(rs.getString("mnt_emp_name"));
                     hp.wg231m.setMnt_date(rs.getString("mnt_date"));
                     hp.wg231m.setMnt_time(rs.getString("mnt_time"));
            hp.wg231mV.addElement(hp.wg231m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg231mV;
} // end selectAll

/**
* Get between Record(condition : last Key from - to) 
* @param String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int f_ele_dur, int t_ele_dur
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectBetween(String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int f_ele_dur, int t_ele_dur) throws Exception{
    return selectBetween(blk_zone_no, bdpa_detl_clsf_code, wcg_code, st_kpnt, f_ele_dur, t_ele_dur, 0);
} // end selectBetween

/**
* Get between Record(condition : last Key from - to) 
* @param String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int f_ele_dur, int t_ele_dur, int lastKeyOrder(0 : ASC-Default, 1 : DESC)
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectBetween(String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int f_ele_dur, int t_ele_dur, int lastKeyOrder) throws Exception{
    java.util.Vector hp.wg231mV = new java.util.Vector();
    HP.WG231MRec hp.wg231m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT BLK_ZONE_NO, BDPA_DETL_CLSF_CODE, WCG_CODE, ST_KPNT, (FIN_KPNT - ST_KPNT + 1) AS ELE_DUR "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
		+ " , RGSR_DATE, RGSR_TIME "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
		+ " , MNT_DATE, MNT_TIME "
		+ " FROM HP.WG231M A "

		+ " where blk_zone_no = ? and bdpa_detl_clsf_code = ? and wcg_code = ? and st_kpnt = ?  " +
                       "  and ele_dur between ? and ?  ";
               if(lastKeyOrder == 1){
                   query += " order by ele_dur DESC "; 
               } else {
                   query += " order by ele_dur"; 
               } // end if(lastKeyOrder == 1)
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,blk_zone_no); 
        pstmt.setString(2,bdpa_detl_clsf_code); 
        pstmt.setString(3,wcg_code); 
        pstmt.setInt(4,st_kpnt); 
        pstmt.setInt(5,f_ele_dur); 
        pstmt.setInt(6,t_ele_dur); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            hp.wg231m = new HP.WG231MRec(); // HP.WG231MRec Constructor
                     hp.wg231m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     hp.wg231m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     hp.wg231m.setWcg_code(rs.getString("wcg_code"));
                     hp.wg231m.setSt_kpnt(rs.getInt("st_kpnt"));
                     hp.wg231m.setEle_dur(rs.getInt("ele_dur"));
                     hp.wg231m.setRgsr_emp_name(rs.getString("rgsr_emp_name"));
                     hp.wg231m.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg231m.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg231m.setMnt_emp_name(rs.getString("mnt_emp_name"));
                     hp.wg231m.setMnt_date(rs.getString("mnt_date"));
                     hp.wg231m.setMnt_time(rs.getString("mnt_time"));
            hp.wg231mV.addElement(hp.wg231m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg231mV;
} // end selectBetween

/**
* Select Data Over the key value(s) and default return count(20) 
* @param String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectOver(String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur) throws Exception{
return selectOver(blk_zone_no, bdpa_detl_clsf_code, wcg_code, st_kpnt, ele_dur,20) ;
}// end selectOver
/**
* Select Data Over(Next) the key value(s) and return record count 
* @param String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur, int 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectOver(String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur, int page) throws Exception{
    java.util.Vector hp.wg231mV = new java.util.Vector();
    HP.WG231MRec hp.wg231m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT BLK_ZONE_NO, BDPA_DETL_CLSF_CODE, WCG_CODE, ST_KPNT, (FIN_KPNT - ST_KPNT + 1) AS ELE_DUR "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
		+ " , RGSR_DATE, RGSR_TIME "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
		+ " , MNT_DATE, MNT_TIME "
		+ " FROM HP.WG231M A "

		+ " where blk_zone_no = ?  and  bdpa_detl_clsf_code = ?  and  wcg_code = ?  and  st_kpnt = ?  and  ele_dur >= ? order by ele_dur "; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,blk_zone_no); 
        pstmt.setString(2,bdpa_detl_clsf_code); 
        pstmt.setString(3,wcg_code); 
        pstmt.setInt(4,st_kpnt); 
        pstmt.setInt(5,ele_dur); 
        rs = pstmt.executeQuery();
        int count = 0;//??f??? SQL?????? Limit??? ????...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            hp.wg231m = new HP.WG231MRec(); // HP.WG231MRec Constructor
                     hp.wg231m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     hp.wg231m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     hp.wg231m.setWcg_code(rs.getString("wcg_code"));
                     hp.wg231m.setSt_kpnt(rs.getInt("st_kpnt"));
                     hp.wg231m.setEle_dur(rs.getInt("ele_dur"));
                     hp.wg231m.setRgsr_emp_name(rs.getString("rgsr_emp_name"));
                     hp.wg231m.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg231m.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg231m.setMnt_emp_name(rs.getString("mnt_emp_name"));
                     hp.wg231m.setMnt_date(rs.getString("mnt_date"));
                     hp.wg231m.setMnt_time(rs.getString("mnt_time"));
            hp.wg231mV.addElement(hp.wg231m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg231mV;
} // end selectOver

/**
* Select Data Under(Previous) the key value(s) and default return count(20) 
* @param String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur
* @return java.util.Vector 
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectUnder(String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur) throws Exception{
return selectUnder(blk_zone_no, bdpa_detl_clsf_code, wcg_code, st_kpnt, ele_dur,20) ;
}// end selectUnder
/**
* Select Data Under(Previous) the key value(s) and return record count 
* @param String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur, int
* @return java.util.Vector
* @author besTeam 
* @date 2006-5-25
*/
public java.util.Vector selectUnder(String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur, int page) throws Exception{
    java.util.Vector hp.wg231mV = new java.util.Vector();
    HP.WG231MRec hp.wg231m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT BLK_ZONE_NO, BDPA_DETL_CLSF_CODE, WCG_CODE, ST_KPNT, (FIN_KPNT - ST_KPNT + 1) AS ELE_DUR "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
		+ " , RGSR_DATE, RGSR_TIME "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
		+ " , MNT_DATE, MNT_TIME "
		+ " FROM HP.WG231M A "

		+ " where blk_zone_no = ?  and bdpa_detl_clsf_code = ?  and wcg_code = ?  and st_kpnt = ?  and ele_dur <= ? order by ele_dur desc" ; 
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,blk_zone_no); 
        pstmt.setString(2,bdpa_detl_clsf_code); 
        pstmt.setString(3,wcg_code); 
        pstmt.setInt(4,st_kpnt); 
        pstmt.setInt(5,ele_dur); 
        rs = pstmt.executeQuery();
        int count = 0;//??f??? SQL?????? Limit??? ????...
        while(rs.next()){
            count ++;
            if(count > page ) break;
            hp.wg231m = new HP.WG231MRec(); // HP.WG231MRec Constructor
                     hp.wg231m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     hp.wg231m.setBdpa_detl_clsf_code(rs.getString("bdpa_detl_clsf_code"));
                     hp.wg231m.setWcg_code(rs.getString("wcg_code"));
                     hp.wg231m.setSt_kpnt(rs.getInt("st_kpnt"));
                     hp.wg231m.setEle_dur(rs.getInt("ele_dur"));
                     hp.wg231m.setRgsr_emp_name(rs.getString("rgsr_emp_name"));
                     hp.wg231m.setRgsr_date(rs.getString("rgsr_date"));
                     hp.wg231m.setRgsr_time(rs.getString("rgsr_time"));
                     hp.wg231m.setMnt_emp_name(rs.getString("mnt_emp_name"));
                     hp.wg231m.setMnt_date(rs.getString("mnt_date"));
                     hp.wg231m.setMnt_time(rs.getString("mnt_time"));
            hp.wg231mV.add(0,hp.wg231m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hp.wg231mV;
} // end selectUnder
/**
* Get Rows Count 
* @param String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur
* @return int 
* @author besTeam 
* @date 2006-5-25
*/
public int count(String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
		+ " , RGSR_DATE, RGSR_TIME "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
		+ " , MNT_DATE, MNT_TIME "
		+ " FROM HP.WG231M A "

		+ " where blk_zone_no = ? and bdpa_detl_clsf_code = ? and wcg_code = ? and st_kpnt = ? and ele_dur = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,blk_zone_no); 
        pstmt.setString(2,bdpa_detl_clsf_code); 
        pstmt.setString(3,wcg_code); 
        pstmt.setInt(4,st_kpnt); 
        pstmt.setInt(5,ele_dur); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param void 
* @return int 
* @author besTeam 
* @date 2006-5-25
*/
public int count() throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " EE.BA500M WHERE EMP_NO = A.RGSR_EMP_NO) AS RGSR_EMP_NAME "
		+ " , RGSR_DATE, RGSR_TIME "
		+ " , (SELECT EMP_NAME_KOR FROM EE.BA500M WHERE EMP_NO = A.MNT_EMP_NO) AS MNT_EMP_NAME "
		+ " , MNT_DATE, MNT_TIME "
		+ " FROM HP.WG231M A "

;        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}// end HP.WG231MDBWrapBES class