package com.bes_line.mst.HPW ;

// Entity Class for HP.WG231M
/**
 *
 * @(#) HP.WG231MRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-5-25
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class HP.WG231MRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String blk_zone_no; 		// (VARCHAR2, 3.0)
    public String bdpa_detl_clsf_code; 		// (VARCHAR2, 6.0)
    public String wcg_code; 		// (VARCHAR2, 4.0)
    public int st_kpnt; 		// (NUMBER, 5.0)
    public int ele_dur; 		// (NUMBER, 0.0)
    public String rgsr_emp_name; 		// (VARCHAR2, 45.0)
    public String rgsr_date; 		// (VARCHAR2, 8.0)
    public String rgsr_time; 		// (VARCHAR2, 6.0)
    public String mnt_emp_name; 		// (VARCHAR2, 45.0)
    public String mnt_date; 		// (VARCHAR2, 8.0)
    public String mnt_time; 		// (VARCHAR2, 6.0)

public HP.WG231MRec(){ } // default constructor

public HP.WG231MRec(
       String blk_zone_no, String bdpa_detl_clsf_code, String wcg_code, int st_kpnt, int ele_dur, String rgsr_emp_name, 
       String rgsr_date, String rgsr_time, String mnt_emp_name, String mnt_date, String mnt_time){
    this.blk_zone_no = blk_zone_no;
    this.bdpa_detl_clsf_code = bdpa_detl_clsf_code;
    this.wcg_code = wcg_code;
    this.st_kpnt = st_kpnt;
    this.ele_dur = ele_dur;
    this.rgsr_emp_name = rgsr_emp_name;
    this.rgsr_date = rgsr_date;
    this.rgsr_time = rgsr_time;
    this.mnt_emp_name = mnt_emp_name;
    this.mnt_date = mnt_date;
    this.mnt_time = mnt_time;
} // Constructor


// Getter 
public String getBlk_zone_no(){ return blk_zone_no;}
public String getBdpa_detl_clsf_code(){ return bdpa_detl_clsf_code;}
public String getWcg_code(){ return wcg_code;}
public int getSt_kpnt(){ return st_kpnt;}
public int getEle_dur(){ return ele_dur;}
public String getRgsr_emp_name(){ return rgsr_emp_name;}
public String getRgsr_date(){ return rgsr_date;}
public String getRgsr_time(){ return rgsr_time;}
public String getMnt_emp_name(){ return mnt_emp_name;}
public String getMnt_date(){ return mnt_date;}
public String getMnt_time(){ return mnt_time;}

// Setter 
public void setBlk_zone_no(String blk_zone_no){ this.blk_zone_no = blk_zone_no;}
public void setBdpa_detl_clsf_code(String bdpa_detl_clsf_code){ this.bdpa_detl_clsf_code = bdpa_detl_clsf_code;}
public void setWcg_code(String wcg_code){ this.wcg_code = wcg_code;}
public void setSt_kpnt(int st_kpnt){ this.st_kpnt = st_kpnt;}
public void setEle_dur(int ele_dur){ this.ele_dur = ele_dur;}
public void setRgsr_emp_name(String rgsr_emp_name){ this.rgsr_emp_name = rgsr_emp_name;}
public void setRgsr_date(String rgsr_date){ this.rgsr_date = rgsr_date;}
public void setRgsr_time(String rgsr_time){ this.rgsr_time = rgsr_time;}
public void setMnt_emp_name(String mnt_emp_name){ this.mnt_emp_name = mnt_emp_name;}
public void setMnt_date(String mnt_date){ this.mnt_date = mnt_date;}
public void setMnt_time(String mnt_time){ this.mnt_time = mnt_time;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = blk_zone_no + "" ; break;
  case  2 : field = bdpa_detl_clsf_code + "" ; break;
  case  3 : field = wcg_code + "" ; break;
  case  4 : field = st_kpnt + "" ; break;
  case  5 : field = ele_dur + "" ; break;
  case  6 : field = rgsr_emp_name + "" ; break;
  case  7 : field = rgsr_date + "" ; break;
  case  8 : field = rgsr_time + "" ; break;
  case  9 : field = mnt_emp_name + "" ; break;
  case  10 : field = mnt_date + "" ; break;
  case  11 : field = mnt_time + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("blk_zone_no")){ field = blk_zone_no + "" ; 
     } else if(rec.equalsIgnoreCase("bdpa_detl_clsf_code")){ field = bdpa_detl_clsf_code + "" ; 
     } else if(rec.equalsIgnoreCase("wcg_code")){ field = wcg_code + "" ; 
     } else if(rec.equalsIgnoreCase("st_kpnt")){ field = st_kpnt + "" ; 
     } else if(rec.equalsIgnoreCase("ele_dur")){ field = ele_dur + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_emp_name")){ field = rgsr_emp_name + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_date")){ field = rgsr_date + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_time")){ field = rgsr_time + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_emp_name")){ field = mnt_emp_name + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_date")){ field = mnt_date + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_time")){ field = mnt_time + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "BLK_ZONE_NO", "BDPA_DETL_CLSF_CODE", "WCG_CODE", "ST_KPNT", "ELE_DUR", "RGSR_EMP_NAME", "RGSR_DATE", 
       "RGSR_TIME", "MNT_EMP_NAME", "MNT_DATE", "MNT_TIME"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "BLK_ZONE_NO", "BDPA_DETL_CLSF_CODE", "WCG_CODE", "ST_KPNT", "ELE_DUR"};
    return tempx;
}

}// end HP.WG231MRec class