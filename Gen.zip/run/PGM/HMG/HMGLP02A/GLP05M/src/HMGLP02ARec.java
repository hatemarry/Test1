package com.bes_line.mst.HMG ;

// Entity Class for HMGLP02A
/**
 *
 * @(#) HMGLP02A.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-27
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class HMGLP02ARec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String po_no; 		// (VARCHAR2, 12.0)
    public String po_lnno; 		// (VARCHAR2, 3.0)
    public String po_rev_no; 		// (VARCHAR2, 2.0)
    public String po_uom; 		// (VARCHAR2, 2.0)
    public int po_qty; 		// (NUMBER, 7.0)
    public double prch_unit_pr; 		// (NUMBER, 13.2)
    public String part_desc; 		// (VARCHAR2, 56.0)
    public int base_unit_pr; 		// (NUMBER, 0.0)
    public int clss_insp_unit_pr; 		// (NUMBER, 0.0)
    public int crry_unit_pr; 		// (NUMBER, 0.0)
    public int acpt_qty; 		// (NUMBER, 7.0)
    public int por_qty; 		// (NUMBER, 7.0)
    public String por_pnd; 		// (VARCHAR2, 8.0)
    public double unit_wt; 		// (NUMBER, 10.3)
    public String po_line_rmrk; 		// (VARCHAR2, 80.0)
    public String por_no; 		// (VARCHAR2, 7.0)
    public String part_no; 		// (VARCHAR2, 18.0)
    public String por_chng_stus_code; 		// (CHAR, 1.0)

public HMGLP02ARec(){ } // default constructor

public HMGLP02ARec(
       String po_no, String po_lnno, String po_rev_no, String po_uom, int po_qty, double prch_unit_pr, 
       String part_desc, int base_unit_pr, int clss_insp_unit_pr, int crry_unit_pr, int acpt_qty, int por_qty, 
       String por_pnd, double unit_wt, String po_line_rmrk, String por_no, String part_no, String por_chng_stus_code){
    this.po_no = po_no;
    this.po_lnno = po_lnno;
    this.po_rev_no = po_rev_no;
    this.po_uom = po_uom;
    this.po_qty = po_qty;
    this.prch_unit_pr = prch_unit_pr;
    this.part_desc = part_desc;
    this.base_unit_pr = base_unit_pr;
    this.clss_insp_unit_pr = clss_insp_unit_pr;
    this.crry_unit_pr = crry_unit_pr;
    this.acpt_qty = acpt_qty;
    this.por_qty = por_qty;
    this.por_pnd = por_pnd;
    this.unit_wt = unit_wt;
    this.po_line_rmrk = po_line_rmrk;
    this.por_no = por_no;
    this.part_no = part_no;
    this.por_chng_stus_code = por_chng_stus_code;
} // Constructor


// Getter 
public String getPo_no(){ return po_no;}
public String getPo_lnno(){ return po_lnno;}
public String getPo_rev_no(){ return po_rev_no;}
public String getPo_uom(){ return po_uom;}
public int getPo_qty(){ return po_qty;}
public double getPrch_unit_pr(){ return prch_unit_pr;}
public String getPart_desc(){ return part_desc;}
public int getBase_unit_pr(){ return base_unit_pr;}
public int getClss_insp_unit_pr(){ return clss_insp_unit_pr;}
public int getCrry_unit_pr(){ return crry_unit_pr;}
public int getAcpt_qty(){ return acpt_qty;}
public int getPor_qty(){ return por_qty;}
public String getPor_pnd(){ return por_pnd;}
public double getUnit_wt(){ return unit_wt;}
public String getPo_line_rmrk(){ return po_line_rmrk;}
public String getPor_no(){ return por_no;}
public String getPart_no(){ return part_no;}
public String getPor_chng_stus_code(){ return por_chng_stus_code;}

// Setter 
public void setPo_no(String po_no){ this.po_no = po_no;}
public void setPo_lnno(String po_lnno){ this.po_lnno = po_lnno;}
public void setPo_rev_no(String po_rev_no){ this.po_rev_no = po_rev_no;}
public void setPo_uom(String po_uom){ this.po_uom = po_uom;}
public void setPo_qty(int po_qty){ this.po_qty = po_qty;}
public void setPrch_unit_pr(double prch_unit_pr){ this.prch_unit_pr = prch_unit_pr;}
public void setPart_desc(String part_desc){ this.part_desc = part_desc;}
public void setBase_unit_pr(int base_unit_pr){ this.base_unit_pr = base_unit_pr;}
public void setClss_insp_unit_pr(int clss_insp_unit_pr){ this.clss_insp_unit_pr = clss_insp_unit_pr;}
public void setCrry_unit_pr(int crry_unit_pr){ this.crry_unit_pr = crry_unit_pr;}
public void setAcpt_qty(int acpt_qty){ this.acpt_qty = acpt_qty;}
public void setPor_qty(int por_qty){ this.por_qty = por_qty;}
public void setPor_pnd(String por_pnd){ this.por_pnd = por_pnd;}
public void setUnit_wt(double unit_wt){ this.unit_wt = unit_wt;}
public void setPo_line_rmrk(String po_line_rmrk){ this.po_line_rmrk = po_line_rmrk;}
public void setPor_no(String por_no){ this.por_no = por_no;}
public void setPart_no(String part_no){ this.part_no = part_no;}
public void setPor_chng_stus_code(String por_chng_stus_code){ this.por_chng_stus_code = por_chng_stus_code;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = po_no + "" ; break;
  case  2 : field = po_lnno + "" ; break;
  case  3 : field = po_rev_no + "" ; break;
  case  4 : field = po_uom + "" ; break;
  case  5 : field = po_qty + "" ; break;
  case  6 : field = prch_unit_pr + "" ; break;
  case  7 : field = part_desc + "" ; break;
  case  8 : field = base_unit_pr + "" ; break;
  case  9 : field = clss_insp_unit_pr + "" ; break;
  case  10 : field = crry_unit_pr + "" ; break;
  case  11 : field = acpt_qty + "" ; break;
  case  12 : field = por_qty + "" ; break;
  case  13 : field = por_pnd + "" ; break;
  case  14 : field = unit_wt + "" ; break;
  case  15 : field = po_line_rmrk + "" ; break;
  case  16 : field = por_no + "" ; break;
  case  17 : field = part_no + "" ; break;
  case  18 : field = por_chng_stus_code + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("po_no")){ field = po_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_lnno")){ field = po_lnno + "" ; 
     } else if(rec.equalsIgnoreCase("po_rev_no")){ field = po_rev_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_uom")){ field = po_uom + "" ; 
     } else if(rec.equalsIgnoreCase("po_qty")){ field = po_qty + "" ; 
     } else if(rec.equalsIgnoreCase("prch_unit_pr")){ field = prch_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("part_desc")){ field = part_desc + "" ; 
     } else if(rec.equalsIgnoreCase("base_unit_pr")){ field = base_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("clss_insp_unit_pr")){ field = clss_insp_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("crry_unit_pr")){ field = crry_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_qty")){ field = acpt_qty + "" ; 
     } else if(rec.equalsIgnoreCase("por_qty")){ field = por_qty + "" ; 
     } else if(rec.equalsIgnoreCase("por_pnd")){ field = por_pnd + "" ; 
     } else if(rec.equalsIgnoreCase("unit_wt")){ field = unit_wt + "" ; 
     } else if(rec.equalsIgnoreCase("po_line_rmrk")){ field = po_line_rmrk + "" ; 
     } else if(rec.equalsIgnoreCase("por_no")){ field = por_no + "" ; 
     } else if(rec.equalsIgnoreCase("part_no")){ field = part_no + "" ; 
     } else if(rec.equalsIgnoreCase("por_chng_stus_code")){ field = por_chng_stus_code + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "PO_NO", "PO_LNNO", "PO_REV_NO", "PO_UOM", "PO_QTY", "PRCH_UNIT_PR", "PART_DESC", 
       "BASE_UNIT_PR", "CLSS_INSP_UNIT_PR", "CRRY_UNIT_PR", "ACPT_QTY", "POR_QTY", "POR_PND", "UNIT_WT", 
       "PO_LINE_RMRK", "POR_NO", "PART_NO", "POR_CHNG_STUS_CODE"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "PO_NO", "PO_LNNO"};
    return tempx;
}

}// end HMGLP02ARec class