package com.bes_line.mst.HMG;

// DBWrapper Class for HMGLP02A
/**
 *
 * @(#) GLP05MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-27
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class HMGLP02ADBWrapBES extends DBWrapper{

public HMGLP02ADBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-27
*/
public java.util.Vector selectAllHMGLP02A(String whereOption,String sortOption) throws Exception{
    java.util.Vector hmglp02aV = new java.util.Vector();
    HMGLP02ARec hmglp02a = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = " SELECT PO_NO, PO_LNNO, PO_REV_NO, PO_UOM, PO_QTY, PRCH_UNIT_PR "
		+ " , (SELECT PART_DESC FROM HM.GLL01M WHERE PART_NO = A.PART_NO) AS PART_DESC "
		+ " , (SELECT BASE_UNIT_PR FROM HM.GLP10M WHERE PO_NO = A.PO_NO AND PO_LNNO = A.PO_LNNO) AS BASE_UNIT_PR "
		+ " , (SELECT CLSS_INSP_UNIT_PR FROM HM.GLP10M WHERE PO_NO = A.PO_NO AND PO_LNNO = A.PO_LNNO) AS CLSS_INSP_UNIT_PR "
		+ " , (SELECT CRRY_UNIT_PR FROM HM.GLP10M WHERE PO_NO = A.PO_NO AND PO_LNNO = A.PO_LNNO) AS CRRY_UNIT_PR "
		+ " , ACPT_QTY, POR_QTY "
		+ " , (SELECT POR_PND FROM HM.GLR03M WHERE POR_NO = A.POR_NO AND PART_NO = A.PART_NO) AS POR_PND "
		+ " , UNIT_WT, PO_LINE_RMRK, POR_NO, PART_NO "
		+ " , (SELECT "
		+ " CASE WHEN (SELECT COUNT(*) FROM HM.GLR17C WHERE POR_NO = A.PART_NO) > 0 "
		+ " THEN (SELECT CASE WHEN CNFM_DATE IS NULL THEN 'Y' ELSE ' ' END FROM HM.GLR17C WHERE POR_NO = A.PART_NO) "
		+ " ELSE ' ' END "
		+ " FROM DUAL) AS POR_CHNG_STUS_CODE "
		+ " FROM HM.GLP05M A "

        + whereOption; 
        if(sortOption.equals(""))  query += " order by  po_no " ;
        else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            hmglp02a = new HMGLP02ARec(); // HMGLP02ARec Constructor
                     hmglp02a.setPo_no(rs.getString("po_no"));
                     hmglp02a.setPo_lnno(rs.getString("po_lnno"));
                     hmglp02a.setPo_rev_no(rs.getString("po_rev_no"));
                     hmglp02a.setPo_uom(rs.getString("po_uom"));
                     hmglp02a.setPo_qty(rs.getInt("po_qty"));
                     hmglp02a.setPrch_unit_pr(rs.getDouble("prch_unit_pr"));
                     hmglp02a.setPart_desc(rs.getString("part_desc"));
                     hmglp02a.setBase_unit_pr(rs.getInt("base_unit_pr"));
                     hmglp02a.setClss_insp_unit_pr(rs.getInt("clss_insp_unit_pr"));
                     hmglp02a.setCrry_unit_pr(rs.getInt("crry_unit_pr"));
                     hmglp02a.setAcpt_qty(rs.getInt("acpt_qty"));
                     hmglp02a.setPor_qty(rs.getInt("por_qty"));
                     hmglp02a.setPor_pnd(rs.getString("por_pnd"));
                     hmglp02a.setUnit_wt(rs.getDouble("unit_wt"));
                     hmglp02a.setPo_line_rmrk(rs.getString("po_line_rmrk"));
                     hmglp02a.setPor_no(rs.getString("por_no"));
                     hmglp02a.setPart_no(rs.getString("part_no"));
                     hmglp02a.setPor_chng_stus_code(rs.getString("por_chng_stus_code"));
            hmglp02aV.addElement(hmglp02a);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hmglp02aV;
} // end selectAll

/**
* Select
* @param String po_no, String po_lnno
* @return HMGLP02ARec 
* @author besTeam 
* @date 2006-6-27
*/
public HMGLP02ARec selectHMGLP02A(String po_no, String po_lnno) throws Exception{
    java.util.Vector HMGLP02AV = new java.util.Vector();
    HMGLP02ARec hmglp02a = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PO_NO, PO_LNNO, PO_REV_NO, PO_UOM, PO_QTY, PRCH_UNIT_PR "
		+ " , (SELECT PART_DESC FROM HM.GLL01M WHERE PART_NO = A.PART_NO) AS PART_DESC "
		+ " , (SELECT BASE_UNIT_PR FROM HM.GLP10M WHERE PO_NO = A.PO_NO AND PO_LNNO = A.PO_LNNO) AS BASE_UNIT_PR "
		+ " , (SELECT CLSS_INSP_UNIT_PR FROM HM.GLP10M WHERE PO_NO = A.PO_NO AND PO_LNNO = A.PO_LNNO) AS CLSS_INSP_UNIT_PR "
		+ " , (SELECT CRRY_UNIT_PR FROM HM.GLP10M WHERE PO_NO = A.PO_NO AND PO_LNNO = A.PO_LNNO) AS CRRY_UNIT_PR "
		+ " , ACPT_QTY, POR_QTY "
		+ " , (SELECT POR_PND FROM HM.GLR03M WHERE POR_NO = A.POR_NO AND PART_NO = A.PART_NO) AS POR_PND "
		+ " , UNIT_WT, PO_LINE_RMRK, POR_NO, PART_NO "
		+ " , (SELECT "
		+ " CASE WHEN (SELECT COUNT(*) FROM HM.GLR17C WHERE POR_NO = A.PART_NO) > 0 "
		+ " THEN (SELECT CASE WHEN CNFM_DATE IS NULL THEN 'Y' ELSE ' ' END FROM HM.GLR17C WHERE POR_NO = A.PART_NO) "
		+ " ELSE ' ' END "
		+ " FROM DUAL) AS POR_CHNG_STUS_CODE "
		+ " FROM HM.GLP05M A "

       +" and po_no = ?  " ;
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_lnno); 
        rs = pstmt.executeQuery();
        if(rs.next()) { 
            hmglp02a = new HMGLP02ARec(); // HMGLP02ARec Constructor
                     hmglp02a.setPo_no(rs.getString("po_no"));
                     hmglp02a.setPo_lnno(rs.getString("po_lnno"));
                     hmglp02a.setPo_rev_no(rs.getString("po_rev_no"));
                     hmglp02a.setPo_uom(rs.getString("po_uom"));
                     hmglp02a.setPo_qty(rs.getInt("po_qty"));
                     hmglp02a.setPrch_unit_pr(rs.getDouble("prch_unit_pr"));
                     hmglp02a.setPart_desc(rs.getString("part_desc"));
                     hmglp02a.setBase_unit_pr(rs.getInt("base_unit_pr"));
                     hmglp02a.setClss_insp_unit_pr(rs.getInt("clss_insp_unit_pr"));
                     hmglp02a.setCrry_unit_pr(rs.getInt("crry_unit_pr"));
                     hmglp02a.setAcpt_qty(rs.getInt("acpt_qty"));
                     hmglp02a.setPor_qty(rs.getInt("por_qty"));
                     hmglp02a.setPor_pnd(rs.getString("por_pnd"));
                     hmglp02a.setUnit_wt(rs.getDouble("unit_wt"));
                     hmglp02a.setPo_line_rmrk(rs.getString("po_line_rmrk"));
                     hmglp02a.setPor_no(rs.getString("por_no"));
                     hmglp02a.setPart_no(rs.getString("part_no"));
                     hmglp02a.setPor_chng_stus_code(rs.getString("por_chng_stus_code"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hmglp02a;
} // end select

/**
* Get Rows Count 
* @param String po_no, String po_lnno
* @return int 
* @author besTeam 
* @date 2006-6-27
*/
public int countHMGLP02A(String po_no, String po_lnno) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " HM.GLL01M WHERE PART_NO = A.PART_NO) AS PART_DESC "
		+ " , (SELECT BASE_UNIT_PR FROM HM.GLP10M WHERE PO_NO = A.PO_NO AND PO_LNNO = A.PO_LNNO) AS BASE_UNIT_PR "
		+ " , (SELECT CLSS_INSP_UNIT_PR FROM HM.GLP10M WHERE PO_NO = A.PO_NO AND PO_LNNO = A.PO_LNNO) AS CLSS_INSP_UNIT_PR "
		+ " , (SELECT CRRY_UNIT_PR FROM HM.GLP10M WHERE PO_NO = A.PO_NO AND PO_LNNO = A.PO_LNNO) AS CRRY_UNIT_PR "
		+ " , ACPT_QTY, POR_QTY "
		+ " , (SELECT POR_PND FROM HM.GLR03M WHERE POR_NO = A.POR_NO AND PART_NO = A.PART_NO) AS POR_PND "
		+ " , UNIT_WT, PO_LINE_RMRK, POR_NO, PART_NO "
		+ " , (SELECT "
		+ " CASE WHEN (SELECT COUNT(*) FROM HM.GLR17C WHERE POR_NO = A.PART_NO) > 0 "
		+ " THEN (SELECT CASE WHEN CNFM_DATE IS NULL THEN 'Y' ELSE ' ' END FROM HM.GLR17C WHERE POR_NO = A.PART_NO) "
		+ " ELSE ' ' END "
		+ " FROM DUAL) AS POR_CHNG_STUS_CODE "
		+ " FROM HM.GLP05M A "

		+ " where po_no = ? and po_lnno = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_lnno); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}