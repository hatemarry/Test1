package com.bes_line.mst.HMG;

// DBWrapper Class for GLP06H
/**
 *
 * @(#) GLP06HDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-27
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLP06HDBWrapBES extends DBWrapper{

public GLP06HDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String po_no, String po_lnno, String po_rev_no
* @return GLP06HRec 
* @author besTeam 
* @date 2006-6-27
*/
public GLP06HRec select(String po_no, String po_lnno, String po_rev_no) throws Exception{
    java.util.Vector glp06hV = new java.util.Vector();
    GLP06HRec glp06h = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_lnno, po_rev_no, po_line_stus_code, po_stus_chng_dt, part_no, part_proj_no, part_flag, part_mat_code, " +
                              "por_qty, ncv_arvl_qty, insp_qty, acpt_qty, rjct_qty, po_qty, po_uom, inv_unit_pr, por_no, " +
                              "prch_unit_pr, buyr_id, pnd, stor_id, po_line_rmrk, rgdt, lmd, mode_id, mnt_date, " +
                              "mnt_time, mnt_emp_no, dlvy_date_frst, dlvy_date_last, unit_wt, arvl_expt_date, po_amt " +
                       "  from HM.GLP06H  " +
                       "  where po_no = ? and po_lnno = ? and po_rev_no = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_lnno); 
        pstmt.setString(3,po_rev_no); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            glp06h = new GLP06HRec(); // GLP06HRec Constructor
                     glp06h.setPo_no(rs.getString("po_no"));
                     glp06h.setPo_lnno(rs.getString("po_lnno"));
                     glp06h.setPo_rev_no(rs.getString("po_rev_no"));
                     glp06h.setPo_line_stus_code(rs.getString("po_line_stus_code"));
                     glp06h.setPo_stus_chng_dt(rs.getString("po_stus_chng_dt"));
                     glp06h.setPart_no(rs.getString("part_no"));
                     glp06h.setPart_proj_no(rs.getString("part_proj_no"));
                     glp06h.setPart_flag(rs.getString("part_flag"));
                     glp06h.setPart_mat_code(rs.getString("part_mat_code"));
                     glp06h.setPor_qty(rs.getInt("por_qty"));
                     glp06h.setNcv_arvl_qty(rs.getInt("ncv_arvl_qty"));
                     glp06h.setInsp_qty(rs.getInt("insp_qty"));
                     glp06h.setAcpt_qty(rs.getInt("acpt_qty"));
                     glp06h.setRjct_qty(rs.getInt("rjct_qty"));
                     glp06h.setPo_qty(rs.getInt("po_qty"));
                     glp06h.setPo_uom(rs.getString("po_uom"));
                     glp06h.setInv_unit_pr(rs.getDouble("inv_unit_pr"));
                     glp06h.setPor_no(rs.getString("por_no"));
                     glp06h.setPrch_unit_pr(rs.getDouble("prch_unit_pr"));
                     glp06h.setBuyr_id(rs.getString("buyr_id"));
                     glp06h.setPnd(rs.getString("pnd"));
                     glp06h.setStor_id(rs.getString("stor_id"));
                     glp06h.setPo_line_rmrk(rs.getString("po_line_rmrk"));
                     glp06h.setRgdt(rs.getString("rgdt"));
                     glp06h.setLmd(rs.getString("lmd"));
                     glp06h.setMode_id(rs.getString("mode_id"));
                     glp06h.setMnt_date(rs.getString("mnt_date"));
                     glp06h.setMnt_time(rs.getString("mnt_time"));
                     glp06h.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     glp06h.setDlvy_date_frst(rs.getString("dlvy_date_frst"));
                     glp06h.setDlvy_date_last(rs.getString("dlvy_date_last"));
                     glp06h.setUnit_wt(rs.getDouble("unit_wt"));
                     glp06h.setArvl_expt_date(rs.getString("arvl_expt_date"));
                     glp06h.setPo_amt(rs.getDouble("po_amt"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp06h;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-27
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glp06hV = new java.util.Vector();
    GLP06HRec glp06h = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_lnno, po_rev_no, po_line_stus_code, po_stus_chng_dt, part_no, part_proj_no, part_flag, part_mat_code, " +
                              "por_qty, ncv_arvl_qty, insp_qty, acpt_qty, rjct_qty, po_qty, po_uom, inv_unit_pr, por_no, " +
                              "prch_unit_pr, buyr_id, pnd, stor_id, po_line_rmrk, rgdt, lmd, mode_id, mnt_date, " +
                              "mnt_time, mnt_emp_no, dlvy_date_frst, dlvy_date_last, unit_wt, arvl_expt_date, po_amt " +
                       "  from HM.GLP06H "+
                       "  order by po_no , po_lnno , po_rev_no ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp06h = new GLP06HRec(); // GLP06HRec Constructor
                     glp06h.setPo_no(rs.getString("po_no"));
                     glp06h.setPo_lnno(rs.getString("po_lnno"));
                     glp06h.setPo_rev_no(rs.getString("po_rev_no"));
                     glp06h.setPo_line_stus_code(rs.getString("po_line_stus_code"));
                     glp06h.setPo_stus_chng_dt(rs.getString("po_stus_chng_dt"));
                     glp06h.setPart_no(rs.getString("part_no"));
                     glp06h.setPart_proj_no(rs.getString("part_proj_no"));
                     glp06h.setPart_flag(rs.getString("part_flag"));
                     glp06h.setPart_mat_code(rs.getString("part_mat_code"));
                     glp06h.setPor_qty(rs.getInt("por_qty"));
                     glp06h.setNcv_arvl_qty(rs.getInt("ncv_arvl_qty"));
                     glp06h.setInsp_qty(rs.getInt("insp_qty"));
                     glp06h.setAcpt_qty(rs.getInt("acpt_qty"));
                     glp06h.setRjct_qty(rs.getInt("rjct_qty"));
                     glp06h.setPo_qty(rs.getInt("po_qty"));
                     glp06h.setPo_uom(rs.getString("po_uom"));
                     glp06h.setInv_unit_pr(rs.getDouble("inv_unit_pr"));
                     glp06h.setPor_no(rs.getString("por_no"));
                     glp06h.setPrch_unit_pr(rs.getDouble("prch_unit_pr"));
                     glp06h.setBuyr_id(rs.getString("buyr_id"));
                     glp06h.setPnd(rs.getString("pnd"));
                     glp06h.setStor_id(rs.getString("stor_id"));
                     glp06h.setPo_line_rmrk(rs.getString("po_line_rmrk"));
                     glp06h.setRgdt(rs.getString("rgdt"));
                     glp06h.setLmd(rs.getString("lmd"));
                     glp06h.setMode_id(rs.getString("mode_id"));
                     glp06h.setMnt_date(rs.getString("mnt_date"));
                     glp06h.setMnt_time(rs.getString("mnt_time"));
                     glp06h.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     glp06h.setDlvy_date_frst(rs.getString("dlvy_date_frst"));
                     glp06h.setDlvy_date_last(rs.getString("dlvy_date_last"));
                     glp06h.setUnit_wt(rs.getDouble("unit_wt"));
                     glp06h.setArvl_expt_date(rs.getString("arvl_expt_date"));
                     glp06h.setPo_amt(rs.getDouble("po_amt"));
            glp06hV.addElement(glp06h);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp06hV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-27
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glp06hV = new java.util.Vector();
    GLP06HRec glp06h = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_lnno, po_rev_no, po_line_stus_code, po_stus_chng_dt, part_no, part_proj_no, part_flag, part_mat_code, " +
                              "por_qty, ncv_arvl_qty, insp_qty, acpt_qty, rjct_qty, po_qty, po_uom, inv_unit_pr, por_no, " +
                              "prch_unit_pr, buyr_id, pnd, stor_id, po_line_rmrk, rgdt, lmd, mode_id, mnt_date, " +
                              "mnt_time, mnt_emp_no, dlvy_date_frst, dlvy_date_last, unit_wt, arvl_expt_date, po_amt " +
                       "  from HM.GLP06H  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  po_no,po_lnno " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp06h = new GLP06HRec(); // GLP06HRec Constructor
                     glp06h.setPo_no(rs.getString("po_no"));
                     glp06h.setPo_lnno(rs.getString("po_lnno"));
                     glp06h.setPo_rev_no(rs.getString("po_rev_no"));
                     glp06h.setPo_line_stus_code(rs.getString("po_line_stus_code"));
                     glp06h.setPo_stus_chng_dt(rs.getString("po_stus_chng_dt"));
                     glp06h.setPart_no(rs.getString("part_no"));
                     glp06h.setPart_proj_no(rs.getString("part_proj_no"));
                     glp06h.setPart_flag(rs.getString("part_flag"));
                     glp06h.setPart_mat_code(rs.getString("part_mat_code"));
                     glp06h.setPor_qty(rs.getInt("por_qty"));
                     glp06h.setNcv_arvl_qty(rs.getInt("ncv_arvl_qty"));
                     glp06h.setInsp_qty(rs.getInt("insp_qty"));
                     glp06h.setAcpt_qty(rs.getInt("acpt_qty"));
                     glp06h.setRjct_qty(rs.getInt("rjct_qty"));
                     glp06h.setPo_qty(rs.getInt("po_qty"));
                     glp06h.setPo_uom(rs.getString("po_uom"));
                     glp06h.setInv_unit_pr(rs.getDouble("inv_unit_pr"));
                     glp06h.setPor_no(rs.getString("por_no"));
                     glp06h.setPrch_unit_pr(rs.getDouble("prch_unit_pr"));
                     glp06h.setBuyr_id(rs.getString("buyr_id"));
                     glp06h.setPnd(rs.getString("pnd"));
                     glp06h.setStor_id(rs.getString("stor_id"));
                     glp06h.setPo_line_rmrk(rs.getString("po_line_rmrk"));
                     glp06h.setRgdt(rs.getString("rgdt"));
                     glp06h.setLmd(rs.getString("lmd"));
                     glp06h.setMode_id(rs.getString("mode_id"));
                     glp06h.setMnt_date(rs.getString("mnt_date"));
                     glp06h.setMnt_time(rs.getString("mnt_time"));
                     glp06h.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     glp06h.setDlvy_date_frst(rs.getString("dlvy_date_frst"));
                     glp06h.setDlvy_date_last(rs.getString("dlvy_date_last"));
                     glp06h.setUnit_wt(rs.getDouble("unit_wt"));
                     glp06h.setArvl_expt_date(rs.getString("arvl_expt_date"));
                     glp06h.setPo_amt(rs.getDouble("po_amt"));
            glp06hV.addElement(glp06h);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp06hV;
} // end selectAll

/**
* Get Rows Count 
* @param String po_no, String po_lnno, String po_rev_no
* @return int 
* @author besTeam 
* @date 2006-6-27
*/
public int count(String po_no, String po_lnno, String po_rev_no) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP06H " +
                       " where po_no = ? and po_lnno = ? and po_rev_no = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_lnno); 
        pstmt.setString(3,po_rev_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-27
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP06H  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLP06HRec 
* @return void 
* @author besTeam 
* @date 2006-6-27
*/
public void insert(GLP06HRec glp06h) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLP06H( " +
                              "po_no, po_lnno, po_rev_no, po_line_stus_code, po_stus_chng_dt, part_no, part_proj_no, part_flag, part_mat_code, " +
                              "por_qty, ncv_arvl_qty, insp_qty, acpt_qty, rjct_qty, po_qty, po_uom, inv_unit_pr, por_no, " +
                              "prch_unit_pr, buyr_id, pnd, stor_id, po_line_rmrk, rgdt, lmd, mode_id, mnt_date, " +
                              "mnt_time, mnt_emp_no, dlvy_date_frst, dlvy_date_last, unit_wt, arvl_expt_date, po_amt"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp06h.getPo_no());
        pstmt.setString(2, glp06h.getPo_lnno());
        pstmt.setString(3, glp06h.getPo_rev_no());
        pstmt.setString(4, glp06h.getPo_line_stus_code());
        pstmt.setString(5, glp06h.getPo_stus_chng_dt());
        pstmt.setString(6, glp06h.getPart_no());
        pstmt.setString(7, glp06h.getPart_proj_no());
        pstmt.setString(8, glp06h.getPart_flag());
        pstmt.setString(9, glp06h.getPart_mat_code());
        pstmt.setInt(10, glp06h.getPor_qty());
        pstmt.setInt(11, glp06h.getNcv_arvl_qty());
        pstmt.setInt(12, glp06h.getInsp_qty());
        pstmt.setInt(13, glp06h.getAcpt_qty());
        pstmt.setInt(14, glp06h.getRjct_qty());
        pstmt.setInt(15, glp06h.getPo_qty());
        pstmt.setString(16, glp06h.getPo_uom());
        pstmt.setDouble(17, glp06h.getInv_unit_pr());
        pstmt.setString(18, glp06h.getPor_no());
        pstmt.setDouble(19, glp06h.getPrch_unit_pr());
        pstmt.setString(20, glp06h.getBuyr_id());
        pstmt.setString(21, glp06h.getPnd());
        pstmt.setString(22, glp06h.getStor_id());
        pstmt.setString(23, glp06h.getPo_line_rmrk());
        pstmt.setString(24, glp06h.getRgdt());
        pstmt.setString(25, glp06h.getLmd());
        pstmt.setString(26, glp06h.getMode_id());
        pstmt.setString(27, glp06h.getMnt_date());
        pstmt.setString(28, glp06h.getMnt_time());
        pstmt.setString(29, glp06h.getMnt_emp_no());
        pstmt.setString(30, glp06h.getDlvy_date_frst());
        pstmt.setString(31, glp06h.getDlvy_date_last());
        pstmt.setDouble(32, glp06h.getUnit_wt());
        pstmt.setString(33, glp06h.getArvl_expt_date());
        pstmt.setDouble(34, glp06h.getPo_amt());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLP06HRec 
* @return void 
* @author besTeam 
* @date 2006-6-27
*/
public void update(GLP06HRec glp06h) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLP06H SET "+
                        "po_no = ?, po_lnno = ?, po_rev_no = ?, po_line_stus_code = ?, po_stus_chng_dt = ?, part_no = ?, part_proj_no = ?, part_flag = ?, part_mat_code = ?, por_qty = ?, " +
                              "ncv_arvl_qty = ?, insp_qty = ?, acpt_qty = ?, rjct_qty = ?, po_qty = ?, po_uom = ?, inv_unit_pr = ?, por_no = ?, prch_unit_pr = ?, " +
                              "buyr_id = ?, pnd = ?, stor_id = ?, po_line_rmrk = ?, rgdt = ?, lmd = ?, mode_id = ?, mnt_date = ?, mnt_time = ?, " +
                              "mnt_emp_no = ?, dlvy_date_frst = ?, dlvy_date_last = ?, unit_wt = ?, arvl_expt_date = ?, po_amt = ?"+
                        " where po_no = ? and po_lnno = ? and po_rev_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp06h.getPo_no());
        pstmt.setString(2, glp06h.getPo_lnno());
        pstmt.setString(3, glp06h.getPo_rev_no());
        pstmt.setString(4, glp06h.getPo_line_stus_code());
        pstmt.setString(5, glp06h.getPo_stus_chng_dt());
        pstmt.setString(6, glp06h.getPart_no());
        pstmt.setString(7, glp06h.getPart_proj_no());
        pstmt.setString(8, glp06h.getPart_flag());
        pstmt.setString(9, glp06h.getPart_mat_code());
        pstmt.setInt(10, glp06h.getPor_qty());
        pstmt.setInt(11, glp06h.getNcv_arvl_qty());
        pstmt.setInt(12, glp06h.getInsp_qty());
        pstmt.setInt(13, glp06h.getAcpt_qty());
        pstmt.setInt(14, glp06h.getRjct_qty());
        pstmt.setInt(15, glp06h.getPo_qty());
        pstmt.setString(16, glp06h.getPo_uom());
        pstmt.setDouble(17, glp06h.getInv_unit_pr());
        pstmt.setString(18, glp06h.getPor_no());
        pstmt.setDouble(19, glp06h.getPrch_unit_pr());
        pstmt.setString(20, glp06h.getBuyr_id());
        pstmt.setString(21, glp06h.getPnd());
        pstmt.setString(22, glp06h.getStor_id());
        pstmt.setString(23, glp06h.getPo_line_rmrk());
        pstmt.setString(24, glp06h.getRgdt());
        pstmt.setString(25, glp06h.getLmd());
        pstmt.setString(26, glp06h.getMode_id());
        pstmt.setString(27, glp06h.getMnt_date());
        pstmt.setString(28, glp06h.getMnt_time());
        pstmt.setString(29, glp06h.getMnt_emp_no());
        pstmt.setString(30, glp06h.getDlvy_date_frst());
        pstmt.setString(31, glp06h.getDlvy_date_last());
        pstmt.setDouble(32, glp06h.getUnit_wt());
        pstmt.setString(33, glp06h.getArvl_expt_date());
        pstmt.setDouble(34, glp06h.getPo_amt());
        // Key
        pstmt.setString(35, glp06h.getPo_no());
        pstmt.setString(36, glp06h.getPo_lnno());
        pstmt.setString(37, glp06h.getPo_rev_no());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String po_no, String po_lnno, String po_rev_no
* @return void 
* @author besTeam 
* @date 2006-6-27
*/
public void delete(String po_no, String po_lnno, String po_rev_no) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLP06H "+
                       "where po_no = ? and po_lnno = ? and po_rev_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_lnno); 
        pstmt.setString(3,po_rev_no); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLP06HRec 
* @return void 
* @author besTeam 
* @date 2006-6-27
*/
public void delete(GLP06HRec glp06h) throws Exception{
     delete(glp06h.getPo_no(), glp06h.getPo_lnno(), glp06h.getPo_rev_no());
} // end Delete

}// end GLP06HDBWrapBES class