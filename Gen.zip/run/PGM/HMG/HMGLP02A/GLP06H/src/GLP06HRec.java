package com.bes_line.mst.HMG ;

// Entity Class for GLP06H
/**
 *
 * @(#) GLP06HRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-27
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLP06HRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String po_no; 		// (VARCHAR2, 12.0)
    public String po_lnno; 		// (VARCHAR2, 3.0)
    public String po_rev_no; 		// (VARCHAR2, 2.0)
    public String po_line_stus_code; 		// (VARCHAR2, 1.0)
    public String po_stus_chng_dt; 		// (VARCHAR2, 8.0)
    public String part_no; 		// (VARCHAR2, 18.0)
    public String part_proj_no; 		// (VARCHAR2, 4.0)
    public String part_flag; 		// (VARCHAR2, 1.0)
    public String part_mat_code; 		// (VARCHAR2, 13.0)
    public int por_qty; 		// (NUMBER, 7.0)
    public int ncv_arvl_qty; 		// (NUMBER, 7.0)
    public int insp_qty; 		// (NUMBER, 7.0)
    public int acpt_qty; 		// (NUMBER, 7.0)
    public int rjct_qty; 		// (NUMBER, 7.0)
    public int po_qty; 		// (NUMBER, 7.0)
    public String po_uom; 		// (VARCHAR2, 2.0)
    public double inv_unit_pr; 		// (NUMBER, 13.2)
    public String por_no; 		// (VARCHAR2, 7.0)
    public double prch_unit_pr; 		// (NUMBER, 13.2)
    public String buyr_id; 		// (VARCHAR2, 4.0)
    public String pnd; 		// (VARCHAR2, 8.0)
    public String stor_id; 		// (VARCHAR2, 4.0)
    public String po_line_rmrk; 		// (VARCHAR2, 40.0)
    public String rgdt; 		// (VARCHAR2, 8.0)
    public String lmd; 		// (VARCHAR2, 8.0)
    public String mode_id; 		// (VARCHAR2, 1.0)
    public String mnt_date; 		// (VARCHAR2, 8.0)
    public String mnt_time; 		// (VARCHAR2, 6.0)
    public String mnt_emp_no; 		// (VARCHAR2, 7.0)
    public String dlvy_date_frst; 		// (VARCHAR2, 8.0)
    public String dlvy_date_last; 		// (VARCHAR2, 8.0)
    public double unit_wt; 		// (NUMBER, 10.3)
    public String arvl_expt_date; 		// (VARCHAR2, 8.0)
    public double po_amt; 		// (NUMBER, 13.2)

public GLP06HRec(){ } // default constructor

public GLP06HRec(
       String po_no, String po_lnno, String po_rev_no, String po_line_stus_code, String po_stus_chng_dt, String part_no, 
       String part_proj_no, String part_flag, String part_mat_code, int por_qty, int ncv_arvl_qty, int insp_qty, 
       int acpt_qty, int rjct_qty, int po_qty, String po_uom, double inv_unit_pr, String por_no, 
       double prch_unit_pr, String buyr_id, String pnd, String stor_id, String po_line_rmrk, String rgdt, 
       String lmd, String mode_id, String mnt_date, String mnt_time, String mnt_emp_no, String dlvy_date_frst, 
       String dlvy_date_last, double unit_wt, String arvl_expt_date, double po_amt){
    this.po_no = po_no;
    this.po_lnno = po_lnno;
    this.po_rev_no = po_rev_no;
    this.po_line_stus_code = po_line_stus_code;
    this.po_stus_chng_dt = po_stus_chng_dt;
    this.part_no = part_no;
    this.part_proj_no = part_proj_no;
    this.part_flag = part_flag;
    this.part_mat_code = part_mat_code;
    this.por_qty = por_qty;
    this.ncv_arvl_qty = ncv_arvl_qty;
    this.insp_qty = insp_qty;
    this.acpt_qty = acpt_qty;
    this.rjct_qty = rjct_qty;
    this.po_qty = po_qty;
    this.po_uom = po_uom;
    this.inv_unit_pr = inv_unit_pr;
    this.por_no = por_no;
    this.prch_unit_pr = prch_unit_pr;
    this.buyr_id = buyr_id;
    this.pnd = pnd;
    this.stor_id = stor_id;
    this.po_line_rmrk = po_line_rmrk;
    this.rgdt = rgdt;
    this.lmd = lmd;
    this.mode_id = mode_id;
    this.mnt_date = mnt_date;
    this.mnt_time = mnt_time;
    this.mnt_emp_no = mnt_emp_no;
    this.dlvy_date_frst = dlvy_date_frst;
    this.dlvy_date_last = dlvy_date_last;
    this.unit_wt = unit_wt;
    this.arvl_expt_date = arvl_expt_date;
    this.po_amt = po_amt;
} // Constructor


// Getter 
public String getPo_no(){ return po_no;}
public String getPo_lnno(){ return po_lnno;}
public String getPo_rev_no(){ return po_rev_no;}
public String getPo_line_stus_code(){ return po_line_stus_code;}
public String getPo_stus_chng_dt(){ return po_stus_chng_dt;}
public String getPart_no(){ return part_no;}
public String getPart_proj_no(){ return part_proj_no;}
public String getPart_flag(){ return part_flag;}
public String getPart_mat_code(){ return part_mat_code;}
public int getPor_qty(){ return por_qty;}
public int getNcv_arvl_qty(){ return ncv_arvl_qty;}
public int getInsp_qty(){ return insp_qty;}
public int getAcpt_qty(){ return acpt_qty;}
public int getRjct_qty(){ return rjct_qty;}
public int getPo_qty(){ return po_qty;}
public String getPo_uom(){ return po_uom;}
public double getInv_unit_pr(){ return inv_unit_pr;}
public String getPor_no(){ return por_no;}
public double getPrch_unit_pr(){ return prch_unit_pr;}
public String getBuyr_id(){ return buyr_id;}
public String getPnd(){ return pnd;}
public String getStor_id(){ return stor_id;}
public String getPo_line_rmrk(){ return po_line_rmrk;}
public String getRgdt(){ return rgdt;}
public String getLmd(){ return lmd;}
public String getMode_id(){ return mode_id;}
public String getMnt_date(){ return mnt_date;}
public String getMnt_time(){ return mnt_time;}
public String getMnt_emp_no(){ return mnt_emp_no;}
public String getDlvy_date_frst(){ return dlvy_date_frst;}
public String getDlvy_date_last(){ return dlvy_date_last;}
public double getUnit_wt(){ return unit_wt;}
public String getArvl_expt_date(){ return arvl_expt_date;}
public double getPo_amt(){ return po_amt;}

// Setter 
public void setPo_no(String po_no){ this.po_no = po_no;}
public void setPo_lnno(String po_lnno){ this.po_lnno = po_lnno;}
public void setPo_rev_no(String po_rev_no){ this.po_rev_no = po_rev_no;}
public void setPo_line_stus_code(String po_line_stus_code){ this.po_line_stus_code = po_line_stus_code;}
public void setPo_stus_chng_dt(String po_stus_chng_dt){ this.po_stus_chng_dt = po_stus_chng_dt;}
public void setPart_no(String part_no){ this.part_no = part_no;}
public void setPart_proj_no(String part_proj_no){ this.part_proj_no = part_proj_no;}
public void setPart_flag(String part_flag){ this.part_flag = part_flag;}
public void setPart_mat_code(String part_mat_code){ this.part_mat_code = part_mat_code;}
public void setPor_qty(int por_qty){ this.por_qty = por_qty;}
public void setNcv_arvl_qty(int ncv_arvl_qty){ this.ncv_arvl_qty = ncv_arvl_qty;}
public void setInsp_qty(int insp_qty){ this.insp_qty = insp_qty;}
public void setAcpt_qty(int acpt_qty){ this.acpt_qty = acpt_qty;}
public void setRjct_qty(int rjct_qty){ this.rjct_qty = rjct_qty;}
public void setPo_qty(int po_qty){ this.po_qty = po_qty;}
public void setPo_uom(String po_uom){ this.po_uom = po_uom;}
public void setInv_unit_pr(double inv_unit_pr){ this.inv_unit_pr = inv_unit_pr;}
public void setPor_no(String por_no){ this.por_no = por_no;}
public void setPrch_unit_pr(double prch_unit_pr){ this.prch_unit_pr = prch_unit_pr;}
public void setBuyr_id(String buyr_id){ this.buyr_id = buyr_id;}
public void setPnd(String pnd){ this.pnd = pnd;}
public void setStor_id(String stor_id){ this.stor_id = stor_id;}
public void setPo_line_rmrk(String po_line_rmrk){ this.po_line_rmrk = po_line_rmrk;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}
public void setLmd(String lmd){ this.lmd = lmd;}
public void setMode_id(String mode_id){ this.mode_id = mode_id;}
public void setMnt_date(String mnt_date){ this.mnt_date = mnt_date;}
public void setMnt_time(String mnt_time){ this.mnt_time = mnt_time;}
public void setMnt_emp_no(String mnt_emp_no){ this.mnt_emp_no = mnt_emp_no;}
public void setDlvy_date_frst(String dlvy_date_frst){ this.dlvy_date_frst = dlvy_date_frst;}
public void setDlvy_date_last(String dlvy_date_last){ this.dlvy_date_last = dlvy_date_last;}
public void setUnit_wt(double unit_wt){ this.unit_wt = unit_wt;}
public void setArvl_expt_date(String arvl_expt_date){ this.arvl_expt_date = arvl_expt_date;}
public void setPo_amt(double po_amt){ this.po_amt = po_amt;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = po_no + "" ; break;
  case  2 : field = po_lnno + "" ; break;
  case  3 : field = po_rev_no + "" ; break;
  case  4 : field = po_line_stus_code + "" ; break;
  case  5 : field = po_stus_chng_dt + "" ; break;
  case  6 : field = part_no + "" ; break;
  case  7 : field = part_proj_no + "" ; break;
  case  8 : field = part_flag + "" ; break;
  case  9 : field = part_mat_code + "" ; break;
  case  10 : field = por_qty + "" ; break;
  case  11 : field = ncv_arvl_qty + "" ; break;
  case  12 : field = insp_qty + "" ; break;
  case  13 : field = acpt_qty + "" ; break;
  case  14 : field = rjct_qty + "" ; break;
  case  15 : field = po_qty + "" ; break;
  case  16 : field = po_uom + "" ; break;
  case  17 : field = inv_unit_pr + "" ; break;
  case  18 : field = por_no + "" ; break;
  case  19 : field = prch_unit_pr + "" ; break;
  case  20 : field = buyr_id + "" ; break;
  case  21 : field = pnd + "" ; break;
  case  22 : field = stor_id + "" ; break;
  case  23 : field = po_line_rmrk + "" ; break;
  case  24 : field = rgdt + "" ; break;
  case  25 : field = lmd + "" ; break;
  case  26 : field = mode_id + "" ; break;
  case  27 : field = mnt_date + "" ; break;
  case  28 : field = mnt_time + "" ; break;
  case  29 : field = mnt_emp_no + "" ; break;
  case  30 : field = dlvy_date_frst + "" ; break;
  case  31 : field = dlvy_date_last + "" ; break;
  case  32 : field = unit_wt + "" ; break;
  case  33 : field = arvl_expt_date + "" ; break;
  case  34 : field = po_amt + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("po_no")){ field = po_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_lnno")){ field = po_lnno + "" ; 
     } else if(rec.equalsIgnoreCase("po_rev_no")){ field = po_rev_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_line_stus_code")){ field = po_line_stus_code + "" ; 
     } else if(rec.equalsIgnoreCase("po_stus_chng_dt")){ field = po_stus_chng_dt + "" ; 
     } else if(rec.equalsIgnoreCase("part_no")){ field = part_no + "" ; 
     } else if(rec.equalsIgnoreCase("part_proj_no")){ field = part_proj_no + "" ; 
     } else if(rec.equalsIgnoreCase("part_flag")){ field = part_flag + "" ; 
     } else if(rec.equalsIgnoreCase("part_mat_code")){ field = part_mat_code + "" ; 
     } else if(rec.equalsIgnoreCase("por_qty")){ field = por_qty + "" ; 
     } else if(rec.equalsIgnoreCase("ncv_arvl_qty")){ field = ncv_arvl_qty + "" ; 
     } else if(rec.equalsIgnoreCase("insp_qty")){ field = insp_qty + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_qty")){ field = acpt_qty + "" ; 
     } else if(rec.equalsIgnoreCase("rjct_qty")){ field = rjct_qty + "" ; 
     } else if(rec.equalsIgnoreCase("po_qty")){ field = po_qty + "" ; 
     } else if(rec.equalsIgnoreCase("po_uom")){ field = po_uom + "" ; 
     } else if(rec.equalsIgnoreCase("inv_unit_pr")){ field = inv_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("por_no")){ field = por_no + "" ; 
     } else if(rec.equalsIgnoreCase("prch_unit_pr")){ field = prch_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("buyr_id")){ field = buyr_id + "" ; 
     } else if(rec.equalsIgnoreCase("pnd")){ field = pnd + "" ; 
     } else if(rec.equalsIgnoreCase("stor_id")){ field = stor_id + "" ; 
     } else if(rec.equalsIgnoreCase("po_line_rmrk")){ field = po_line_rmrk + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("lmd")){ field = lmd + "" ; 
     } else if(rec.equalsIgnoreCase("mode_id")){ field = mode_id + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_date")){ field = mnt_date + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_time")){ field = mnt_time + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_emp_no")){ field = mnt_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("dlvy_date_frst")){ field = dlvy_date_frst + "" ; 
     } else if(rec.equalsIgnoreCase("dlvy_date_last")){ field = dlvy_date_last + "" ; 
     } else if(rec.equalsIgnoreCase("unit_wt")){ field = unit_wt + "" ; 
     } else if(rec.equalsIgnoreCase("arvl_expt_date")){ field = arvl_expt_date + "" ; 
     } else if(rec.equalsIgnoreCase("po_amt")){ field = po_amt + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "PO_NO", "PO_LNNO", "PO_REV_NO", "PO_LINE_STUS_CODE", "PO_STUS_CHNG_DT", "PART_NO", "PART_PROJ_NO", 
       "PART_FLAG", "PART_MAT_CODE", "POR_QTY", "NCV_ARVL_QTY", "INSP_QTY", "ACPT_QTY", "RJCT_QTY", 
       "PO_QTY", "PO_UOM", "INV_UNIT_PR", "POR_NO", "PRCH_UNIT_PR", "BUYR_ID", "PND", 
       "STOR_ID", "PO_LINE_RMRK", "RGDT", "LMD", "MODE_ID", "MNT_DATE", "MNT_TIME", 
       "MNT_EMP_NO", "DLVY_DATE_FRST", "DLVY_DATE_LAST", "UNIT_WT", "ARVL_EXPT_DATE", "PO_AMT"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "PO_NO", "PO_LNNO", "PO_REV_NO"};
    return tempx;
}

}// end GLP06HRec class