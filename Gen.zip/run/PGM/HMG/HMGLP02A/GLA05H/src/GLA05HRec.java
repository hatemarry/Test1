package com.bes_line.mst.HMG ;

// Entity Class for GLA05H
/**
 *
 * @(#) GLA05HRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-27
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLA05HRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String acpt_id; 		// (VARCHAR2, 11.0)
    public String acpt_rev_no; 		// (VARCHAR2, 2.0)
    public String acpt_stus_code; 		// (VARCHAR2, 1.0)
    public String proj_no; 		// (VARCHAR2, 4.0)
    public String po_type; 		// (VARCHAR2, 1.0)
    public String curr_code; 		// (VARCHAR2, 2.0)
    public String lc_no; 		// (VARCHAR2, 15.0)
    public String bl_no; 		// (VARCHAR2, 20.0)
    public String invc_no; 		// (VARCHAR2, 20.0)
    public String po_no; 		// (VARCHAR2, 12.0)
    public String stor_id; 		// (VARCHAR2, 4.0)
    public String vndr_grp_code; 		// (VARCHAR2, 4.0)
    public String vhcl_no; 		// (VARCHAR2, 20.0)
    public int acpt_tot_item; 		// (NUMBER, 3.0)
    public double tot_wt; 		// (NUMBER, 13.3)
    public double acpt_tot_amt; 		// (NUMBER, 13.2)
    public double rgsr_tot_amt; 		// (NUMBER, 13.2)
    public double acpt_tamt_yuan; 		// (NUMBER, 13.2)
    public double raw_mat_amt; 		// (NUMBER, 13.2)
    public double stck_mat_amt; 		// (NUMBER, 13.2)
    public double cons_mat_amt; 		// (NUMBER, 13.2)
    public double acpt_exch_rate; 		// (NUMBER, 9.4)
    public String arvl_date; 		// (VARCHAR2, 8.0)
    public String insp_date; 		// (VARCHAR2, 8.0)
    public String acpt_date; 		// (VARCHAR2, 8.0)
    public String rgdt; 		// (VARCHAR2, 8.0)
    public String lmd; 		// (VARCHAR2, 8.0)
    public String last_fnl_date; 		// (VARCHAR2, 8.0)
    public String acct_id; 		// (VARCHAR2, 4.0)
    public int acpt_yymm_ser; 		// (NUMBER, 1.0)
    public String mode_id; 		// (VARCHAR2, 1.0)
    public String mnt_date; 		// (VARCHAR2, 8.0)
    public String mnt_time; 		// (VARCHAR2, 6.0)
    public String mnt_emp_no; 		// (VARCHAR2, 7.0)
    public String curr_aply_date; 		// (VARCHAR2, 8.0)

public GLA05HRec(){ } // default constructor

public GLA05HRec(
       String acpt_id, String acpt_rev_no, String acpt_stus_code, String proj_no, String po_type, String curr_code, 
       String lc_no, String bl_no, String invc_no, String po_no, String stor_id, String vndr_grp_code, 
       String vhcl_no, int acpt_tot_item, double tot_wt, double acpt_tot_amt, double rgsr_tot_amt, double acpt_tamt_yuan, 
       double raw_mat_amt, double stck_mat_amt, double cons_mat_amt, double acpt_exch_rate, String arvl_date, String insp_date, 
       String acpt_date, String rgdt, String lmd, String last_fnl_date, String acct_id, int acpt_yymm_ser, 
       String mode_id, String mnt_date, String mnt_time, String mnt_emp_no, String curr_aply_date){
    this.acpt_id = acpt_id;
    this.acpt_rev_no = acpt_rev_no;
    this.acpt_stus_code = acpt_stus_code;
    this.proj_no = proj_no;
    this.po_type = po_type;
    this.curr_code = curr_code;
    this.lc_no = lc_no;
    this.bl_no = bl_no;
    this.invc_no = invc_no;
    this.po_no = po_no;
    this.stor_id = stor_id;
    this.vndr_grp_code = vndr_grp_code;
    this.vhcl_no = vhcl_no;
    this.acpt_tot_item = acpt_tot_item;
    this.tot_wt = tot_wt;
    this.acpt_tot_amt = acpt_tot_amt;
    this.rgsr_tot_amt = rgsr_tot_amt;
    this.acpt_tamt_yuan = acpt_tamt_yuan;
    this.raw_mat_amt = raw_mat_amt;
    this.stck_mat_amt = stck_mat_amt;
    this.cons_mat_amt = cons_mat_amt;
    this.acpt_exch_rate = acpt_exch_rate;
    this.arvl_date = arvl_date;
    this.insp_date = insp_date;
    this.acpt_date = acpt_date;
    this.rgdt = rgdt;
    this.lmd = lmd;
    this.last_fnl_date = last_fnl_date;
    this.acct_id = acct_id;
    this.acpt_yymm_ser = acpt_yymm_ser;
    this.mode_id = mode_id;
    this.mnt_date = mnt_date;
    this.mnt_time = mnt_time;
    this.mnt_emp_no = mnt_emp_no;
    this.curr_aply_date = curr_aply_date;
} // Constructor


// Getter 
public String getAcpt_id(){ return acpt_id;}
public String getAcpt_rev_no(){ return acpt_rev_no;}
public String getAcpt_stus_code(){ return acpt_stus_code;}
public String getProj_no(){ return proj_no;}
public String getPo_type(){ return po_type;}
public String getCurr_code(){ return curr_code;}
public String getLc_no(){ return lc_no;}
public String getBl_no(){ return bl_no;}
public String getInvc_no(){ return invc_no;}
public String getPo_no(){ return po_no;}
public String getStor_id(){ return stor_id;}
public String getVndr_grp_code(){ return vndr_grp_code;}
public String getVhcl_no(){ return vhcl_no;}
public int getAcpt_tot_item(){ return acpt_tot_item;}
public double getTot_wt(){ return tot_wt;}
public double getAcpt_tot_amt(){ return acpt_tot_amt;}
public double getRgsr_tot_amt(){ return rgsr_tot_amt;}
public double getAcpt_tamt_yuan(){ return acpt_tamt_yuan;}
public double getRaw_mat_amt(){ return raw_mat_amt;}
public double getStck_mat_amt(){ return stck_mat_amt;}
public double getCons_mat_amt(){ return cons_mat_amt;}
public double getAcpt_exch_rate(){ return acpt_exch_rate;}
public String getArvl_date(){ return arvl_date;}
public String getInsp_date(){ return insp_date;}
public String getAcpt_date(){ return acpt_date;}
public String getRgdt(){ return rgdt;}
public String getLmd(){ return lmd;}
public String getLast_fnl_date(){ return last_fnl_date;}
public String getAcct_id(){ return acct_id;}
public int getAcpt_yymm_ser(){ return acpt_yymm_ser;}
public String getMode_id(){ return mode_id;}
public String getMnt_date(){ return mnt_date;}
public String getMnt_time(){ return mnt_time;}
public String getMnt_emp_no(){ return mnt_emp_no;}
public String getCurr_aply_date(){ return curr_aply_date;}

// Setter 
public void setAcpt_id(String acpt_id){ this.acpt_id = acpt_id;}
public void setAcpt_rev_no(String acpt_rev_no){ this.acpt_rev_no = acpt_rev_no;}
public void setAcpt_stus_code(String acpt_stus_code){ this.acpt_stus_code = acpt_stus_code;}
public void setProj_no(String proj_no){ this.proj_no = proj_no;}
public void setPo_type(String po_type){ this.po_type = po_type;}
public void setCurr_code(String curr_code){ this.curr_code = curr_code;}
public void setLc_no(String lc_no){ this.lc_no = lc_no;}
public void setBl_no(String bl_no){ this.bl_no = bl_no;}
public void setInvc_no(String invc_no){ this.invc_no = invc_no;}
public void setPo_no(String po_no){ this.po_no = po_no;}
public void setStor_id(String stor_id){ this.stor_id = stor_id;}
public void setVndr_grp_code(String vndr_grp_code){ this.vndr_grp_code = vndr_grp_code;}
public void setVhcl_no(String vhcl_no){ this.vhcl_no = vhcl_no;}
public void setAcpt_tot_item(int acpt_tot_item){ this.acpt_tot_item = acpt_tot_item;}
public void setTot_wt(double tot_wt){ this.tot_wt = tot_wt;}
public void setAcpt_tot_amt(double acpt_tot_amt){ this.acpt_tot_amt = acpt_tot_amt;}
public void setRgsr_tot_amt(double rgsr_tot_amt){ this.rgsr_tot_amt = rgsr_tot_amt;}
public void setAcpt_tamt_yuan(double acpt_tamt_yuan){ this.acpt_tamt_yuan = acpt_tamt_yuan;}
public void setRaw_mat_amt(double raw_mat_amt){ this.raw_mat_amt = raw_mat_amt;}
public void setStck_mat_amt(double stck_mat_amt){ this.stck_mat_amt = stck_mat_amt;}
public void setCons_mat_amt(double cons_mat_amt){ this.cons_mat_amt = cons_mat_amt;}
public void setAcpt_exch_rate(double acpt_exch_rate){ this.acpt_exch_rate = acpt_exch_rate;}
public void setArvl_date(String arvl_date){ this.arvl_date = arvl_date;}
public void setInsp_date(String insp_date){ this.insp_date = insp_date;}
public void setAcpt_date(String acpt_date){ this.acpt_date = acpt_date;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}
public void setLmd(String lmd){ this.lmd = lmd;}
public void setLast_fnl_date(String last_fnl_date){ this.last_fnl_date = last_fnl_date;}
public void setAcct_id(String acct_id){ this.acct_id = acct_id;}
public void setAcpt_yymm_ser(int acpt_yymm_ser){ this.acpt_yymm_ser = acpt_yymm_ser;}
public void setMode_id(String mode_id){ this.mode_id = mode_id;}
public void setMnt_date(String mnt_date){ this.mnt_date = mnt_date;}
public void setMnt_time(String mnt_time){ this.mnt_time = mnt_time;}
public void setMnt_emp_no(String mnt_emp_no){ this.mnt_emp_no = mnt_emp_no;}
public void setCurr_aply_date(String curr_aply_date){ this.curr_aply_date = curr_aply_date;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = acpt_id + "" ; break;
  case  2 : field = acpt_rev_no + "" ; break;
  case  3 : field = acpt_stus_code + "" ; break;
  case  4 : field = proj_no + "" ; break;
  case  5 : field = po_type + "" ; break;
  case  6 : field = curr_code + "" ; break;
  case  7 : field = lc_no + "" ; break;
  case  8 : field = bl_no + "" ; break;
  case  9 : field = invc_no + "" ; break;
  case  10 : field = po_no + "" ; break;
  case  11 : field = stor_id + "" ; break;
  case  12 : field = vndr_grp_code + "" ; break;
  case  13 : field = vhcl_no + "" ; break;
  case  14 : field = acpt_tot_item + "" ; break;
  case  15 : field = tot_wt + "" ; break;
  case  16 : field = acpt_tot_amt + "" ; break;
  case  17 : field = rgsr_tot_amt + "" ; break;
  case  18 : field = acpt_tamt_yuan + "" ; break;
  case  19 : field = raw_mat_amt + "" ; break;
  case  20 : field = stck_mat_amt + "" ; break;
  case  21 : field = cons_mat_amt + "" ; break;
  case  22 : field = acpt_exch_rate + "" ; break;
  case  23 : field = arvl_date + "" ; break;
  case  24 : field = insp_date + "" ; break;
  case  25 : field = acpt_date + "" ; break;
  case  26 : field = rgdt + "" ; break;
  case  27 : field = lmd + "" ; break;
  case  28 : field = last_fnl_date + "" ; break;
  case  29 : field = acct_id + "" ; break;
  case  30 : field = acpt_yymm_ser + "" ; break;
  case  31 : field = mode_id + "" ; break;
  case  32 : field = mnt_date + "" ; break;
  case  33 : field = mnt_time + "" ; break;
  case  34 : field = mnt_emp_no + "" ; break;
  case  35 : field = curr_aply_date + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("acpt_id")){ field = acpt_id + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_rev_no")){ field = acpt_rev_no + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_stus_code")){ field = acpt_stus_code + "" ; 
     } else if(rec.equalsIgnoreCase("proj_no")){ field = proj_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_type")){ field = po_type + "" ; 
     } else if(rec.equalsIgnoreCase("curr_code")){ field = curr_code + "" ; 
     } else if(rec.equalsIgnoreCase("lc_no")){ field = lc_no + "" ; 
     } else if(rec.equalsIgnoreCase("bl_no")){ field = bl_no + "" ; 
     } else if(rec.equalsIgnoreCase("invc_no")){ field = invc_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_no")){ field = po_no + "" ; 
     } else if(rec.equalsIgnoreCase("stor_id")){ field = stor_id + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_grp_code")){ field = vndr_grp_code + "" ; 
     } else if(rec.equalsIgnoreCase("vhcl_no")){ field = vhcl_no + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_tot_item")){ field = acpt_tot_item + "" ; 
     } else if(rec.equalsIgnoreCase("tot_wt")){ field = tot_wt + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_tot_amt")){ field = acpt_tot_amt + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_tot_amt")){ field = rgsr_tot_amt + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_tamt_yuan")){ field = acpt_tamt_yuan + "" ; 
     } else if(rec.equalsIgnoreCase("raw_mat_amt")){ field = raw_mat_amt + "" ; 
     } else if(rec.equalsIgnoreCase("stck_mat_amt")){ field = stck_mat_amt + "" ; 
     } else if(rec.equalsIgnoreCase("cons_mat_amt")){ field = cons_mat_amt + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_exch_rate")){ field = acpt_exch_rate + "" ; 
     } else if(rec.equalsIgnoreCase("arvl_date")){ field = arvl_date + "" ; 
     } else if(rec.equalsIgnoreCase("insp_date")){ field = insp_date + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_date")){ field = acpt_date + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("lmd")){ field = lmd + "" ; 
     } else if(rec.equalsIgnoreCase("last_fnl_date")){ field = last_fnl_date + "" ; 
     } else if(rec.equalsIgnoreCase("acct_id")){ field = acct_id + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_yymm_ser")){ field = acpt_yymm_ser + "" ; 
     } else if(rec.equalsIgnoreCase("mode_id")){ field = mode_id + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_date")){ field = mnt_date + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_time")){ field = mnt_time + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_emp_no")){ field = mnt_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("curr_aply_date")){ field = curr_aply_date + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "ACPT_ID", "ACPT_REV_NO", "ACPT_STUS_CODE", "PROJ_NO", "PO_TYPE", "CURR_CODE", "LC_NO", 
       "BL_NO", "INVC_NO", "PO_NO", "STOR_ID", "VNDR_GRP_CODE", "VHCL_NO", "ACPT_TOT_ITEM", 
       "TOT_WT", "ACPT_TOT_AMT", "RGSR_TOT_AMT", "ACPT_TAMT_YUAN", "RAW_MAT_AMT", "STCK_MAT_AMT", "CONS_MAT_AMT", 
       "ACPT_EXCH_RATE", "ARVL_DATE", "INSP_DATE", "ACPT_DATE", "RGDT", "LMD", "LAST_FNL_DATE", 
       "ACCT_ID", "ACPT_YYMM_SER", "MODE_ID", "MNT_DATE", "MNT_TIME", "MNT_EMP_NO", "CURR_APLY_DATE"
       };
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "ACPT_ID", "ACPT_REV_NO"};
    return tempx;
}

}// end GLA05HRec class