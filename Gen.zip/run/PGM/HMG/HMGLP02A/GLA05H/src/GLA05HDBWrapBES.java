package com.bes_line.mst.HMG;

// DBWrapper Class for GLA05H
/**
 *
 * @(#) GLA05HDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-27
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLA05HDBWrapBES extends DBWrapper{

public GLA05HDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String acpt_id, String acpt_rev_no
* @return GLA05HRec 
* @author besTeam 
* @date 2006-6-27
*/
public GLA05HRec select(String acpt_id, String acpt_rev_no) throws Exception{
    java.util.Vector gla05hV = new java.util.Vector();
    GLA05HRec gla05h = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select acpt_id, acpt_rev_no, acpt_stus_code, proj_no, po_type, curr_code, lc_no, bl_no, invc_no, " +
                              "po_no, stor_id, vndr_grp_code, vhcl_no, acpt_tot_item, tot_wt, acpt_tot_amt, rgsr_tot_amt, acpt_tamt_yuan, " +
                              "raw_mat_amt, stck_mat_amt, cons_mat_amt, acpt_exch_rate, arvl_date, insp_date, acpt_date, rgdt, lmd, " +
                              "last_fnl_date, acct_id, acpt_yymm_ser, mode_id, mnt_date, mnt_time, mnt_emp_no, curr_aply_date " +
                       "  from HM.GLA05H  " +
                       "  where acpt_id = ? and acpt_rev_no = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,acpt_id); 
        pstmt.setString(2,acpt_rev_no); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            gla05h = new GLA05HRec(); // GLA05HRec Constructor
                     gla05h.setAcpt_id(rs.getString("acpt_id"));
                     gla05h.setAcpt_rev_no(rs.getString("acpt_rev_no"));
                     gla05h.setAcpt_stus_code(rs.getString("acpt_stus_code"));
                     gla05h.setProj_no(rs.getString("proj_no"));
                     gla05h.setPo_type(rs.getString("po_type"));
                     gla05h.setCurr_code(rs.getString("curr_code"));
                     gla05h.setLc_no(rs.getString("lc_no"));
                     gla05h.setBl_no(rs.getString("bl_no"));
                     gla05h.setInvc_no(rs.getString("invc_no"));
                     gla05h.setPo_no(rs.getString("po_no"));
                     gla05h.setStor_id(rs.getString("stor_id"));
                     gla05h.setVndr_grp_code(rs.getString("vndr_grp_code"));
                     gla05h.setVhcl_no(rs.getString("vhcl_no"));
                     gla05h.setAcpt_tot_item(rs.getInt("acpt_tot_item"));
                     gla05h.setTot_wt(rs.getDouble("tot_wt"));
                     gla05h.setAcpt_tot_amt(rs.getDouble("acpt_tot_amt"));
                     gla05h.setRgsr_tot_amt(rs.getDouble("rgsr_tot_amt"));
                     gla05h.setAcpt_tamt_yuan(rs.getDouble("acpt_tamt_yuan"));
                     gla05h.setRaw_mat_amt(rs.getDouble("raw_mat_amt"));
                     gla05h.setStck_mat_amt(rs.getDouble("stck_mat_amt"));
                     gla05h.setCons_mat_amt(rs.getDouble("cons_mat_amt"));
                     gla05h.setAcpt_exch_rate(rs.getDouble("acpt_exch_rate"));
                     gla05h.setArvl_date(rs.getString("arvl_date"));
                     gla05h.setInsp_date(rs.getString("insp_date"));
                     gla05h.setAcpt_date(rs.getString("acpt_date"));
                     gla05h.setRgdt(rs.getString("rgdt"));
                     gla05h.setLmd(rs.getString("lmd"));
                     gla05h.setLast_fnl_date(rs.getString("last_fnl_date"));
                     gla05h.setAcct_id(rs.getString("acct_id"));
                     gla05h.setAcpt_yymm_ser(rs.getInt("acpt_yymm_ser"));
                     gla05h.setMode_id(rs.getString("mode_id"));
                     gla05h.setMnt_date(rs.getString("mnt_date"));
                     gla05h.setMnt_time(rs.getString("mnt_time"));
                     gla05h.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     gla05h.setCurr_aply_date(rs.getString("curr_aply_date"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gla05h;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-27
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector gla05hV = new java.util.Vector();
    GLA05HRec gla05h = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select acpt_id, acpt_rev_no, acpt_stus_code, proj_no, po_type, curr_code, lc_no, bl_no, invc_no, " +
                              "po_no, stor_id, vndr_grp_code, vhcl_no, acpt_tot_item, tot_wt, acpt_tot_amt, rgsr_tot_amt, acpt_tamt_yuan, " +
                              "raw_mat_amt, stck_mat_amt, cons_mat_amt, acpt_exch_rate, arvl_date, insp_date, acpt_date, rgdt, lmd, " +
                              "last_fnl_date, acct_id, acpt_yymm_ser, mode_id, mnt_date, mnt_time, mnt_emp_no, curr_aply_date " +
                       "  from HM.GLA05H "+
                       "  order by acpt_id , acpt_rev_no ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            gla05h = new GLA05HRec(); // GLA05HRec Constructor
                     gla05h.setAcpt_id(rs.getString("acpt_id"));
                     gla05h.setAcpt_rev_no(rs.getString("acpt_rev_no"));
                     gla05h.setAcpt_stus_code(rs.getString("acpt_stus_code"));
                     gla05h.setProj_no(rs.getString("proj_no"));
                     gla05h.setPo_type(rs.getString("po_type"));
                     gla05h.setCurr_code(rs.getString("curr_code"));
                     gla05h.setLc_no(rs.getString("lc_no"));
                     gla05h.setBl_no(rs.getString("bl_no"));
                     gla05h.setInvc_no(rs.getString("invc_no"));
                     gla05h.setPo_no(rs.getString("po_no"));
                     gla05h.setStor_id(rs.getString("stor_id"));
                     gla05h.setVndr_grp_code(rs.getString("vndr_grp_code"));
                     gla05h.setVhcl_no(rs.getString("vhcl_no"));
                     gla05h.setAcpt_tot_item(rs.getInt("acpt_tot_item"));
                     gla05h.setTot_wt(rs.getDouble("tot_wt"));
                     gla05h.setAcpt_tot_amt(rs.getDouble("acpt_tot_amt"));
                     gla05h.setRgsr_tot_amt(rs.getDouble("rgsr_tot_amt"));
                     gla05h.setAcpt_tamt_yuan(rs.getDouble("acpt_tamt_yuan"));
                     gla05h.setRaw_mat_amt(rs.getDouble("raw_mat_amt"));
                     gla05h.setStck_mat_amt(rs.getDouble("stck_mat_amt"));
                     gla05h.setCons_mat_amt(rs.getDouble("cons_mat_amt"));
                     gla05h.setAcpt_exch_rate(rs.getDouble("acpt_exch_rate"));
                     gla05h.setArvl_date(rs.getString("arvl_date"));
                     gla05h.setInsp_date(rs.getString("insp_date"));
                     gla05h.setAcpt_date(rs.getString("acpt_date"));
                     gla05h.setRgdt(rs.getString("rgdt"));
                     gla05h.setLmd(rs.getString("lmd"));
                     gla05h.setLast_fnl_date(rs.getString("last_fnl_date"));
                     gla05h.setAcct_id(rs.getString("acct_id"));
                     gla05h.setAcpt_yymm_ser(rs.getInt("acpt_yymm_ser"));
                     gla05h.setMode_id(rs.getString("mode_id"));
                     gla05h.setMnt_date(rs.getString("mnt_date"));
                     gla05h.setMnt_time(rs.getString("mnt_time"));
                     gla05h.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     gla05h.setCurr_aply_date(rs.getString("curr_aply_date"));
            gla05hV.addElement(gla05h);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gla05hV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-27
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector gla05hV = new java.util.Vector();
    GLA05HRec gla05h = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select acpt_id, acpt_rev_no, acpt_stus_code, proj_no, po_type, curr_code, lc_no, bl_no, invc_no, " +
                              "po_no, stor_id, vndr_grp_code, vhcl_no, acpt_tot_item, tot_wt, acpt_tot_amt, rgsr_tot_amt, acpt_tamt_yuan, " +
                              "raw_mat_amt, stck_mat_amt, cons_mat_amt, acpt_exch_rate, arvl_date, insp_date, acpt_date, rgdt, lmd, " +
                              "last_fnl_date, acct_id, acpt_yymm_ser, mode_id, mnt_date, mnt_time, mnt_emp_no, curr_aply_date " +
                       "  from HM.GLA05H  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  acpt_id " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            gla05h = new GLA05HRec(); // GLA05HRec Constructor
                     gla05h.setAcpt_id(rs.getString("acpt_id"));
                     gla05h.setAcpt_rev_no(rs.getString("acpt_rev_no"));
                     gla05h.setAcpt_stus_code(rs.getString("acpt_stus_code"));
                     gla05h.setProj_no(rs.getString("proj_no"));
                     gla05h.setPo_type(rs.getString("po_type"));
                     gla05h.setCurr_code(rs.getString("curr_code"));
                     gla05h.setLc_no(rs.getString("lc_no"));
                     gla05h.setBl_no(rs.getString("bl_no"));
                     gla05h.setInvc_no(rs.getString("invc_no"));
                     gla05h.setPo_no(rs.getString("po_no"));
                     gla05h.setStor_id(rs.getString("stor_id"));
                     gla05h.setVndr_grp_code(rs.getString("vndr_grp_code"));
                     gla05h.setVhcl_no(rs.getString("vhcl_no"));
                     gla05h.setAcpt_tot_item(rs.getInt("acpt_tot_item"));
                     gla05h.setTot_wt(rs.getDouble("tot_wt"));
                     gla05h.setAcpt_tot_amt(rs.getDouble("acpt_tot_amt"));
                     gla05h.setRgsr_tot_amt(rs.getDouble("rgsr_tot_amt"));
                     gla05h.setAcpt_tamt_yuan(rs.getDouble("acpt_tamt_yuan"));
                     gla05h.setRaw_mat_amt(rs.getDouble("raw_mat_amt"));
                     gla05h.setStck_mat_amt(rs.getDouble("stck_mat_amt"));
                     gla05h.setCons_mat_amt(rs.getDouble("cons_mat_amt"));
                     gla05h.setAcpt_exch_rate(rs.getDouble("acpt_exch_rate"));
                     gla05h.setArvl_date(rs.getString("arvl_date"));
                     gla05h.setInsp_date(rs.getString("insp_date"));
                     gla05h.setAcpt_date(rs.getString("acpt_date"));
                     gla05h.setRgdt(rs.getString("rgdt"));
                     gla05h.setLmd(rs.getString("lmd"));
                     gla05h.setLast_fnl_date(rs.getString("last_fnl_date"));
                     gla05h.setAcct_id(rs.getString("acct_id"));
                     gla05h.setAcpt_yymm_ser(rs.getInt("acpt_yymm_ser"));
                     gla05h.setMode_id(rs.getString("mode_id"));
                     gla05h.setMnt_date(rs.getString("mnt_date"));
                     gla05h.setMnt_time(rs.getString("mnt_time"));
                     gla05h.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     gla05h.setCurr_aply_date(rs.getString("curr_aply_date"));
            gla05hV.addElement(gla05h);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gla05hV;
} // end selectAll

/**
* Get Rows Count 
* @param String acpt_id, String acpt_rev_no
* @return int 
* @author besTeam 
* @date 2006-6-27
*/
public int count(String acpt_id, String acpt_rev_no) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLA05H " +
                       " where acpt_id = ? and acpt_rev_no = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,acpt_id); 
        pstmt.setString(2,acpt_rev_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-27
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLA05H  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLA05HRec 
* @return void 
* @author besTeam 
* @date 2006-6-27
*/
public void insert(GLA05HRec gla05h) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLA05H( " +
                              "acpt_id, acpt_rev_no, acpt_stus_code, proj_no, po_type, curr_code, lc_no, bl_no, invc_no, " +
                              "po_no, stor_id, vndr_grp_code, vhcl_no, acpt_tot_item, tot_wt, acpt_tot_amt, rgsr_tot_amt, acpt_tamt_yuan, " +
                              "raw_mat_amt, stck_mat_amt, cons_mat_amt, acpt_exch_rate, arvl_date, insp_date, acpt_date, rgdt, lmd, " +
                              "last_fnl_date, acct_id, acpt_yymm_ser, mode_id, mnt_date, mnt_time, mnt_emp_no, curr_aply_date"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, gla05h.getAcpt_id());
        pstmt.setString(2, gla05h.getAcpt_rev_no());
        pstmt.setString(3, gla05h.getAcpt_stus_code());
        pstmt.setString(4, gla05h.getProj_no());
        pstmt.setString(5, gla05h.getPo_type());
        pstmt.setString(6, gla05h.getCurr_code());
        pstmt.setString(7, gla05h.getLc_no());
        pstmt.setString(8, gla05h.getBl_no());
        pstmt.setString(9, gla05h.getInvc_no());
        pstmt.setString(10, gla05h.getPo_no());
        pstmt.setString(11, gla05h.getStor_id());
        pstmt.setString(12, gla05h.getVndr_grp_code());
        pstmt.setString(13, gla05h.getVhcl_no());
        pstmt.setInt(14, gla05h.getAcpt_tot_item());
        pstmt.setDouble(15, gla05h.getTot_wt());
        pstmt.setDouble(16, gla05h.getAcpt_tot_amt());
        pstmt.setDouble(17, gla05h.getRgsr_tot_amt());
        pstmt.setDouble(18, gla05h.getAcpt_tamt_yuan());
        pstmt.setDouble(19, gla05h.getRaw_mat_amt());
        pstmt.setDouble(20, gla05h.getStck_mat_amt());
        pstmt.setDouble(21, gla05h.getCons_mat_amt());
        pstmt.setDouble(22, gla05h.getAcpt_exch_rate());
        pstmt.setString(23, gla05h.getArvl_date());
        pstmt.setString(24, gla05h.getInsp_date());
        pstmt.setString(25, gla05h.getAcpt_date());
        pstmt.setString(26, gla05h.getRgdt());
        pstmt.setString(27, gla05h.getLmd());
        pstmt.setString(28, gla05h.getLast_fnl_date());
        pstmt.setString(29, gla05h.getAcct_id());
        pstmt.setInt(30, gla05h.getAcpt_yymm_ser());
        pstmt.setString(31, gla05h.getMode_id());
        pstmt.setString(32, gla05h.getMnt_date());
        pstmt.setString(33, gla05h.getMnt_time());
        pstmt.setString(34, gla05h.getMnt_emp_no());
        pstmt.setString(35, gla05h.getCurr_aply_date());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLA05HRec 
* @return void 
* @author besTeam 
* @date 2006-6-27
*/
public void update(GLA05HRec gla05h) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLA05H SET "+
                        "acpt_id = ?, acpt_rev_no = ?, acpt_stus_code = ?, proj_no = ?, po_type = ?, curr_code = ?, lc_no = ?, bl_no = ?, invc_no = ?, po_no = ?, " +
                              "stor_id = ?, vndr_grp_code = ?, vhcl_no = ?, acpt_tot_item = ?, tot_wt = ?, acpt_tot_amt = ?, rgsr_tot_amt = ?, acpt_tamt_yuan = ?, raw_mat_amt = ?, " +
                              "stck_mat_amt = ?, cons_mat_amt = ?, acpt_exch_rate = ?, arvl_date = ?, insp_date = ?, acpt_date = ?, rgdt = ?, lmd = ?, last_fnl_date = ?, " +
                              "acct_id = ?, acpt_yymm_ser = ?, mode_id = ?, mnt_date = ?, mnt_time = ?, mnt_emp_no = ?, curr_aply_date = ?"+
                        " where acpt_id = ? and acpt_rev_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, gla05h.getAcpt_id());
        pstmt.setString(2, gla05h.getAcpt_rev_no());
        pstmt.setString(3, gla05h.getAcpt_stus_code());
        pstmt.setString(4, gla05h.getProj_no());
        pstmt.setString(5, gla05h.getPo_type());
        pstmt.setString(6, gla05h.getCurr_code());
        pstmt.setString(7, gla05h.getLc_no());
        pstmt.setString(8, gla05h.getBl_no());
        pstmt.setString(9, gla05h.getInvc_no());
        pstmt.setString(10, gla05h.getPo_no());
        pstmt.setString(11, gla05h.getStor_id());
        pstmt.setString(12, gla05h.getVndr_grp_code());
        pstmt.setString(13, gla05h.getVhcl_no());
        pstmt.setInt(14, gla05h.getAcpt_tot_item());
        pstmt.setDouble(15, gla05h.getTot_wt());
        pstmt.setDouble(16, gla05h.getAcpt_tot_amt());
        pstmt.setDouble(17, gla05h.getRgsr_tot_amt());
        pstmt.setDouble(18, gla05h.getAcpt_tamt_yuan());
        pstmt.setDouble(19, gla05h.getRaw_mat_amt());
        pstmt.setDouble(20, gla05h.getStck_mat_amt());
        pstmt.setDouble(21, gla05h.getCons_mat_amt());
        pstmt.setDouble(22, gla05h.getAcpt_exch_rate());
        pstmt.setString(23, gla05h.getArvl_date());
        pstmt.setString(24, gla05h.getInsp_date());
        pstmt.setString(25, gla05h.getAcpt_date());
        pstmt.setString(26, gla05h.getRgdt());
        pstmt.setString(27, gla05h.getLmd());
        pstmt.setString(28, gla05h.getLast_fnl_date());
        pstmt.setString(29, gla05h.getAcct_id());
        pstmt.setInt(30, gla05h.getAcpt_yymm_ser());
        pstmt.setString(31, gla05h.getMode_id());
        pstmt.setString(32, gla05h.getMnt_date());
        pstmt.setString(33, gla05h.getMnt_time());
        pstmt.setString(34, gla05h.getMnt_emp_no());
        pstmt.setString(35, gla05h.getCurr_aply_date());
        // Key
        pstmt.setString(36, gla05h.getAcpt_id());
        pstmt.setString(37, gla05h.getAcpt_rev_no());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String acpt_id, String acpt_rev_no
* @return void 
* @author besTeam 
* @date 2006-6-27
*/
public void delete(String acpt_id, String acpt_rev_no) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLA05H "+
                       "where acpt_id = ? and acpt_rev_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,acpt_id); 
        pstmt.setString(2,acpt_rev_no); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLA05HRec 
* @return void 
* @author besTeam 
* @date 2006-6-27
*/
public void delete(GLA05HRec gla05h) throws Exception{
     delete(gla05h.getAcpt_id(), gla05h.getAcpt_rev_no());
} // end Delete

}// end GLA05HDBWrapBES class