package com.bes_line.mst.HMG;

// DBWrapper Class for GLP02H
/**
 *
 * @(#) GLP02HDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-28
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLP02HDBWrapBES extends DBWrapper{

public GLP02HDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String po_no, String po_rev_no
* @return GLP02HRec 
* @author besTeam 
* @date 2006-6-28
*/
public GLP02HRec select(String po_no, String po_rev_no) throws Exception{
    java.util.Vector glp02hV = new java.util.Vector();
    GLP02HRec glp02h = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_rev_no, po_stus_code, po_stus_chng_dt, rgdt, po_cnrt_date, po_cfdt_intl, dlvy_term_code, spmt_port_code, " +
                              "pay_term_code, po_bilg_amt, buyr_id, po_cnfm_indc, po_cfdt_last, lmd, curr_code, vndr_grp_code, po_type, " +
                              "prdr_grp_code, po_last_lnno, po_exch_rate, rmrk_indc, rmrk_last_ser_no, mode_id, mnt_date, mnt_time, mnt_emp_no, " +
                              "arvl_code, shpg_due_date, ord_rank, dlvy_plc_code, path_plc_code, thrd_dlvy_matl_indc, advc_pay_indc " +
                       "  from HM.GLP02H  " +
                       "  where po_no = ? and po_rev_no = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_rev_no); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            glp02h = new GLP02HRec(); // GLP02HRec Constructor
                     glp02h.setPo_no(rs.getString("po_no"));
                     glp02h.setPo_rev_no(rs.getString("po_rev_no"));
                     glp02h.setPo_stus_code(rs.getString("po_stus_code"));
                     glp02h.setPo_stus_chng_dt(rs.getString("po_stus_chng_dt"));
                     glp02h.setRgdt(rs.getString("rgdt"));
                     glp02h.setPo_cnrt_date(rs.getString("po_cnrt_date"));
                     glp02h.setPo_cfdt_intl(rs.getString("po_cfdt_intl"));
                     glp02h.setDlvy_term_code(rs.getString("dlvy_term_code"));
                     glp02h.setSpmt_port_code(rs.getString("spmt_port_code"));
                     glp02h.setPay_term_code(rs.getString("pay_term_code"));
                     glp02h.setPo_bilg_amt(rs.getDouble("po_bilg_amt"));
                     glp02h.setBuyr_id(rs.getString("buyr_id"));
                     glp02h.setPo_cnfm_indc(rs.getString("po_cnfm_indc"));
                     glp02h.setPo_cfdt_last(rs.getString("po_cfdt_last"));
                     glp02h.setLmd(rs.getString("lmd"));
                     glp02h.setCurr_code(rs.getString("curr_code"));
                     glp02h.setVndr_grp_code(rs.getString("vndr_grp_code"));
                     glp02h.setPo_type(rs.getString("po_type"));
                     glp02h.setPrdr_grp_code(rs.getString("prdr_grp_code"));
                     glp02h.setPo_last_lnno(rs.getInt("po_last_lnno"));
                     glp02h.setPo_exch_rate(rs.getDouble("po_exch_rate"));
                     glp02h.setRmrk_indc(rs.getString("rmrk_indc"));
                     glp02h.setRmrk_last_ser_no(rs.getString("rmrk_last_ser_no"));
                     glp02h.setMode_id(rs.getString("mode_id"));
                     glp02h.setMnt_date(rs.getString("mnt_date"));
                     glp02h.setMnt_time(rs.getString("mnt_time"));
                     glp02h.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     glp02h.setArvl_code(rs.getString("arvl_code"));
                     glp02h.setShpg_due_date(rs.getString("shpg_due_date"));
                     glp02h.setOrd_rank(rs.getString("ord_rank"));
                     glp02h.setDlvy_plc_code(rs.getString("dlvy_plc_code"));
                     glp02h.setPath_plc_code(rs.getString("path_plc_code"));
                     glp02h.setThrd_dlvy_matl_indc(rs.getString("thrd_dlvy_matl_indc"));
                     glp02h.setAdvc_pay_indc(rs.getString("advc_pay_indc"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp02h;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-28
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glp02hV = new java.util.Vector();
    GLP02HRec glp02h = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_rev_no, po_stus_code, po_stus_chng_dt, rgdt, po_cnrt_date, po_cfdt_intl, dlvy_term_code, spmt_port_code, " +
                              "pay_term_code, po_bilg_amt, buyr_id, po_cnfm_indc, po_cfdt_last, lmd, curr_code, vndr_grp_code, po_type, " +
                              "prdr_grp_code, po_last_lnno, po_exch_rate, rmrk_indc, rmrk_last_ser_no, mode_id, mnt_date, mnt_time, mnt_emp_no, " +
                              "arvl_code, shpg_due_date, ord_rank, dlvy_plc_code, path_plc_code, thrd_dlvy_matl_indc, advc_pay_indc " +
                       "  from HM.GLP02H "+
                       "  order by po_no , po_rev_no ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp02h = new GLP02HRec(); // GLP02HRec Constructor
                     glp02h.setPo_no(rs.getString("po_no"));
                     glp02h.setPo_rev_no(rs.getString("po_rev_no"));
                     glp02h.setPo_stus_code(rs.getString("po_stus_code"));
                     glp02h.setPo_stus_chng_dt(rs.getString("po_stus_chng_dt"));
                     glp02h.setRgdt(rs.getString("rgdt"));
                     glp02h.setPo_cnrt_date(rs.getString("po_cnrt_date"));
                     glp02h.setPo_cfdt_intl(rs.getString("po_cfdt_intl"));
                     glp02h.setDlvy_term_code(rs.getString("dlvy_term_code"));
                     glp02h.setSpmt_port_code(rs.getString("spmt_port_code"));
                     glp02h.setPay_term_code(rs.getString("pay_term_code"));
                     glp02h.setPo_bilg_amt(rs.getDouble("po_bilg_amt"));
                     glp02h.setBuyr_id(rs.getString("buyr_id"));
                     glp02h.setPo_cnfm_indc(rs.getString("po_cnfm_indc"));
                     glp02h.setPo_cfdt_last(rs.getString("po_cfdt_last"));
                     glp02h.setLmd(rs.getString("lmd"));
                     glp02h.setCurr_code(rs.getString("curr_code"));
                     glp02h.setVndr_grp_code(rs.getString("vndr_grp_code"));
                     glp02h.setPo_type(rs.getString("po_type"));
                     glp02h.setPrdr_grp_code(rs.getString("prdr_grp_code"));
                     glp02h.setPo_last_lnno(rs.getInt("po_last_lnno"));
                     glp02h.setPo_exch_rate(rs.getDouble("po_exch_rate"));
                     glp02h.setRmrk_indc(rs.getString("rmrk_indc"));
                     glp02h.setRmrk_last_ser_no(rs.getString("rmrk_last_ser_no"));
                     glp02h.setMode_id(rs.getString("mode_id"));
                     glp02h.setMnt_date(rs.getString("mnt_date"));
                     glp02h.setMnt_time(rs.getString("mnt_time"));
                     glp02h.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     glp02h.setArvl_code(rs.getString("arvl_code"));
                     glp02h.setShpg_due_date(rs.getString("shpg_due_date"));
                     glp02h.setOrd_rank(rs.getString("ord_rank"));
                     glp02h.setDlvy_plc_code(rs.getString("dlvy_plc_code"));
                     glp02h.setPath_plc_code(rs.getString("path_plc_code"));
                     glp02h.setThrd_dlvy_matl_indc(rs.getString("thrd_dlvy_matl_indc"));
                     glp02h.setAdvc_pay_indc(rs.getString("advc_pay_indc"));
            glp02hV.addElement(glp02h);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp02hV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-28
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glp02hV = new java.util.Vector();
    GLP02HRec glp02h = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_rev_no, po_stus_code, po_stus_chng_dt, rgdt, po_cnrt_date, po_cfdt_intl, dlvy_term_code, spmt_port_code, " +
                              "pay_term_code, po_bilg_amt, buyr_id, po_cnfm_indc, po_cfdt_last, lmd, curr_code, vndr_grp_code, po_type, " +
                              "prdr_grp_code, po_last_lnno, po_exch_rate, rmrk_indc, rmrk_last_ser_no, mode_id, mnt_date, mnt_time, mnt_emp_no, " +
                              "arvl_code, shpg_due_date, ord_rank, dlvy_plc_code, path_plc_code, thrd_dlvy_matl_indc, advc_pay_indc " +
                       "  from HM.GLP02H  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  po_no " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp02h = new GLP02HRec(); // GLP02HRec Constructor
                     glp02h.setPo_no(rs.getString("po_no"));
                     glp02h.setPo_rev_no(rs.getString("po_rev_no"));
                     glp02h.setPo_stus_code(rs.getString("po_stus_code"));
                     glp02h.setPo_stus_chng_dt(rs.getString("po_stus_chng_dt"));
                     glp02h.setRgdt(rs.getString("rgdt"));
                     glp02h.setPo_cnrt_date(rs.getString("po_cnrt_date"));
                     glp02h.setPo_cfdt_intl(rs.getString("po_cfdt_intl"));
                     glp02h.setDlvy_term_code(rs.getString("dlvy_term_code"));
                     glp02h.setSpmt_port_code(rs.getString("spmt_port_code"));
                     glp02h.setPay_term_code(rs.getString("pay_term_code"));
                     glp02h.setPo_bilg_amt(rs.getDouble("po_bilg_amt"));
                     glp02h.setBuyr_id(rs.getString("buyr_id"));
                     glp02h.setPo_cnfm_indc(rs.getString("po_cnfm_indc"));
                     glp02h.setPo_cfdt_last(rs.getString("po_cfdt_last"));
                     glp02h.setLmd(rs.getString("lmd"));
                     glp02h.setCurr_code(rs.getString("curr_code"));
                     glp02h.setVndr_grp_code(rs.getString("vndr_grp_code"));
                     glp02h.setPo_type(rs.getString("po_type"));
                     glp02h.setPrdr_grp_code(rs.getString("prdr_grp_code"));
                     glp02h.setPo_last_lnno(rs.getInt("po_last_lnno"));
                     glp02h.setPo_exch_rate(rs.getDouble("po_exch_rate"));
                     glp02h.setRmrk_indc(rs.getString("rmrk_indc"));
                     glp02h.setRmrk_last_ser_no(rs.getString("rmrk_last_ser_no"));
                     glp02h.setMode_id(rs.getString("mode_id"));
                     glp02h.setMnt_date(rs.getString("mnt_date"));
                     glp02h.setMnt_time(rs.getString("mnt_time"));
                     glp02h.setMnt_emp_no(rs.getString("mnt_emp_no"));
                     glp02h.setArvl_code(rs.getString("arvl_code"));
                     glp02h.setShpg_due_date(rs.getString("shpg_due_date"));
                     glp02h.setOrd_rank(rs.getString("ord_rank"));
                     glp02h.setDlvy_plc_code(rs.getString("dlvy_plc_code"));
                     glp02h.setPath_plc_code(rs.getString("path_plc_code"));
                     glp02h.setThrd_dlvy_matl_indc(rs.getString("thrd_dlvy_matl_indc"));
                     glp02h.setAdvc_pay_indc(rs.getString("advc_pay_indc"));
            glp02hV.addElement(glp02h);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp02hV;
} // end selectAll

/**
* Get Rows Count 
* @param String po_no, String po_rev_no
* @return int 
* @author besTeam 
* @date 2006-6-28
*/
public int count(String po_no, String po_rev_no) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP02H " +
                       " where po_no = ? and po_rev_no = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_rev_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-28
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP02H  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLP02HRec 
* @return void 
* @author besTeam 
* @date 2006-6-28
*/
public void insert(GLP02HRec glp02h) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLP02H( " +
                              "po_no, po_rev_no, po_stus_code, po_stus_chng_dt, rgdt, po_cnrt_date, po_cfdt_intl, dlvy_term_code, spmt_port_code, " +
                              "pay_term_code, po_bilg_amt, buyr_id, po_cnfm_indc, po_cfdt_last, lmd, curr_code, vndr_grp_code, po_type, " +
                              "prdr_grp_code, po_last_lnno, po_exch_rate, rmrk_indc, rmrk_last_ser_no, mode_id, mnt_date, mnt_time, mnt_emp_no, " +
                              "arvl_code, shpg_due_date, ord_rank, dlvy_plc_code, path_plc_code, thrd_dlvy_matl_indc, advc_pay_indc"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp02h.getPo_no());
        pstmt.setString(2, glp02h.getPo_rev_no());
        pstmt.setString(3, glp02h.getPo_stus_code());
        pstmt.setString(4, glp02h.getPo_stus_chng_dt());
        pstmt.setString(5, glp02h.getRgdt());
        pstmt.setString(6, glp02h.getPo_cnrt_date());
        pstmt.setString(7, glp02h.getPo_cfdt_intl());
        pstmt.setString(8, glp02h.getDlvy_term_code());
        pstmt.setString(9, glp02h.getSpmt_port_code());
        pstmt.setString(10, glp02h.getPay_term_code());
        pstmt.setDouble(11, glp02h.getPo_bilg_amt());
        pstmt.setString(12, glp02h.getBuyr_id());
        pstmt.setString(13, glp02h.getPo_cnfm_indc());
        pstmt.setString(14, glp02h.getPo_cfdt_last());
        pstmt.setString(15, glp02h.getLmd());
        pstmt.setString(16, glp02h.getCurr_code());
        pstmt.setString(17, glp02h.getVndr_grp_code());
        pstmt.setString(18, glp02h.getPo_type());
        pstmt.setString(19, glp02h.getPrdr_grp_code());
        pstmt.setInt(20, glp02h.getPo_last_lnno());
        pstmt.setDouble(21, glp02h.getPo_exch_rate());
        pstmt.setString(22, glp02h.getRmrk_indc());
        pstmt.setString(23, glp02h.getRmrk_last_ser_no());
        pstmt.setString(24, glp02h.getMode_id());
        pstmt.setString(25, glp02h.getMnt_date());
        pstmt.setString(26, glp02h.getMnt_time());
        pstmt.setString(27, glp02h.getMnt_emp_no());
        pstmt.setString(28, glp02h.getArvl_code());
        pstmt.setString(29, glp02h.getShpg_due_date());
        pstmt.setString(30, glp02h.getOrd_rank());
        pstmt.setString(31, glp02h.getDlvy_plc_code());
        pstmt.setString(32, glp02h.getPath_plc_code());
        pstmt.setString(33, glp02h.getThrd_dlvy_matl_indc());
        pstmt.setString(34, glp02h.getAdvc_pay_indc());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLP02HRec 
* @return void 
* @author besTeam 
* @date 2006-6-28
*/
public void update(GLP02HRec glp02h) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLP02H SET "+
                        "po_no = ?, po_rev_no = ?, po_stus_code = ?, po_stus_chng_dt = ?, rgdt = ?, po_cnrt_date = ?, po_cfdt_intl = ?, dlvy_term_code = ?, spmt_port_code = ?, pay_term_code = ?, " +
                              "po_bilg_amt = ?, buyr_id = ?, po_cnfm_indc = ?, po_cfdt_last = ?, lmd = ?, curr_code = ?, vndr_grp_code = ?, po_type = ?, prdr_grp_code = ?, " +
                              "po_last_lnno = ?, po_exch_rate = ?, rmrk_indc = ?, rmrk_last_ser_no = ?, mode_id = ?, mnt_date = ?, mnt_time = ?, mnt_emp_no = ?, arvl_code = ?, " +
                              "shpg_due_date = ?, ord_rank = ?, dlvy_plc_code = ?, path_plc_code = ?, thrd_dlvy_matl_indc = ?, advc_pay_indc = ?"+
                        " where po_no = ? and po_rev_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp02h.getPo_no());
        pstmt.setString(2, glp02h.getPo_rev_no());
        pstmt.setString(3, glp02h.getPo_stus_code());
        pstmt.setString(4, glp02h.getPo_stus_chng_dt());
        pstmt.setString(5, glp02h.getRgdt());
        pstmt.setString(6, glp02h.getPo_cnrt_date());
        pstmt.setString(7, glp02h.getPo_cfdt_intl());
        pstmt.setString(8, glp02h.getDlvy_term_code());
        pstmt.setString(9, glp02h.getSpmt_port_code());
        pstmt.setString(10, glp02h.getPay_term_code());
        pstmt.setDouble(11, glp02h.getPo_bilg_amt());
        pstmt.setString(12, glp02h.getBuyr_id());
        pstmt.setString(13, glp02h.getPo_cnfm_indc());
        pstmt.setString(14, glp02h.getPo_cfdt_last());
        pstmt.setString(15, glp02h.getLmd());
        pstmt.setString(16, glp02h.getCurr_code());
        pstmt.setString(17, glp02h.getVndr_grp_code());
        pstmt.setString(18, glp02h.getPo_type());
        pstmt.setString(19, glp02h.getPrdr_grp_code());
        pstmt.setInt(20, glp02h.getPo_last_lnno());
        pstmt.setDouble(21, glp02h.getPo_exch_rate());
        pstmt.setString(22, glp02h.getRmrk_indc());
        pstmt.setString(23, glp02h.getRmrk_last_ser_no());
        pstmt.setString(24, glp02h.getMode_id());
        pstmt.setString(25, glp02h.getMnt_date());
        pstmt.setString(26, glp02h.getMnt_time());
        pstmt.setString(27, glp02h.getMnt_emp_no());
        pstmt.setString(28, glp02h.getArvl_code());
        pstmt.setString(29, glp02h.getShpg_due_date());
        pstmt.setString(30, glp02h.getOrd_rank());
        pstmt.setString(31, glp02h.getDlvy_plc_code());
        pstmt.setString(32, glp02h.getPath_plc_code());
        pstmt.setString(33, glp02h.getThrd_dlvy_matl_indc());
        pstmt.setString(34, glp02h.getAdvc_pay_indc());
        // Key
        pstmt.setString(35, glp02h.getPo_no());
        pstmt.setString(36, glp02h.getPo_rev_no());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String po_no, String po_rev_no
* @return void 
* @author besTeam 
* @date 2006-6-28
*/
public void delete(String po_no, String po_rev_no) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLP02H "+
                       "where po_no = ? and po_rev_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_rev_no); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLP02HRec 
* @return void 
* @author besTeam 
* @date 2006-6-28
*/
public void delete(GLP02HRec glp02h) throws Exception{
     delete(glp02h.getPo_no(), glp02h.getPo_rev_no());
} // end Delete

}// end GLP02HDBWrapBES class