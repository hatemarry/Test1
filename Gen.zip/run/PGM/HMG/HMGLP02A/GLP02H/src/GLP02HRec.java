package com.bes_line.mst.HMG ;

// Entity Class for GLP02H
/**
 *
 * @(#) GLP02HRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-28
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLP02HRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String po_no; 		// (VARCHAR2, 12.0)
    public String po_rev_no; 		// (VARCHAR2, 2.0)
    public String po_stus_code; 		// (VARCHAR2, 1.0)
    public String po_stus_chng_dt; 		// (VARCHAR2, 8.0)
    public String rgdt; 		// (VARCHAR2, 8.0)
    public String po_cnrt_date; 		// (VARCHAR2, 8.0)
    public String po_cfdt_intl; 		// (VARCHAR2, 8.0)
    public String dlvy_term_code; 		// (VARCHAR2, 3.0)
    public String spmt_port_code; 		// (VARCHAR2, 3.0)
    public String pay_term_code; 		// (VARCHAR2, 2.0)
    public double po_bilg_amt; 		// (NUMBER, 13.2)
    public String buyr_id; 		// (VARCHAR2, 4.0)
    public String po_cnfm_indc; 		// (VARCHAR2, 1.0)
    public String po_cfdt_last; 		// (VARCHAR2, 8.0)
    public String lmd; 		// (VARCHAR2, 8.0)
    public String curr_code; 		// (VARCHAR2, 2.0)
    public String vndr_grp_code; 		// (VARCHAR2, 4.0)
    public String po_type; 		// (VARCHAR2, 1.0)
    public String prdr_grp_code; 		// (VARCHAR2, 4.0)
    public int po_last_lnno; 		// (NUMBER, 3.0)
    public double po_exch_rate; 		// (NUMBER, 9.4)
    public String rmrk_indc; 		// (VARCHAR2, 1.0)
    public String rmrk_last_ser_no; 		// (VARCHAR2, 2.0)
    public String mode_id; 		// (VARCHAR2, 1.0)
    public String mnt_date; 		// (VARCHAR2, 8.0)
    public String mnt_time; 		// (VARCHAR2, 6.0)
    public String mnt_emp_no; 		// (VARCHAR2, 7.0)
    public String arvl_code; 		// (VARCHAR2, 3.0)
    public String shpg_due_date; 		// (VARCHAR2, 8.0)
    public String ord_rank; 		// (VARCHAR2, 3.0)
    public String dlvy_plc_code; 		// (VARCHAR2, 3.0)
    public String path_plc_code; 		// (VARCHAR2, 3.0)
    public String thrd_dlvy_matl_indc; 		// (VARCHAR2, 1.0)
    public String advc_pay_indc; 		// (VARCHAR2, 1.0)

public GLP02HRec(){ } // default constructor

public GLP02HRec(
       String po_no, String po_rev_no, String po_stus_code, String po_stus_chng_dt, String rgdt, String po_cnrt_date, 
       String po_cfdt_intl, String dlvy_term_code, String spmt_port_code, String pay_term_code, double po_bilg_amt, String buyr_id, 
       String po_cnfm_indc, String po_cfdt_last, String lmd, String curr_code, String vndr_grp_code, String po_type, 
       String prdr_grp_code, int po_last_lnno, double po_exch_rate, String rmrk_indc, String rmrk_last_ser_no, String mode_id, 
       String mnt_date, String mnt_time, String mnt_emp_no, String arvl_code, String shpg_due_date, String ord_rank, 
       String dlvy_plc_code, String path_plc_code, String thrd_dlvy_matl_indc, String advc_pay_indc){
    this.po_no = po_no;
    this.po_rev_no = po_rev_no;
    this.po_stus_code = po_stus_code;
    this.po_stus_chng_dt = po_stus_chng_dt;
    this.rgdt = rgdt;
    this.po_cnrt_date = po_cnrt_date;
    this.po_cfdt_intl = po_cfdt_intl;
    this.dlvy_term_code = dlvy_term_code;
    this.spmt_port_code = spmt_port_code;
    this.pay_term_code = pay_term_code;
    this.po_bilg_amt = po_bilg_amt;
    this.buyr_id = buyr_id;
    this.po_cnfm_indc = po_cnfm_indc;
    this.po_cfdt_last = po_cfdt_last;
    this.lmd = lmd;
    this.curr_code = curr_code;
    this.vndr_grp_code = vndr_grp_code;
    this.po_type = po_type;
    this.prdr_grp_code = prdr_grp_code;
    this.po_last_lnno = po_last_lnno;
    this.po_exch_rate = po_exch_rate;
    this.rmrk_indc = rmrk_indc;
    this.rmrk_last_ser_no = rmrk_last_ser_no;
    this.mode_id = mode_id;
    this.mnt_date = mnt_date;
    this.mnt_time = mnt_time;
    this.mnt_emp_no = mnt_emp_no;
    this.arvl_code = arvl_code;
    this.shpg_due_date = shpg_due_date;
    this.ord_rank = ord_rank;
    this.dlvy_plc_code = dlvy_plc_code;
    this.path_plc_code = path_plc_code;
    this.thrd_dlvy_matl_indc = thrd_dlvy_matl_indc;
    this.advc_pay_indc = advc_pay_indc;
} // Constructor


// Getter 
public String getPo_no(){ return po_no;}
public String getPo_rev_no(){ return po_rev_no;}
public String getPo_stus_code(){ return po_stus_code;}
public String getPo_stus_chng_dt(){ return po_stus_chng_dt;}
public String getRgdt(){ return rgdt;}
public String getPo_cnrt_date(){ return po_cnrt_date;}
public String getPo_cfdt_intl(){ return po_cfdt_intl;}
public String getDlvy_term_code(){ return dlvy_term_code;}
public String getSpmt_port_code(){ return spmt_port_code;}
public String getPay_term_code(){ return pay_term_code;}
public double getPo_bilg_amt(){ return po_bilg_amt;}
public String getBuyr_id(){ return buyr_id;}
public String getPo_cnfm_indc(){ return po_cnfm_indc;}
public String getPo_cfdt_last(){ return po_cfdt_last;}
public String getLmd(){ return lmd;}
public String getCurr_code(){ return curr_code;}
public String getVndr_grp_code(){ return vndr_grp_code;}
public String getPo_type(){ return po_type;}
public String getPrdr_grp_code(){ return prdr_grp_code;}
public int getPo_last_lnno(){ return po_last_lnno;}
public double getPo_exch_rate(){ return po_exch_rate;}
public String getRmrk_indc(){ return rmrk_indc;}
public String getRmrk_last_ser_no(){ return rmrk_last_ser_no;}
public String getMode_id(){ return mode_id;}
public String getMnt_date(){ return mnt_date;}
public String getMnt_time(){ return mnt_time;}
public String getMnt_emp_no(){ return mnt_emp_no;}
public String getArvl_code(){ return arvl_code;}
public String getShpg_due_date(){ return shpg_due_date;}
public String getOrd_rank(){ return ord_rank;}
public String getDlvy_plc_code(){ return dlvy_plc_code;}
public String getPath_plc_code(){ return path_plc_code;}
public String getThrd_dlvy_matl_indc(){ return thrd_dlvy_matl_indc;}
public String getAdvc_pay_indc(){ return advc_pay_indc;}

// Setter 
public void setPo_no(String po_no){ this.po_no = po_no;}
public void setPo_rev_no(String po_rev_no){ this.po_rev_no = po_rev_no;}
public void setPo_stus_code(String po_stus_code){ this.po_stus_code = po_stus_code;}
public void setPo_stus_chng_dt(String po_stus_chng_dt){ this.po_stus_chng_dt = po_stus_chng_dt;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}
public void setPo_cnrt_date(String po_cnrt_date){ this.po_cnrt_date = po_cnrt_date;}
public void setPo_cfdt_intl(String po_cfdt_intl){ this.po_cfdt_intl = po_cfdt_intl;}
public void setDlvy_term_code(String dlvy_term_code){ this.dlvy_term_code = dlvy_term_code;}
public void setSpmt_port_code(String spmt_port_code){ this.spmt_port_code = spmt_port_code;}
public void setPay_term_code(String pay_term_code){ this.pay_term_code = pay_term_code;}
public void setPo_bilg_amt(double po_bilg_amt){ this.po_bilg_amt = po_bilg_amt;}
public void setBuyr_id(String buyr_id){ this.buyr_id = buyr_id;}
public void setPo_cnfm_indc(String po_cnfm_indc){ this.po_cnfm_indc = po_cnfm_indc;}
public void setPo_cfdt_last(String po_cfdt_last){ this.po_cfdt_last = po_cfdt_last;}
public void setLmd(String lmd){ this.lmd = lmd;}
public void setCurr_code(String curr_code){ this.curr_code = curr_code;}
public void setVndr_grp_code(String vndr_grp_code){ this.vndr_grp_code = vndr_grp_code;}
public void setPo_type(String po_type){ this.po_type = po_type;}
public void setPrdr_grp_code(String prdr_grp_code){ this.prdr_grp_code = prdr_grp_code;}
public void setPo_last_lnno(int po_last_lnno){ this.po_last_lnno = po_last_lnno;}
public void setPo_exch_rate(double po_exch_rate){ this.po_exch_rate = po_exch_rate;}
public void setRmrk_indc(String rmrk_indc){ this.rmrk_indc = rmrk_indc;}
public void setRmrk_last_ser_no(String rmrk_last_ser_no){ this.rmrk_last_ser_no = rmrk_last_ser_no;}
public void setMode_id(String mode_id){ this.mode_id = mode_id;}
public void setMnt_date(String mnt_date){ this.mnt_date = mnt_date;}
public void setMnt_time(String mnt_time){ this.mnt_time = mnt_time;}
public void setMnt_emp_no(String mnt_emp_no){ this.mnt_emp_no = mnt_emp_no;}
public void setArvl_code(String arvl_code){ this.arvl_code = arvl_code;}
public void setShpg_due_date(String shpg_due_date){ this.shpg_due_date = shpg_due_date;}
public void setOrd_rank(String ord_rank){ this.ord_rank = ord_rank;}
public void setDlvy_plc_code(String dlvy_plc_code){ this.dlvy_plc_code = dlvy_plc_code;}
public void setPath_plc_code(String path_plc_code){ this.path_plc_code = path_plc_code;}
public void setThrd_dlvy_matl_indc(String thrd_dlvy_matl_indc){ this.thrd_dlvy_matl_indc = thrd_dlvy_matl_indc;}
public void setAdvc_pay_indc(String advc_pay_indc){ this.advc_pay_indc = advc_pay_indc;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = po_no + "" ; break;
  case  2 : field = po_rev_no + "" ; break;
  case  3 : field = po_stus_code + "" ; break;
  case  4 : field = po_stus_chng_dt + "" ; break;
  case  5 : field = rgdt + "" ; break;
  case  6 : field = po_cnrt_date + "" ; break;
  case  7 : field = po_cfdt_intl + "" ; break;
  case  8 : field = dlvy_term_code + "" ; break;
  case  9 : field = spmt_port_code + "" ; break;
  case  10 : field = pay_term_code + "" ; break;
  case  11 : field = po_bilg_amt + "" ; break;
  case  12 : field = buyr_id + "" ; break;
  case  13 : field = po_cnfm_indc + "" ; break;
  case  14 : field = po_cfdt_last + "" ; break;
  case  15 : field = lmd + "" ; break;
  case  16 : field = curr_code + "" ; break;
  case  17 : field = vndr_grp_code + "" ; break;
  case  18 : field = po_type + "" ; break;
  case  19 : field = prdr_grp_code + "" ; break;
  case  20 : field = po_last_lnno + "" ; break;
  case  21 : field = po_exch_rate + "" ; break;
  case  22 : field = rmrk_indc + "" ; break;
  case  23 : field = rmrk_last_ser_no + "" ; break;
  case  24 : field = mode_id + "" ; break;
  case  25 : field = mnt_date + "" ; break;
  case  26 : field = mnt_time + "" ; break;
  case  27 : field = mnt_emp_no + "" ; break;
  case  28 : field = arvl_code + "" ; break;
  case  29 : field = shpg_due_date + "" ; break;
  case  30 : field = ord_rank + "" ; break;
  case  31 : field = dlvy_plc_code + "" ; break;
  case  32 : field = path_plc_code + "" ; break;
  case  33 : field = thrd_dlvy_matl_indc + "" ; break;
  case  34 : field = advc_pay_indc + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("po_no")){ field = po_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_rev_no")){ field = po_rev_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_stus_code")){ field = po_stus_code + "" ; 
     } else if(rec.equalsIgnoreCase("po_stus_chng_dt")){ field = po_stus_chng_dt + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("po_cnrt_date")){ field = po_cnrt_date + "" ; 
     } else if(rec.equalsIgnoreCase("po_cfdt_intl")){ field = po_cfdt_intl + "" ; 
     } else if(rec.equalsIgnoreCase("dlvy_term_code")){ field = dlvy_term_code + "" ; 
     } else if(rec.equalsIgnoreCase("spmt_port_code")){ field = spmt_port_code + "" ; 
     } else if(rec.equalsIgnoreCase("pay_term_code")){ field = pay_term_code + "" ; 
     } else if(rec.equalsIgnoreCase("po_bilg_amt")){ field = po_bilg_amt + "" ; 
     } else if(rec.equalsIgnoreCase("buyr_id")){ field = buyr_id + "" ; 
     } else if(rec.equalsIgnoreCase("po_cnfm_indc")){ field = po_cnfm_indc + "" ; 
     } else if(rec.equalsIgnoreCase("po_cfdt_last")){ field = po_cfdt_last + "" ; 
     } else if(rec.equalsIgnoreCase("lmd")){ field = lmd + "" ; 
     } else if(rec.equalsIgnoreCase("curr_code")){ field = curr_code + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_grp_code")){ field = vndr_grp_code + "" ; 
     } else if(rec.equalsIgnoreCase("po_type")){ field = po_type + "" ; 
     } else if(rec.equalsIgnoreCase("prdr_grp_code")){ field = prdr_grp_code + "" ; 
     } else if(rec.equalsIgnoreCase("po_last_lnno")){ field = po_last_lnno + "" ; 
     } else if(rec.equalsIgnoreCase("po_exch_rate")){ field = po_exch_rate + "" ; 
     } else if(rec.equalsIgnoreCase("rmrk_indc")){ field = rmrk_indc + "" ; 
     } else if(rec.equalsIgnoreCase("rmrk_last_ser_no")){ field = rmrk_last_ser_no + "" ; 
     } else if(rec.equalsIgnoreCase("mode_id")){ field = mode_id + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_date")){ field = mnt_date + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_time")){ field = mnt_time + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_emp_no")){ field = mnt_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("arvl_code")){ field = arvl_code + "" ; 
     } else if(rec.equalsIgnoreCase("shpg_due_date")){ field = shpg_due_date + "" ; 
     } else if(rec.equalsIgnoreCase("ord_rank")){ field = ord_rank + "" ; 
     } else if(rec.equalsIgnoreCase("dlvy_plc_code")){ field = dlvy_plc_code + "" ; 
     } else if(rec.equalsIgnoreCase("path_plc_code")){ field = path_plc_code + "" ; 
     } else if(rec.equalsIgnoreCase("thrd_dlvy_matl_indc")){ field = thrd_dlvy_matl_indc + "" ; 
     } else if(rec.equalsIgnoreCase("advc_pay_indc")){ field = advc_pay_indc + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "PO_NO", "PO_REV_NO", "PO_STUS_CODE", "PO_STUS_CHNG_DT", "RGDT", "PO_CNRT_DATE", "PO_CFDT_INTL", 
       "DLVY_TERM_CODE", "SPMT_PORT_CODE", "PAY_TERM_CODE", "PO_BILG_AMT", "BUYR_ID", "PO_CNFM_INDC", "PO_CFDT_LAST", 
       "LMD", "CURR_CODE", "VNDR_GRP_CODE", "PO_TYPE", "PRDR_GRP_CODE", "PO_LAST_LNNO", "PO_EXCH_RATE", 
       "RMRK_INDC", "RMRK_LAST_SER_NO", "MODE_ID", "MNT_DATE", "MNT_TIME", "MNT_EMP_NO", "ARVL_CODE", 
       "SHPG_DUE_DATE", "ORD_RANK", "DLVY_PLC_CODE", "PATH_PLC_CODE", "THRD_DLVY_MATL_INDC", "ADVC_PAY_INDC"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "PO_NO", "PO_REV_NO"};
    return tempx;
}

}// end GLP02HRec class