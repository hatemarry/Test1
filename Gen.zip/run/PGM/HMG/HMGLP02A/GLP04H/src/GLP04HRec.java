package com.bes_line.mst.HMG ;

// Entity Class for GLP04H
/**
 *
 * @(#) GLP04HRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-28
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLP04HRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String po_no; 		// (VARCHAR2, 12.0)
    public String po_rmrk_ser_no; 		// (VARCHAR2, 2.0)
    public String po_rev_no; 		// (VARCHAR2, 2.0)
    public String po_rmrk_chns; 		// (VARCHAR2, 150.0)
    public String mode_id; 		// (VARCHAR2, 1.0)
    public String mnt_date; 		// (VARCHAR2, 8.0)
    public String mnt_time; 		// (VARCHAR2, 6.0)
    public String mnt_emp_no; 		// (VARCHAR2, 7.0)

public GLP04HRec(){ } // default constructor

public GLP04HRec(
       String po_no, String po_rmrk_ser_no, String po_rev_no, String po_rmrk_chns, String mode_id, String mnt_date, 
       String mnt_time, String mnt_emp_no){
    this.po_no = po_no;
    this.po_rmrk_ser_no = po_rmrk_ser_no;
    this.po_rev_no = po_rev_no;
    this.po_rmrk_chns = po_rmrk_chns;
    this.mode_id = mode_id;
    this.mnt_date = mnt_date;
    this.mnt_time = mnt_time;
    this.mnt_emp_no = mnt_emp_no;
} // Constructor


// Getter 
public String getPo_no(){ return po_no;}
public String getPo_rmrk_ser_no(){ return po_rmrk_ser_no;}
public String getPo_rev_no(){ return po_rev_no;}
public String getPo_rmrk_chns(){ return po_rmrk_chns;}
public String getMode_id(){ return mode_id;}
public String getMnt_date(){ return mnt_date;}
public String getMnt_time(){ return mnt_time;}
public String getMnt_emp_no(){ return mnt_emp_no;}

// Setter 
public void setPo_no(String po_no){ this.po_no = po_no;}
public void setPo_rmrk_ser_no(String po_rmrk_ser_no){ this.po_rmrk_ser_no = po_rmrk_ser_no;}
public void setPo_rev_no(String po_rev_no){ this.po_rev_no = po_rev_no;}
public void setPo_rmrk_chns(String po_rmrk_chns){ this.po_rmrk_chns = po_rmrk_chns;}
public void setMode_id(String mode_id){ this.mode_id = mode_id;}
public void setMnt_date(String mnt_date){ this.mnt_date = mnt_date;}
public void setMnt_time(String mnt_time){ this.mnt_time = mnt_time;}
public void setMnt_emp_no(String mnt_emp_no){ this.mnt_emp_no = mnt_emp_no;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = po_no + "" ; break;
  case  2 : field = po_rmrk_ser_no + "" ; break;
  case  3 : field = po_rev_no + "" ; break;
  case  4 : field = po_rmrk_chns + "" ; break;
  case  5 : field = mode_id + "" ; break;
  case  6 : field = mnt_date + "" ; break;
  case  7 : field = mnt_time + "" ; break;
  case  8 : field = mnt_emp_no + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("po_no")){ field = po_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_rmrk_ser_no")){ field = po_rmrk_ser_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_rev_no")){ field = po_rev_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_rmrk_chns")){ field = po_rmrk_chns + "" ; 
     } else if(rec.equalsIgnoreCase("mode_id")){ field = mode_id + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_date")){ field = mnt_date + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_time")){ field = mnt_time + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_emp_no")){ field = mnt_emp_no + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "PO_NO", "PO_RMRK_SER_NO", "PO_REV_NO", "PO_RMRK_CHNS", "MODE_ID", "MNT_DATE", "MNT_TIME", 
       "MNT_EMP_NO"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "PO_NO", "PO_RMRK_SER_NO", "PO_REV_NO"};
    return tempx;
}

}// end GLP04HRec class