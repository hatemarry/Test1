package com.bes_line.mst.HMG;

// DBWrapper Class for GLP04H
/**
 *
 * @(#) GLP04HDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-28
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLP04HDBWrapBES extends DBWrapper{

public GLP04HDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String po_no, String po_rmrk_ser_no, String po_rev_no
* @return GLP04HRec 
* @author besTeam 
* @date 2006-6-28
*/
public GLP04HRec select(String po_no, String po_rmrk_ser_no, String po_rev_no) throws Exception{
    java.util.Vector glp04hV = new java.util.Vector();
    GLP04HRec glp04h = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_rmrk_ser_no, po_rev_no, po_rmrk_chns, mode_id, mnt_date, mnt_time, mnt_emp_no " +
                       "  from HM.GLP04H  " +
                       "  where po_no = ? and po_rmrk_ser_no = ? and po_rev_no = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_rmrk_ser_no); 
        pstmt.setString(3,po_rev_no); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            glp04h = new GLP04HRec(); // GLP04HRec Constructor
                     glp04h.setPo_no(rs.getString("po_no"));
                     glp04h.setPo_rmrk_ser_no(rs.getString("po_rmrk_ser_no"));
                     glp04h.setPo_rev_no(rs.getString("po_rev_no"));
                     glp04h.setPo_rmrk_chns(rs.getString("po_rmrk_chns"));
                     glp04h.setMode_id(rs.getString("mode_id"));
                     glp04h.setMnt_date(rs.getString("mnt_date"));
                     glp04h.setMnt_time(rs.getString("mnt_time"));
                     glp04h.setMnt_emp_no(rs.getString("mnt_emp_no"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp04h;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-28
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glp04hV = new java.util.Vector();
    GLP04HRec glp04h = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_rmrk_ser_no, po_rev_no, po_rmrk_chns, mode_id, mnt_date, mnt_time, mnt_emp_no " +
                       "  from HM.GLP04H "+
                       "  order by po_no , po_rmrk_ser_no , po_rev_no ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp04h = new GLP04HRec(); // GLP04HRec Constructor
                     glp04h.setPo_no(rs.getString("po_no"));
                     glp04h.setPo_rmrk_ser_no(rs.getString("po_rmrk_ser_no"));
                     glp04h.setPo_rev_no(rs.getString("po_rev_no"));
                     glp04h.setPo_rmrk_chns(rs.getString("po_rmrk_chns"));
                     glp04h.setMode_id(rs.getString("mode_id"));
                     glp04h.setMnt_date(rs.getString("mnt_date"));
                     glp04h.setMnt_time(rs.getString("mnt_time"));
                     glp04h.setMnt_emp_no(rs.getString("mnt_emp_no"));
            glp04hV.addElement(glp04h);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp04hV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-28
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glp04hV = new java.util.Vector();
    GLP04HRec glp04h = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_rmrk_ser_no, po_rev_no, po_rmrk_chns, mode_id, mnt_date, mnt_time, mnt_emp_no " +
                       "  from HM.GLP04H  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  po_no,po_rmrk_ser_no " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp04h = new GLP04HRec(); // GLP04HRec Constructor
                     glp04h.setPo_no(rs.getString("po_no"));
                     glp04h.setPo_rmrk_ser_no(rs.getString("po_rmrk_ser_no"));
                     glp04h.setPo_rev_no(rs.getString("po_rev_no"));
                     glp04h.setPo_rmrk_chns(rs.getString("po_rmrk_chns"));
                     glp04h.setMode_id(rs.getString("mode_id"));
                     glp04h.setMnt_date(rs.getString("mnt_date"));
                     glp04h.setMnt_time(rs.getString("mnt_time"));
                     glp04h.setMnt_emp_no(rs.getString("mnt_emp_no"));
            glp04hV.addElement(glp04h);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp04hV;
} // end selectAll

/**
* Get Rows Count 
* @param String po_no, String po_rmrk_ser_no, String po_rev_no
* @return int 
* @author besTeam 
* @date 2006-6-28
*/
public int count(String po_no, String po_rmrk_ser_no, String po_rev_no) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP04H " +
                       " where po_no = ? and po_rmrk_ser_no = ? and po_rev_no = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_rmrk_ser_no); 
        pstmt.setString(3,po_rev_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-28
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP04H  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLP04HRec 
* @return void 
* @author besTeam 
* @date 2006-6-28
*/
public void insert(GLP04HRec glp04h) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLP04H( " +
                              "po_no, po_rmrk_ser_no, po_rev_no, po_rmrk_chns, mode_id, mnt_date, mnt_time, mnt_emp_no"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp04h.getPo_no());
        pstmt.setString(2, glp04h.getPo_rmrk_ser_no());
        pstmt.setString(3, glp04h.getPo_rev_no());
        pstmt.setString(4, glp04h.getPo_rmrk_chns());
        pstmt.setString(5, glp04h.getMode_id());
        pstmt.setString(6, glp04h.getMnt_date());
        pstmt.setString(7, glp04h.getMnt_time());
        pstmt.setString(8, glp04h.getMnt_emp_no());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLP04HRec 
* @return void 
* @author besTeam 
* @date 2006-6-28
*/
public void update(GLP04HRec glp04h) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLP04H SET "+
                        "po_no = ?, po_rmrk_ser_no = ?, po_rev_no = ?, po_rmrk_chns = ?, mode_id = ?, mnt_date = ?, mnt_time = ?, mnt_emp_no = ?"+
                        " where po_no = ? and po_rmrk_ser_no = ? and po_rev_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp04h.getPo_no());
        pstmt.setString(2, glp04h.getPo_rmrk_ser_no());
        pstmt.setString(3, glp04h.getPo_rev_no());
        pstmt.setString(4, glp04h.getPo_rmrk_chns());
        pstmt.setString(5, glp04h.getMode_id());
        pstmt.setString(6, glp04h.getMnt_date());
        pstmt.setString(7, glp04h.getMnt_time());
        pstmt.setString(8, glp04h.getMnt_emp_no());
        // Key
        pstmt.setString(9, glp04h.getPo_no());
        pstmt.setString(10, glp04h.getPo_rmrk_ser_no());
        pstmt.setString(11, glp04h.getPo_rev_no());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String po_no, String po_rmrk_ser_no, String po_rev_no
* @return void 
* @author besTeam 
* @date 2006-6-28
*/
public void delete(String po_no, String po_rmrk_ser_no, String po_rev_no) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLP04H "+
                       "where po_no = ? and po_rmrk_ser_no = ? and po_rev_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_rmrk_ser_no); 
        pstmt.setString(3,po_rev_no); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLP04HRec 
* @return void 
* @author besTeam 
* @date 2006-6-28
*/
public void delete(GLP04HRec glp04h) throws Exception{
     delete(glp04h.getPo_no(), glp04h.getPo_rmrk_ser_no(), glp04h.getPo_rev_no());
} // end Delete

}// end GLP04HDBWrapBES class