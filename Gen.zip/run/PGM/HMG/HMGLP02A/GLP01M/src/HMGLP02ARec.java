package com.bes_line.mst.HMG ;

// Entity Class for HMGLP02A
/**
 *
 * @(#) HMGLP02A.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-21
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class HMGLP02ARec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String po_no; 		// (VARCHAR2, 12.0)
    public String po_stus_code; 		// (VARCHAR2, 1.0)
    public String po_rev_no; 		// (VARCHAR2, 2.0)
    public String vndr_grp_code; 		// (VARCHAR2, 4.0)
    public String vndr_name_chns; 		// (VARCHAR2, 100.0)
    public String curr_code; 		// (VARCHAR2, 2.0)
    public String curr_desc; 		// (VARCHAR2, 40.0)
    public double po_bilg_amt; 		// (NUMBER, 13.2)
    public String po_cfdt_last; 		// (VARCHAR2, 8.0)
    public String pay_term_code; 		// (VARCHAR2, 2.0)
    public String pay_term_code_desc; 		// (VARCHAR2, 80.0)
    public String advc_pay_indc; 		// (VARCHAR2, 1.0)
    public String dlvy_term_code; 		// (VARCHAR2, 3.0)
    public String dlvy_term_code_desc; 		// (VARCHAR2, 40.0)
    public String spmt_port_code; 		// (VARCHAR2, 3.0)
    public String spmt_port_desc; 		// (VARCHAR2, 80.0)
    public String arvl_code; 		// (VARCHAR2, 3.0)
    public String arvl_code_desc; 		// (VARCHAR2, 80.0)
    public String dlvy_plc_code; 		// (VARCHAR2, 3.0)
    public String dlvy_plc_code_desc; 		// (VARCHAR2, 80.0)
    public String po_type; 		// (VARCHAR2, 1.0)
    public String prdr_grp_code; 		// (VARCHAR2, 4.0)
    public String prdr_grp_code_desc; 		// (VARCHAR2, 100.0)
    public String ord_rank; 		// (VARCHAR2, 3.0)
    public int rmrk_last_ser_no; 		// (NUMBER, 2.0)
    public String buyr_id; 		// (VARCHAR2, 4.0)
    public String buyr_name_chns; 		// (VARCHAR2, 40.0)

public HMGLP02ARec(){ } // default constructor

public HMGLP02ARec(
       String po_no, String po_stus_code, String po_rev_no, String vndr_grp_code, String vndr_name_chns, String curr_code, 
       String curr_desc, double po_bilg_amt, String po_cfdt_last, String pay_term_code, String pay_term_code_desc, String advc_pay_indc, 
       String dlvy_term_code, String dlvy_term_code_desc, String spmt_port_code, String spmt_port_desc, String arvl_code, String arvl_code_desc, 
       String dlvy_plc_code, String dlvy_plc_code_desc, String po_type, String prdr_grp_code, String prdr_grp_code_desc, String ord_rank, 
       int rmrk_last_ser_no, String buyr_id, String buyr_name_chns){
    this.po_no = po_no;
    this.po_stus_code = po_stus_code;
    this.po_rev_no = po_rev_no;
    this.vndr_grp_code = vndr_grp_code;
    this.vndr_name_chns = vndr_name_chns;
    this.curr_code = curr_code;
    this.curr_desc = curr_desc;
    this.po_bilg_amt = po_bilg_amt;
    this.po_cfdt_last = po_cfdt_last;
    this.pay_term_code = pay_term_code;
    this.pay_term_code_desc = pay_term_code_desc;
    this.advc_pay_indc = advc_pay_indc;
    this.dlvy_term_code = dlvy_term_code;
    this.dlvy_term_code_desc = dlvy_term_code_desc;
    this.spmt_port_code = spmt_port_code;
    this.spmt_port_desc = spmt_port_desc;
    this.arvl_code = arvl_code;
    this.arvl_code_desc = arvl_code_desc;
    this.dlvy_plc_code = dlvy_plc_code;
    this.dlvy_plc_code_desc = dlvy_plc_code_desc;
    this.po_type = po_type;
    this.prdr_grp_code = prdr_grp_code;
    this.prdr_grp_code_desc = prdr_grp_code_desc;
    this.ord_rank = ord_rank;
    this.rmrk_last_ser_no = rmrk_last_ser_no;
    this.buyr_id = buyr_id;
    this.buyr_name_chns = buyr_name_chns;
} // Constructor


// Getter 
public String getPo_no(){ return po_no;}
public String getPo_stus_code(){ return po_stus_code;}
public String getPo_rev_no(){ return po_rev_no;}
public String getVndr_grp_code(){ return vndr_grp_code;}
public String getVndr_name_chns(){ return vndr_name_chns;}
public String getCurr_code(){ return curr_code;}
public String getCurr_desc(){ return curr_desc;}
public double getPo_bilg_amt(){ return po_bilg_amt;}
public String getPo_cfdt_last(){ return po_cfdt_last;}
public String getPay_term_code(){ return pay_term_code;}
public String getPay_term_code_desc(){ return pay_term_code_desc;}
public String getAdvc_pay_indc(){ return advc_pay_indc;}
public String getDlvy_term_code(){ return dlvy_term_code;}
public String getDlvy_term_code_desc(){ return dlvy_term_code_desc;}
public String getSpmt_port_code(){ return spmt_port_code;}
public String getSpmt_port_desc(){ return spmt_port_desc;}
public String getArvl_code(){ return arvl_code;}
public String getArvl_code_desc(){ return arvl_code_desc;}
public String getDlvy_plc_code(){ return dlvy_plc_code;}
public String getDlvy_plc_code_desc(){ return dlvy_plc_code_desc;}
public String getPo_type(){ return po_type;}
public String getPrdr_grp_code(){ return prdr_grp_code;}
public String getPrdr_grp_code_desc(){ return prdr_grp_code_desc;}
public String getOrd_rank(){ return ord_rank;}
public int getRmrk_last_ser_no(){ return rmrk_last_ser_no;}
public String getBuyr_id(){ return buyr_id;}
public String getBuyr_name_chns(){ return buyr_name_chns;}

// Setter 
public void setPo_no(String po_no){ this.po_no = po_no;}
public void setPo_stus_code(String po_stus_code){ this.po_stus_code = po_stus_code;}
public void setPo_rev_no(String po_rev_no){ this.po_rev_no = po_rev_no;}
public void setVndr_grp_code(String vndr_grp_code){ this.vndr_grp_code = vndr_grp_code;}
public void setVndr_name_chns(String vndr_name_chns){ this.vndr_name_chns = vndr_name_chns;}
public void setCurr_code(String curr_code){ this.curr_code = curr_code;}
public void setCurr_desc(String curr_desc){ this.curr_desc = curr_desc;}
public void setPo_bilg_amt(double po_bilg_amt){ this.po_bilg_amt = po_bilg_amt;}
public void setPo_cfdt_last(String po_cfdt_last){ this.po_cfdt_last = po_cfdt_last;}
public void setPay_term_code(String pay_term_code){ this.pay_term_code = pay_term_code;}
public void setPay_term_code_desc(String pay_term_code_desc){ this.pay_term_code_desc = pay_term_code_desc;}
public void setAdvc_pay_indc(String advc_pay_indc){ this.advc_pay_indc = advc_pay_indc;}
public void setDlvy_term_code(String dlvy_term_code){ this.dlvy_term_code = dlvy_term_code;}
public void setDlvy_term_code_desc(String dlvy_term_code_desc){ this.dlvy_term_code_desc = dlvy_term_code_desc;}
public void setSpmt_port_code(String spmt_port_code){ this.spmt_port_code = spmt_port_code;}
public void setSpmt_port_desc(String spmt_port_desc){ this.spmt_port_desc = spmt_port_desc;}
public void setArvl_code(String arvl_code){ this.arvl_code = arvl_code;}
public void setArvl_code_desc(String arvl_code_desc){ this.arvl_code_desc = arvl_code_desc;}
public void setDlvy_plc_code(String dlvy_plc_code){ this.dlvy_plc_code = dlvy_plc_code;}
public void setDlvy_plc_code_desc(String dlvy_plc_code_desc){ this.dlvy_plc_code_desc = dlvy_plc_code_desc;}
public void setPo_type(String po_type){ this.po_type = po_type;}
public void setPrdr_grp_code(String prdr_grp_code){ this.prdr_grp_code = prdr_grp_code;}
public void setPrdr_grp_code_desc(String prdr_grp_code_desc){ this.prdr_grp_code_desc = prdr_grp_code_desc;}
public void setOrd_rank(String ord_rank){ this.ord_rank = ord_rank;}
public void setRmrk_last_ser_no(int rmrk_last_ser_no){ this.rmrk_last_ser_no = rmrk_last_ser_no;}
public void setBuyr_id(String buyr_id){ this.buyr_id = buyr_id;}
public void setBuyr_name_chns(String buyr_name_chns){ this.buyr_name_chns = buyr_name_chns;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = po_no + "" ; break;
  case  2 : field = po_stus_code + "" ; break;
  case  3 : field = po_rev_no + "" ; break;
  case  4 : field = vndr_grp_code + "" ; break;
  case  5 : field = vndr_name_chns + "" ; break;
  case  6 : field = curr_code + "" ; break;
  case  7 : field = curr_desc + "" ; break;
  case  8 : field = po_bilg_amt + "" ; break;
  case  9 : field = po_cfdt_last + "" ; break;
  case  10 : field = pay_term_code + "" ; break;
  case  11 : field = pay_term_code_desc + "" ; break;
  case  12 : field = advc_pay_indc + "" ; break;
  case  13 : field = dlvy_term_code + "" ; break;
  case  14 : field = dlvy_term_code_desc + "" ; break;
  case  15 : field = spmt_port_code + "" ; break;
  case  16 : field = spmt_port_desc + "" ; break;
  case  17 : field = arvl_code + "" ; break;
  case  18 : field = arvl_code_desc + "" ; break;
  case  19 : field = dlvy_plc_code + "" ; break;
  case  20 : field = dlvy_plc_code_desc + "" ; break;
  case  21 : field = po_type + "" ; break;
  case  22 : field = prdr_grp_code + "" ; break;
  case  23 : field = prdr_grp_code_desc + "" ; break;
  case  24 : field = ord_rank + "" ; break;
  case  25 : field = rmrk_last_ser_no + "" ; break;
  case  26 : field = buyr_id + "" ; break;
  case  27 : field = buyr_name_chns + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("po_no")){ field = po_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_stus_code")){ field = po_stus_code + "" ; 
     } else if(rec.equalsIgnoreCase("po_rev_no")){ field = po_rev_no + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_grp_code")){ field = vndr_grp_code + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_name_chns")){ field = vndr_name_chns + "" ; 
     } else if(rec.equalsIgnoreCase("curr_code")){ field = curr_code + "" ; 
     } else if(rec.equalsIgnoreCase("curr_desc")){ field = curr_desc + "" ; 
     } else if(rec.equalsIgnoreCase("po_bilg_amt")){ field = po_bilg_amt + "" ; 
     } else if(rec.equalsIgnoreCase("po_cfdt_last")){ field = po_cfdt_last + "" ; 
     } else if(rec.equalsIgnoreCase("pay_term_code")){ field = pay_term_code + "" ; 
     } else if(rec.equalsIgnoreCase("pay_term_code_desc")){ field = pay_term_code_desc + "" ; 
     } else if(rec.equalsIgnoreCase("advc_pay_indc")){ field = advc_pay_indc + "" ; 
     } else if(rec.equalsIgnoreCase("dlvy_term_code")){ field = dlvy_term_code + "" ; 
     } else if(rec.equalsIgnoreCase("dlvy_term_code_desc")){ field = dlvy_term_code_desc + "" ; 
     } else if(rec.equalsIgnoreCase("spmt_port_code")){ field = spmt_port_code + "" ; 
     } else if(rec.equalsIgnoreCase("spmt_port_desc")){ field = spmt_port_desc + "" ; 
     } else if(rec.equalsIgnoreCase("arvl_code")){ field = arvl_code + "" ; 
     } else if(rec.equalsIgnoreCase("arvl_code_desc")){ field = arvl_code_desc + "" ; 
     } else if(rec.equalsIgnoreCase("dlvy_plc_code")){ field = dlvy_plc_code + "" ; 
     } else if(rec.equalsIgnoreCase("dlvy_plc_code_desc")){ field = dlvy_plc_code_desc + "" ; 
     } else if(rec.equalsIgnoreCase("po_type")){ field = po_type + "" ; 
     } else if(rec.equalsIgnoreCase("prdr_grp_code")){ field = prdr_grp_code + "" ; 
     } else if(rec.equalsIgnoreCase("prdr_grp_code_desc")){ field = prdr_grp_code_desc + "" ; 
     } else if(rec.equalsIgnoreCase("ord_rank")){ field = ord_rank + "" ; 
     } else if(rec.equalsIgnoreCase("rmrk_last_ser_no")){ field = rmrk_last_ser_no + "" ; 
     } else if(rec.equalsIgnoreCase("buyr_id")){ field = buyr_id + "" ; 
     } else if(rec.equalsIgnoreCase("buyr_name_chns")){ field = buyr_name_chns + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "PO_NO", "PO_STUS_CODE", "PO_REV_NO", "VNDR_GRP_CODE", "VNDR_NAME_CHNS", "CURR_CODE", "CURR_DESC", 
       "PO_BILG_AMT", "PO_CFDT_LAST", "PAY_TERM_CODE", "PAY_TERM_CODE_DESC", "ADVC_PAY_INDC", "DLVY_TERM_CODE", "DLVY_TERM_CODE_DESC", 
       "SPMT_PORT_CODE", "SPMT_PORT_DESC", "ARVL_CODE", "ARVL_CODE_DESC", "DLVY_PLC_CODE", "DLVY_PLC_CODE_DESC", "PO_TYPE", 
       "PRDR_GRP_CODE", "PRDR_GRP_CODE_DESC", "ORD_RANK", "RMRK_LAST_SER_NO", "BUYR_ID", "BUYR_NAME_CHNS"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "PO_NO"};
    return tempx;
}

}// end HMGLP02ARec class