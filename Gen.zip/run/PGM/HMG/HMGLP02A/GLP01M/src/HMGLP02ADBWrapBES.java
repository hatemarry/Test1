package com.bes_line.mst.HMG;

// DBWrapper Class for HMGLP02A
/**
 *
 * @(#) GLP01MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-21
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class HMGLP02ADBWrapBES extends DBWrapper{

public HMGLP02ADBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-21
*/
public java.util.Vector selectAllHMGLP02A(String whereOption,String sortOption) throws Exception{
    java.util.Vector hmglp02aV = new java.util.Vector();
    HMGLP02ARec hmglp02a = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = " SELECT PO_NO, PO_STUS_CODE, PO_REV_NO "
		+ " , VNDR_GRP_CODE , (SELECT VNDR_NAME_CHNS FROM HM.GLG05C WHERE VNDR_GRP_CODE = A.VNDR_GRP_CODE AND TRAD_INDC = 'Y') AS VNDR_NAME_CHNS "
		+ " , CURR_CODE, (SELECT CURR_DESC FROM HM.GLG03C WHERE CURR_CODE = A.CURR_CODE) AS CURR_DESC "
		+ " , PO_BILG_AMT, PO_CFDT_LAST "
		+ " , PAY_TERM_CODE, (SELECT PAY_TERM_CODE_DESC FROM HM.GLG09C WHERE PAY_TERM_CODE = A.PAY_TERM_CODE) AS PAY_TERM_CODE_DESC "
		+ " , ADVC_PAY_INDC "
		+ " , DLVY_TERM_CODE, (SELECT DLVY_TERM_CODE_DESC FROM HM.GLG07C WHERE DLVY_TERM_CODE = A.DLVY_TERM_CODE) AS DLVY_TERM_CODE_DESC "
		+ " , SPMT_PORT_CODE, (SELECT SPMT_PORT_DESC FROM HM.GLG08C WHERE SPMT_PORT_CODE = A.SPMT_PORT_CODE) AS SPMT_PORT_DESC "
		+ " , ARVL_CODE, (SELECT ARVL_CODE_DESC FROM HM.GLG11C WHERE ARVL_CODE = A.ARVL_CODE) AS ARVL_CODE_DESC "
		+ " , DLVY_PLC_CODE, (SELECT ARVL_CODE_DESC FROM HM.GLG11C WHERE ARVL_CODE = A.DLVY_PLC_CODE) AS DLVY_PLC_CODE_DESC "
		+ " , PO_TYPE, PRDR_GRP_CODE, (SELECT VNDR_NAME_CHNS FROM HM.GLG05C WHERE VNDR_GRP_CODE = A.VNDR_GRP_CODE AND TRAD_INDC = 'Y') AS PRDR_GRP_CODE_DESC "
		+ " , ORD_RANK, RMRK_LAST_SER_NO "
		+ " , BUYR_ID, (SELECT BUYR_NAME_CHNS FROM HM.GLG06C WHERE BUYR_ID = A.BUYR_ID) AS BUYR_NAME_CHNS "
		+ " FROM HM.GLP01M A "

        + whereOption; 
        if(sortOption.equals(""))  query += " order by  po_no " ;
        else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            hmglp02a = new HMGLP02ARec(); // HMGLP02ARec Constructor
                     hmglp02a.setPo_no(rs.getString("po_no"));
                     hmglp02a.setPo_stus_code(rs.getString("po_stus_code"));
                     hmglp02a.setPo_rev_no(rs.getString("po_rev_no"));
                     hmglp02a.setVndr_grp_code(rs.getString("vndr_grp_code"));
                     hmglp02a.setVndr_name_chns(rs.getString("vndr_name_chns"));
                     hmglp02a.setCurr_code(rs.getString("curr_code"));
                     hmglp02a.setCurr_desc(rs.getString("curr_desc"));
                     hmglp02a.setPo_bilg_amt(rs.getDouble("po_bilg_amt"));
                     hmglp02a.setPo_cfdt_last(rs.getString("po_cfdt_last"));
                     hmglp02a.setPay_term_code(rs.getString("pay_term_code"));
                     hmglp02a.setPay_term_code_desc(rs.getString("pay_term_code_desc"));
                     hmglp02a.setAdvc_pay_indc(rs.getString("advc_pay_indc"));
                     hmglp02a.setDlvy_term_code(rs.getString("dlvy_term_code"));
                     hmglp02a.setDlvy_term_code_desc(rs.getString("dlvy_term_code_desc"));
                     hmglp02a.setSpmt_port_code(rs.getString("spmt_port_code"));
                     hmglp02a.setSpmt_port_desc(rs.getString("spmt_port_desc"));
                     hmglp02a.setArvl_code(rs.getString("arvl_code"));
                     hmglp02a.setArvl_code_desc(rs.getString("arvl_code_desc"));
                     hmglp02a.setDlvy_plc_code(rs.getString("dlvy_plc_code"));
                     hmglp02a.setDlvy_plc_code_desc(rs.getString("dlvy_plc_code_desc"));
                     hmglp02a.setPo_type(rs.getString("po_type"));
                     hmglp02a.setPrdr_grp_code(rs.getString("prdr_grp_code"));
                     hmglp02a.setPrdr_grp_code_desc(rs.getString("prdr_grp_code_desc"));
                     hmglp02a.setOrd_rank(rs.getString("ord_rank"));
                     hmglp02a.setRmrk_last_ser_no(rs.getInt("rmrk_last_ser_no"));
                     hmglp02a.setBuyr_id(rs.getString("buyr_id"));
                     hmglp02a.setBuyr_name_chns(rs.getString("buyr_name_chns"));
            hmglp02aV.addElement(hmglp02a);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hmglp02aV;
} // end selectAll

/**
* Select
* @param String po_no
* @return HMGLP02ARec 
* @author besTeam 
* @date 2006-6-21
*/
public HMGLP02ARec selectHMGLP02A(String po_no) throws Exception{
    java.util.Vector HMGLP02AV = new java.util.Vector();
    HMGLP02ARec hmglp02a = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT PO_NO, PO_STUS_CODE, PO_REV_NO "
		+ " , VNDR_GRP_CODE , (SELECT VNDR_NAME_CHNS FROM HM.GLG05C WHERE VNDR_GRP_CODE = A.VNDR_GRP_CODE AND TRAD_INDC = 'Y') AS VNDR_NAME_CHNS "
		+ " , CURR_CODE, (SELECT CURR_DESC FROM HM.GLG03C WHERE CURR_CODE = A.CURR_CODE) AS CURR_DESC "
		+ " , PO_BILG_AMT, PO_CFDT_LAST "
		+ " , PAY_TERM_CODE, (SELECT PAY_TERM_CODE_DESC FROM HM.GLG09C WHERE PAY_TERM_CODE = A.PAY_TERM_CODE) AS PAY_TERM_CODE_DESC "
		+ " , ADVC_PAY_INDC "
		+ " , DLVY_TERM_CODE, (SELECT DLVY_TERM_CODE_DESC FROM HM.GLG07C WHERE DLVY_TERM_CODE = A.DLVY_TERM_CODE) AS DLVY_TERM_CODE_DESC "
		+ " , SPMT_PORT_CODE, (SELECT SPMT_PORT_DESC FROM HM.GLG08C WHERE SPMT_PORT_CODE = A.SPMT_PORT_CODE) AS SPMT_PORT_DESC "
		+ " , ARVL_CODE, (SELECT ARVL_CODE_DESC FROM HM.GLG11C WHERE ARVL_CODE = A.ARVL_CODE) AS ARVL_CODE_DESC "
		+ " , DLVY_PLC_CODE, (SELECT ARVL_CODE_DESC FROM HM.GLG11C WHERE ARVL_CODE = A.DLVY_PLC_CODE) AS DLVY_PLC_CODE_DESC "
		+ " , PO_TYPE, PRDR_GRP_CODE, (SELECT VNDR_NAME_CHNS FROM HM.GLG05C WHERE VNDR_GRP_CODE = A.VNDR_GRP_CODE AND TRAD_INDC = 'Y') AS PRDR_GRP_CODE_DESC "
		+ " , ORD_RANK, RMRK_LAST_SER_NO "
		+ " , BUYR_ID, (SELECT BUYR_NAME_CHNS FROM HM.GLG06C WHERE BUYR_ID = A.BUYR_ID) AS BUYR_NAME_CHNS "
		+ " FROM HM.GLP01M A "

       +" and po_no = ?  " ;
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        rs = pstmt.executeQuery();
        if(rs.next()) { 
            hmglp02a = new HMGLP02ARec(); // HMGLP02ARec Constructor
                     hmglp02a.setPo_no(rs.getString("po_no"));
                     hmglp02a.setPo_stus_code(rs.getString("po_stus_code"));
                     hmglp02a.setPo_rev_no(rs.getString("po_rev_no"));
                     hmglp02a.setVndr_grp_code(rs.getString("vndr_grp_code"));
                     hmglp02a.setVndr_name_chns(rs.getString("vndr_name_chns"));
                     hmglp02a.setCurr_code(rs.getString("curr_code"));
                     hmglp02a.setCurr_desc(rs.getString("curr_desc"));
                     hmglp02a.setPo_bilg_amt(rs.getDouble("po_bilg_amt"));
                     hmglp02a.setPo_cfdt_last(rs.getString("po_cfdt_last"));
                     hmglp02a.setPay_term_code(rs.getString("pay_term_code"));
                     hmglp02a.setPay_term_code_desc(rs.getString("pay_term_code_desc"));
                     hmglp02a.setAdvc_pay_indc(rs.getString("advc_pay_indc"));
                     hmglp02a.setDlvy_term_code(rs.getString("dlvy_term_code"));
                     hmglp02a.setDlvy_term_code_desc(rs.getString("dlvy_term_code_desc"));
                     hmglp02a.setSpmt_port_code(rs.getString("spmt_port_code"));
                     hmglp02a.setSpmt_port_desc(rs.getString("spmt_port_desc"));
                     hmglp02a.setArvl_code(rs.getString("arvl_code"));
                     hmglp02a.setArvl_code_desc(rs.getString("arvl_code_desc"));
                     hmglp02a.setDlvy_plc_code(rs.getString("dlvy_plc_code"));
                     hmglp02a.setDlvy_plc_code_desc(rs.getString("dlvy_plc_code_desc"));
                     hmglp02a.setPo_type(rs.getString("po_type"));
                     hmglp02a.setPrdr_grp_code(rs.getString("prdr_grp_code"));
                     hmglp02a.setPrdr_grp_code_desc(rs.getString("prdr_grp_code_desc"));
                     hmglp02a.setOrd_rank(rs.getString("ord_rank"));
                     hmglp02a.setRmrk_last_ser_no(rs.getInt("rmrk_last_ser_no"));
                     hmglp02a.setBuyr_id(rs.getString("buyr_id"));
                     hmglp02a.setBuyr_name_chns(rs.getString("buyr_name_chns"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hmglp02a;
} // end select

/**
* Get Rows Count 
* @param String po_no
* @return int 
* @author besTeam 
* @date 2006-6-21
*/
public int countHMGLP02A(String po_no) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " HM.GLG05C WHERE VNDR_GRP_CODE = A.VNDR_GRP_CODE AND TRAD_INDC = 'Y') AS VNDR_NAME_CHNS "
		+ " , CURR_CODE, (SELECT CURR_DESC FROM HM.GLG03C WHERE CURR_CODE = A.CURR_CODE) AS CURR_DESC "
		+ " , PO_BILG_AMT, PO_CFDT_LAST "
		+ " , PAY_TERM_CODE, (SELECT PAY_TERM_CODE_DESC FROM HM.GLG09C WHERE PAY_TERM_CODE = A.PAY_TERM_CODE) AS PAY_TERM_CODE_DESC "
		+ " , ADVC_PAY_INDC "
		+ " , DLVY_TERM_CODE, (SELECT DLVY_TERM_CODE_DESC FROM HM.GLG07C WHERE DLVY_TERM_CODE = A.DLVY_TERM_CODE) AS DLVY_TERM_CODE_DESC "
		+ " , SPMT_PORT_CODE, (SELECT SPMT_PORT_DESC FROM HM.GLG08C WHERE SPMT_PORT_CODE = A.SPMT_PORT_CODE) AS SPMT_PORT_DESC "
		+ " , ARVL_CODE, (SELECT ARVL_CODE_DESC FROM HM.GLG11C WHERE ARVL_CODE = A.ARVL_CODE) AS ARVL_CODE_DESC "
		+ " , DLVY_PLC_CODE, (SELECT ARVL_CODE_DESC FROM HM.GLG11C WHERE ARVL_CODE = A.DLVY_PLC_CODE) AS DLVY_PLC_CODE_DESC "
		+ " , PO_TYPE, PRDR_GRP_CODE, (SELECT VNDR_NAME_CHNS FROM HM.GLG05C WHERE VNDR_GRP_CODE = A.VNDR_GRP_CODE AND TRAD_INDC = 'Y') AS PRDR_GRP_CODE_DESC "
		+ " , ORD_RANK, RMRK_LAST_SER_NO "
		+ " , BUYR_ID, (SELECT BUYR_NAME_CHNS FROM HM.GLG06C WHERE BUYR_ID = A.BUYR_ID) AS BUYR_NAME_CHNS "
		+ " FROM HM.GLP01M A "

		+ " where po_no = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}