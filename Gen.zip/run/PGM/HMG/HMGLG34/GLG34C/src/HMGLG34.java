package com.bes_line.HMG;  
  
import org.jsn.jdf.*;  
import org.jsn.jdf.db.*;  
import org.jsn.jdf.jtx.*;  
import org.jsn.jdf.servlet.*;  
  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.io.*;  
import java.net.*;  
import java.util.Vector;  
  
import com.bes_line.mst.*;  
import com.bes_line.mst.HMG.*;  
import com.bes_line.base.*;  
  
public class HMGLG34 extends HttpServlet{  
  
public void init(ServletConfig sc) throws ServletException {  
    super.init(sc);  
} // init  
  
public void destroy(){  
    super.destroy();  
}// destory  
  
public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e ) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
  } // end try                     
}//end doGet  
  
public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
    } // try-catch  
}//end doPost  
  
//=============================================================================  
protected void performTask (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
String cmd = request.getParameter("cmd");  
try {        if ( cmd.equals( "add1_ok" ) )     { insertGLG34C(request, response);  
      } else if ( cmd.equals( "update1_ok" ) )  { updateGLG34C(request, response);   
      } else if ( cmd.equals( "delete1_ok" ) )  { deleteGLG34C(request, response);  
      } else if ( cmd.equals( "update1_list" ) )  { update1_list(request, response);  
      }  
 } catch(Throwable e ) {  
    e.printStackTrace(System.err);  
     System.err.flush();  
 } // end try  
}//end performTask  
  
//================================================================================  
public  void update1_list(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLG34/index.jsp" ;  
    String listJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLG34/list1.jsp" ;  
    String listCount = request.getParameter("listCount");   
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String trmid = request.getParameter("trmid");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String FBOM_NEED_RSN_CODE = BesUtil.chNull(request.getParameter("FBOM_NEED_RSN_CODE"));   
    callParameter += "&FBOM_NEED_RSN_CODE=" + FBOM_NEED_RSN_CODE;
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	String bom_need_rsn_code = "";
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
		GLG34CRec glg34c = new GLG34CRec() ; 
		GLG34CDBWrap glg34cdbw = new GLG34CDBWrap(resource); 
		for( int lc=1; lc<=Integer.parseInt(listCount); lc++ ) { 
			bom_need_rsn_code = request.getParameter("bom_need_rsn_code"+String.valueOf(lc)); 
			String check = request.getParameter("check__"+String.valueOf(lc));
			if(check == null || !check.equals("Y")) continue; 

			glg34c = glg34cdbw.select(bom_need_rsn_code); 
			Utility.fixNullAndTrim(glg34c); 
			glg34c.setBom_need_rsn_code(  request.getParameter("bom_need_rsn_code" + String.valueOf(lc))); 
			glg34cdbw.update(glg34c); 
		}
		tx.commit(); 
    } catch(Exception e) {  
		tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(listJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen=" + screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&bom_need_rsn_code="+bom_need_rsn_code) ; 
  
} // end updateGLG34C  
  
//================================================================================  
public  void insertGLG34C(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLG34/index.jsp" ;  
    String bom_need_rsn_code = box.getString("bom_need_rsn_code"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String FBOM_NEED_RSN_CODE = BesUtil.chNull(request.getParameter("FBOM_NEED_RSN_CODE"));   
    callParameter += "&FBOM_NEED_RSN_CODE=" + FBOM_NEED_RSN_CODE;
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	GLG34CRec glg34c = new GLG34CRec() ; 
	box.copyToEntity(glg34c); 
	Utility.fixNullAndTrim(glg34c); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	BesInit bi = new BesInit();  
	UserInfo ui = bi.checkSession(request , response); 
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        GLG34CDBWrap glg34cdbw = new GLG34CDBWrap(resource); 
/** 
 * ?????? ????? alert ?; ??? ??? ?? ?????? ???? 
 */ 
    int cnt = glg34cdbw.count(bom_need_rsn_code); 
	if(cnt == 0){ 
        // System Colulms.. 
        glg34c.setAdate(curdate); 
        glg34c.setAuser(usrid); 
        glg34c.setMdate(curdate); 
        glg34c.setMuser(usrid); 
		glg34cdbw.insert(glg34c); 
		tx.commit(); 
      response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&bom_need_rsn_code="+bom_need_rsn_code) ; 
    }else{ 
      tx.rollback(); 
      out.println("<script language='javascript'>"); 
      out.println("  alert('" + BesDBUtil.getMessage("bsc128",ui) + "');"); 
      out.println("  history.back(-1);"); 
      out.println("</script>"); 
    } 
    } catch(Exception e) {  
        tx.rollback(); 
        out.println(e.getMessage()+"<br>"+e.toString());  
        e.printStackTrace();  
        out.println(box.toString());  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
} // end insertGLG34C  
  
//================================================================================  
public  void updateGLG34C(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLG34/index.jsp" ;  
    String bom_need_rsn_code = box.getString("bom_need_rsn_code"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String FBOM_NEED_RSN_CODE = BesUtil.chNull(request.getParameter("FBOM_NEED_RSN_CODE"));   
    callParameter += "&FBOM_NEED_RSN_CODE=" + FBOM_NEED_RSN_CODE;
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
    GLG34CRec glg34cBox = new GLG34CRec() ; 
    box.copyToEntity(glg34cBox); 
    Utility.fixNullAndTrim(glg34cBox); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        GLG34CDBWrap glg34cdbw = new GLG34CDBWrap(resource); 
        GLG34CRec glg34c = glg34cdbw.select(bom_need_rsn_code);
         // System Colulms.. 
        glg34c.setMdate(curdate); 
        glg34c.setMuser(usrid); 
        // Editable Colulms.. 
        glg34cdbw.update(glg34c); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&bom_need_rsn_code="+bom_need_rsn_code) ; 
  
} // end updateGLG34C  
  
//================================================================================  
public  void deleteGLG34C(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLG34/index.jsp" ;  
    String bom_need_rsn_code = box.getString("bom_need_rsn_code"); 
    String screen = "addscreen";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String callParameter = "";
    String errMsg = "";
    String FBOM_NEED_RSN_CODE = BesUtil.chNull(request.getParameter("FBOM_NEED_RSN_CODE"));   
    callParameter += "&FBOM_NEED_RSN_CODE=" + FBOM_NEED_RSN_CODE;
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
  
    GLG34CRec glg34c = new GLG34CRec() ; 
    box.copyToEntity(glg34c); 
    Utility.fixNullAndTrim(glg34c); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        GLG34CDBWrap glg34cdbw = new GLG34CDBWrap(resource); 
        glg34cdbw.delete(glg34c); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8"));  
//================================================================================  
 } 
}// end Class  
