package com.bes_line.HMG;  
  
import org.jsn.jdf.*;  
import org.jsn.jdf.db.*;  
import org.jsn.jdf.jtx.*;  
import org.jsn.jdf.servlet.*;  
  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.io.*;  
import java.net.*;  
import java.util.Vector;  
  
import com.bes_line.mst.*;  
import com.bes_line.mst.HMG.*;  
import com.bes_line.base.*;  
  
public class HMGLG57 extends HttpServlet{  
  
public void init(ServletConfig sc) throws ServletException {  
    super.init(sc);  
} // init  
  
public void destroy(){  
    super.destroy();  
}// destory  
  
public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e ) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
  } // end try                     
}//end doGet  
  
public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
    } // try-catch  
}//end doPost  
  
//=============================================================================  
protected void performTask (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
String cmd = request.getParameter("cmd");  
try {        if ( cmd.equals( "add1_ok" ) )     { insertGLG57C(request, response);  
      } else if ( cmd.equals( "update1_ok" ) )  { updateGLG57C(request, response);   
      } else if ( cmd.equals( "delete1_ok" ) )  { deleteGLG57C(request, response);  
      } else if ( cmd.equals( "update1_list" ) )  { update1_list(request, response);  
      }  
 } catch(Throwable e ) {  
    e.printStackTrace(System.err);  
     System.err.flush();  
 } // end try  
}//end performTask  
  
//================================================================================  
public  void update1_list(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLG57/index.jsp" ;  
    String listJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLG57/list1.jsp" ;  
    String listCount = request.getParameter("listCount");   
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String trmid = request.getParameter("trmid");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String FPOR_REV_RSN_CODE = BesUtil.chNull(request.getParameter("FPOR_REV_RSN_CODE"));   
    callParameter += "&FPOR_REV_RSN_CODE=" + FPOR_REV_RSN_CODE;
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	String por_rev_rsn_code = "";
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
		GLG57CRec glg57c = new GLG57CRec() ; 
		GLG57CDBWrap glg57cdbw = new GLG57CDBWrap(resource); 
		for( int lc=1; lc<=Integer.parseInt(listCount); lc++ ) { 
			por_rev_rsn_code = request.getParameter("por_rev_rsn_code"+String.valueOf(lc)); 
			String check = request.getParameter("check__"+String.valueOf(lc));
			if(check == null || !check.equals("Y")) continue; 

			glg57c = glg57cdbw.select(por_rev_rsn_code); 
			Utility.fixNullAndTrim(glg57c); 
			glg57c.setPor_rev_rsn_code(  request.getParameter("por_rev_rsn_code" + String.valueOf(lc))); 
			glg57cdbw.update(glg57c); 
		}
		tx.commit(); 
    } catch(Exception e) {  
		tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(listJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen=" + screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&por_rev_rsn_code="+por_rev_rsn_code) ; 
  
} // end updateGLG57C  
  
//================================================================================  
public  void insertGLG57C(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLG57/index.jsp" ;  
    String por_rev_rsn_code = box.getString("por_rev_rsn_code"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String FPOR_REV_RSN_CODE = BesUtil.chNull(request.getParameter("FPOR_REV_RSN_CODE"));   
    callParameter += "&FPOR_REV_RSN_CODE=" + FPOR_REV_RSN_CODE;
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	GLG57CRec glg57c = new GLG57CRec() ; 
	box.copyToEntity(glg57c); 
	Utility.fixNullAndTrim(glg57c); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	BesInit bi = new BesInit();  
	UserInfo ui = bi.checkSession(request , response); 
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        GLG57CDBWrap glg57cdbw = new GLG57CDBWrap(resource); 
/** 
 * ?????? ????? alert ?; ??? ??? ?? ?????? ???? 
 */ 
    int cnt = glg57cdbw.count(por_rev_rsn_code); 
	if(cnt == 0){ 
        // System Colulms.. 
        glg57c.setAdate(curdate); 
        glg57c.setAuser(usrid); 
        glg57c.setMdate(curdate); 
        glg57c.setMuser(usrid); 
		glg57cdbw.insert(glg57c); 
		tx.commit(); 
      response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&por_rev_rsn_code="+por_rev_rsn_code) ; 
    }else{ 
      tx.rollback(); 
      out.println("<script language='javascript'>"); 
      out.println("  alert('" + BesDBUtil.getMessage("bsc128",ui) + "');"); 
      out.println("  history.back(-1);"); 
      out.println("</script>"); 
    } 
    } catch(Exception e) {  
        tx.rollback(); 
        out.println(e.getMessage()+"<br>"+e.toString());  
        e.printStackTrace();  
        out.println(box.toString());  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
} // end insertGLG57C  
  
//================================================================================  
public  void updateGLG57C(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLG57/index.jsp" ;  
    String por_rev_rsn_code = box.getString("por_rev_rsn_code"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String FPOR_REV_RSN_CODE = BesUtil.chNull(request.getParameter("FPOR_REV_RSN_CODE"));   
    callParameter += "&FPOR_REV_RSN_CODE=" + FPOR_REV_RSN_CODE;
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
    GLG57CRec glg57cBox = new GLG57CRec() ; 
    box.copyToEntity(glg57cBox); 
    Utility.fixNullAndTrim(glg57cBox); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        GLG57CDBWrap glg57cdbw = new GLG57CDBWrap(resource); 
        GLG57CRec glg57c = glg57cdbw.select(por_rev_rsn_code);
         // System Colulms.. 
        glg57c.setMdate(curdate); 
        glg57c.setMuser(usrid); 
        // Editable Colulms.. 
        glg57cdbw.update(glg57c); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&por_rev_rsn_code="+por_rev_rsn_code) ; 
  
} // end updateGLG57C  
  
//================================================================================  
public  void deleteGLG57C(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLG57/index.jsp" ;  
    String por_rev_rsn_code = box.getString("por_rev_rsn_code"); 
    String screen = "addscreen";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String callParameter = "";
    String errMsg = "";
    String FPOR_REV_RSN_CODE = BesUtil.chNull(request.getParameter("FPOR_REV_RSN_CODE"));   
    callParameter += "&FPOR_REV_RSN_CODE=" + FPOR_REV_RSN_CODE;
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
  
    GLG57CRec glg57c = new GLG57CRec() ; 
    box.copyToEntity(glg57c); 
    Utility.fixNullAndTrim(glg57c); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        GLG57CDBWrap glg57cdbw = new GLG57CDBWrap(resource); 
        glg57cdbw.delete(glg57c); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8"));  
//================================================================================  
 } 
}// end Class  
