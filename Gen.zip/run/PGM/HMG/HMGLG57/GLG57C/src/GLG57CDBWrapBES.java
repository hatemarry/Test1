package com.bes_line.mst.HMG;

// DBWrapper Class for GLG57C
/**
 *
 * @(#) GLG57CDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-7-26
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLG57CDBWrapBES extends DBWrapper{

public GLG57CDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String por_rev_rsn_code
* @return GLG57CRec 
* @author besTeam 
* @date 2006-7-26
*/
public GLG57CRec select(String por_rev_rsn_code) throws Exception{
    java.util.Vector glg57cV = new java.util.Vector();
    GLG57CRec glg57c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select por_rev_rsn_code, por_rev_rsn_code_desc " +
                       "  from HM.GLG57C  " +
                       "  where por_rev_rsn_code = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,por_rev_rsn_code); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            glg57c = new GLG57CRec(); // GLG57CRec Constructor
                     glg57c.setPor_rev_rsn_code(rs.getString("por_rev_rsn_code"));
                     glg57c.setPor_rev_rsn_code_desc(rs.getString("por_rev_rsn_code_desc"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg57c;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-7-26
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glg57cV = new java.util.Vector();
    GLG57CRec glg57c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select por_rev_rsn_code, por_rev_rsn_code_desc " +
                       "  from HM.GLG57C "+
                       "  order by por_rev_rsn_code ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glg57c = new GLG57CRec(); // GLG57CRec Constructor
                     glg57c.setPor_rev_rsn_code(rs.getString("por_rev_rsn_code"));
                     glg57c.setPor_rev_rsn_code_desc(rs.getString("por_rev_rsn_code_desc"));
            glg57cV.addElement(glg57c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg57cV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-7-26
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glg57cV = new java.util.Vector();
    GLG57CRec glg57c = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select por_rev_rsn_code, por_rev_rsn_code_desc " +
                       "  from HM.GLG57C  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  por_rev_rsn_code " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glg57c = new GLG57CRec(); // GLG57CRec Constructor
                     glg57c.setPor_rev_rsn_code(rs.getString("por_rev_rsn_code"));
                     glg57c.setPor_rev_rsn_code_desc(rs.getString("por_rev_rsn_code_desc"));
            glg57cV.addElement(glg57c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg57cV;
} // end selectAll

/**
* Get Rows Count 
* @param String por_rev_rsn_code
* @return int 
* @author besTeam 
* @date 2006-7-26
*/
public int count(String por_rev_rsn_code) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLG57C " +
                       " where por_rev_rsn_code = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,por_rev_rsn_code); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-7-26
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLG57C  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLG57CRec 
* @return void 
* @author besTeam 
* @date 2006-7-26
*/
public void insert(GLG57CRec glg57c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLG57C( " +
                              "por_rev_rsn_code, por_rev_rsn_code_desc"+
                       " ) values ( "+
                              "?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glg57c.getPor_rev_rsn_code());
        pstmt.setString(2, glg57c.getPor_rev_rsn_code_desc());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLG57CRec 
* @return void 
* @author besTeam 
* @date 2006-7-26
*/
public void update(GLG57CRec glg57c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLG57C SET "+
                        "por_rev_rsn_code = ?, por_rev_rsn_code_desc = ?"+
                        " where por_rev_rsn_code = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glg57c.getPor_rev_rsn_code());
        pstmt.setString(2, glg57c.getPor_rev_rsn_code_desc());
        // Key
        pstmt.setString(3, glg57c.getPor_rev_rsn_code());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String por_rev_rsn_code
* @return void 
* @author besTeam 
* @date 2006-7-26
*/
public void delete(String por_rev_rsn_code) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLG57C "+
                       "where por_rev_rsn_code = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,por_rev_rsn_code); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLG57CRec 
* @return void 
* @author besTeam 
* @date 2006-7-26
*/
public void delete(GLG57CRec glg57c) throws Exception{
     delete(glg57c.getPor_rev_rsn_code());
} // end Delete

}// end GLG57CDBWrapBES class