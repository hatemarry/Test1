package com.bes_line.mst.HMG ;

// Entity Class for GLG57C
/**
 *
 * @(#) GLG57CRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-7-26
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLG57CRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String por_rev_rsn_code; 		// (VARCHAR2, 2.0)
    public String por_rev_rsn_code_desc; 		// (VARCHAR2, 40.0)

public GLG57CRec(){ } // default constructor

public GLG57CRec(
       String por_rev_rsn_code, String por_rev_rsn_code_desc){
    this.por_rev_rsn_code = por_rev_rsn_code;
    this.por_rev_rsn_code_desc = por_rev_rsn_code_desc;
} // Constructor


// Getter 
public String getPor_rev_rsn_code(){ return por_rev_rsn_code;}
public String getPor_rev_rsn_code_desc(){ return por_rev_rsn_code_desc;}

// Setter 
public void setPor_rev_rsn_code(String por_rev_rsn_code){ this.por_rev_rsn_code = por_rev_rsn_code;}
public void setPor_rev_rsn_code_desc(String por_rev_rsn_code_desc){ this.por_rev_rsn_code_desc = por_rev_rsn_code_desc;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = por_rev_rsn_code + "" ; break;
  case  2 : field = por_rev_rsn_code_desc + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("por_rev_rsn_code")){ field = por_rev_rsn_code + "" ; 
     } else if(rec.equalsIgnoreCase("por_rev_rsn_code_desc")){ field = por_rev_rsn_code_desc + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "POR_REV_RSN_CODE", "POR_REV_RSN_CODE_DESC"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "POR_REV_RSN_CODE"};
    return tempx;
}

}// end GLG57CRec class