package com.bes_line.mst.HMG ;

// Entity Class for GLP03C
/**
 *
 * @(#) GLP03CRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLP03CRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String po_no; 		// (VARCHAR2, 12.0)
    public String po_rmrk_ser_no; 		// (VARCHAR2, 2.0)
    public String po_rmrk_chns; 		// (VARCHAR2, 150.0)
    public String rev_no_old; 		// (VARCHAR2, 2.0)
    public String rev_no_new; 		// (VARCHAR2, 2.0)

public GLP03CRec(){ } // default constructor

public GLP03CRec(
       String po_no, String po_rmrk_ser_no, String po_rmrk_chns, String rev_no_old, String rev_no_new){
    this.po_no = po_no;
    this.po_rmrk_ser_no = po_rmrk_ser_no;
    this.po_rmrk_chns = po_rmrk_chns;
    this.rev_no_old = rev_no_old;
    this.rev_no_new = rev_no_new;
} // Constructor


// Getter 
public String getPo_no(){ return po_no;}
public String getPo_rmrk_ser_no(){ return po_rmrk_ser_no;}
public String getPo_rmrk_chns(){ return po_rmrk_chns;}
public String getRev_no_old(){ return rev_no_old;}
public String getRev_no_new(){ return rev_no_new;}

// Setter 
public void setPo_no(String po_no){ this.po_no = po_no;}
public void setPo_rmrk_ser_no(String po_rmrk_ser_no){ this.po_rmrk_ser_no = po_rmrk_ser_no;}
public void setPo_rmrk_chns(String po_rmrk_chns){ this.po_rmrk_chns = po_rmrk_chns;}
public void setRev_no_old(String rev_no_old){ this.rev_no_old = rev_no_old;}
public void setRev_no_new(String rev_no_new){ this.rev_no_new = rev_no_new;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = po_no + "" ; break;
  case  2 : field = po_rmrk_ser_no + "" ; break;
  case  3 : field = po_rmrk_chns + "" ; break;
  case  4 : field = rev_no_old + "" ; break;
  case  5 : field = rev_no_new + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("po_no")){ field = po_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_rmrk_ser_no")){ field = po_rmrk_ser_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_rmrk_chns")){ field = po_rmrk_chns + "" ; 
     } else if(rec.equalsIgnoreCase("rev_no_old")){ field = rev_no_old + "" ; 
     } else if(rec.equalsIgnoreCase("rev_no_new")){ field = rev_no_new + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "PO_NO", "PO_RMRK_SER_NO", "PO_RMRK_CHNS", "REV_NO_OLD", "REV_NO_NEW"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "PO_NO", "PO_RMRK_SER_NO"};
    return tempx;
}

}// end GLP03CRec class