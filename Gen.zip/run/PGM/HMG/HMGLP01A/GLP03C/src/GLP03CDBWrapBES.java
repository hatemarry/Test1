package com.bes_line.mst.HMG;

// DBWrapper Class for GLP03C
/**
 *
 * @(#) GLP03CDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLP03CDBWrapBES extends DBWrapper{

public GLP03CDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String po_no, String po_rmrk_ser_no
* @return GLP03CRec 
* @author besTeam 
* @date 2006-6-15
*/
public GLP03CRec select(String po_no, String po_rmrk_ser_no) throws Exception{
    java.util.Vector glp03cV = new java.util.Vector();
    GLP03CRec glp03c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_rmrk_ser_no, po_rmrk_chns, rev_no_old, rev_no_new " +
                       "  from HM.GLP03C  " +
                       "  where po_no = ? and po_rmrk_ser_no = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_rmrk_ser_no); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            glp03c = new GLP03CRec(); // GLP03CRec Constructor
                     glp03c.setPo_no(rs.getString("po_no"));
                     glp03c.setPo_rmrk_ser_no(rs.getString("po_rmrk_ser_no"));
                     glp03c.setPo_rmrk_chns(rs.getString("po_rmrk_chns"));
                     glp03c.setRev_no_old(rs.getString("rev_no_old"));
                     glp03c.setRev_no_new(rs.getString("rev_no_new"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp03c;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glp03cV = new java.util.Vector();
    GLP03CRec glp03c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_rmrk_ser_no, po_rmrk_chns, rev_no_old, rev_no_new " +
                       "  from HM.GLP03C "+
                       "  order by po_no , po_rmrk_ser_no ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp03c = new GLP03CRec(); // GLP03CRec Constructor
                     glp03c.setPo_no(rs.getString("po_no"));
                     glp03c.setPo_rmrk_ser_no(rs.getString("po_rmrk_ser_no"));
                     glp03c.setPo_rmrk_chns(rs.getString("po_rmrk_chns"));
                     glp03c.setRev_no_old(rs.getString("rev_no_old"));
                     glp03c.setRev_no_new(rs.getString("rev_no_new"));
            glp03cV.addElement(glp03c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp03cV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glp03cV = new java.util.Vector();
    GLP03CRec glp03c = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_rmrk_ser_no, po_rmrk_chns, rev_no_old, rev_no_new " +
                       "  from HM.GLP03C  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  po_no " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp03c = new GLP03CRec(); // GLP03CRec Constructor
                     glp03c.setPo_no(rs.getString("po_no"));
                     glp03c.setPo_rmrk_ser_no(rs.getString("po_rmrk_ser_no"));
                     glp03c.setPo_rmrk_chns(rs.getString("po_rmrk_chns"));
                     glp03c.setRev_no_old(rs.getString("rev_no_old"));
                     glp03c.setRev_no_new(rs.getString("rev_no_new"));
            glp03cV.addElement(glp03c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp03cV;
} // end selectAll

/**
* Get Rows Count 
* @param String po_no, String po_rmrk_ser_no
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int count(String po_no, String po_rmrk_ser_no) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP03C " +
                       " where po_no = ? and po_rmrk_ser_no = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_rmrk_ser_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP03C  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLP03CRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void insert(GLP03CRec glp03c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLP03C( " +
                              "po_no, po_rmrk_ser_no, po_rmrk_chns, rev_no_old, rev_no_new"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp03c.getPo_no());
        pstmt.setString(2, glp03c.getPo_rmrk_ser_no());
        pstmt.setString(3, glp03c.getPo_rmrk_chns());
        pstmt.setString(4, glp03c.getRev_no_old());
        pstmt.setString(5, glp03c.getRev_no_new());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLP03CRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void update(GLP03CRec glp03c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLP03C SET "+
                        "po_no = ?, po_rmrk_ser_no = ?, po_rmrk_chns = ?, rev_no_old = ?, rev_no_new = ?"+
                        " where po_no = ? and po_rmrk_ser_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp03c.getPo_no());
        pstmt.setString(2, glp03c.getPo_rmrk_ser_no());
        pstmt.setString(3, glp03c.getPo_rmrk_chns());
        pstmt.setString(4, glp03c.getRev_no_old());
        pstmt.setString(5, glp03c.getRev_no_new());
        // Key
        pstmt.setString(6, glp03c.getPo_no());
        pstmt.setString(7, glp03c.getPo_rmrk_ser_no());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String po_no, String po_rmrk_ser_no
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(String po_no, String po_rmrk_ser_no) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLP03C "+
                       "where po_no = ? and po_rmrk_ser_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_rmrk_ser_no); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLP03CRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(GLP03CRec glp03c) throws Exception{
     delete(glp03c.getPo_no(), glp03c.getPo_rmrk_ser_no());
} // end Delete

}// end GLP03CDBWrapBES class