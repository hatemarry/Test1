package com.bes_line.mst.HMG ;

// Entity Class for GLG06C
/**
 *
 * @(#) GLG06CRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-14
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLG06CRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String buyr_id; 		// (VARCHAR2, 4.0)
    public String buyr_name_chns; 		// (VARCHAR2, 40.0)
    public String emp_no; 		// (VARCHAR2, 7.0)
    public String buyr_name_engl; 		// (VARCHAR2, 16.0)
    public String buyr_sect_code; 		// (VARCHAR2, 4.0)
    public String tel_no; 		// (VARCHAR2, 8.0)
    public String rgdt; 		// (VARCHAR2, 8.0)
    public String po_gen_y; 		// (VARCHAR2, 1.0)
    public int po_last_ser_no; 		// (NUMBER, 5.0)

public GLG06CRec(){ } // default constructor

public GLG06CRec(
       String buyr_id, String buyr_name_chns, String emp_no, String buyr_name_engl, String buyr_sect_code, String tel_no, 
       String rgdt, String po_gen_y, int po_last_ser_no){
    this.buyr_id = buyr_id;
    this.buyr_name_chns = buyr_name_chns;
    this.emp_no = emp_no;
    this.buyr_name_engl = buyr_name_engl;
    this.buyr_sect_code = buyr_sect_code;
    this.tel_no = tel_no;
    this.rgdt = rgdt;
    this.po_gen_y = po_gen_y;
    this.po_last_ser_no = po_last_ser_no;
} // Constructor


// Getter 
public String getBuyr_id(){ return buyr_id;}
public String getBuyr_name_chns(){ return buyr_name_chns;}
public String getEmp_no(){ return emp_no;}
public String getBuyr_name_engl(){ return buyr_name_engl;}
public String getBuyr_sect_code(){ return buyr_sect_code;}
public String getTel_no(){ return tel_no;}
public String getRgdt(){ return rgdt;}
public String getPo_gen_y(){ return po_gen_y;}
public int getPo_last_ser_no(){ return po_last_ser_no;}

// Setter 
public void setBuyr_id(String buyr_id){ this.buyr_id = buyr_id;}
public void setBuyr_name_chns(String buyr_name_chns){ this.buyr_name_chns = buyr_name_chns;}
public void setEmp_no(String emp_no){ this.emp_no = emp_no;}
public void setBuyr_name_engl(String buyr_name_engl){ this.buyr_name_engl = buyr_name_engl;}
public void setBuyr_sect_code(String buyr_sect_code){ this.buyr_sect_code = buyr_sect_code;}
public void setTel_no(String tel_no){ this.tel_no = tel_no;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}
public void setPo_gen_y(String po_gen_y){ this.po_gen_y = po_gen_y;}
public void setPo_last_ser_no(int po_last_ser_no){ this.po_last_ser_no = po_last_ser_no;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = buyr_id + "" ; break;
  case  2 : field = buyr_name_chns + "" ; break;
  case  3 : field = emp_no + "" ; break;
  case  4 : field = buyr_name_engl + "" ; break;
  case  5 : field = buyr_sect_code + "" ; break;
  case  6 : field = tel_no + "" ; break;
  case  7 : field = rgdt + "" ; break;
  case  8 : field = po_gen_y + "" ; break;
  case  9 : field = po_last_ser_no + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("buyr_id")){ field = buyr_id + "" ; 
     } else if(rec.equalsIgnoreCase("buyr_name_chns")){ field = buyr_name_chns + "" ; 
     } else if(rec.equalsIgnoreCase("emp_no")){ field = emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("buyr_name_engl")){ field = buyr_name_engl + "" ; 
     } else if(rec.equalsIgnoreCase("buyr_sect_code")){ field = buyr_sect_code + "" ; 
     } else if(rec.equalsIgnoreCase("tel_no")){ field = tel_no + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("po_gen_y")){ field = po_gen_y + "" ; 
     } else if(rec.equalsIgnoreCase("po_last_ser_no")){ field = po_last_ser_no + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "BUYR_ID", "BUYR_NAME_CHNS", "EMP_NO", "BUYR_NAME_ENGL", "BUYR_SECT_CODE", "TEL_NO", "RGDT", 
       "PO_GEN_Y", "PO_LAST_SER_NO"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "BUYR_ID"};
    return tempx;
}

}// end GLG06CRec class