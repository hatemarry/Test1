package com.bes_line.mst.HMG;

// DBWrapper Class for GLG06C
/**
 *
 * @(#) GLG06CDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-14
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLG06CDBWrapBES extends DBWrapper{

public GLG06CDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String buyr_id
* @return GLG06CRec 
* @author besTeam 
* @date 2006-6-14
*/
public GLG06CRec select(String buyr_id) throws Exception{
    java.util.Vector glg06cV = new java.util.Vector();
    GLG06CRec glg06c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select buyr_id, buyr_name_chns, emp_no, buyr_name_engl, buyr_sect_code, tel_no, rgdt, po_gen_y, po_last_ser_no " +
                       "  from HM.GLG06C  " +
                       "  where buyr_id = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,buyr_id); 
        rs = pstmt.executeQuery();
        while(rs.next()) { 
            glg06c = new GLG06CRec(); // GLG06CRec Constructor
                     glg06c.setBuyr_id(rs.getString("buyr_id"));
                     glg06c.setBuyr_name_chns(rs.getString("buyr_name_chns"));
                     glg06c.setEmp_no(rs.getString("emp_no"));
                     glg06c.setBuyr_name_engl(rs.getString("buyr_name_engl"));
                     glg06c.setBuyr_sect_code(rs.getString("buyr_sect_code"));
                     glg06c.setTel_no(rs.getString("tel_no"));
                     glg06c.setRgdt(rs.getString("rgdt"));
                     glg06c.setPo_gen_y(rs.getString("po_gen_y"));
                     glg06c.setPo_last_ser_no(rs.getInt("po_last_ser_no"));
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg06c;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-14
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glg06cV = new java.util.Vector();
    GLG06CRec glg06c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select buyr_id, buyr_name_chns, emp_no, buyr_name_engl, buyr_sect_code, tel_no, rgdt, po_gen_y, po_last_ser_no " +
                       "  from HM.GLG06C "+
                       "  order by buyr_id ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glg06c = new GLG06CRec(); // GLG06CRec Constructor
                     glg06c.setBuyr_id(rs.getString("buyr_id"));
                     glg06c.setBuyr_name_chns(rs.getString("buyr_name_chns"));
                     glg06c.setEmp_no(rs.getString("emp_no"));
                     glg06c.setBuyr_name_engl(rs.getString("buyr_name_engl"));
                     glg06c.setBuyr_sect_code(rs.getString("buyr_sect_code"));
                     glg06c.setTel_no(rs.getString("tel_no"));
                     glg06c.setRgdt(rs.getString("rgdt"));
                     glg06c.setPo_gen_y(rs.getString("po_gen_y"));
                     glg06c.setPo_last_ser_no(rs.getInt("po_last_ser_no"));
            glg06cV.addElement(glg06c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg06cV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-14
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glg06cV = new java.util.Vector();
    GLG06CRec glg06c = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select buyr_id, buyr_name_chns, emp_no, buyr_name_engl, buyr_sect_code, tel_no, rgdt, po_gen_y, po_last_ser_no " +
                       "  from HM.GLG06C  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  buyr_id " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glg06c = new GLG06CRec(); // GLG06CRec Constructor
                     glg06c.setBuyr_id(rs.getString("buyr_id"));
                     glg06c.setBuyr_name_chns(rs.getString("buyr_name_chns"));
                     glg06c.setEmp_no(rs.getString("emp_no"));
                     glg06c.setBuyr_name_engl(rs.getString("buyr_name_engl"));
                     glg06c.setBuyr_sect_code(rs.getString("buyr_sect_code"));
                     glg06c.setTel_no(rs.getString("tel_no"));
                     glg06c.setRgdt(rs.getString("rgdt"));
                     glg06c.setPo_gen_y(rs.getString("po_gen_y"));
                     glg06c.setPo_last_ser_no(rs.getInt("po_last_ser_no"));
            glg06cV.addElement(glg06c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg06cV;
} // end selectAll

/**
* Get Rows Count 
* @param String buyr_id
* @return int 
* @author besTeam 
* @date 2006-6-14
*/
public int count(String buyr_id) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLG06C " +
                       " where buyr_id = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,buyr_id); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-14
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLG06C  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLG06CRec 
* @return void 
* @author besTeam 
* @date 2006-6-14
*/
public void insert(GLG06CRec glg06c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLG06C( " +
                              "buyr_id, buyr_name_chns, emp_no, buyr_name_engl, buyr_sect_code, tel_no, rgdt, po_gen_y, po_last_ser_no"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glg06c.getBuyr_id());
        pstmt.setString(2, glg06c.getBuyr_name_chns());
        pstmt.setString(3, glg06c.getEmp_no());
        pstmt.setString(4, glg06c.getBuyr_name_engl());
        pstmt.setString(5, glg06c.getBuyr_sect_code());
        pstmt.setString(6, glg06c.getTel_no());
        pstmt.setString(7, glg06c.getRgdt());
        pstmt.setString(8, glg06c.getPo_gen_y());
        pstmt.setInt(9, glg06c.getPo_last_ser_no());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLG06CRec 
* @return void 
* @author besTeam 
* @date 2006-6-14
*/
public void update(GLG06CRec glg06c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLG06C SET "+
                        "buyr_id = ?, buyr_name_chns = ?, emp_no = ?, buyr_name_engl = ?, buyr_sect_code = ?, tel_no = ?, rgdt = ?, po_gen_y = ?, po_last_ser_no = ?"+
                        " where buyr_id = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glg06c.getBuyr_id());
        pstmt.setString(2, glg06c.getBuyr_name_chns());
        pstmt.setString(3, glg06c.getEmp_no());
        pstmt.setString(4, glg06c.getBuyr_name_engl());
        pstmt.setString(5, glg06c.getBuyr_sect_code());
        pstmt.setString(6, glg06c.getTel_no());
        pstmt.setString(7, glg06c.getRgdt());
        pstmt.setString(8, glg06c.getPo_gen_y());
        pstmt.setInt(9, glg06c.getPo_last_ser_no());
        // Key
        pstmt.setString(10, glg06c.getBuyr_id());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String buyr_id
* @return void 
* @author besTeam 
* @date 2006-6-14
*/
public void delete(String buyr_id) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLG06C "+
                       "where buyr_id = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,buyr_id); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLG06CRec 
* @return void 
* @author besTeam 
* @date 2006-6-14
*/
public void delete(GLG06CRec glg06c) throws Exception{
     delete(glg06c.getBuyr_id());
} // end Delete

}// end GLG06CDBWrapBES class