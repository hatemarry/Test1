package com.bes_line.mst.HMG;

// DBWrapper's Wrapper  Class for GLG06C
/**
 *
 * @(#) GLG06CDBWrap.java
 * Copyright 1999-2001 by Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-14
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLG06CDBWrap extends GLG06CDBWrapBES{
public GLG06CDBWrap(ConnectionContext ctx){
    super(ctx);
} // Constructor



////////////////// User Define Code Start //////////////////


//****** You should delete this line when you edit this source ^&*%%^%%(*&%(^%(*^^ 

////////////////// User Define  Code  End //////////////////

}// end  class