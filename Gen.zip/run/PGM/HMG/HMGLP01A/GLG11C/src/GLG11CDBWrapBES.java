package com.bes_line.mst.HMG;

// DBWrapper Class for GLG11C
/**
 *
 * @(#) GLG11CDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLG11CDBWrapBES extends DBWrapper{

public GLG11CDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String arvl_code
* @return GLG11CRec 
* @author besTeam 
* @date 2006-6-15
*/
public GLG11CRec select(String arvl_code) throws Exception{
    java.util.Vector glg11cV = new java.util.Vector();
    GLG11CRec glg11c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select arvl_code, arvl_code_desc, rgdt, aply_po_type " +
                       "  from HM.GLG11C  " +
                       "  where arvl_code = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,arvl_code); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            glg11c = new GLG11CRec(); // GLG11CRec Constructor
                     glg11c.setArvl_code(rs.getString("arvl_code"));
                     glg11c.setArvl_code_desc(rs.getString("arvl_code_desc"));
                     glg11c.setRgdt(rs.getString("rgdt"));
                     glg11c.setAply_po_type(rs.getString("aply_po_type"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg11c;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glg11cV = new java.util.Vector();
    GLG11CRec glg11c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select arvl_code, arvl_code_desc, rgdt, aply_po_type " +
                       "  from HM.GLG11C "+
                       "  order by arvl_code ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glg11c = new GLG11CRec(); // GLG11CRec Constructor
                     glg11c.setArvl_code(rs.getString("arvl_code"));
                     glg11c.setArvl_code_desc(rs.getString("arvl_code_desc"));
                     glg11c.setRgdt(rs.getString("rgdt"));
                     glg11c.setAply_po_type(rs.getString("aply_po_type"));
            glg11cV.addElement(glg11c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg11cV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glg11cV = new java.util.Vector();
    GLG11CRec glg11c = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select arvl_code, arvl_code_desc, rgdt, aply_po_type " +
                       "  from HM.GLG11C  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  arvl_code " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glg11c = new GLG11CRec(); // GLG11CRec Constructor
                     glg11c.setArvl_code(rs.getString("arvl_code"));
                     glg11c.setArvl_code_desc(rs.getString("arvl_code_desc"));
                     glg11c.setRgdt(rs.getString("rgdt"));
                     glg11c.setAply_po_type(rs.getString("aply_po_type"));
            glg11cV.addElement(glg11c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg11cV;
} // end selectAll

/**
* Get Rows Count 
* @param String arvl_code
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int count(String arvl_code) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLG11C " +
                       " where arvl_code = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,arvl_code); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLG11C  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLG11CRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void insert(GLG11CRec glg11c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLG11C( " +
                              "arvl_code, arvl_code_desc, rgdt, aply_po_type"+
                       " ) values ( "+
                              "?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glg11c.getArvl_code());
        pstmt.setString(2, glg11c.getArvl_code_desc());
        pstmt.setString(3, glg11c.getRgdt());
        pstmt.setString(4, glg11c.getAply_po_type());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLG11CRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void update(GLG11CRec glg11c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLG11C SET "+
                        "arvl_code = ?, arvl_code_desc = ?, rgdt = ?, aply_po_type = ?"+
                        " where arvl_code = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glg11c.getArvl_code());
        pstmt.setString(2, glg11c.getArvl_code_desc());
        pstmt.setString(3, glg11c.getRgdt());
        pstmt.setString(4, glg11c.getAply_po_type());
        // Key
        pstmt.setString(5, glg11c.getArvl_code());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String arvl_code
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(String arvl_code) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLG11C "+
                       "where arvl_code = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,arvl_code); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLG11CRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(GLG11CRec glg11c) throws Exception{
     delete(glg11c.getArvl_code());
} // end Delete

}// end GLG11CDBWrapBES class