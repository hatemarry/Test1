package com.bes_line.HMG;  
  
import org.jsn.jdf.*;  
import org.jsn.jdf.db.*;  
import org.jsn.jdf.jtx.*;  
import org.jsn.jdf.servlet.*;  
  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.io.*;  
import java.net.*;  
import java.util.Vector;  
  
import com.bes_line.mst.*;  
import com.bes_line.mst.HMG.*;  
import com.bes_line.base.*;  
  
public class HMGLP01A extends HttpServlet{  
  
public void init(ServletConfig sc) throws ServletException {  
    super.init(sc);  
} // init  
  
public void destroy(){  
    super.destroy();  
}// destory  
  
public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e ) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
  } // end try                     
}//end doGet  
  
public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
    } // try-catch  
}//end doPost  
  
//=============================================================================  
protected void performTask (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
String cmd = request.getParameter("cmd");  
try {        if ( cmd.equals( "add1_ok" ) )     { insertGLG11C(request, response);  
      } else if ( cmd.equals( "update1_ok" ) )  { updateGLG11C(request, response);   
      } else if ( cmd.equals( "delete1_ok" ) )  { deleteGLG11C(request, response);  
      } else if ( cmd.equals( "update1_list" ) )  { update1_list(request, response);  
      }  
 } catch(Throwable e ) {  
    e.printStackTrace(System.err);  
     System.err.flush();  
 } // end try  
}//end performTask  
  
//================================================================================  
public  void update1_list(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLP01A/index.jsp" ;  
    String listJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLP01A/list1.jsp" ;  
    String listCount = request.getParameter("listCount");   
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String trmid = request.getParameter("trmid");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String FARVL_CODE = BesUtil.chNull(request.getParameter("FARVL_CODE"));   
    callParameter += "&FARVL_CODE=" + FARVL_CODE;
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	String arvl_code = "";
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
		GLG11CRec glg11c = new GLG11CRec() ; 
		GLG11CDBWrap glg11cdbw = new GLG11CDBWrap(resource); 
		for( int lc=1; lc<=Integer.parseInt(listCount); lc++ ) { 
			arvl_code = request.getParameter("arvl_code"+String.valueOf(lc)); 
			String check = request.getParameter("check__"+String.valueOf(lc));
			if(check == null || !check.equals("Y")) continue; 

			glg11c = glg11cdbw.select(arvl_code); 
			Utility.fixNullAndTrim(glg11c); 
			glg11c.setArvl_code(  request.getParameter("arvl_code" + String.valueOf(lc))); 
			glg11cdbw.update(glg11c); 
		}
		tx.commit(); 
    } catch(Exception e) {  
		tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(listJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen=" + screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&arvl_code="+arvl_code) ; 
  
} // end updateGLG11C  
  
//================================================================================  
public  void insertGLG11C(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLP01A/index.jsp" ;  
    String arvl_code = box.getString("arvl_code"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String FARVL_CODE = BesUtil.chNull(request.getParameter("FARVL_CODE"));   
    callParameter += "&FARVL_CODE=" + FARVL_CODE;
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	GLG11CRec glg11c = new GLG11CRec() ; 
	box.copyToEntity(glg11c); 
	Utility.fixNullAndTrim(glg11c); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	BesInit bi = new BesInit();  
	UserInfo ui = bi.checkSession(request , response); 
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        GLG11CDBWrap glg11cdbw = new GLG11CDBWrap(resource); 
/** 
 * ?????? ????? alert ?; ??? ??? ?? ?????? ???? 
 */ 
    int cnt = glg11cdbw.count(arvl_code); 
	if(cnt == 0){ 
        // System Colulms.. 
        glg11c.setAdate(curdate); 
        glg11c.setAuser(usrid); 
        glg11c.setMdate(curdate); 
        glg11c.setMuser(usrid); 
		glg11cdbw.insert(glg11c); 
		tx.commit(); 
      response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&arvl_code="+arvl_code) ; 
    }else{ 
      tx.rollback(); 
      out.println("<script language='javascript'>"); 
      out.println("  alert('" + BesDBUtil.getMessage("bsc128",ui) + "');"); 
      out.println("  history.back(-1);"); 
      out.println("</script>"); 
    } 
    } catch(Exception e) {  
        tx.rollback(); 
        out.println(e.getMessage()+"<br>"+e.toString());  
        e.printStackTrace();  
        out.println(box.toString());  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
} // end insertGLG11C  
  
//================================================================================  
public  void updateGLG11C(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLP01A/index.jsp" ;  
    String arvl_code = box.getString("arvl_code"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String FARVL_CODE = BesUtil.chNull(request.getParameter("FARVL_CODE"));   
    callParameter += "&FARVL_CODE=" + FARVL_CODE;
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
    GLG11CRec glg11cBox = new GLG11CRec() ; 
    box.copyToEntity(glg11cBox); 
    Utility.fixNullAndTrim(glg11cBox); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        GLG11CDBWrap glg11cdbw = new GLG11CDBWrap(resource); 
        GLG11CRec glg11c = glg11cdbw.select(arvl_code);
         // System Colulms.. 
        glg11c.setMdate(curdate); 
        glg11c.setMuser(usrid); 
        // Editable Colulms.. 
        glg11cdbw.update(glg11c); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&arvl_code="+arvl_code) ; 
  
} // end updateGLG11C  
  
//================================================================================  
public  void deleteGLG11C(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLP01A/index.jsp" ;  
    String arvl_code = box.getString("arvl_code"); 
    String screen = "addscreen";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String callParameter = "";
    String errMsg = "";
    String FARVL_CODE = BesUtil.chNull(request.getParameter("FARVL_CODE"));   
    callParameter += "&FARVL_CODE=" + FARVL_CODE;
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
  
    GLG11CRec glg11c = new GLG11CRec() ; 
    box.copyToEntity(glg11c); 
    Utility.fixNullAndTrim(glg11c); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        GLG11CDBWrap glg11cdbw = new GLG11CDBWrap(resource); 
        glg11cdbw.delete(glg11c); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8"));  
//================================================================================  
 } 
}// end Class  
