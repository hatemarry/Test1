package com.bes_line.mst.HMG;

// DBWrapper Class for GLG03C
/**
 *
 * @(#) GLG03CDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLG03CDBWrapBES extends DBWrapper{

public GLG03CDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String curr_code
* @return GLG03CRec 
* @author besTeam 
* @date 2006-6-15
*/
public GLG03CRec select(String curr_code) throws Exception{
    java.util.Vector glg03cV = new java.util.Vector();
    GLG03CRec glg03c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select curr_code, curr_desc, natn_code " +
                       "  from HM.GLG03C  " +
                       "  where curr_code = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,curr_code); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            glg03c = new GLG03CRec(); // GLG03CRec Constructor
                     glg03c.setCurr_code(rs.getString("curr_code"));
                     glg03c.setCurr_desc(rs.getString("curr_desc"));
                     glg03c.setNatn_code(rs.getString("natn_code"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg03c;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glg03cV = new java.util.Vector();
    GLG03CRec glg03c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select curr_code, curr_desc, natn_code " +
                       "  from HM.GLG03C "+
                       "  order by curr_code ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glg03c = new GLG03CRec(); // GLG03CRec Constructor
                     glg03c.setCurr_code(rs.getString("curr_code"));
                     glg03c.setCurr_desc(rs.getString("curr_desc"));
                     glg03c.setNatn_code(rs.getString("natn_code"));
            glg03cV.addElement(glg03c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg03cV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glg03cV = new java.util.Vector();
    GLG03CRec glg03c = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select curr_code, curr_desc, natn_code " +
                       "  from HM.GLG03C  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  curr_code " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glg03c = new GLG03CRec(); // GLG03CRec Constructor
                     glg03c.setCurr_code(rs.getString("curr_code"));
                     glg03c.setCurr_desc(rs.getString("curr_desc"));
                     glg03c.setNatn_code(rs.getString("natn_code"));
            glg03cV.addElement(glg03c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg03cV;
} // end selectAll

/**
* Get Rows Count 
* @param String curr_code
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int count(String curr_code) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLG03C " +
                       " where curr_code = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,curr_code); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLG03C  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLG03CRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void insert(GLG03CRec glg03c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLG03C( " +
                              "curr_code, curr_desc, natn_code"+
                       " ) values ( "+
                              "?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glg03c.getCurr_code());
        pstmt.setString(2, glg03c.getCurr_desc());
        pstmt.setString(3, glg03c.getNatn_code());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLG03CRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void update(GLG03CRec glg03c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLG03C SET "+
                        "curr_code = ?, curr_desc = ?, natn_code = ?"+
                        " where curr_code = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glg03c.getCurr_code());
        pstmt.setString(2, glg03c.getCurr_desc());
        pstmt.setString(3, glg03c.getNatn_code());
        // Key
        pstmt.setString(4, glg03c.getCurr_code());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String curr_code
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(String curr_code) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLG03C "+
                       "where curr_code = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,curr_code); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLG03CRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(GLG03CRec glg03c) throws Exception{
     delete(glg03c.getCurr_code());
} // end Delete

}// end GLG03CDBWrapBES class