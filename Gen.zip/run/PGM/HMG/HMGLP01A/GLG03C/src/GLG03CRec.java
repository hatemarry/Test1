package com.bes_line.mst.HMG ;

// Entity Class for GLG03C
/**
 *
 * @(#) GLG03CRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLG03CRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String curr_code; 		// (VARCHAR2, 2.0)
    public String curr_desc; 		// (VARCHAR2, 40.0)
    public String natn_code; 		// (VARCHAR2, 3.0)

public GLG03CRec(){ } // default constructor

public GLG03CRec(
       String curr_code, String curr_desc, String natn_code){
    this.curr_code = curr_code;
    this.curr_desc = curr_desc;
    this.natn_code = natn_code;
} // Constructor


// Getter 
public String getCurr_code(){ return curr_code;}
public String getCurr_desc(){ return curr_desc;}
public String getNatn_code(){ return natn_code;}

// Setter 
public void setCurr_code(String curr_code){ this.curr_code = curr_code;}
public void setCurr_desc(String curr_desc){ this.curr_desc = curr_desc;}
public void setNatn_code(String natn_code){ this.natn_code = natn_code;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = curr_code + "" ; break;
  case  2 : field = curr_desc + "" ; break;
  case  3 : field = natn_code + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("curr_code")){ field = curr_code + "" ; 
     } else if(rec.equalsIgnoreCase("curr_desc")){ field = curr_desc + "" ; 
     } else if(rec.equalsIgnoreCase("natn_code")){ field = natn_code + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "CURR_CODE", "CURR_DESC", "NATN_CODE"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "CURR_CODE"};
    return tempx;
}

}// end GLG03CRec class