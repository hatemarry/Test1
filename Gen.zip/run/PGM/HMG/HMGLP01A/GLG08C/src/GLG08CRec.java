package com.bes_line.mst.HMG ;

// Entity Class for GLG08C
/**
 *
 * @(#) GLG08CRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLG08CRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String spmt_port_code; 		// (VARCHAR2, 3.0)
    public String spmt_port_desc; 		// (VARCHAR2, 80.0)
    public String rgdt; 		// (VARCHAR2, 8.0)
    public String aply_po_type; 		// (VARCHAR2, 3.0)
    public String natn_code; 		// (VARCHAR2, 3.0)

public GLG08CRec(){ } // default constructor

public GLG08CRec(
       String spmt_port_code, String spmt_port_desc, String rgdt, String aply_po_type, String natn_code){
    this.spmt_port_code = spmt_port_code;
    this.spmt_port_desc = spmt_port_desc;
    this.rgdt = rgdt;
    this.aply_po_type = aply_po_type;
    this.natn_code = natn_code;
} // Constructor


// Getter 
public String getSpmt_port_code(){ return spmt_port_code;}
public String getSpmt_port_desc(){ return spmt_port_desc;}
public String getRgdt(){ return rgdt;}
public String getAply_po_type(){ return aply_po_type;}
public String getNatn_code(){ return natn_code;}

// Setter 
public void setSpmt_port_code(String spmt_port_code){ this.spmt_port_code = spmt_port_code;}
public void setSpmt_port_desc(String spmt_port_desc){ this.spmt_port_desc = spmt_port_desc;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}
public void setAply_po_type(String aply_po_type){ this.aply_po_type = aply_po_type;}
public void setNatn_code(String natn_code){ this.natn_code = natn_code;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = spmt_port_code + "" ; break;
  case  2 : field = spmt_port_desc + "" ; break;
  case  3 : field = rgdt + "" ; break;
  case  4 : field = aply_po_type + "" ; break;
  case  5 : field = natn_code + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("spmt_port_code")){ field = spmt_port_code + "" ; 
     } else if(rec.equalsIgnoreCase("spmt_port_desc")){ field = spmt_port_desc + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("aply_po_type")){ field = aply_po_type + "" ; 
     } else if(rec.equalsIgnoreCase("natn_code")){ field = natn_code + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "SPMT_PORT_CODE", "SPMT_PORT_DESC", "RGDT", "APLY_PO_TYPE", "NATN_CODE"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "SPMT_PORT_CODE"};
    return tempx;
}

}// end GLG08CRec class