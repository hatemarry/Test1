package com.bes_line.mst.HMG;

// DBWrapper Class for GLG08C
/**
 *
 * @(#) GLG08CDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLG08CDBWrapBES extends DBWrapper{

public GLG08CDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String spmt_port_code
* @return GLG08CRec 
* @author besTeam 
* @date 2006-6-15
*/
public GLG08CRec select(String spmt_port_code) throws Exception{
    java.util.Vector glg08cV = new java.util.Vector();
    GLG08CRec glg08c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select spmt_port_code, spmt_port_desc, rgdt, aply_po_type, natn_code " +
                       "  from HM.GLG08C  " +
                       "  where spmt_port_code = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,spmt_port_code); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            glg08c = new GLG08CRec(); // GLG08CRec Constructor
                     glg08c.setSpmt_port_code(rs.getString("spmt_port_code"));
                     glg08c.setSpmt_port_desc(rs.getString("spmt_port_desc"));
                     glg08c.setRgdt(rs.getString("rgdt"));
                     glg08c.setAply_po_type(rs.getString("aply_po_type"));
                     glg08c.setNatn_code(rs.getString("natn_code"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg08c;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glg08cV = new java.util.Vector();
    GLG08CRec glg08c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select spmt_port_code, spmt_port_desc, rgdt, aply_po_type, natn_code " +
                       "  from HM.GLG08C "+
                       "  order by spmt_port_code ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glg08c = new GLG08CRec(); // GLG08CRec Constructor
                     glg08c.setSpmt_port_code(rs.getString("spmt_port_code"));
                     glg08c.setSpmt_port_desc(rs.getString("spmt_port_desc"));
                     glg08c.setRgdt(rs.getString("rgdt"));
                     glg08c.setAply_po_type(rs.getString("aply_po_type"));
                     glg08c.setNatn_code(rs.getString("natn_code"));
            glg08cV.addElement(glg08c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg08cV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glg08cV = new java.util.Vector();
    GLG08CRec glg08c = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select spmt_port_code, spmt_port_desc, rgdt, aply_po_type, natn_code " +
                       "  from HM.GLG08C  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  spmt_port_code " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glg08c = new GLG08CRec(); // GLG08CRec Constructor
                     glg08c.setSpmt_port_code(rs.getString("spmt_port_code"));
                     glg08c.setSpmt_port_desc(rs.getString("spmt_port_desc"));
                     glg08c.setRgdt(rs.getString("rgdt"));
                     glg08c.setAply_po_type(rs.getString("aply_po_type"));
                     glg08c.setNatn_code(rs.getString("natn_code"));
            glg08cV.addElement(glg08c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg08cV;
} // end selectAll

/**
* Get Rows Count 
* @param String spmt_port_code
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int count(String spmt_port_code) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLG08C " +
                       " where spmt_port_code = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,spmt_port_code); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLG08C  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLG08CRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void insert(GLG08CRec glg08c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLG08C( " +
                              "spmt_port_code, spmt_port_desc, rgdt, aply_po_type, natn_code"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glg08c.getSpmt_port_code());
        pstmt.setString(2, glg08c.getSpmt_port_desc());
        pstmt.setString(3, glg08c.getRgdt());
        pstmt.setString(4, glg08c.getAply_po_type());
        pstmt.setString(5, glg08c.getNatn_code());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLG08CRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void update(GLG08CRec glg08c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLG08C SET "+
                        "spmt_port_code = ?, spmt_port_desc = ?, rgdt = ?, aply_po_type = ?, natn_code = ?"+
                        " where spmt_port_code = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glg08c.getSpmt_port_code());
        pstmt.setString(2, glg08c.getSpmt_port_desc());
        pstmt.setString(3, glg08c.getRgdt());
        pstmt.setString(4, glg08c.getAply_po_type());
        pstmt.setString(5, glg08c.getNatn_code());
        // Key
        pstmt.setString(6, glg08c.getSpmt_port_code());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String spmt_port_code
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(String spmt_port_code) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLG08C "+
                       "where spmt_port_code = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,spmt_port_code); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLG08CRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(GLG08CRec glg08c) throws Exception{
     delete(glg08c.getSpmt_port_code());
} // end Delete

}// end GLG08CDBWrapBES class