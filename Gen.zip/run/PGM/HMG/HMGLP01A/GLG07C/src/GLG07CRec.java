package com.bes_line.mst.HMG ;

// Entity Class for GLG07C
/**
 *
 * @(#) GLG07CRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLG07CRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String dlvy_term_code; 		// (VARCHAR2, 3.0)
    public String dlvy_term_code_desc; 		// (VARCHAR2, 40.0)
    public String rgdt; 		// (VARCHAR2, 8.0)
    public String aply_po_type; 		// (VARCHAR2, 3.0)

public GLG07CRec(){ } // default constructor

public GLG07CRec(
       String dlvy_term_code, String dlvy_term_code_desc, String rgdt, String aply_po_type){
    this.dlvy_term_code = dlvy_term_code;
    this.dlvy_term_code_desc = dlvy_term_code_desc;
    this.rgdt = rgdt;
    this.aply_po_type = aply_po_type;
} // Constructor


// Getter 
public String getDlvy_term_code(){ return dlvy_term_code;}
public String getDlvy_term_code_desc(){ return dlvy_term_code_desc;}
public String getRgdt(){ return rgdt;}
public String getAply_po_type(){ return aply_po_type;}

// Setter 
public void setDlvy_term_code(String dlvy_term_code){ this.dlvy_term_code = dlvy_term_code;}
public void setDlvy_term_code_desc(String dlvy_term_code_desc){ this.dlvy_term_code_desc = dlvy_term_code_desc;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}
public void setAply_po_type(String aply_po_type){ this.aply_po_type = aply_po_type;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = dlvy_term_code + "" ; break;
  case  2 : field = dlvy_term_code_desc + "" ; break;
  case  3 : field = rgdt + "" ; break;
  case  4 : field = aply_po_type + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("dlvy_term_code")){ field = dlvy_term_code + "" ; 
     } else if(rec.equalsIgnoreCase("dlvy_term_code_desc")){ field = dlvy_term_code_desc + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("aply_po_type")){ field = aply_po_type + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "DLVY_TERM_CODE", "DLVY_TERM_CODE_DESC", "RGDT", "APLY_PO_TYPE"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "DLVY_TERM_CODE"};
    return tempx;
}

}// end GLG07CRec class