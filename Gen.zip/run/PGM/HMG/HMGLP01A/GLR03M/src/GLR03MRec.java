package com.bes_line.mst.HMG ;

// Entity Class for GLR03M
/**
 *
 * @(#) GLR03MRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class HMGLP01ARec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String por_no; 		// (VARCHAR2, 7.0)
    public String part_no; 		// (VARCHAR2, 18.0)
    public String part_proj_no; 		// (VARCHAR2, 4.0)
    public String part_flag; 		// (VARCHAR2, 1.0)
    public String part_mat_code; 		// (VARCHAR2, 13.0)
    public String por_rev_no; 		// (VARCHAR2, 2.0)
    public String por_stus_code; 		// (VARCHAR2, 1.0)
    public String prcs_stus_code; 		// (VARCHAR2, 1.0)
    public String por_pnd_last; 		// (VARCHAR2, 8.0)
    public String por_pnd; 		// (VARCHAR2, 8.0)
    public int need_qty_dsgn; 		// (NUMBER, 7.0)
    public int por_qty; 		// (NUMBER, 7.0)
    public int po_qty; 		// (NUMBER, 7.0)
    public int acpt_qty; 		// (NUMBER, 7.0)
    public int iss_qty; 		// (NUMBER, 7.0)
    public int iss_req_qty; 		// (NUMBER, 7.0)
    public String por_atch_indc; 		// (VARCHAR2, 1.0)
    public String po_resp_code; 		// (VARCHAR2, 2.0)
    public String por_cfdt_last; 		// (VARCHAR2, 8.0)
    public String por_line_rmrk_chns; 		// (VARCHAR2, 80.0)
    public String buyr_id; 		// (VARCHAR2, 4.0)
    public String blk_zone_no; 		// (VARCHAR2, 3.0)
    public String work_stge_code; 		// (VARCHAR2, 1.0)
    public String bom_chng_rsn_code; 		// (VARCHAR2, 1.0)
    public String bom_need_rsn_code; 		// (VARCHAR2, 2.0)
    public String po_indc; 		// (VARCHAR2, 1.0)
    public String rgdt; 		// (VARCHAR2, 8.0)
    public String lmd; 		// (VARCHAR2, 8.0)

public GLR03MRec(){ } // default constructor

public GLR03MRec(
       String por_no, String part_no, String part_proj_no, String part_flag, String part_mat_code, String por_rev_no, 
       String por_stus_code, String prcs_stus_code, String por_pnd_last, String por_pnd, int need_qty_dsgn, int por_qty, 
       int po_qty, int acpt_qty, int iss_qty, int iss_req_qty, String por_atch_indc, String po_resp_code, 
       String por_cfdt_last, String por_line_rmrk_chns, String buyr_id, String blk_zone_no, String work_stge_code, String bom_chng_rsn_code, 
       String bom_need_rsn_code, String po_indc, String rgdt, String lmd){
    this.por_no = por_no;
    this.part_no = part_no;
    this.part_proj_no = part_proj_no;
    this.part_flag = part_flag;
    this.part_mat_code = part_mat_code;
    this.por_rev_no = por_rev_no;
    this.por_stus_code = por_stus_code;
    this.prcs_stus_code = prcs_stus_code;
    this.por_pnd_last = por_pnd_last;
    this.por_pnd = por_pnd;
    this.need_qty_dsgn = need_qty_dsgn;
    this.por_qty = por_qty;
    this.po_qty = po_qty;
    this.acpt_qty = acpt_qty;
    this.iss_qty = iss_qty;
    this.iss_req_qty = iss_req_qty;
    this.por_atch_indc = por_atch_indc;
    this.po_resp_code = po_resp_code;
    this.por_cfdt_last = por_cfdt_last;
    this.por_line_rmrk_chns = por_line_rmrk_chns;
    this.buyr_id = buyr_id;
    this.blk_zone_no = blk_zone_no;
    this.work_stge_code = work_stge_code;
    this.bom_chng_rsn_code = bom_chng_rsn_code;
    this.bom_need_rsn_code = bom_need_rsn_code;
    this.po_indc = po_indc;
    this.rgdt = rgdt;
    this.lmd = lmd;
} // Constructor


// Getter 
public String getPor_no(){ return por_no;}
public String getPart_no(){ return part_no;}
public String getPart_proj_no(){ return part_proj_no;}
public String getPart_flag(){ return part_flag;}
public String getPart_mat_code(){ return part_mat_code;}
public String getPor_rev_no(){ return por_rev_no;}
public String getPor_stus_code(){ return por_stus_code;}
public String getPrcs_stus_code(){ return prcs_stus_code;}
public String getPor_pnd_last(){ return por_pnd_last;}
public String getPor_pnd(){ return por_pnd;}
public int getNeed_qty_dsgn(){ return need_qty_dsgn;}
public int getPor_qty(){ return por_qty;}
public int getPo_qty(){ return po_qty;}
public int getAcpt_qty(){ return acpt_qty;}
public int getIss_qty(){ return iss_qty;}
public int getIss_req_qty(){ return iss_req_qty;}
public String getPor_atch_indc(){ return por_atch_indc;}
public String getPo_resp_code(){ return po_resp_code;}
public String getPor_cfdt_last(){ return por_cfdt_last;}
public String getPor_line_rmrk_chns(){ return por_line_rmrk_chns;}
public String getBuyr_id(){ return buyr_id;}
public String getBlk_zone_no(){ return blk_zone_no;}
public String getWork_stge_code(){ return work_stge_code;}
public String getBom_chng_rsn_code(){ return bom_chng_rsn_code;}
public String getBom_need_rsn_code(){ return bom_need_rsn_code;}
public String getPo_indc(){ return po_indc;}
public String getRgdt(){ return rgdt;}
public String getLmd(){ return lmd;}

// Setter 
public void setPor_no(String por_no){ this.por_no = por_no;}
public void setPart_no(String part_no){ this.part_no = part_no;}
public void setPart_proj_no(String part_proj_no){ this.part_proj_no = part_proj_no;}
public void setPart_flag(String part_flag){ this.part_flag = part_flag;}
public void setPart_mat_code(String part_mat_code){ this.part_mat_code = part_mat_code;}
public void setPor_rev_no(String por_rev_no){ this.por_rev_no = por_rev_no;}
public void setPor_stus_code(String por_stus_code){ this.por_stus_code = por_stus_code;}
public void setPrcs_stus_code(String prcs_stus_code){ this.prcs_stus_code = prcs_stus_code;}
public void setPor_pnd_last(String por_pnd_last){ this.por_pnd_last = por_pnd_last;}
public void setPor_pnd(String por_pnd){ this.por_pnd = por_pnd;}
public void setNeed_qty_dsgn(int need_qty_dsgn){ this.need_qty_dsgn = need_qty_dsgn;}
public void setPor_qty(int por_qty){ this.por_qty = por_qty;}
public void setPo_qty(int po_qty){ this.po_qty = po_qty;}
public void setAcpt_qty(int acpt_qty){ this.acpt_qty = acpt_qty;}
public void setIss_qty(int iss_qty){ this.iss_qty = iss_qty;}
public void setIss_req_qty(int iss_req_qty){ this.iss_req_qty = iss_req_qty;}
public void setPor_atch_indc(String por_atch_indc){ this.por_atch_indc = por_atch_indc;}
public void setPo_resp_code(String po_resp_code){ this.po_resp_code = po_resp_code;}
public void setPor_cfdt_last(String por_cfdt_last){ this.por_cfdt_last = por_cfdt_last;}
public void setPor_line_rmrk_chns(String por_line_rmrk_chns){ this.por_line_rmrk_chns = por_line_rmrk_chns;}
public void setBuyr_id(String buyr_id){ this.buyr_id = buyr_id;}
public void setBlk_zone_no(String blk_zone_no){ this.blk_zone_no = blk_zone_no;}
public void setWork_stge_code(String work_stge_code){ this.work_stge_code = work_stge_code;}
public void setBom_chng_rsn_code(String bom_chng_rsn_code){ this.bom_chng_rsn_code = bom_chng_rsn_code;}
public void setBom_need_rsn_code(String bom_need_rsn_code){ this.bom_need_rsn_code = bom_need_rsn_code;}
public void setPo_indc(String po_indc){ this.po_indc = po_indc;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}
public void setLmd(String lmd){ this.lmd = lmd;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = por_no + "" ; break;
  case  2 : field = part_no + "" ; break;
  case  3 : field = part_proj_no + "" ; break;
  case  4 : field = part_flag + "" ; break;
  case  5 : field = part_mat_code + "" ; break;
  case  6 : field = por_rev_no + "" ; break;
  case  7 : field = por_stus_code + "" ; break;
  case  8 : field = prcs_stus_code + "" ; break;
  case  9 : field = por_pnd_last + "" ; break;
  case  10 : field = por_pnd + "" ; break;
  case  11 : field = need_qty_dsgn + "" ; break;
  case  12 : field = por_qty + "" ; break;
  case  13 : field = po_qty + "" ; break;
  case  14 : field = acpt_qty + "" ; break;
  case  15 : field = iss_qty + "" ; break;
  case  16 : field = iss_req_qty + "" ; break;
  case  17 : field = por_atch_indc + "" ; break;
  case  18 : field = po_resp_code + "" ; break;
  case  19 : field = por_cfdt_last + "" ; break;
  case  20 : field = por_line_rmrk_chns + "" ; break;
  case  21 : field = buyr_id + "" ; break;
  case  22 : field = blk_zone_no + "" ; break;
  case  23 : field = work_stge_code + "" ; break;
  case  24 : field = bom_chng_rsn_code + "" ; break;
  case  25 : field = bom_need_rsn_code + "" ; break;
  case  26 : field = po_indc + "" ; break;
  case  27 : field = rgdt + "" ; break;
  case  28 : field = lmd + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("por_no")){ field = por_no + "" ; 
     } else if(rec.equalsIgnoreCase("part_no")){ field = part_no + "" ; 
     } else if(rec.equalsIgnoreCase("part_proj_no")){ field = part_proj_no + "" ; 
     } else if(rec.equalsIgnoreCase("part_flag")){ field = part_flag + "" ; 
     } else if(rec.equalsIgnoreCase("part_mat_code")){ field = part_mat_code + "" ; 
     } else if(rec.equalsIgnoreCase("por_rev_no")){ field = por_rev_no + "" ; 
     } else if(rec.equalsIgnoreCase("por_stus_code")){ field = por_stus_code + "" ; 
     } else if(rec.equalsIgnoreCase("prcs_stus_code")){ field = prcs_stus_code + "" ; 
     } else if(rec.equalsIgnoreCase("por_pnd_last")){ field = por_pnd_last + "" ; 
     } else if(rec.equalsIgnoreCase("por_pnd")){ field = por_pnd + "" ; 
     } else if(rec.equalsIgnoreCase("need_qty_dsgn")){ field = need_qty_dsgn + "" ; 
     } else if(rec.equalsIgnoreCase("por_qty")){ field = por_qty + "" ; 
     } else if(rec.equalsIgnoreCase("po_qty")){ field = po_qty + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_qty")){ field = acpt_qty + "" ; 
     } else if(rec.equalsIgnoreCase("iss_qty")){ field = iss_qty + "" ; 
     } else if(rec.equalsIgnoreCase("iss_req_qty")){ field = iss_req_qty + "" ; 
     } else if(rec.equalsIgnoreCase("por_atch_indc")){ field = por_atch_indc + "" ; 
     } else if(rec.equalsIgnoreCase("po_resp_code")){ field = po_resp_code + "" ; 
     } else if(rec.equalsIgnoreCase("por_cfdt_last")){ field = por_cfdt_last + "" ; 
     } else if(rec.equalsIgnoreCase("por_line_rmrk_chns")){ field = por_line_rmrk_chns + "" ; 
     } else if(rec.equalsIgnoreCase("buyr_id")){ field = buyr_id + "" ; 
     } else if(rec.equalsIgnoreCase("blk_zone_no")){ field = blk_zone_no + "" ; 
     } else if(rec.equalsIgnoreCase("work_stge_code")){ field = work_stge_code + "" ; 
     } else if(rec.equalsIgnoreCase("bom_chng_rsn_code")){ field = bom_chng_rsn_code + "" ; 
     } else if(rec.equalsIgnoreCase("bom_need_rsn_code")){ field = bom_need_rsn_code + "" ; 
     } else if(rec.equalsIgnoreCase("po_indc")){ field = po_indc + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("lmd")){ field = lmd + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "POR_NO", "PART_NO", "PART_PROJ_NO", "PART_FLAG", "PART_MAT_CODE", "POR_REV_NO", "POR_STUS_CODE", 
       "PRCS_STUS_CODE", "POR_PND_LAST", "POR_PND", "NEED_QTY_DSGN", "POR_QTY", "PO_QTY", "ACPT_QTY", 
       "ISS_QTY", "ISS_REQ_QTY", "POR_ATCH_INDC", "PO_RESP_CODE", "POR_CFDT_LAST", "POR_LINE_RMRK_CHNS", "BUYR_ID", 
       "BLK_ZONE_NO", "WORK_STGE_CODE", "BOM_CHNG_RSN_CODE", "BOM_NEED_RSN_CODE", "PO_INDC", "RGDT", "LMD"
       };
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "POR_NO", "PART_NO"};
    return tempx;
}

}// end GLR03MRec class