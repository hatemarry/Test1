package com.bes_line.mst.HMG;

// DBWrapper Class for HMGLP01A
/**
 *
 * @(#) glr03mDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-20
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class HMGLP01ADBWrapBES extends DBWrapper{

public HMGLP01ADBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-20
*/
public java.util.Vector selectAllHMGLP01A(String whereOption,String sortOption) throws Exception{
    java.util.Vector hmglp01aV = new java.util.Vector();
    HMGLP01ARec hmglp01a = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = " SELECT "
		+ " A.POR_NO, A.PART_NO, A.POR_QTY "
		+ " , 1111111 AS PRV_PO_QTY, B.UOM, B.UNIT_WT, B.PART_DESC, B.CLSF_SCTY_CODE_1, B.CLSF_SCTY_CODE_2, B.CLSF_SCTY_CODE_3, A.POR_PND, A.POR_PND_LAST "
		+ " , A.POR_LINE_RMRK_CHNS, A.VNDR_GRP_CODE "
		+ " FROM HM.GLR03M A "
		+ " INNER JOIN HM.GLL01M B ON(A.PART_NO = B.PART_NO) "

        + whereOption; 
        if(sortOption.equals(""))  query += " order by  por_no " ;
        else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            hmglp01a = new HMGLP01ARec(); // HMGLP01ARec Constructor
                     hmglp01a.setPor_no(rs.getString("por_no"));
                     hmglp01a.setPart_no(rs.getString("part_no"));
                     hmglp01a.setPor_qty(rs.getInt("por_qty"));
                     hmglp01a.setPrv_po_qty(rs.getInt("prv_po_qty"));
                     hmglp01a.setUom(rs.getString("uom"));
                     hmglp01a.setUnit_wt(rs.getDouble("unit_wt"));
                     hmglp01a.setPart_desc(rs.getString("part_desc"));
                     hmglp01a.setClsf_scty_code_1(rs.getString("clsf_scty_code_1"));
                     hmglp01a.setClsf_scty_code_2(rs.getString("clsf_scty_code_2"));
                     hmglp01a.setClsf_scty_code_3(rs.getString("clsf_scty_code_3"));
                     hmglp01a.setPor_pnd(rs.getString("por_pnd"));
                     hmglp01a.setPor_pnd_last(rs.getString("por_pnd_last"));
                     hmglp01a.setPor_line_rmrk_chns(rs.getString("por_line_rmrk_chns"));
                     hmglp01a.setVndr_grp_code(rs.getString("vndr_grp_code"));
            hmglp01aV.addElement(hmglp01a);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hmglp01aV;
} // end selectAll

/**
* Select
* @param String por_no
* @return HMGLP01ARec 
* @author besTeam 
* @date 2006-6-20
*/
public HMGLP01ARec selectHMGLP01A(String por_no) throws Exception{
    java.util.Vector HMGLP01AV = new java.util.Vector();
    HMGLP01ARec hmglp01a = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " SELECT "
		+ " A.POR_NO, A.PART_NO, A.POR_QTY "
		+ " , 1111111 AS PRV_PO_QTY, B.UOM, B.UNIT_WT, B.PART_DESC, B.CLSF_SCTY_CODE_1, B.CLSF_SCTY_CODE_2, B.CLSF_SCTY_CODE_3, A.POR_PND, A.POR_PND_LAST "
		+ " , A.POR_LINE_RMRK_CHNS, A.VNDR_GRP_CODE "
		+ " FROM HM.GLR03M A "
		+ " INNER JOIN HM.GLL01M B ON(A.PART_NO = B.PART_NO) "

       +" and por_no = ?  " ;
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,por_no); 
        rs = pstmt.executeQuery();
        if(rs.next()) { 
            hmglp01a = new HMGLP01ARec(); // HMGLP01ARec Constructor
                     hmglp01a.setPor_no(rs.getString("por_no"));
                     hmglp01a.setPart_no(rs.getString("part_no"));
                     hmglp01a.setPor_qty(rs.getInt("por_qty"));
                     hmglp01a.setPrv_po_qty(rs.getInt("prv_po_qty"));
                     hmglp01a.setUom(rs.getString("uom"));
                     hmglp01a.setUnit_wt(rs.getDouble("unit_wt"));
                     hmglp01a.setPart_desc(rs.getString("part_desc"));
                     hmglp01a.setClsf_scty_code_1(rs.getString("clsf_scty_code_1"));
                     hmglp01a.setClsf_scty_code_2(rs.getString("clsf_scty_code_2"));
                     hmglp01a.setClsf_scty_code_3(rs.getString("clsf_scty_code_3"));
                     hmglp01a.setPor_pnd(rs.getString("por_pnd"));
                     hmglp01a.setPor_pnd_last(rs.getString("por_pnd_last"));
                     hmglp01a.setPor_line_rmrk_chns(rs.getString("por_line_rmrk_chns"));
                     hmglp01a.setVndr_grp_code(rs.getString("vndr_grp_code"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return hmglp01a;
} // end select

/**
* Get Rows Count 
* @param String por_no
* @return int 
* @author besTeam 
* @date 2006-6-20
*/
public int countHMGLP01A(String por_no) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = " Select COUNT(*) FROM " + " HM.GLR03M A "
		+ " INNER JOIN HM.GLL01M B ON(A.PART_NO = B.PART_NO) "

		+ " where por_no = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,por_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

}