package com.bes_line.HMG;  
  
import org.jsn.jdf.*;  
import org.jsn.jdf.db.*;  
import org.jsn.jdf.jtx.*;  
import org.jsn.jdf.servlet.*;  
  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.io.*;  
import java.net.*;  
import java.util.Vector;  
  
import com.bes_line.mst.*;  
import com.bes_line.mst.HMG.*;  
import com.bes_line.base.*;  
  
public class HMGLP01A extends HttpServlet{  
  
public void init(ServletConfig sc) throws ServletException {  
    super.init(sc);  
} // init  
  
public void destroy(){  
    super.destroy();  
}// destory  
  
public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e ) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
  } // end try                     
}//end doGet  
  
public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    try {  
        performTask(request,response);  
    } catch(Throwable e) {  
        e.printStackTrace(System.err);  
        System.err.flush();  
    } // try-catch  
}//end doPost  
  
//=============================================================================  
protected void performTask (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
String cmd = request.getParameter("cmd");  
try {        if ( cmd.equals( "add1_ok" ) )     { insertGLR03M(request, response);  
      } else if ( cmd.equals( "update1_ok" ) )  { updateGLR03M(request, response);   
      } else if ( cmd.equals( "delete1_ok" ) )  { deleteGLR03M(request, response);  
      } else if ( cmd.equals( "update1_list" ) )  { update1_list(request, response);  
      }  
 } catch(Throwable e ) {  
    e.printStackTrace(System.err);  
     System.err.flush();  
 } // end try  
}//end performTask  
  
//================================================================================  
public  void update1_list(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLP01A/index.jsp" ;  
    String listJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLP01A/list1.jsp" ;  
    String listCount = request.getParameter("listCount");   
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String trmid = request.getParameter("trmid");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	String por_no = "";
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
		GLR03MRec glr03m = new GLR03MRec() ; 
		GLR03MDBWrap glr03mdbw = new GLR03MDBWrap(resource); 
		for( int lc=1; lc<=Integer.parseInt(listCount); lc++ ) { 
			por_no = request.getParameter("por_no"+String.valueOf(lc)); 
			String check = request.getParameter("check__"+String.valueOf(lc));
			if(check == null || !check.equals("Y")) continue; 

			glr03m = glr03mdbw.select(por_no); 
			Utility.fixNullAndTrim(glr03m); 
			glr03mdbw.update(glr03m); 
		}
		tx.commit(); 
    } catch(Exception e) {  
		tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(listJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen=" + screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&por_no="+por_no) ; 
  
} // end updateGLR03M  
  
//================================================================================  
public  void insertGLR03M(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLP01A/index.jsp" ;  
    String por_no = box.getString("por_no"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
	GLR03MRec glr03m = new GLR03MRec() ; 
	box.copyToEntity(glr03m); 
	Utility.fixNullAndTrim(glr03m); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
	BesInit bi = new BesInit();  
	UserInfo ui = bi.checkSession(request , response); 
	try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        GLR03MDBWrap glr03mdbw = new GLR03MDBWrap(resource); 
/** 
 * ?????? ????? alert ?; ??? ??? ?? ?????? ???? 
 */ 
    int cnt = glr03mdbw.count(por_no); 
	if(cnt == 0){ 
        // System Colulms.. 
        glr03m.setAdate(curdate); 
        glr03m.setAuser(usrid); 
        glr03m.setMdate(curdate); 
        glr03m.setMuser(usrid); 
		glr03mdbw.insert(glr03m); 
		tx.commit(); 
      response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&por_no="+por_no) ; 
    }else{ 
      tx.rollback(); 
      out.println("<script language='javascript'>"); 
      out.println("  alert('" + BesDBUtil.getMessage("bsc128",ui) + "');"); 
      out.println("  history.back(-1);"); 
      out.println("</script>"); 
    } 
    } catch(Exception e) {  
        tx.rollback(); 
        out.println(e.getMessage()+"<br>"+e.toString());  
        e.printStackTrace();  
        out.println(box.toString());  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
} // end insertGLR03M  
  
//================================================================================  
public  void updateGLR03M(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLP01A/index.jsp" ;  
    String por_no = box.getString("por_no"); 
    String screen = "display";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String usrid = request.getParameter("usrid");   
    String callParameter = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
    String errMsg = "";
    int curdate = BesUtil.getDay();
 
    GLR03MRec glr03mBox = new GLR03MRec() ; 
    box.copyToEntity(glr03mBox); 
    Utility.fixNullAndTrim(glr03mBox); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        GLR03MDBWrap glr03mdbw = new GLR03MDBWrap(resource); 
        GLR03MRec glr03m = glr03mdbw.select(por_no);
         // System Colulms.. 
        glr03m.setMdate(curdate); 
        glr03m.setMuser(usrid); 
        // Editable Colulms.. 
        glr03mdbw.update(glr03m); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8")+"&por_no="+por_no) ; 
  
} // end updateGLR03M  
  
//================================================================================  
public  void deleteGLR03M(HttpServletRequest request, HttpServletResponse response) throws Exception {  
    response.setContentType("text/html;charset=utf-8");  
    PrintWriter out = response.getWriter();  
    BesUtil bu = new BesUtil();   
    Box box = HttpUtility.getBox(request);   
    String homeJsp   = bu.HTTPSERVER + "/webpages/HMG/HMGLP01A/index.jsp" ;  
    String por_no = box.getString("por_no"); 
    String screen = "addscreen";  
    String posName = request.getParameter("posName");   
    String posField = request.getParameter("posField");   
    String posValue = request.getParameter("posValue");   
    String posOrder = request.getParameter("posOrder");   
    String current_Page = request.getParameter("current_Page");   
    String callParameter = "";
    String errMsg = "";
    String parm1 = BesUtil.chNull(request.getParameter("parm1"));   
    callParameter += "&parm1=" + parm1;
 
  
    GLR03MRec glr03m = new GLR03MRec() ; 
    box.copyToEntity(glr03m); 
    Utility.fixNullAndTrim(glr03m); 
	TransactionalResource resource = null;  
	UserTransaction tx = null;  
    try {  
		resource = new com.bes_line.db.BesConnResourceTx();   
		tx = resource.getUserTransaction();  
        GLR03MDBWrap glr03mdbw = new GLR03MDBWrap(resource); 
        glr03mdbw.delete(glr03m); 
        tx.commit(); 
    } catch(Exception e) {  
        tx.rollback(); 
        if( errMsg.equals("") ) {   
        	e.printStackTrace();  
        	errMsg = e.toString();   
        }  
    } finally {  
        if ( resource != null ) resource.release();  
    } // end try-catch-finally  
  
       response.sendRedirect(homeJsp+"?posName="+URLEncoder.encode(posName,"utf-8")+"&posField="+posField+"&posValue="+URLEncoder.encode(posValue,"utf-8")+callParameter+"&posOrder="+posOrder+"&current_Page="+current_Page+"&screen="+screen + "&errMsg="+URLEncoder.encode(errMsg,"utf-8"));  
//================================================================================  
 } 
}// end Class  
