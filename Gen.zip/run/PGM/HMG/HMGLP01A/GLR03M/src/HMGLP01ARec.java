package com.bes_line.mst.HMG ;

// Entity Class for HMGLP01A
/**
 *
 * @(#) HMGLP01A.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-20
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class HMGLP01ARec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String por_no; 		// (VARCHAR2, 7.0)
    public String part_no; 		// (VARCHAR2, 18.0)
    public int por_qty; 		// (NUMBER, 7.0)
    public int prv_po_qty; 		// (NUMBER, 0.0)
    public String uom; 		// (VARCHAR2, 2.0)
    public double unit_wt; 		// (NUMBER, 10.3)
    public String part_desc; 		// (VARCHAR2, 56.0)
    public String clsf_scty_code_1; 		// (VARCHAR2, 4.0)
    public String clsf_scty_code_2; 		// (VARCHAR2, 4.0)
    public String clsf_scty_code_3; 		// (VARCHAR2, 4.0)
    public String por_pnd; 		// (VARCHAR2, 8.0)
    public String por_pnd_last; 		// (VARCHAR2, 8.0)
    public String por_line_rmrk_chns; 		// (VARCHAR2, 80.0)
    public String vndr_grp_code; 		// (VARCHAR2, 4.0)

public HMGLP01ARec(){ } // default constructor

public HMGLP01ARec(
       String por_no, String part_no, int por_qty, int prv_po_qty, String uom, double unit_wt, 
       String part_desc, String clsf_scty_code_1, String clsf_scty_code_2, String clsf_scty_code_3, String por_pnd, String por_pnd_last, 
       String por_line_rmrk_chns, String vndr_grp_code){
    this.por_no = por_no;
    this.part_no = part_no;
    this.por_qty = por_qty;
    this.prv_po_qty = prv_po_qty;
    this.uom = uom;
    this.unit_wt = unit_wt;
    this.part_desc = part_desc;
    this.clsf_scty_code_1 = clsf_scty_code_1;
    this.clsf_scty_code_2 = clsf_scty_code_2;
    this.clsf_scty_code_3 = clsf_scty_code_3;
    this.por_pnd = por_pnd;
    this.por_pnd_last = por_pnd_last;
    this.por_line_rmrk_chns = por_line_rmrk_chns;
    this.vndr_grp_code = vndr_grp_code;
} // Constructor


// Getter 
public String getPor_no(){ return por_no;}
public String getPart_no(){ return part_no;}
public int getPor_qty(){ return por_qty;}
public int getPrv_po_qty(){ return prv_po_qty;}
public String getUom(){ return uom;}
public double getUnit_wt(){ return unit_wt;}
public String getPart_desc(){ return part_desc;}
public String getClsf_scty_code_1(){ return clsf_scty_code_1;}
public String getClsf_scty_code_2(){ return clsf_scty_code_2;}
public String getClsf_scty_code_3(){ return clsf_scty_code_3;}
public String getPor_pnd(){ return por_pnd;}
public String getPor_pnd_last(){ return por_pnd_last;}
public String getPor_line_rmrk_chns(){ return por_line_rmrk_chns;}
public String getVndr_grp_code(){ return vndr_grp_code;}

// Setter 
public void setPor_no(String por_no){ this.por_no = por_no;}
public void setPart_no(String part_no){ this.part_no = part_no;}
public void setPor_qty(int por_qty){ this.por_qty = por_qty;}
public void setPrv_po_qty(int prv_po_qty){ this.prv_po_qty = prv_po_qty;}
public void setUom(String uom){ this.uom = uom;}
public void setUnit_wt(double unit_wt){ this.unit_wt = unit_wt;}
public void setPart_desc(String part_desc){ this.part_desc = part_desc;}
public void setClsf_scty_code_1(String clsf_scty_code_1){ this.clsf_scty_code_1 = clsf_scty_code_1;}
public void setClsf_scty_code_2(String clsf_scty_code_2){ this.clsf_scty_code_2 = clsf_scty_code_2;}
public void setClsf_scty_code_3(String clsf_scty_code_3){ this.clsf_scty_code_3 = clsf_scty_code_3;}
public void setPor_pnd(String por_pnd){ this.por_pnd = por_pnd;}
public void setPor_pnd_last(String por_pnd_last){ this.por_pnd_last = por_pnd_last;}
public void setPor_line_rmrk_chns(String por_line_rmrk_chns){ this.por_line_rmrk_chns = por_line_rmrk_chns;}
public void setVndr_grp_code(String vndr_grp_code){ this.vndr_grp_code = vndr_grp_code;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = por_no + "" ; break;
  case  2 : field = part_no + "" ; break;
  case  3 : field = por_qty + "" ; break;
  case  4 : field = prv_po_qty + "" ; break;
  case  5 : field = uom + "" ; break;
  case  6 : field = unit_wt + "" ; break;
  case  7 : field = part_desc + "" ; break;
  case  8 : field = clsf_scty_code_1 + "" ; break;
  case  9 : field = clsf_scty_code_2 + "" ; break;
  case  10 : field = clsf_scty_code_3 + "" ; break;
  case  11 : field = por_pnd + "" ; break;
  case  12 : field = por_pnd_last + "" ; break;
  case  13 : field = por_line_rmrk_chns + "" ; break;
  case  14 : field = vndr_grp_code + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("por_no")){ field = por_no + "" ; 
     } else if(rec.equalsIgnoreCase("part_no")){ field = part_no + "" ; 
     } else if(rec.equalsIgnoreCase("por_qty")){ field = por_qty + "" ; 
     } else if(rec.equalsIgnoreCase("prv_po_qty")){ field = prv_po_qty + "" ; 
     } else if(rec.equalsIgnoreCase("uom")){ field = uom + "" ; 
     } else if(rec.equalsIgnoreCase("unit_wt")){ field = unit_wt + "" ; 
     } else if(rec.equalsIgnoreCase("part_desc")){ field = part_desc + "" ; 
     } else if(rec.equalsIgnoreCase("clsf_scty_code_1")){ field = clsf_scty_code_1 + "" ; 
     } else if(rec.equalsIgnoreCase("clsf_scty_code_2")){ field = clsf_scty_code_2 + "" ; 
     } else if(rec.equalsIgnoreCase("clsf_scty_code_3")){ field = clsf_scty_code_3 + "" ; 
     } else if(rec.equalsIgnoreCase("por_pnd")){ field = por_pnd + "" ; 
     } else if(rec.equalsIgnoreCase("por_pnd_last")){ field = por_pnd_last + "" ; 
     } else if(rec.equalsIgnoreCase("por_line_rmrk_chns")){ field = por_line_rmrk_chns + "" ; 
     } else if(rec.equalsIgnoreCase("vndr_grp_code")){ field = vndr_grp_code + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "POR_NO", "PART_NO", "POR_QTY", "PRV_PO_QTY", "UOM", "UNIT_WT", "PART_DESC", 
       "CLSF_SCTY_CODE_1", "CLSF_SCTY_CODE_2", "CLSF_SCTY_CODE_3", "POR_PND", "POR_PND_LAST", "POR_LINE_RMRK_CHNS", "VNDR_GRP_CODE"
       };
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "POR_NO"};
    return tempx;
}

}// end HMGLP01ARec class