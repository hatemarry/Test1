package com.bes_line.mst.HMG;

// DBWrapper Class for GLR03M
/**
 *
 * @(#) GLR03MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLR03MDBWrapBES extends DBWrapper{

public GLR03MDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String por_no, String part_no
* @return GLR03MRec 
* @author besTeam 
* @date 2006-6-15
*/
public GLR03MRec select(String por_no, String part_no) throws Exception{
    java.util.Vector glr03mV = new java.util.Vector();
    GLR03MRec glr03m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select por_no, part_no, part_proj_no, part_flag, part_mat_code, por_rev_no, por_stus_code, prcs_stus_code, por_pnd_last, " +
                              "por_pnd, need_qty_dsgn, por_qty, po_qty, acpt_qty, iss_qty, iss_req_qty, por_atch_indc, po_resp_code, " +
                              "por_cfdt_last, por_line_rmrk_chns, buyr_id, blk_zone_no, work_stge_code, bom_chng_rsn_code, bom_need_rsn_code, po_indc, rgdt, " +
                              "lmd " +
                       "  from HM.GLR03M  " +
                       "  where por_no = ? and part_no = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,por_no); 
        pstmt.setString(2,part_no); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            glr03m = new GLR03MRec(); // GLR03MRec Constructor
                     glr03m.setPor_no(rs.getString("por_no"));
                     glr03m.setPart_no(rs.getString("part_no"));
                     glr03m.setPart_proj_no(rs.getString("part_proj_no"));
                     glr03m.setPart_flag(rs.getString("part_flag"));
                     glr03m.setPart_mat_code(rs.getString("part_mat_code"));
                     glr03m.setPor_rev_no(rs.getString("por_rev_no"));
                     glr03m.setPor_stus_code(rs.getString("por_stus_code"));
                     glr03m.setPrcs_stus_code(rs.getString("prcs_stus_code"));
                     glr03m.setPor_pnd_last(rs.getString("por_pnd_last"));
                     glr03m.setPor_pnd(rs.getString("por_pnd"));
                     glr03m.setNeed_qty_dsgn(rs.getInt("need_qty_dsgn"));
                     glr03m.setPor_qty(rs.getInt("por_qty"));
                     glr03m.setPo_qty(rs.getInt("po_qty"));
                     glr03m.setAcpt_qty(rs.getInt("acpt_qty"));
                     glr03m.setIss_qty(rs.getInt("iss_qty"));
                     glr03m.setIss_req_qty(rs.getInt("iss_req_qty"));
                     glr03m.setPor_atch_indc(rs.getString("por_atch_indc"));
                     glr03m.setPo_resp_code(rs.getString("po_resp_code"));
                     glr03m.setPor_cfdt_last(rs.getString("por_cfdt_last"));
                     glr03m.setPor_line_rmrk_chns(rs.getString("por_line_rmrk_chns"));
                     glr03m.setBuyr_id(rs.getString("buyr_id"));
                     glr03m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     glr03m.setWork_stge_code(rs.getString("work_stge_code"));
                     glr03m.setBom_chng_rsn_code(rs.getString("bom_chng_rsn_code"));
                     glr03m.setBom_need_rsn_code(rs.getString("bom_need_rsn_code"));
                     glr03m.setPo_indc(rs.getString("po_indc"));
                     glr03m.setRgdt(rs.getString("rgdt"));
                     glr03m.setLmd(rs.getString("lmd"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glr03m;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glr03mV = new java.util.Vector();
    GLR03MRec glr03m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select por_no, part_no, part_proj_no, part_flag, part_mat_code, por_rev_no, por_stus_code, prcs_stus_code, por_pnd_last, " +
                              "por_pnd, need_qty_dsgn, por_qty, po_qty, acpt_qty, iss_qty, iss_req_qty, por_atch_indc, po_resp_code, " +
                              "por_cfdt_last, por_line_rmrk_chns, buyr_id, blk_zone_no, work_stge_code, bom_chng_rsn_code, bom_need_rsn_code, po_indc, rgdt, " +
                              "lmd " +
                       "  from HM.GLR03M "+
                       "  order by por_no , part_no ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glr03m = new GLR03MRec(); // GLR03MRec Constructor
                     glr03m.setPor_no(rs.getString("por_no"));
                     glr03m.setPart_no(rs.getString("part_no"));
                     glr03m.setPart_proj_no(rs.getString("part_proj_no"));
                     glr03m.setPart_flag(rs.getString("part_flag"));
                     glr03m.setPart_mat_code(rs.getString("part_mat_code"));
                     glr03m.setPor_rev_no(rs.getString("por_rev_no"));
                     glr03m.setPor_stus_code(rs.getString("por_stus_code"));
                     glr03m.setPrcs_stus_code(rs.getString("prcs_stus_code"));
                     glr03m.setPor_pnd_last(rs.getString("por_pnd_last"));
                     glr03m.setPor_pnd(rs.getString("por_pnd"));
                     glr03m.setNeed_qty_dsgn(rs.getInt("need_qty_dsgn"));
                     glr03m.setPor_qty(rs.getInt("por_qty"));
                     glr03m.setPo_qty(rs.getInt("po_qty"));
                     glr03m.setAcpt_qty(rs.getInt("acpt_qty"));
                     glr03m.setIss_qty(rs.getInt("iss_qty"));
                     glr03m.setIss_req_qty(rs.getInt("iss_req_qty"));
                     glr03m.setPor_atch_indc(rs.getString("por_atch_indc"));
                     glr03m.setPo_resp_code(rs.getString("po_resp_code"));
                     glr03m.setPor_cfdt_last(rs.getString("por_cfdt_last"));
                     glr03m.setPor_line_rmrk_chns(rs.getString("por_line_rmrk_chns"));
                     glr03m.setBuyr_id(rs.getString("buyr_id"));
                     glr03m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     glr03m.setWork_stge_code(rs.getString("work_stge_code"));
                     glr03m.setBom_chng_rsn_code(rs.getString("bom_chng_rsn_code"));
                     glr03m.setBom_need_rsn_code(rs.getString("bom_need_rsn_code"));
                     glr03m.setPo_indc(rs.getString("po_indc"));
                     glr03m.setRgdt(rs.getString("rgdt"));
                     glr03m.setLmd(rs.getString("lmd"));
            glr03mV.addElement(glr03m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glr03mV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glr03mV = new java.util.Vector();
    GLR03MRec glr03m = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select por_no, part_no, part_proj_no, part_flag, part_mat_code, por_rev_no, por_stus_code, prcs_stus_code, por_pnd_last, " +
                              "por_pnd, need_qty_dsgn, por_qty, po_qty, acpt_qty, iss_qty, iss_req_qty, por_atch_indc, po_resp_code, " +
                              "por_cfdt_last, por_line_rmrk_chns, buyr_id, blk_zone_no, work_stge_code, bom_chng_rsn_code, bom_need_rsn_code, po_indc, rgdt, " +
                              "lmd " +
                       "  from HM.GLR03M  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  por_no " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glr03m = new GLR03MRec(); // GLR03MRec Constructor
                     glr03m.setPor_no(rs.getString("por_no"));
                     glr03m.setPart_no(rs.getString("part_no"));
                     glr03m.setPart_proj_no(rs.getString("part_proj_no"));
                     glr03m.setPart_flag(rs.getString("part_flag"));
                     glr03m.setPart_mat_code(rs.getString("part_mat_code"));
                     glr03m.setPor_rev_no(rs.getString("por_rev_no"));
                     glr03m.setPor_stus_code(rs.getString("por_stus_code"));
                     glr03m.setPrcs_stus_code(rs.getString("prcs_stus_code"));
                     glr03m.setPor_pnd_last(rs.getString("por_pnd_last"));
                     glr03m.setPor_pnd(rs.getString("por_pnd"));
                     glr03m.setNeed_qty_dsgn(rs.getInt("need_qty_dsgn"));
                     glr03m.setPor_qty(rs.getInt("por_qty"));
                     glr03m.setPo_qty(rs.getInt("po_qty"));
                     glr03m.setAcpt_qty(rs.getInt("acpt_qty"));
                     glr03m.setIss_qty(rs.getInt("iss_qty"));
                     glr03m.setIss_req_qty(rs.getInt("iss_req_qty"));
                     glr03m.setPor_atch_indc(rs.getString("por_atch_indc"));
                     glr03m.setPo_resp_code(rs.getString("po_resp_code"));
                     glr03m.setPor_cfdt_last(rs.getString("por_cfdt_last"));
                     glr03m.setPor_line_rmrk_chns(rs.getString("por_line_rmrk_chns"));
                     glr03m.setBuyr_id(rs.getString("buyr_id"));
                     glr03m.setBlk_zone_no(rs.getString("blk_zone_no"));
                     glr03m.setWork_stge_code(rs.getString("work_stge_code"));
                     glr03m.setBom_chng_rsn_code(rs.getString("bom_chng_rsn_code"));
                     glr03m.setBom_need_rsn_code(rs.getString("bom_need_rsn_code"));
                     glr03m.setPo_indc(rs.getString("po_indc"));
                     glr03m.setRgdt(rs.getString("rgdt"));
                     glr03m.setLmd(rs.getString("lmd"));
            glr03mV.addElement(glr03m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glr03mV;
} // end selectAll

/**
* Get Rows Count 
* @param String por_no, String part_no
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int count(String por_no, String part_no) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLR03M " +
                       " where por_no = ? and part_no = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,por_no); 
        pstmt.setString(2,part_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLR03M  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLR03MRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void insert(GLR03MRec glr03m) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLR03M( " +
                              "por_no, part_no, part_proj_no, part_flag, part_mat_code, por_rev_no, por_stus_code, prcs_stus_code, por_pnd_last, " +
                              "por_pnd, need_qty_dsgn, por_qty, po_qty, acpt_qty, iss_qty, iss_req_qty, por_atch_indc, po_resp_code, " +
                              "por_cfdt_last, por_line_rmrk_chns, buyr_id, blk_zone_no, work_stge_code, bom_chng_rsn_code, bom_need_rsn_code, po_indc, rgdt, " +
                              "lmd"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?"+
                              ")";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glr03m.getPor_no());
        pstmt.setString(2, glr03m.getPart_no());
        pstmt.setString(3, glr03m.getPart_proj_no());
        pstmt.setString(4, glr03m.getPart_flag());
        pstmt.setString(5, glr03m.getPart_mat_code());
        pstmt.setString(6, glr03m.getPor_rev_no());
        pstmt.setString(7, glr03m.getPor_stus_code());
        pstmt.setString(8, glr03m.getPrcs_stus_code());
        pstmt.setString(9, glr03m.getPor_pnd_last());
        pstmt.setString(10, glr03m.getPor_pnd());
        pstmt.setInt(11, glr03m.getNeed_qty_dsgn());
        pstmt.setInt(12, glr03m.getPor_qty());
        pstmt.setInt(13, glr03m.getPo_qty());
        pstmt.setInt(14, glr03m.getAcpt_qty());
        pstmt.setInt(15, glr03m.getIss_qty());
        pstmt.setInt(16, glr03m.getIss_req_qty());
        pstmt.setString(17, glr03m.getPor_atch_indc());
        pstmt.setString(18, glr03m.getPo_resp_code());
        pstmt.setString(19, glr03m.getPor_cfdt_last());
        pstmt.setString(20, glr03m.getPor_line_rmrk_chns());
        pstmt.setString(21, glr03m.getBuyr_id());
        pstmt.setString(22, glr03m.getBlk_zone_no());
        pstmt.setString(23, glr03m.getWork_stge_code());
        pstmt.setString(24, glr03m.getBom_chng_rsn_code());
        pstmt.setString(25, glr03m.getBom_need_rsn_code());
        pstmt.setString(26, glr03m.getPo_indc());
        pstmt.setString(27, glr03m.getRgdt());
        pstmt.setString(28, glr03m.getLmd());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLR03MRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void update(GLR03MRec glr03m) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLR03M SET "+
                        "por_no = ?, part_no = ?, part_proj_no = ?, part_flag = ?, part_mat_code = ?, por_rev_no = ?, por_stus_code = ?, prcs_stus_code = ?, por_pnd_last = ?, por_pnd = ?, " +
                              "need_qty_dsgn = ?, por_qty = ?, po_qty = ?, acpt_qty = ?, iss_qty = ?, iss_req_qty = ?, por_atch_indc = ?, po_resp_code = ?, por_cfdt_last = ?, " +
                              "por_line_rmrk_chns = ?, buyr_id = ?, blk_zone_no = ?, work_stge_code = ?, bom_chng_rsn_code = ?, bom_need_rsn_code = ?, po_indc = ?, rgdt = ?, lmd = ?" +
                              ""+
                        " where por_no = ? and part_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glr03m.getPor_no());
        pstmt.setString(2, glr03m.getPart_no());
        pstmt.setString(3, glr03m.getPart_proj_no());
        pstmt.setString(4, glr03m.getPart_flag());
        pstmt.setString(5, glr03m.getPart_mat_code());
        pstmt.setString(6, glr03m.getPor_rev_no());
        pstmt.setString(7, glr03m.getPor_stus_code());
        pstmt.setString(8, glr03m.getPrcs_stus_code());
        pstmt.setString(9, glr03m.getPor_pnd_last());
        pstmt.setString(10, glr03m.getPor_pnd());
        pstmt.setInt(11, glr03m.getNeed_qty_dsgn());
        pstmt.setInt(12, glr03m.getPor_qty());
        pstmt.setInt(13, glr03m.getPo_qty());
        pstmt.setInt(14, glr03m.getAcpt_qty());
        pstmt.setInt(15, glr03m.getIss_qty());
        pstmt.setInt(16, glr03m.getIss_req_qty());
        pstmt.setString(17, glr03m.getPor_atch_indc());
        pstmt.setString(18, glr03m.getPo_resp_code());
        pstmt.setString(19, glr03m.getPor_cfdt_last());
        pstmt.setString(20, glr03m.getPor_line_rmrk_chns());
        pstmt.setString(21, glr03m.getBuyr_id());
        pstmt.setString(22, glr03m.getBlk_zone_no());
        pstmt.setString(23, glr03m.getWork_stge_code());
        pstmt.setString(24, glr03m.getBom_chng_rsn_code());
        pstmt.setString(25, glr03m.getBom_need_rsn_code());
        pstmt.setString(26, glr03m.getPo_indc());
        pstmt.setString(27, glr03m.getRgdt());
        pstmt.setString(28, glr03m.getLmd());
        // Key
        pstmt.setString(29, glr03m.getPor_no());
        pstmt.setString(30, glr03m.getPart_no());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String por_no, String part_no
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(String por_no, String part_no) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLR03M "+
                       "where por_no = ? and part_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,por_no); 
        pstmt.setString(2,part_no); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLR03MRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(GLR03MRec glr03m) throws Exception{
     delete(glr03m.getPor_no(), glr03m.getPart_no());
} // end Delete

}// end GLR03MDBWrapBES class