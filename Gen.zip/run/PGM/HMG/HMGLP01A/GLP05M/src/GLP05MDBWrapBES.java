package com.bes_line.mst.HMG;

// DBWrapper Class for GLP05M
/**
 *
 * @(#) GLP05MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLP05MDBWrapBES extends DBWrapper{

public GLP05MDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String po_no, String po_lnno
* @return GLP05MRec 
* @author besTeam 
* @date 2006-6-15
*/
public GLP05MRec select(String po_no, String po_lnno) throws Exception{
    java.util.Vector glp05mV = new java.util.Vector();
    GLP05MRec glp05m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_lnno, po_line_stus_code, po_rev_no, po_stus_chng_dt, part_no, part_proj_no, part_flag, part_mat_code, " +
                              "por_qty, ncv_arvl_qty, insp_qty, acpt_qty, rjct_qty, po_qty, po_uom, inv_unit_pr, por_no, " +
                              "prch_unit_pr, buyr_id, pnd, stor_id, po_line_rmrk, dlvy_date_frst, dlvy_date_last, unit_wt, arvl_expt_date, " +
                              "po_amt, rgdt, lmd " +
                       "  from HM.GLP05M  " +
                       "  where po_no = ? and po_lnno = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_lnno); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            glp05m = new GLP05MRec(); // GLP05MRec Constructor
                     glp05m.setPo_no(rs.getString("po_no"));
                     glp05m.setPo_lnno(rs.getString("po_lnno"));
                     glp05m.setPo_line_stus_code(rs.getString("po_line_stus_code"));
                     glp05m.setPo_rev_no(rs.getString("po_rev_no"));
                     glp05m.setPo_stus_chng_dt(rs.getString("po_stus_chng_dt"));
                     glp05m.setPart_no(rs.getString("part_no"));
                     glp05m.setPart_proj_no(rs.getString("part_proj_no"));
                     glp05m.setPart_flag(rs.getString("part_flag"));
                     glp05m.setPart_mat_code(rs.getString("part_mat_code"));
                     glp05m.setPor_qty(rs.getInt("por_qty"));
                     glp05m.setNcv_arvl_qty(rs.getInt("ncv_arvl_qty"));
                     glp05m.setInsp_qty(rs.getInt("insp_qty"));
                     glp05m.setAcpt_qty(rs.getInt("acpt_qty"));
                     glp05m.setRjct_qty(rs.getInt("rjct_qty"));
                     glp05m.setPo_qty(rs.getInt("po_qty"));
                     glp05m.setPo_uom(rs.getString("po_uom"));
                     glp05m.setInv_unit_pr(rs.getDouble("inv_unit_pr"));
                     glp05m.setPor_no(rs.getString("por_no"));
                     glp05m.setPrch_unit_pr(rs.getDouble("prch_unit_pr"));
                     glp05m.setBuyr_id(rs.getString("buyr_id"));
                     glp05m.setPnd(rs.getString("pnd"));
                     glp05m.setStor_id(rs.getString("stor_id"));
                     glp05m.setPo_line_rmrk(rs.getString("po_line_rmrk"));
                     glp05m.setDlvy_date_frst(rs.getString("dlvy_date_frst"));
                     glp05m.setDlvy_date_last(rs.getString("dlvy_date_last"));
                     glp05m.setUnit_wt(rs.getDouble("unit_wt"));
                     glp05m.setArvl_expt_date(rs.getString("arvl_expt_date"));
                     glp05m.setPo_amt(rs.getDouble("po_amt"));
                     glp05m.setRgdt(rs.getString("rgdt"));
                     glp05m.setLmd(rs.getString("lmd"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp05m;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glp05mV = new java.util.Vector();
    GLP05MRec glp05m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_lnno, po_line_stus_code, po_rev_no, po_stus_chng_dt, part_no, part_proj_no, part_flag, part_mat_code, " +
                              "por_qty, ncv_arvl_qty, insp_qty, acpt_qty, rjct_qty, po_qty, po_uom, inv_unit_pr, por_no, " +
                              "prch_unit_pr, buyr_id, pnd, stor_id, po_line_rmrk, dlvy_date_frst, dlvy_date_last, unit_wt, arvl_expt_date, " +
                              "po_amt, rgdt, lmd " +
                       "  from HM.GLP05M "+
                       "  order by po_no , po_lnno ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp05m = new GLP05MRec(); // GLP05MRec Constructor
                     glp05m.setPo_no(rs.getString("po_no"));
                     glp05m.setPo_lnno(rs.getString("po_lnno"));
                     glp05m.setPo_line_stus_code(rs.getString("po_line_stus_code"));
                     glp05m.setPo_rev_no(rs.getString("po_rev_no"));
                     glp05m.setPo_stus_chng_dt(rs.getString("po_stus_chng_dt"));
                     glp05m.setPart_no(rs.getString("part_no"));
                     glp05m.setPart_proj_no(rs.getString("part_proj_no"));
                     glp05m.setPart_flag(rs.getString("part_flag"));
                     glp05m.setPart_mat_code(rs.getString("part_mat_code"));
                     glp05m.setPor_qty(rs.getInt("por_qty"));
                     glp05m.setNcv_arvl_qty(rs.getInt("ncv_arvl_qty"));
                     glp05m.setInsp_qty(rs.getInt("insp_qty"));
                     glp05m.setAcpt_qty(rs.getInt("acpt_qty"));
                     glp05m.setRjct_qty(rs.getInt("rjct_qty"));
                     glp05m.setPo_qty(rs.getInt("po_qty"));
                     glp05m.setPo_uom(rs.getString("po_uom"));
                     glp05m.setInv_unit_pr(rs.getDouble("inv_unit_pr"));
                     glp05m.setPor_no(rs.getString("por_no"));
                     glp05m.setPrch_unit_pr(rs.getDouble("prch_unit_pr"));
                     glp05m.setBuyr_id(rs.getString("buyr_id"));
                     glp05m.setPnd(rs.getString("pnd"));
                     glp05m.setStor_id(rs.getString("stor_id"));
                     glp05m.setPo_line_rmrk(rs.getString("po_line_rmrk"));
                     glp05m.setDlvy_date_frst(rs.getString("dlvy_date_frst"));
                     glp05m.setDlvy_date_last(rs.getString("dlvy_date_last"));
                     glp05m.setUnit_wt(rs.getDouble("unit_wt"));
                     glp05m.setArvl_expt_date(rs.getString("arvl_expt_date"));
                     glp05m.setPo_amt(rs.getDouble("po_amt"));
                     glp05m.setRgdt(rs.getString("rgdt"));
                     glp05m.setLmd(rs.getString("lmd"));
            glp05mV.addElement(glp05m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp05mV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glp05mV = new java.util.Vector();
    GLP05MRec glp05m = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_lnno, po_line_stus_code, po_rev_no, po_stus_chng_dt, part_no, part_proj_no, part_flag, part_mat_code, " +
                              "por_qty, ncv_arvl_qty, insp_qty, acpt_qty, rjct_qty, po_qty, po_uom, inv_unit_pr, por_no, " +
                              "prch_unit_pr, buyr_id, pnd, stor_id, po_line_rmrk, dlvy_date_frst, dlvy_date_last, unit_wt, arvl_expt_date, " +
                              "po_amt, rgdt, lmd " +
                       "  from HM.GLP05M  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  po_no " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp05m = new GLP05MRec(); // GLP05MRec Constructor
                     glp05m.setPo_no(rs.getString("po_no"));
                     glp05m.setPo_lnno(rs.getString("po_lnno"));
                     glp05m.setPo_line_stus_code(rs.getString("po_line_stus_code"));
                     glp05m.setPo_rev_no(rs.getString("po_rev_no"));
                     glp05m.setPo_stus_chng_dt(rs.getString("po_stus_chng_dt"));
                     glp05m.setPart_no(rs.getString("part_no"));
                     glp05m.setPart_proj_no(rs.getString("part_proj_no"));
                     glp05m.setPart_flag(rs.getString("part_flag"));
                     glp05m.setPart_mat_code(rs.getString("part_mat_code"));
                     glp05m.setPor_qty(rs.getInt("por_qty"));
                     glp05m.setNcv_arvl_qty(rs.getInt("ncv_arvl_qty"));
                     glp05m.setInsp_qty(rs.getInt("insp_qty"));
                     glp05m.setAcpt_qty(rs.getInt("acpt_qty"));
                     glp05m.setRjct_qty(rs.getInt("rjct_qty"));
                     glp05m.setPo_qty(rs.getInt("po_qty"));
                     glp05m.setPo_uom(rs.getString("po_uom"));
                     glp05m.setInv_unit_pr(rs.getDouble("inv_unit_pr"));
                     glp05m.setPor_no(rs.getString("por_no"));
                     glp05m.setPrch_unit_pr(rs.getDouble("prch_unit_pr"));
                     glp05m.setBuyr_id(rs.getString("buyr_id"));
                     glp05m.setPnd(rs.getString("pnd"));
                     glp05m.setStor_id(rs.getString("stor_id"));
                     glp05m.setPo_line_rmrk(rs.getString("po_line_rmrk"));
                     glp05m.setDlvy_date_frst(rs.getString("dlvy_date_frst"));
                     glp05m.setDlvy_date_last(rs.getString("dlvy_date_last"));
                     glp05m.setUnit_wt(rs.getDouble("unit_wt"));
                     glp05m.setArvl_expt_date(rs.getString("arvl_expt_date"));
                     glp05m.setPo_amt(rs.getDouble("po_amt"));
                     glp05m.setRgdt(rs.getString("rgdt"));
                     glp05m.setLmd(rs.getString("lmd"));
            glp05mV.addElement(glp05m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp05mV;
} // end selectAll

/**
* Get Rows Count 
* @param String po_no, String po_lnno
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int count(String po_no, String po_lnno) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP05M " +
                       " where po_no = ? and po_lnno = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_lnno); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP05M  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLP05MRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void insert(GLP05MRec glp05m) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLP05M( " +
                              "po_no, po_lnno, po_line_stus_code, po_rev_no, po_stus_chng_dt, part_no, part_proj_no, part_flag, part_mat_code, " +
                              "por_qty, ncv_arvl_qty, insp_qty, acpt_qty, rjct_qty, po_qty, po_uom, inv_unit_pr, por_no, " +
                              "prch_unit_pr, buyr_id, pnd, stor_id, po_line_rmrk, dlvy_date_frst, dlvy_date_last, unit_wt, arvl_expt_date, " +
                              "po_amt, rgdt, lmd"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp05m.getPo_no());
        pstmt.setString(2, glp05m.getPo_lnno());
        pstmt.setString(3, glp05m.getPo_line_stus_code());
        pstmt.setString(4, glp05m.getPo_rev_no());
        pstmt.setString(5, glp05m.getPo_stus_chng_dt());
        pstmt.setString(6, glp05m.getPart_no());
        pstmt.setString(7, glp05m.getPart_proj_no());
        pstmt.setString(8, glp05m.getPart_flag());
        pstmt.setString(9, glp05m.getPart_mat_code());
        pstmt.setInt(10, glp05m.getPor_qty());
        pstmt.setInt(11, glp05m.getNcv_arvl_qty());
        pstmt.setInt(12, glp05m.getInsp_qty());
        pstmt.setInt(13, glp05m.getAcpt_qty());
        pstmt.setInt(14, glp05m.getRjct_qty());
        pstmt.setInt(15, glp05m.getPo_qty());
        pstmt.setString(16, glp05m.getPo_uom());
        pstmt.setDouble(17, glp05m.getInv_unit_pr());
        pstmt.setString(18, glp05m.getPor_no());
        pstmt.setDouble(19, glp05m.getPrch_unit_pr());
        pstmt.setString(20, glp05m.getBuyr_id());
        pstmt.setString(21, glp05m.getPnd());
        pstmt.setString(22, glp05m.getStor_id());
        pstmt.setString(23, glp05m.getPo_line_rmrk());
        pstmt.setString(24, glp05m.getDlvy_date_frst());
        pstmt.setString(25, glp05m.getDlvy_date_last());
        pstmt.setDouble(26, glp05m.getUnit_wt());
        pstmt.setString(27, glp05m.getArvl_expt_date());
        pstmt.setDouble(28, glp05m.getPo_amt());
        pstmt.setString(29, glp05m.getRgdt());
        pstmt.setString(30, glp05m.getLmd());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLP05MRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void update(GLP05MRec glp05m) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLP05M SET "+
                        "po_no = ?, po_lnno = ?, po_line_stus_code = ?, po_rev_no = ?, po_stus_chng_dt = ?, part_no = ?, part_proj_no = ?, part_flag = ?, part_mat_code = ?, por_qty = ?, " +
                              "ncv_arvl_qty = ?, insp_qty = ?, acpt_qty = ?, rjct_qty = ?, po_qty = ?, po_uom = ?, inv_unit_pr = ?, por_no = ?, prch_unit_pr = ?, " +
                              "buyr_id = ?, pnd = ?, stor_id = ?, po_line_rmrk = ?, dlvy_date_frst = ?, dlvy_date_last = ?, unit_wt = ?, arvl_expt_date = ?, po_amt = ?, " +
                              "rgdt = ?, lmd = ?"+
                        " where po_no = ? and po_lnno = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp05m.getPo_no());
        pstmt.setString(2, glp05m.getPo_lnno());
        pstmt.setString(3, glp05m.getPo_line_stus_code());
        pstmt.setString(4, glp05m.getPo_rev_no());
        pstmt.setString(5, glp05m.getPo_stus_chng_dt());
        pstmt.setString(6, glp05m.getPart_no());
        pstmt.setString(7, glp05m.getPart_proj_no());
        pstmt.setString(8, glp05m.getPart_flag());
        pstmt.setString(9, glp05m.getPart_mat_code());
        pstmt.setInt(10, glp05m.getPor_qty());
        pstmt.setInt(11, glp05m.getNcv_arvl_qty());
        pstmt.setInt(12, glp05m.getInsp_qty());
        pstmt.setInt(13, glp05m.getAcpt_qty());
        pstmt.setInt(14, glp05m.getRjct_qty());
        pstmt.setInt(15, glp05m.getPo_qty());
        pstmt.setString(16, glp05m.getPo_uom());
        pstmt.setDouble(17, glp05m.getInv_unit_pr());
        pstmt.setString(18, glp05m.getPor_no());
        pstmt.setDouble(19, glp05m.getPrch_unit_pr());
        pstmt.setString(20, glp05m.getBuyr_id());
        pstmt.setString(21, glp05m.getPnd());
        pstmt.setString(22, glp05m.getStor_id());
        pstmt.setString(23, glp05m.getPo_line_rmrk());
        pstmt.setString(24, glp05m.getDlvy_date_frst());
        pstmt.setString(25, glp05m.getDlvy_date_last());
        pstmt.setDouble(26, glp05m.getUnit_wt());
        pstmt.setString(27, glp05m.getArvl_expt_date());
        pstmt.setDouble(28, glp05m.getPo_amt());
        pstmt.setString(29, glp05m.getRgdt());
        pstmt.setString(30, glp05m.getLmd());
        // Key
        pstmt.setString(31, glp05m.getPo_no());
        pstmt.setString(32, glp05m.getPo_lnno());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String po_no, String po_lnno
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(String po_no, String po_lnno) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLP05M "+
                       "where po_no = ? and po_lnno = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_lnno); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLP05MRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(GLP05MRec glp05m) throws Exception{
     delete(glp05m.getPo_no(), glp05m.getPo_lnno());
} // end Delete

}// end GLP05MDBWrapBES class