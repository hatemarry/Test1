package com.bes_line.mst.HMG;

// DBWrapper Class for GLP10M
/**
 *
 * @(#) GLP10MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLP10MDBWrapBES extends DBWrapper{

public GLP10MDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String po_no, String po_lnno
* @return GLP10MRec 
* @author besTeam 
* @date 2006-6-15
*/
public GLP10MRec select(String po_no, String po_lnno) throws Exception{
    java.util.Vector glp10mV = new java.util.Vector();
    GLP10MRec glp10m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_lnno, base_unit_pr, size_extr_unit_pr, lnth_extr_unit_pr, per_size_unit_pr, grd_extr_unit_pr, crry_unit_pr, clss_insp_unit_pr, " +
                              "cmsn_unit_pr, intr_extr_unit_pr, othr_extr_unit_pr, pnt_extr_unit_pr, dir_arvl_extr_unit_pr, cmpt_mat_extr_unit_pr, alwc_extr_unit_pr " +
                       "  from HM.GLP10M  " +
                       "  where po_no = ? and po_lnno = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_lnno); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            glp10m = new GLP10MRec(); // GLP10MRec Constructor
                     glp10m.setPo_no(rs.getString("po_no"));
                     glp10m.setPo_lnno(rs.getString("po_lnno"));
                     glp10m.setBase_unit_pr(rs.getDouble("base_unit_pr"));
                     glp10m.setSize_extr_unit_pr(rs.getDouble("size_extr_unit_pr"));
                     glp10m.setLnth_extr_unit_pr(rs.getDouble("lnth_extr_unit_pr"));
                     glp10m.setPer_size_unit_pr(rs.getDouble("per_size_unit_pr"));
                     glp10m.setGrd_extr_unit_pr(rs.getDouble("grd_extr_unit_pr"));
                     glp10m.setCrry_unit_pr(rs.getDouble("crry_unit_pr"));
                     glp10m.setClss_insp_unit_pr(rs.getDouble("clss_insp_unit_pr"));
                     glp10m.setCmsn_unit_pr(rs.getDouble("cmsn_unit_pr"));
                     glp10m.setIntr_extr_unit_pr(rs.getDouble("intr_extr_unit_pr"));
                     glp10m.setOthr_extr_unit_pr(rs.getDouble("othr_extr_unit_pr"));
                     glp10m.setPnt_extr_unit_pr(rs.getDouble("pnt_extr_unit_pr"));
                     glp10m.setDir_arvl_extr_unit_pr(rs.getDouble("dir_arvl_extr_unit_pr"));
                     glp10m.setCmpt_mat_extr_unit_pr(rs.getDouble("cmpt_mat_extr_unit_pr"));
                     glp10m.setAlwc_extr_unit_pr(rs.getDouble("alwc_extr_unit_pr"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp10m;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glp10mV = new java.util.Vector();
    GLP10MRec glp10m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_lnno, base_unit_pr, size_extr_unit_pr, lnth_extr_unit_pr, per_size_unit_pr, grd_extr_unit_pr, crry_unit_pr, clss_insp_unit_pr, " +
                              "cmsn_unit_pr, intr_extr_unit_pr, othr_extr_unit_pr, pnt_extr_unit_pr, dir_arvl_extr_unit_pr, cmpt_mat_extr_unit_pr, alwc_extr_unit_pr " +
                       "  from HM.GLP10M "+
                       "  order by po_no , po_lnno ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp10m = new GLP10MRec(); // GLP10MRec Constructor
                     glp10m.setPo_no(rs.getString("po_no"));
                     glp10m.setPo_lnno(rs.getString("po_lnno"));
                     glp10m.setBase_unit_pr(rs.getDouble("base_unit_pr"));
                     glp10m.setSize_extr_unit_pr(rs.getDouble("size_extr_unit_pr"));
                     glp10m.setLnth_extr_unit_pr(rs.getDouble("lnth_extr_unit_pr"));
                     glp10m.setPer_size_unit_pr(rs.getDouble("per_size_unit_pr"));
                     glp10m.setGrd_extr_unit_pr(rs.getDouble("grd_extr_unit_pr"));
                     glp10m.setCrry_unit_pr(rs.getDouble("crry_unit_pr"));
                     glp10m.setClss_insp_unit_pr(rs.getDouble("clss_insp_unit_pr"));
                     glp10m.setCmsn_unit_pr(rs.getDouble("cmsn_unit_pr"));
                     glp10m.setIntr_extr_unit_pr(rs.getDouble("intr_extr_unit_pr"));
                     glp10m.setOthr_extr_unit_pr(rs.getDouble("othr_extr_unit_pr"));
                     glp10m.setPnt_extr_unit_pr(rs.getDouble("pnt_extr_unit_pr"));
                     glp10m.setDir_arvl_extr_unit_pr(rs.getDouble("dir_arvl_extr_unit_pr"));
                     glp10m.setCmpt_mat_extr_unit_pr(rs.getDouble("cmpt_mat_extr_unit_pr"));
                     glp10m.setAlwc_extr_unit_pr(rs.getDouble("alwc_extr_unit_pr"));
            glp10mV.addElement(glp10m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp10mV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-15
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glp10mV = new java.util.Vector();
    GLP10MRec glp10m = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_lnno, base_unit_pr, size_extr_unit_pr, lnth_extr_unit_pr, per_size_unit_pr, grd_extr_unit_pr, crry_unit_pr, clss_insp_unit_pr, " +
                              "cmsn_unit_pr, intr_extr_unit_pr, othr_extr_unit_pr, pnt_extr_unit_pr, dir_arvl_extr_unit_pr, cmpt_mat_extr_unit_pr, alwc_extr_unit_pr " +
                       "  from HM.GLP10M  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  po_no " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp10m = new GLP10MRec(); // GLP10MRec Constructor
                     glp10m.setPo_no(rs.getString("po_no"));
                     glp10m.setPo_lnno(rs.getString("po_lnno"));
                     glp10m.setBase_unit_pr(rs.getDouble("base_unit_pr"));
                     glp10m.setSize_extr_unit_pr(rs.getDouble("size_extr_unit_pr"));
                     glp10m.setLnth_extr_unit_pr(rs.getDouble("lnth_extr_unit_pr"));
                     glp10m.setPer_size_unit_pr(rs.getDouble("per_size_unit_pr"));
                     glp10m.setGrd_extr_unit_pr(rs.getDouble("grd_extr_unit_pr"));
                     glp10m.setCrry_unit_pr(rs.getDouble("crry_unit_pr"));
                     glp10m.setClss_insp_unit_pr(rs.getDouble("clss_insp_unit_pr"));
                     glp10m.setCmsn_unit_pr(rs.getDouble("cmsn_unit_pr"));
                     glp10m.setIntr_extr_unit_pr(rs.getDouble("intr_extr_unit_pr"));
                     glp10m.setOthr_extr_unit_pr(rs.getDouble("othr_extr_unit_pr"));
                     glp10m.setPnt_extr_unit_pr(rs.getDouble("pnt_extr_unit_pr"));
                     glp10m.setDir_arvl_extr_unit_pr(rs.getDouble("dir_arvl_extr_unit_pr"));
                     glp10m.setCmpt_mat_extr_unit_pr(rs.getDouble("cmpt_mat_extr_unit_pr"));
                     glp10m.setAlwc_extr_unit_pr(rs.getDouble("alwc_extr_unit_pr"));
            glp10mV.addElement(glp10m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp10mV;
} // end selectAll

/**
* Get Rows Count 
* @param String po_no, String po_lnno
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int count(String po_no, String po_lnno) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP10M " +
                       " where po_no = ? and po_lnno = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_lnno); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-15
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP10M  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLP10MRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void insert(GLP10MRec glp10m) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLP10M( " +
                              "po_no, po_lnno, base_unit_pr, size_extr_unit_pr, lnth_extr_unit_pr, per_size_unit_pr, grd_extr_unit_pr, crry_unit_pr, clss_insp_unit_pr, " +
                              "cmsn_unit_pr, intr_extr_unit_pr, othr_extr_unit_pr, pnt_extr_unit_pr, dir_arvl_extr_unit_pr, cmpt_mat_extr_unit_pr, alwc_extr_unit_pr"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp10m.getPo_no());
        pstmt.setString(2, glp10m.getPo_lnno());
        pstmt.setDouble(3, glp10m.getBase_unit_pr());
        pstmt.setDouble(4, glp10m.getSize_extr_unit_pr());
        pstmt.setDouble(5, glp10m.getLnth_extr_unit_pr());
        pstmt.setDouble(6, glp10m.getPer_size_unit_pr());
        pstmt.setDouble(7, glp10m.getGrd_extr_unit_pr());
        pstmt.setDouble(8, glp10m.getCrry_unit_pr());
        pstmt.setDouble(9, glp10m.getClss_insp_unit_pr());
        pstmt.setDouble(10, glp10m.getCmsn_unit_pr());
        pstmt.setDouble(11, glp10m.getIntr_extr_unit_pr());
        pstmt.setDouble(12, glp10m.getOthr_extr_unit_pr());
        pstmt.setDouble(13, glp10m.getPnt_extr_unit_pr());
        pstmt.setDouble(14, glp10m.getDir_arvl_extr_unit_pr());
        pstmt.setDouble(15, glp10m.getCmpt_mat_extr_unit_pr());
        pstmt.setDouble(16, glp10m.getAlwc_extr_unit_pr());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLP10MRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void update(GLP10MRec glp10m) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLP10M SET "+
                        "po_no = ?, po_lnno = ?, base_unit_pr = ?, size_extr_unit_pr = ?, lnth_extr_unit_pr = ?, per_size_unit_pr = ?, grd_extr_unit_pr = ?, crry_unit_pr = ?, clss_insp_unit_pr = ?, cmsn_unit_pr = ?, " +
                              "intr_extr_unit_pr = ?, othr_extr_unit_pr = ?, pnt_extr_unit_pr = ?, dir_arvl_extr_unit_pr = ?, cmpt_mat_extr_unit_pr = ?, alwc_extr_unit_pr = ?"+
                        " where po_no = ? and po_lnno = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp10m.getPo_no());
        pstmt.setString(2, glp10m.getPo_lnno());
        pstmt.setDouble(3, glp10m.getBase_unit_pr());
        pstmt.setDouble(4, glp10m.getSize_extr_unit_pr());
        pstmt.setDouble(5, glp10m.getLnth_extr_unit_pr());
        pstmt.setDouble(6, glp10m.getPer_size_unit_pr());
        pstmt.setDouble(7, glp10m.getGrd_extr_unit_pr());
        pstmt.setDouble(8, glp10m.getCrry_unit_pr());
        pstmt.setDouble(9, glp10m.getClss_insp_unit_pr());
        pstmt.setDouble(10, glp10m.getCmsn_unit_pr());
        pstmt.setDouble(11, glp10m.getIntr_extr_unit_pr());
        pstmt.setDouble(12, glp10m.getOthr_extr_unit_pr());
        pstmt.setDouble(13, glp10m.getPnt_extr_unit_pr());
        pstmt.setDouble(14, glp10m.getDir_arvl_extr_unit_pr());
        pstmt.setDouble(15, glp10m.getCmpt_mat_extr_unit_pr());
        pstmt.setDouble(16, glp10m.getAlwc_extr_unit_pr());
        // Key
        pstmt.setString(17, glp10m.getPo_no());
        pstmt.setString(18, glp10m.getPo_lnno());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String po_no, String po_lnno
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(String po_no, String po_lnno) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLP10M "+
                       "where po_no = ? and po_lnno = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        pstmt.setString(2,po_lnno); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLP10MRec 
* @return void 
* @author besTeam 
* @date 2006-6-15
*/
public void delete(GLP10MRec glp10m) throws Exception{
     delete(glp10m.getPo_no(), glp10m.getPo_lnno());
} // end Delete

}// end GLP10MDBWrapBES class