package com.bes_line.mst.HMG ;

// Entity Class for GLP10M
/**
 *
 * @(#) GLP10MRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-15
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLP10MRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String po_no; 		// (VARCHAR2, 12.0)
    public String po_lnno; 		// (VARCHAR2, 3.0)
    public double base_unit_pr; 		// (NUMBER, 13.2)
    public double size_extr_unit_pr; 		// (NUMBER, 13.2)
    public double lnth_extr_unit_pr; 		// (NUMBER, 13.2)
    public double per_size_unit_pr; 		// (NUMBER, 13.2)
    public double grd_extr_unit_pr; 		// (NUMBER, 13.2)
    public double crry_unit_pr; 		// (NUMBER, 13.2)
    public double clss_insp_unit_pr; 		// (NUMBER, 13.2)
    public double cmsn_unit_pr; 		// (NUMBER, 13.2)
    public double intr_extr_unit_pr; 		// (NUMBER, 13.2)
    public double othr_extr_unit_pr; 		// (NUMBER, 13.2)
    public double pnt_extr_unit_pr; 		// (NUMBER, 13.2)
    public double dir_arvl_extr_unit_pr; 		// (NUMBER, 13.2)
    public double cmpt_mat_extr_unit_pr; 		// (NUMBER, 13.2)
    public double alwc_extr_unit_pr; 		// (NUMBER, 13.2)

public GLP10MRec(){ } // default constructor

public GLP10MRec(
       String po_no, String po_lnno, double base_unit_pr, double size_extr_unit_pr, double lnth_extr_unit_pr, double per_size_unit_pr, 
       double grd_extr_unit_pr, double crry_unit_pr, double clss_insp_unit_pr, double cmsn_unit_pr, double intr_extr_unit_pr, double othr_extr_unit_pr, 
       double pnt_extr_unit_pr, double dir_arvl_extr_unit_pr, double cmpt_mat_extr_unit_pr, double alwc_extr_unit_pr){
    this.po_no = po_no;
    this.po_lnno = po_lnno;
    this.base_unit_pr = base_unit_pr;
    this.size_extr_unit_pr = size_extr_unit_pr;
    this.lnth_extr_unit_pr = lnth_extr_unit_pr;
    this.per_size_unit_pr = per_size_unit_pr;
    this.grd_extr_unit_pr = grd_extr_unit_pr;
    this.crry_unit_pr = crry_unit_pr;
    this.clss_insp_unit_pr = clss_insp_unit_pr;
    this.cmsn_unit_pr = cmsn_unit_pr;
    this.intr_extr_unit_pr = intr_extr_unit_pr;
    this.othr_extr_unit_pr = othr_extr_unit_pr;
    this.pnt_extr_unit_pr = pnt_extr_unit_pr;
    this.dir_arvl_extr_unit_pr = dir_arvl_extr_unit_pr;
    this.cmpt_mat_extr_unit_pr = cmpt_mat_extr_unit_pr;
    this.alwc_extr_unit_pr = alwc_extr_unit_pr;
} // Constructor


// Getter 
public String getPo_no(){ return po_no;}
public String getPo_lnno(){ return po_lnno;}
public double getBase_unit_pr(){ return base_unit_pr;}
public double getSize_extr_unit_pr(){ return size_extr_unit_pr;}
public double getLnth_extr_unit_pr(){ return lnth_extr_unit_pr;}
public double getPer_size_unit_pr(){ return per_size_unit_pr;}
public double getGrd_extr_unit_pr(){ return grd_extr_unit_pr;}
public double getCrry_unit_pr(){ return crry_unit_pr;}
public double getClss_insp_unit_pr(){ return clss_insp_unit_pr;}
public double getCmsn_unit_pr(){ return cmsn_unit_pr;}
public double getIntr_extr_unit_pr(){ return intr_extr_unit_pr;}
public double getOthr_extr_unit_pr(){ return othr_extr_unit_pr;}
public double getPnt_extr_unit_pr(){ return pnt_extr_unit_pr;}
public double getDir_arvl_extr_unit_pr(){ return dir_arvl_extr_unit_pr;}
public double getCmpt_mat_extr_unit_pr(){ return cmpt_mat_extr_unit_pr;}
public double getAlwc_extr_unit_pr(){ return alwc_extr_unit_pr;}

// Setter 
public void setPo_no(String po_no){ this.po_no = po_no;}
public void setPo_lnno(String po_lnno){ this.po_lnno = po_lnno;}
public void setBase_unit_pr(double base_unit_pr){ this.base_unit_pr = base_unit_pr;}
public void setSize_extr_unit_pr(double size_extr_unit_pr){ this.size_extr_unit_pr = size_extr_unit_pr;}
public void setLnth_extr_unit_pr(double lnth_extr_unit_pr){ this.lnth_extr_unit_pr = lnth_extr_unit_pr;}
public void setPer_size_unit_pr(double per_size_unit_pr){ this.per_size_unit_pr = per_size_unit_pr;}
public void setGrd_extr_unit_pr(double grd_extr_unit_pr){ this.grd_extr_unit_pr = grd_extr_unit_pr;}
public void setCrry_unit_pr(double crry_unit_pr){ this.crry_unit_pr = crry_unit_pr;}
public void setClss_insp_unit_pr(double clss_insp_unit_pr){ this.clss_insp_unit_pr = clss_insp_unit_pr;}
public void setCmsn_unit_pr(double cmsn_unit_pr){ this.cmsn_unit_pr = cmsn_unit_pr;}
public void setIntr_extr_unit_pr(double intr_extr_unit_pr){ this.intr_extr_unit_pr = intr_extr_unit_pr;}
public void setOthr_extr_unit_pr(double othr_extr_unit_pr){ this.othr_extr_unit_pr = othr_extr_unit_pr;}
public void setPnt_extr_unit_pr(double pnt_extr_unit_pr){ this.pnt_extr_unit_pr = pnt_extr_unit_pr;}
public void setDir_arvl_extr_unit_pr(double dir_arvl_extr_unit_pr){ this.dir_arvl_extr_unit_pr = dir_arvl_extr_unit_pr;}
public void setCmpt_mat_extr_unit_pr(double cmpt_mat_extr_unit_pr){ this.cmpt_mat_extr_unit_pr = cmpt_mat_extr_unit_pr;}
public void setAlwc_extr_unit_pr(double alwc_extr_unit_pr){ this.alwc_extr_unit_pr = alwc_extr_unit_pr;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = po_no + "" ; break;
  case  2 : field = po_lnno + "" ; break;
  case  3 : field = base_unit_pr + "" ; break;
  case  4 : field = size_extr_unit_pr + "" ; break;
  case  5 : field = lnth_extr_unit_pr + "" ; break;
  case  6 : field = per_size_unit_pr + "" ; break;
  case  7 : field = grd_extr_unit_pr + "" ; break;
  case  8 : field = crry_unit_pr + "" ; break;
  case  9 : field = clss_insp_unit_pr + "" ; break;
  case  10 : field = cmsn_unit_pr + "" ; break;
  case  11 : field = intr_extr_unit_pr + "" ; break;
  case  12 : field = othr_extr_unit_pr + "" ; break;
  case  13 : field = pnt_extr_unit_pr + "" ; break;
  case  14 : field = dir_arvl_extr_unit_pr + "" ; break;
  case  15 : field = cmpt_mat_extr_unit_pr + "" ; break;
  case  16 : field = alwc_extr_unit_pr + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("po_no")){ field = po_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_lnno")){ field = po_lnno + "" ; 
     } else if(rec.equalsIgnoreCase("base_unit_pr")){ field = base_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("size_extr_unit_pr")){ field = size_extr_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("lnth_extr_unit_pr")){ field = lnth_extr_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("per_size_unit_pr")){ field = per_size_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("grd_extr_unit_pr")){ field = grd_extr_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("crry_unit_pr")){ field = crry_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("clss_insp_unit_pr")){ field = clss_insp_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("cmsn_unit_pr")){ field = cmsn_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("intr_extr_unit_pr")){ field = intr_extr_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("othr_extr_unit_pr")){ field = othr_extr_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("pnt_extr_unit_pr")){ field = pnt_extr_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("dir_arvl_extr_unit_pr")){ field = dir_arvl_extr_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("cmpt_mat_extr_unit_pr")){ field = cmpt_mat_extr_unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("alwc_extr_unit_pr")){ field = alwc_extr_unit_pr + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "PO_NO", "PO_LNNO", "BASE_UNIT_PR", "SIZE_EXTR_UNIT_PR", "LNTH_EXTR_UNIT_PR", "PER_SIZE_UNIT_PR", "GRD_EXTR_UNIT_PR", 
       "CRRY_UNIT_PR", "CLSS_INSP_UNIT_PR", "CMSN_UNIT_PR", "INTR_EXTR_UNIT_PR", "OTHR_EXTR_UNIT_PR", "PNT_EXTR_UNIT_PR", "DIR_ARVL_EXTR_UNIT_PR", 
       "CMPT_MAT_EXTR_UNIT_PR", "ALWC_EXTR_UNIT_PR"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "PO_NO", "PO_LNNO"};
    return tempx;
}

}// end GLP10MRec class