package com.bes_line.mst.HMG;

// DBWrapper Class for GLP01M
/**
 *
 * @(#) GLP01MDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-12
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLP01MDBWrapBES extends DBWrapper{

public GLP01MDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String po_no
* @return GLP01MRec 
* @author besTeam 
* @date 2006-6-12
*/
public GLP01MRec select(String po_no) throws Exception{
    java.util.Vector glp01mV = new java.util.Vector();
    GLP01MRec glp01m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_stus_code, po_rev_no, po_stus_chng_dt, rgdt, po_crnt_date, po_cfdt_intl, dlvy_term_code, spmt_port_code, " +
                              "pay_term_code, po_bilg_amt, buyr_id, po_cnfm_indc, po_cfdt_last, lmd, curr_code, vndr_grp_code, po_type, " +
                              "prdr_grp_code, po_last_lnno, po_exch_rate, rmrk_indc, rmrk_last_ser_no, arvl_code, shpg_due_date, ord_rank, dlvy_plc_code, " +
                              "path_plc_code, advc_pay_indc " +
                       "  from HM.GLP01M  " +
                       "  where po_no = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        rs = pstmt.executeQuery();
        while(rs.next()) { 
            glp01m = new GLP01MRec(); // GLP01MRec Constructor
                     glp01m.setPo_no(rs.getString("po_no"));
                     glp01m.setPo_stus_code(rs.getString("po_stus_code"));
                     glp01m.setPo_rev_no(rs.getString("po_rev_no"));
                     glp01m.setPo_stus_chng_dt(rs.getString("po_stus_chng_dt"));
                     glp01m.setRgdt(rs.getString("rgdt"));
                     glp01m.setPo_crnt_date(rs.getString("po_crnt_date"));
                     glp01m.setPo_cfdt_intl(rs.getString("po_cfdt_intl"));
                     glp01m.setDlvy_term_code(rs.getString("dlvy_term_code"));
                     glp01m.setSpmt_port_code(rs.getString("spmt_port_code"));
                     glp01m.setPay_term_code(rs.getString("pay_term_code"));
                     glp01m.setPo_bilg_amt(rs.getDouble("po_bilg_amt"));
                     glp01m.setBuyr_id(rs.getString("buyr_id"));
                     glp01m.setPo_cnfm_indc(rs.getString("po_cnfm_indc"));
                     glp01m.setPo_cfdt_last(rs.getString("po_cfdt_last"));
                     glp01m.setLmd(rs.getString("lmd"));
                     glp01m.setCurr_code(rs.getString("curr_code"));
                     glp01m.setVndr_grp_code(rs.getString("vndr_grp_code"));
                     glp01m.setPo_type(rs.getString("po_type"));
                     glp01m.setPrdr_grp_code(rs.getString("prdr_grp_code"));
                     glp01m.setPo_last_lnno(rs.getInt("po_last_lnno"));
                     glp01m.setPo_exch_rate(rs.getDouble("po_exch_rate"));
                     glp01m.setRmrk_indc(rs.getString("rmrk_indc"));
                     glp01m.setRmrk_last_ser_no(rs.getInt("rmrk_last_ser_no"));
                     glp01m.setArvl_code(rs.getString("arvl_code"));
                     glp01m.setShpg_due_date(rs.getString("shpg_due_date"));
                     glp01m.setOrd_rank(rs.getString("ord_rank"));
                     glp01m.setDlvy_plc_code(rs.getString("dlvy_plc_code"));
                     glp01m.setPath_plc_code(rs.getString("path_plc_code"));
                     glp01m.setAdvc_pay_indc(rs.getString("advc_pay_indc"));
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp01m;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-12
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glp01mV = new java.util.Vector();
    GLP01MRec glp01m = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_stus_code, po_rev_no, po_stus_chng_dt, rgdt, po_crnt_date, po_cfdt_intl, dlvy_term_code, spmt_port_code, " +
                              "pay_term_code, po_bilg_amt, buyr_id, po_cnfm_indc, po_cfdt_last, lmd, curr_code, vndr_grp_code, po_type, " +
                              "prdr_grp_code, po_last_lnno, po_exch_rate, rmrk_indc, rmrk_last_ser_no, arvl_code, shpg_due_date, ord_rank, dlvy_plc_code, " +
                              "path_plc_code, advc_pay_indc " +
                       "  from HM.GLP01M "+
                       "  order by po_no ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp01m = new GLP01MRec(); // GLP01MRec Constructor
                     glp01m.setPo_no(rs.getString("po_no"));
                     glp01m.setPo_stus_code(rs.getString("po_stus_code"));
                     glp01m.setPo_rev_no(rs.getString("po_rev_no"));
                     glp01m.setPo_stus_chng_dt(rs.getString("po_stus_chng_dt"));
                     glp01m.setRgdt(rs.getString("rgdt"));
                     glp01m.setPo_crnt_date(rs.getString("po_crnt_date"));
                     glp01m.setPo_cfdt_intl(rs.getString("po_cfdt_intl"));
                     glp01m.setDlvy_term_code(rs.getString("dlvy_term_code"));
                     glp01m.setSpmt_port_code(rs.getString("spmt_port_code"));
                     glp01m.setPay_term_code(rs.getString("pay_term_code"));
                     glp01m.setPo_bilg_amt(rs.getDouble("po_bilg_amt"));
                     glp01m.setBuyr_id(rs.getString("buyr_id"));
                     glp01m.setPo_cnfm_indc(rs.getString("po_cnfm_indc"));
                     glp01m.setPo_cfdt_last(rs.getString("po_cfdt_last"));
                     glp01m.setLmd(rs.getString("lmd"));
                     glp01m.setCurr_code(rs.getString("curr_code"));
                     glp01m.setVndr_grp_code(rs.getString("vndr_grp_code"));
                     glp01m.setPo_type(rs.getString("po_type"));
                     glp01m.setPrdr_grp_code(rs.getString("prdr_grp_code"));
                     glp01m.setPo_last_lnno(rs.getInt("po_last_lnno"));
                     glp01m.setPo_exch_rate(rs.getDouble("po_exch_rate"));
                     glp01m.setRmrk_indc(rs.getString("rmrk_indc"));
                     glp01m.setRmrk_last_ser_no(rs.getInt("rmrk_last_ser_no"));
                     glp01m.setArvl_code(rs.getString("arvl_code"));
                     glp01m.setShpg_due_date(rs.getString("shpg_due_date"));
                     glp01m.setOrd_rank(rs.getString("ord_rank"));
                     glp01m.setDlvy_plc_code(rs.getString("dlvy_plc_code"));
                     glp01m.setPath_plc_code(rs.getString("path_plc_code"));
                     glp01m.setAdvc_pay_indc(rs.getString("advc_pay_indc"));
            glp01mV.addElement(glp01m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp01mV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-12
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glp01mV = new java.util.Vector();
    GLP01MRec glp01m = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select po_no, po_stus_code, po_rev_no, po_stus_chng_dt, rgdt, po_crnt_date, po_cfdt_intl, dlvy_term_code, spmt_port_code, " +
                              "pay_term_code, po_bilg_amt, buyr_id, po_cnfm_indc, po_cfdt_last, lmd, curr_code, vndr_grp_code, po_type, " +
                              "prdr_grp_code, po_last_lnno, po_exch_rate, rmrk_indc, rmrk_last_ser_no, arvl_code, shpg_due_date, ord_rank, dlvy_plc_code, " +
                              "path_plc_code, advc_pay_indc " +
                       "  from HM.GLP01M  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  po_no " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glp01m = new GLP01MRec(); // GLP01MRec Constructor
                     glp01m.setPo_no(rs.getString("po_no"));
                     glp01m.setPo_stus_code(rs.getString("po_stus_code"));
                     glp01m.setPo_rev_no(rs.getString("po_rev_no"));
                     glp01m.setPo_stus_chng_dt(rs.getString("po_stus_chng_dt"));
                     glp01m.setRgdt(rs.getString("rgdt"));
                     glp01m.setPo_crnt_date(rs.getString("po_crnt_date"));
                     glp01m.setPo_cfdt_intl(rs.getString("po_cfdt_intl"));
                     glp01m.setDlvy_term_code(rs.getString("dlvy_term_code"));
                     glp01m.setSpmt_port_code(rs.getString("spmt_port_code"));
                     glp01m.setPay_term_code(rs.getString("pay_term_code"));
                     glp01m.setPo_bilg_amt(rs.getDouble("po_bilg_amt"));
                     glp01m.setBuyr_id(rs.getString("buyr_id"));
                     glp01m.setPo_cnfm_indc(rs.getString("po_cnfm_indc"));
                     glp01m.setPo_cfdt_last(rs.getString("po_cfdt_last"));
                     glp01m.setLmd(rs.getString("lmd"));
                     glp01m.setCurr_code(rs.getString("curr_code"));
                     glp01m.setVndr_grp_code(rs.getString("vndr_grp_code"));
                     glp01m.setPo_type(rs.getString("po_type"));
                     glp01m.setPrdr_grp_code(rs.getString("prdr_grp_code"));
                     glp01m.setPo_last_lnno(rs.getInt("po_last_lnno"));
                     glp01m.setPo_exch_rate(rs.getDouble("po_exch_rate"));
                     glp01m.setRmrk_indc(rs.getString("rmrk_indc"));
                     glp01m.setRmrk_last_ser_no(rs.getInt("rmrk_last_ser_no"));
                     glp01m.setArvl_code(rs.getString("arvl_code"));
                     glp01m.setShpg_due_date(rs.getString("shpg_due_date"));
                     glp01m.setOrd_rank(rs.getString("ord_rank"));
                     glp01m.setDlvy_plc_code(rs.getString("dlvy_plc_code"));
                     glp01m.setPath_plc_code(rs.getString("path_plc_code"));
                     glp01m.setAdvc_pay_indc(rs.getString("advc_pay_indc"));
            glp01mV.addElement(glp01m);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glp01mV;
} // end selectAll

/**
* Get Rows Count 
* @param String po_no
* @return int 
* @author besTeam 
* @date 2006-6-12
*/
public int count(String po_no) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP01M " +
                       " where po_no = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-12
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLP01M  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLP01MRec 
* @return void 
* @author besTeam 
* @date 2006-6-12
*/
public void insert(GLP01MRec glp01m) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLP01M( " +
                              "po_no, po_stus_code, po_rev_no, po_stus_chng_dt, rgdt, po_crnt_date, po_cfdt_intl, dlvy_term_code, spmt_port_code, " +
                              "pay_term_code, po_bilg_amt, buyr_id, po_cnfm_indc, po_cfdt_last, lmd, curr_code, vndr_grp_code, po_type, " +
                              "prdr_grp_code, po_last_lnno, po_exch_rate, rmrk_indc, rmrk_last_ser_no, arvl_code, shpg_due_date, ord_rank, dlvy_plc_code, " +
                              "path_plc_code, advc_pay_indc"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp01m.getPo_no());
        pstmt.setString(2, glp01m.getPo_stus_code());
        pstmt.setString(3, glp01m.getPo_rev_no());
        pstmt.setString(4, glp01m.getPo_stus_chng_dt());
        pstmt.setString(5, glp01m.getRgdt());
        pstmt.setString(6, glp01m.getPo_crnt_date());
        pstmt.setString(7, glp01m.getPo_cfdt_intl());
        pstmt.setString(8, glp01m.getDlvy_term_code());
        pstmt.setString(9, glp01m.getSpmt_port_code());
        pstmt.setString(10, glp01m.getPay_term_code());
        pstmt.setDouble(11, glp01m.getPo_bilg_amt());
        pstmt.setString(12, glp01m.getBuyr_id());
        pstmt.setString(13, glp01m.getPo_cnfm_indc());
        pstmt.setString(14, glp01m.getPo_cfdt_last());
        pstmt.setString(15, glp01m.getLmd());
        pstmt.setString(16, glp01m.getCurr_code());
        pstmt.setString(17, glp01m.getVndr_grp_code());
        pstmt.setString(18, glp01m.getPo_type());
        pstmt.setString(19, glp01m.getPrdr_grp_code());
        pstmt.setInt(20, glp01m.getPo_last_lnno());
        pstmt.setDouble(21, glp01m.getPo_exch_rate());
        pstmt.setString(22, glp01m.getRmrk_indc());
        pstmt.setInt(23, glp01m.getRmrk_last_ser_no());
        pstmt.setString(24, glp01m.getArvl_code());
        pstmt.setString(25, glp01m.getShpg_due_date());
        pstmt.setString(26, glp01m.getOrd_rank());
        pstmt.setString(27, glp01m.getDlvy_plc_code());
        pstmt.setString(28, glp01m.getPath_plc_code());
        pstmt.setString(29, glp01m.getAdvc_pay_indc());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLP01MRec 
* @return void 
* @author besTeam 
* @date 2006-6-12
*/
public void update(GLP01MRec glp01m) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLP01M SET "+
                        "po_no = ?, po_stus_code = ?, po_rev_no = ?, po_stus_chng_dt = ?, rgdt = ?, po_crnt_date = ?, po_cfdt_intl = ?, dlvy_term_code = ?, spmt_port_code = ?, pay_term_code = ?, " +
                              "po_bilg_amt = ?, buyr_id = ?, po_cnfm_indc = ?, po_cfdt_last = ?, lmd = ?, curr_code = ?, vndr_grp_code = ?, po_type = ?, prdr_grp_code = ?, " +
                              "po_last_lnno = ?, po_exch_rate = ?, rmrk_indc = ?, rmrk_last_ser_no = ?, arvl_code = ?, shpg_due_date = ?, ord_rank = ?, dlvy_plc_code = ?, path_plc_code = ?, " +
                              "advc_pay_indc = ?"+
                        " where po_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glp01m.getPo_no());
        pstmt.setString(2, glp01m.getPo_stus_code());
        pstmt.setString(3, glp01m.getPo_rev_no());
        pstmt.setString(4, glp01m.getPo_stus_chng_dt());
        pstmt.setString(5, glp01m.getRgdt());
        pstmt.setString(6, glp01m.getPo_crnt_date());
        pstmt.setString(7, glp01m.getPo_cfdt_intl());
        pstmt.setString(8, glp01m.getDlvy_term_code());
        pstmt.setString(9, glp01m.getSpmt_port_code());
        pstmt.setString(10, glp01m.getPay_term_code());
        pstmt.setDouble(11, glp01m.getPo_bilg_amt());
        pstmt.setString(12, glp01m.getBuyr_id());
        pstmt.setString(13, glp01m.getPo_cnfm_indc());
        pstmt.setString(14, glp01m.getPo_cfdt_last());
        pstmt.setString(15, glp01m.getLmd());
        pstmt.setString(16, glp01m.getCurr_code());
        pstmt.setString(17, glp01m.getVndr_grp_code());
        pstmt.setString(18, glp01m.getPo_type());
        pstmt.setString(19, glp01m.getPrdr_grp_code());
        pstmt.setInt(20, glp01m.getPo_last_lnno());
        pstmt.setDouble(21, glp01m.getPo_exch_rate());
        pstmt.setString(22, glp01m.getRmrk_indc());
        pstmt.setInt(23, glp01m.getRmrk_last_ser_no());
        pstmt.setString(24, glp01m.getArvl_code());
        pstmt.setString(25, glp01m.getShpg_due_date());
        pstmt.setString(26, glp01m.getOrd_rank());
        pstmt.setString(27, glp01m.getDlvy_plc_code());
        pstmt.setString(28, glp01m.getPath_plc_code());
        pstmt.setString(29, glp01m.getAdvc_pay_indc());
        // Key
        pstmt.setString(30, glp01m.getPo_no());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String po_no
* @return void 
* @author besTeam 
* @date 2006-6-12
*/
public void delete(String po_no) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLP01M "+
                       "where po_no = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,po_no); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLP01MRec 
* @return void 
* @author besTeam 
* @date 2006-6-12
*/
public void delete(GLP01MRec glp01m) throws Exception{
     delete(glp01m.getPo_no());
} // end Delete

}// end GLP01MDBWrapBES class