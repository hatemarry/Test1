package com.bes_line.mst.HMG ;

// Entity Class for GLG23C
/**
 *
 * @(#) GLG23CRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-9
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLG23CRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String natn_code; 		// (VARCHAR2, 3.0)
    public String natn_code_iso; 		// (VARCHAR2, 3.0)
    public String natn_code_iso_2; 		// (VARCHAR2, 2.0)
    public String natn_desc; 		// (VARCHAR2, 65.0)
    public String natn_std_desc_chns; 		// (VARCHAR2, 80.0)
    public String natn_ctnt_id; 		// (VARCHAR2, 1.0)
    public String tel_natn_code; 		// (VARCHAR2, 3.0)
    public String rgsr_emp_no; 		// (VARCHAR2, 7.0)
    public String rgdt; 		// (VARCHAR2, 8.0)

public GLG23CRec(){ } // default constructor

public GLG23CRec(
       String natn_code, String natn_code_iso, String natn_code_iso_2, String natn_desc, String natn_std_desc_chns, String natn_ctnt_id, 
       String tel_natn_code, String rgsr_emp_no, String rgdt){
    this.natn_code = natn_code;
    this.natn_code_iso = natn_code_iso;
    this.natn_code_iso_2 = natn_code_iso_2;
    this.natn_desc = natn_desc;
    this.natn_std_desc_chns = natn_std_desc_chns;
    this.natn_ctnt_id = natn_ctnt_id;
    this.tel_natn_code = tel_natn_code;
    this.rgsr_emp_no = rgsr_emp_no;
    this.rgdt = rgdt;
} // Constructor


// Getter 
public String getNatn_code(){ return natn_code;}
public String getNatn_code_iso(){ return natn_code_iso;}
public String getNatn_code_iso_2(){ return natn_code_iso_2;}
public String getNatn_desc(){ return natn_desc;}
public String getNatn_std_desc_chns(){ return natn_std_desc_chns;}
public String getNatn_ctnt_id(){ return natn_ctnt_id;}
public String getTel_natn_code(){ return tel_natn_code;}
public String getRgsr_emp_no(){ return rgsr_emp_no;}
public String getRgdt(){ return rgdt;}

// Setter 
public void setNatn_code(String natn_code){ this.natn_code = natn_code;}
public void setNatn_code_iso(String natn_code_iso){ this.natn_code_iso = natn_code_iso;}
public void setNatn_code_iso_2(String natn_code_iso_2){ this.natn_code_iso_2 = natn_code_iso_2;}
public void setNatn_desc(String natn_desc){ this.natn_desc = natn_desc;}
public void setNatn_std_desc_chns(String natn_std_desc_chns){ this.natn_std_desc_chns = natn_std_desc_chns;}
public void setNatn_ctnt_id(String natn_ctnt_id){ this.natn_ctnt_id = natn_ctnt_id;}
public void setTel_natn_code(String tel_natn_code){ this.tel_natn_code = tel_natn_code;}
public void setRgsr_emp_no(String rgsr_emp_no){ this.rgsr_emp_no = rgsr_emp_no;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = natn_code + "" ; break;
  case  2 : field = natn_code_iso + "" ; break;
  case  3 : field = natn_code_iso_2 + "" ; break;
  case  4 : field = natn_desc + "" ; break;
  case  5 : field = natn_std_desc_chns + "" ; break;
  case  6 : field = natn_ctnt_id + "" ; break;
  case  7 : field = tel_natn_code + "" ; break;
  case  8 : field = rgsr_emp_no + "" ; break;
  case  9 : field = rgdt + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("natn_code")){ field = natn_code + "" ; 
     } else if(rec.equalsIgnoreCase("natn_code_iso")){ field = natn_code_iso + "" ; 
     } else if(rec.equalsIgnoreCase("natn_code_iso_2")){ field = natn_code_iso_2 + "" ; 
     } else if(rec.equalsIgnoreCase("natn_desc")){ field = natn_desc + "" ; 
     } else if(rec.equalsIgnoreCase("natn_std_desc_chns")){ field = natn_std_desc_chns + "" ; 
     } else if(rec.equalsIgnoreCase("natn_ctnt_id")){ field = natn_ctnt_id + "" ; 
     } else if(rec.equalsIgnoreCase("tel_natn_code")){ field = tel_natn_code + "" ; 
     } else if(rec.equalsIgnoreCase("rgsr_emp_no")){ field = rgsr_emp_no + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "NATN_CODE", "NATN_CODE_ISO", "NATN_CODE_ISO_2", "NATN_DESC", "NATN_STD_DESC_CHNS", "NATN_CTNT_ID", "TEL_NATN_CODE", 
       "RGSR_EMP_NO", "RGDT"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "NATN_CODE"};
    return tempx;
}

}// end GLG23CRec class