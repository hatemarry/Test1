package com.bes_line.mst.HMG;

// DBWrapper Class for GLG23C
/**
 *
 * @(#) GLG23CDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-9
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLG23CDBWrapBES extends DBWrapper{

public GLG23CDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String natn_code
* @return GLG23CRec 
* @author besTeam 
* @date 2006-6-9
*/
public GLG23CRec select(String natn_code) throws Exception{
    java.util.Vector glg23cV = new java.util.Vector();
    GLG23CRec glg23c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select natn_code, natn_code_iso, natn_code_iso_2, natn_desc, natn_std_desc_chns, natn_ctnt_id, tel_natn_code, rgsr_emp_no, rgdt " +
                       "  from HM.GLG23C  " +
                       "  where natn_code = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,natn_code); 
        rs = pstmt.executeQuery();
        while(rs.next()) { 
            glg23c = new GLG23CRec(); // GLG23CRec Constructor
                     glg23c.setNatn_code(rs.getString("natn_code"));
                     glg23c.setNatn_code_iso(rs.getString("natn_code_iso"));
                     glg23c.setNatn_code_iso_2(rs.getString("natn_code_iso_2"));
                     glg23c.setNatn_desc(rs.getString("natn_desc"));
                     glg23c.setNatn_std_desc_chns(rs.getString("natn_std_desc_chns"));
                     glg23c.setNatn_ctnt_id(rs.getString("natn_ctnt_id"));
                     glg23c.setTel_natn_code(rs.getString("tel_natn_code"));
                     glg23c.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     glg23c.setRgdt(rs.getString("rgdt"));
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg23c;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-9
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector glg23cV = new java.util.Vector();
    GLG23CRec glg23c = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select natn_code, natn_code_iso, natn_code_iso_2, natn_desc, natn_std_desc_chns, natn_ctnt_id, tel_natn_code, rgsr_emp_no, rgdt " +
                       "  from HM.GLG23C "+
                       "  order by natn_code ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            glg23c = new GLG23CRec(); // GLG23CRec Constructor
                     glg23c.setNatn_code(rs.getString("natn_code"));
                     glg23c.setNatn_code_iso(rs.getString("natn_code_iso"));
                     glg23c.setNatn_code_iso_2(rs.getString("natn_code_iso_2"));
                     glg23c.setNatn_desc(rs.getString("natn_desc"));
                     glg23c.setNatn_std_desc_chns(rs.getString("natn_std_desc_chns"));
                     glg23c.setNatn_ctnt_id(rs.getString("natn_ctnt_id"));
                     glg23c.setTel_natn_code(rs.getString("tel_natn_code"));
                     glg23c.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     glg23c.setRgdt(rs.getString("rgdt"));
            glg23cV.addElement(glg23c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg23cV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-9
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector glg23cV = new java.util.Vector();
    GLG23CRec glg23c = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select natn_code, natn_code_iso, natn_code_iso_2, natn_desc, natn_std_desc_chns, natn_ctnt_id, tel_natn_code, rgsr_emp_no, rgdt " +
                       "  from HM.GLG23C  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  natn_code " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            glg23c = new GLG23CRec(); // GLG23CRec Constructor
                     glg23c.setNatn_code(rs.getString("natn_code"));
                     glg23c.setNatn_code_iso(rs.getString("natn_code_iso"));
                     glg23c.setNatn_code_iso_2(rs.getString("natn_code_iso_2"));
                     glg23c.setNatn_desc(rs.getString("natn_desc"));
                     glg23c.setNatn_std_desc_chns(rs.getString("natn_std_desc_chns"));
                     glg23c.setNatn_ctnt_id(rs.getString("natn_ctnt_id"));
                     glg23c.setTel_natn_code(rs.getString("tel_natn_code"));
                     glg23c.setRgsr_emp_no(rs.getString("rgsr_emp_no"));
                     glg23c.setRgdt(rs.getString("rgdt"));
            glg23cV.addElement(glg23c);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return glg23cV;
} // end selectAll

/**
* Get Rows Count 
* @param String natn_code
* @return int 
* @author besTeam 
* @date 2006-6-9
*/
public int count(String natn_code) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLG23C " +
                       " where natn_code = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,natn_code); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-9
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLG23C  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLG23CRec 
* @return void 
* @author besTeam 
* @date 2006-6-9
*/
public void insert(GLG23CRec glg23c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLG23C( " +
                              "natn_code, natn_code_iso, natn_code_iso_2, natn_desc, natn_std_desc_chns, natn_ctnt_id, tel_natn_code, rgsr_emp_no, rgdt"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glg23c.getNatn_code());
        pstmt.setString(2, glg23c.getNatn_code_iso());
        pstmt.setString(3, glg23c.getNatn_code_iso_2());
        pstmt.setString(4, glg23c.getNatn_desc());
        pstmt.setString(5, glg23c.getNatn_std_desc_chns());
        pstmt.setString(6, glg23c.getNatn_ctnt_id());
        pstmt.setString(7, glg23c.getTel_natn_code());
        pstmt.setString(8, glg23c.getRgsr_emp_no());
        pstmt.setString(9, glg23c.getRgdt());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLG23CRec 
* @return void 
* @author besTeam 
* @date 2006-6-9
*/
public void update(GLG23CRec glg23c) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLG23C SET "+
                        "natn_code = ?, natn_code_iso = ?, natn_code_iso_2 = ?, natn_desc = ?, natn_std_desc_chns = ?, natn_ctnt_id = ?, tel_natn_code = ?, rgdt = ?"+
                        " where natn_code = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, glg23c.getNatn_code());
        pstmt.setString(2, glg23c.getNatn_code_iso());
        pstmt.setString(3, glg23c.getNatn_code_iso_2());
        pstmt.setString(4, glg23c.getNatn_desc());
        pstmt.setString(5, glg23c.getNatn_std_desc_chns());
        pstmt.setString(6, glg23c.getNatn_ctnt_id());
        pstmt.setString(7, glg23c.getTel_natn_code());
        pstmt.setString(8, glg23c.getRgdt());
        // Key
        pstmt.setString(9, glg23c.getNatn_code());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String natn_code
* @return void 
* @author besTeam 
* @date 2006-6-9
*/
public void delete(String natn_code) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLG23C "+
                       "where natn_code = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,natn_code); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLG23CRec 
* @return void 
* @author besTeam 
* @date 2006-6-9
*/
public void delete(GLG23CRec glg23c) throws Exception{
     delete(glg23c.getNatn_code());
} // end Delete

}// end GLG23CDBWrapBES class