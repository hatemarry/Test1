package com.bes_line.mst.HMG ;

// Entity Class for GLA06H
/**
 *
 * @(#) GLA06HRec.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-27
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import org.jsn.jdf.db.*;

public class GLA06HRec extends EntityData {
    // NUMERIC = Zoned Decimal, DECIMAL = Packed Decimal. (7.3 = 1234.123) 
    public String acpt_id; 		// (VARCHAR2, 11.0)
    public String acpt_rev_no; 		// (VARCHAR2, 2.0)
    public String po_lnno; 		// (VARCHAR2, 3.0)
    public String po_no; 		// (VARCHAR2, 12.0)
    public String part_no; 		// (VARCHAR2, 18.0)
    public String stor_id; 		// (VARCHAR2, 4.0)
    public String rjct_code; 		// (VARCHAR2, 3.0)
    public String loc_code; 		// (VARCHAR2, 6.0)
    public double unit_pr; 		// (NUMBER, 13.2)
    public int arvl_qty; 		// (NUMBER, 7.0)
    public int rjct_qty; 		// (NUMBER, 7.0)
    public int acpt_qty; 		// (NUMBER, 7.0)
    public double acpt_amt; 		// (NUMBER, 13.2)
    public double acpt_amt_yuan; 		// (NUMBER, 13.2)
    public double acpt_wt; 		// (NUMBER, 13.3)
    public String acpt_date; 		// (VARCHAR2, 8.0)
    public String rgdt; 		// (VARCHAR2, 8.0)
    public String lmd; 		// (VARCHAR2, 8.0)
    public String mode_id; 		// (VARCHAR2, 1.0)
    public String mnt_date; 		// (VARCHAR2, 8.0)
    public String mnt_time; 		// (VARCHAR2, 6.0)
    public String mnt_emp_no; 		// (VARCHAR2, 7.0)

public GLA06HRec(){ } // default constructor

public GLA06HRec(
       String acpt_id, String acpt_rev_no, String po_lnno, String po_no, String part_no, String stor_id, 
       String rjct_code, String loc_code, double unit_pr, int arvl_qty, int rjct_qty, int acpt_qty, 
       double acpt_amt, double acpt_amt_yuan, double acpt_wt, String acpt_date, String rgdt, String lmd, 
       String mode_id, String mnt_date, String mnt_time, String mnt_emp_no){
    this.acpt_id = acpt_id;
    this.acpt_rev_no = acpt_rev_no;
    this.po_lnno = po_lnno;
    this.po_no = po_no;
    this.part_no = part_no;
    this.stor_id = stor_id;
    this.rjct_code = rjct_code;
    this.loc_code = loc_code;
    this.unit_pr = unit_pr;
    this.arvl_qty = arvl_qty;
    this.rjct_qty = rjct_qty;
    this.acpt_qty = acpt_qty;
    this.acpt_amt = acpt_amt;
    this.acpt_amt_yuan = acpt_amt_yuan;
    this.acpt_wt = acpt_wt;
    this.acpt_date = acpt_date;
    this.rgdt = rgdt;
    this.lmd = lmd;
    this.mode_id = mode_id;
    this.mnt_date = mnt_date;
    this.mnt_time = mnt_time;
    this.mnt_emp_no = mnt_emp_no;
} // Constructor


// Getter 
public String getAcpt_id(){ return acpt_id;}
public String getAcpt_rev_no(){ return acpt_rev_no;}
public String getPo_lnno(){ return po_lnno;}
public String getPo_no(){ return po_no;}
public String getPart_no(){ return part_no;}
public String getStor_id(){ return stor_id;}
public String getRjct_code(){ return rjct_code;}
public String getLoc_code(){ return loc_code;}
public double getUnit_pr(){ return unit_pr;}
public int getArvl_qty(){ return arvl_qty;}
public int getRjct_qty(){ return rjct_qty;}
public int getAcpt_qty(){ return acpt_qty;}
public double getAcpt_amt(){ return acpt_amt;}
public double getAcpt_amt_yuan(){ return acpt_amt_yuan;}
public double getAcpt_wt(){ return acpt_wt;}
public String getAcpt_date(){ return acpt_date;}
public String getRgdt(){ return rgdt;}
public String getLmd(){ return lmd;}
public String getMode_id(){ return mode_id;}
public String getMnt_date(){ return mnt_date;}
public String getMnt_time(){ return mnt_time;}
public String getMnt_emp_no(){ return mnt_emp_no;}

// Setter 
public void setAcpt_id(String acpt_id){ this.acpt_id = acpt_id;}
public void setAcpt_rev_no(String acpt_rev_no){ this.acpt_rev_no = acpt_rev_no;}
public void setPo_lnno(String po_lnno){ this.po_lnno = po_lnno;}
public void setPo_no(String po_no){ this.po_no = po_no;}
public void setPart_no(String part_no){ this.part_no = part_no;}
public void setStor_id(String stor_id){ this.stor_id = stor_id;}
public void setRjct_code(String rjct_code){ this.rjct_code = rjct_code;}
public void setLoc_code(String loc_code){ this.loc_code = loc_code;}
public void setUnit_pr(double unit_pr){ this.unit_pr = unit_pr;}
public void setArvl_qty(int arvl_qty){ this.arvl_qty = arvl_qty;}
public void setRjct_qty(int rjct_qty){ this.rjct_qty = rjct_qty;}
public void setAcpt_qty(int acpt_qty){ this.acpt_qty = acpt_qty;}
public void setAcpt_amt(double acpt_amt){ this.acpt_amt = acpt_amt;}
public void setAcpt_amt_yuan(double acpt_amt_yuan){ this.acpt_amt_yuan = acpt_amt_yuan;}
public void setAcpt_wt(double acpt_wt){ this.acpt_wt = acpt_wt;}
public void setAcpt_date(String acpt_date){ this.acpt_date = acpt_date;}
public void setRgdt(String rgdt){ this.rgdt = rgdt;}
public void setLmd(String lmd){ this.lmd = lmd;}
public void setMode_id(String mode_id){ this.mode_id = mode_id;}
public void setMnt_date(String mnt_date){ this.mnt_date = mnt_date;}
public void setMnt_time(String mnt_time){ this.mnt_time = mnt_time;}
public void setMnt_emp_no(String mnt_emp_no){ this.mnt_emp_no = mnt_emp_no;}

/**
* getString 
* @param int seq 
* @return field Value 
*/
public String getString(int seq){ 
 String field=null;
  switch (seq) {
  case  1 : field = acpt_id + "" ; break;
  case  2 : field = acpt_rev_no + "" ; break;
  case  3 : field = po_lnno + "" ; break;
  case  4 : field = po_no + "" ; break;
  case  5 : field = part_no + "" ; break;
  case  6 : field = stor_id + "" ; break;
  case  7 : field = rjct_code + "" ; break;
  case  8 : field = loc_code + "" ; break;
  case  9 : field = unit_pr + "" ; break;
  case  10 : field = arvl_qty + "" ; break;
  case  11 : field = rjct_qty + "" ; break;
  case  12 : field = acpt_qty + "" ; break;
  case  13 : field = acpt_amt + "" ; break;
  case  14 : field = acpt_amt_yuan + "" ; break;
  case  15 : field = acpt_wt + "" ; break;
  case  16 : field = acpt_date + "" ; break;
  case  17 : field = rgdt + "" ; break;
  case  18 : field = lmd + "" ; break;
  case  19 : field = mode_id + "" ; break;
  case  20 : field = mnt_date + "" ; break;
  case  21 : field = mnt_time + "" ; break;
  case  22 : field = mnt_emp_no + "" ; break;
  } // end switch
  return field;
}// end getString (int seq)

/**
* getString 
* @param String fieldName 
* @return field Value 
*/
public String getString(String rec){ 
 String field=null;
     if       (rec.equalsIgnoreCase("acpt_id")){ field = acpt_id + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_rev_no")){ field = acpt_rev_no + "" ; 
     } else if(rec.equalsIgnoreCase("po_lnno")){ field = po_lnno + "" ; 
     } else if(rec.equalsIgnoreCase("po_no")){ field = po_no + "" ; 
     } else if(rec.equalsIgnoreCase("part_no")){ field = part_no + "" ; 
     } else if(rec.equalsIgnoreCase("stor_id")){ field = stor_id + "" ; 
     } else if(rec.equalsIgnoreCase("rjct_code")){ field = rjct_code + "" ; 
     } else if(rec.equalsIgnoreCase("loc_code")){ field = loc_code + "" ; 
     } else if(rec.equalsIgnoreCase("unit_pr")){ field = unit_pr + "" ; 
     } else if(rec.equalsIgnoreCase("arvl_qty")){ field = arvl_qty + "" ; 
     } else if(rec.equalsIgnoreCase("rjct_qty")){ field = rjct_qty + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_qty")){ field = acpt_qty + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_amt")){ field = acpt_amt + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_amt_yuan")){ field = acpt_amt_yuan + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_wt")){ field = acpt_wt + "" ; 
     } else if(rec.equalsIgnoreCase("acpt_date")){ field = acpt_date + "" ; 
     } else if(rec.equalsIgnoreCase("rgdt")){ field = rgdt + "" ; 
     } else if(rec.equalsIgnoreCase("lmd")){ field = lmd + "" ; 
     } else if(rec.equalsIgnoreCase("mode_id")){ field = mode_id + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_date")){ field = mnt_date + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_time")){ field = mnt_time + "" ; 
     } else if(rec.equalsIgnoreCase("mnt_emp_no")){ field = mnt_emp_no + "" ; 
}// end if
 return field;
}// end getString (String fieldName)

/**
* fieldNames 
* @param none 
* @return field Names[]
*/
public String[] fieldNames() {
    String [] tempx = {"", "ACPT_ID", "ACPT_REV_NO", "PO_LNNO", "PO_NO", "PART_NO", "STOR_ID", "RJCT_CODE", 
       "LOC_CODE", "UNIT_PR", "ARVL_QTY", "RJCT_QTY", "ACPT_QTY", "ACPT_AMT", "ACPT_AMT_YUAN", 
       "ACPT_WT", "ACPT_DATE", "RGDT", "LMD", "MODE_ID", "MNT_DATE", "MNT_TIME", 
       "MNT_EMP_NO"};
    return tempx;
}

/**
* Key fieldNames 
* @param none 
* @return Key field Names[]
*/
public String[] keyFieldNames() {
    String [] tempx = {"", "ACPT_ID", "ACPT_REV_NO", "PO_LNNO"};
    return tempx;
}

}// end GLA06HRec class