package com.bes_line.mst.HMG;

// DBWrapper Class for GLA06H
/**
 *
 * @(#) GLA06HDBWrapBES.java
 * Copyright 1999-2001 by  Daewoo Information System, Inc.,
 * BES(Best Enterprise System) Team,
 * 526, 5-Ga, NamDaeMoon-Ro, Jung-Gu, Seoul, 100-095, Korea
 * All rights reserved.
 *
 * NOTICE !  You cannot copy or redistribute this code,
 * and you should not remove the information about the
 * copyright notice and the author.
 *
 * @version v0.1
 * @date    2006-6-27
 * @author  WonDeok Kim, wdkim(at)disc.co.kr.
 * @since   JDK1.2
 *
 */

import java.sql.*;
import org.jsn.jdf.db.*;

public class GLA06HDBWrapBES extends DBWrapper{

public GLA06HDBWrapBES(ConnectionContext ctx){
    super(ctx);
} // Constructor


/**
* Select
* @param String acpt_id, String acpt_rev_no, String po_lnno
* @return GLA06HRec 
* @author besTeam 
* @date 2006-6-27
*/
public GLA06HRec select(String acpt_id, String acpt_rev_no, String po_lnno) throws Exception{
    java.util.Vector gla06hV = new java.util.Vector();
    GLA06HRec gla06h = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select acpt_id, acpt_rev_no, po_lnno, po_no, part_no, stor_id, rjct_code, loc_code, unit_pr, " +
                              "arvl_qty, rjct_qty, acpt_qty, acpt_amt, acpt_amt_yuan, acpt_wt, acpt_date, rgdt, lmd, " +
                              "mode_id, mnt_date, mnt_time, mnt_emp_no " +
                       "  from HM.GLA06H  " +
                       "  where acpt_id = ? and acpt_rev_no = ? and po_lnno = ?  ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,acpt_id); 
        pstmt.setString(2,acpt_rev_no); 
        pstmt.setString(3,po_lnno); 
        rs = pstmt.executeQuery();
       if(rs.next()) { 
            gla06h = new GLA06HRec(); // GLA06HRec Constructor
                     gla06h.setAcpt_id(rs.getString("acpt_id"));
                     gla06h.setAcpt_rev_no(rs.getString("acpt_rev_no"));
                     gla06h.setPo_lnno(rs.getString("po_lnno"));
                     gla06h.setPo_no(rs.getString("po_no"));
                     gla06h.setPart_no(rs.getString("part_no"));
                     gla06h.setStor_id(rs.getString("stor_id"));
                     gla06h.setRjct_code(rs.getString("rjct_code"));
                     gla06h.setLoc_code(rs.getString("loc_code"));
                     gla06h.setUnit_pr(rs.getDouble("unit_pr"));
                     gla06h.setArvl_qty(rs.getInt("arvl_qty"));
                     gla06h.setRjct_qty(rs.getInt("rjct_qty"));
                     gla06h.setAcpt_qty(rs.getInt("acpt_qty"));
                     gla06h.setAcpt_amt(rs.getDouble("acpt_amt"));
                     gla06h.setAcpt_amt_yuan(rs.getDouble("acpt_amt_yuan"));
                     gla06h.setAcpt_wt(rs.getDouble("acpt_wt"));
                     gla06h.setAcpt_date(rs.getString("acpt_date"));
                     gla06h.setRgdt(rs.getString("rgdt"));
                     gla06h.setLmd(rs.getString("lmd"));
                     gla06h.setMode_id(rs.getString("mode_id"));
                     gla06h.setMnt_date(rs.getString("mnt_date"));
                     gla06h.setMnt_time(rs.getString("mnt_time"));
                     gla06h.setMnt_emp_no(rs.getString("mnt_emp_no"));
        } // end While
        else {  throw new DataNotFoundException();} 
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gla06h;
} // end select

/**
* Get All Record 
* @param  void 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-27
*/
public java.util.Vector selectAll() throws Exception{
    java.util.Vector gla06hV = new java.util.Vector();
    GLA06HRec gla06h = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "Select acpt_id, acpt_rev_no, po_lnno, po_no, part_no, stor_id, rjct_code, loc_code, unit_pr, " +
                              "arvl_qty, rjct_qty, acpt_qty, acpt_amt, acpt_amt_yuan, acpt_wt, acpt_date, rgdt, lmd, " +
                              "mode_id, mnt_date, mnt_time, mnt_emp_no " +
                       "  from HM.GLA06H "+
                       "  order by acpt_id , acpt_rev_no , po_lnno ";
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        while(rs.next()){
            gla06h = new GLA06HRec(); // GLA06HRec Constructor
                     gla06h.setAcpt_id(rs.getString("acpt_id"));
                     gla06h.setAcpt_rev_no(rs.getString("acpt_rev_no"));
                     gla06h.setPo_lnno(rs.getString("po_lnno"));
                     gla06h.setPo_no(rs.getString("po_no"));
                     gla06h.setPart_no(rs.getString("part_no"));
                     gla06h.setStor_id(rs.getString("stor_id"));
                     gla06h.setRjct_code(rs.getString("rjct_code"));
                     gla06h.setLoc_code(rs.getString("loc_code"));
                     gla06h.setUnit_pr(rs.getDouble("unit_pr"));
                     gla06h.setArvl_qty(rs.getInt("arvl_qty"));
                     gla06h.setRjct_qty(rs.getInt("rjct_qty"));
                     gla06h.setAcpt_qty(rs.getInt("acpt_qty"));
                     gla06h.setAcpt_amt(rs.getDouble("acpt_amt"));
                     gla06h.setAcpt_amt_yuan(rs.getDouble("acpt_amt_yuan"));
                     gla06h.setAcpt_wt(rs.getDouble("acpt_wt"));
                     gla06h.setAcpt_date(rs.getString("acpt_date"));
                     gla06h.setRgdt(rs.getString("rgdt"));
                     gla06h.setLmd(rs.getString("lmd"));
                     gla06h.setMode_id(rs.getString("mode_id"));
                     gla06h.setMnt_date(rs.getString("mnt_date"));
                     gla06h.setMnt_time(rs.getString("mnt_time"));
                     gla06h.setMnt_emp_no(rs.getString("mnt_emp_no"));
            gla06hV.addElement(gla06h);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gla06hV;
} // end selectAll

/**
* Get selectAllWhere Record 
* @param  String 
* @return java.util.Vector 
* @author besTeam 
* @date 2006-6-27
*/
public java.util.Vector selectAllWhere(String whereOption,String sortOption) throws Exception{
    java.util.Vector gla06hV = new java.util.Vector();
    GLA06HRec gla06h = null;
    PreparedStatement pstmt = null;
    whereOption = whereOption.trim();
    ResultSet rs = null;
    try{
        String query = "Select acpt_id, acpt_rev_no, po_lnno, po_no, part_no, stor_id, rjct_code, loc_code, unit_pr, " +
                              "arvl_qty, rjct_qty, acpt_qty, acpt_amt, acpt_amt_yuan, acpt_wt, acpt_date, rgdt, lmd, " +
                              "mode_id, mnt_date, mnt_time, mnt_emp_no " +
                       "  from HM.GLA06H  where 1=1  " + whereOption ;
 
                      if(sortOption.equals(""))  query += " order by  acpt_id,acpt_rev_no " ;
                         else query+=sortOption ;
        pstmt = connection.prepareStatement(query); 
        rs = pstmt.executeQuery();

        while(rs.next()){
            gla06h = new GLA06HRec(); // GLA06HRec Constructor
                     gla06h.setAcpt_id(rs.getString("acpt_id"));
                     gla06h.setAcpt_rev_no(rs.getString("acpt_rev_no"));
                     gla06h.setPo_lnno(rs.getString("po_lnno"));
                     gla06h.setPo_no(rs.getString("po_no"));
                     gla06h.setPart_no(rs.getString("part_no"));
                     gla06h.setStor_id(rs.getString("stor_id"));
                     gla06h.setRjct_code(rs.getString("rjct_code"));
                     gla06h.setLoc_code(rs.getString("loc_code"));
                     gla06h.setUnit_pr(rs.getDouble("unit_pr"));
                     gla06h.setArvl_qty(rs.getInt("arvl_qty"));
                     gla06h.setRjct_qty(rs.getInt("rjct_qty"));
                     gla06h.setAcpt_qty(rs.getInt("acpt_qty"));
                     gla06h.setAcpt_amt(rs.getDouble("acpt_amt"));
                     gla06h.setAcpt_amt_yuan(rs.getDouble("acpt_amt_yuan"));
                     gla06h.setAcpt_wt(rs.getDouble("acpt_wt"));
                     gla06h.setAcpt_date(rs.getString("acpt_date"));
                     gla06h.setRgdt(rs.getString("rgdt"));
                     gla06h.setLmd(rs.getString("lmd"));
                     gla06h.setMode_id(rs.getString("mode_id"));
                     gla06h.setMnt_date(rs.getString("mnt_date"));
                     gla06h.setMnt_time(rs.getString("mnt_time"));
                     gla06h.setMnt_emp_no(rs.getString("mnt_emp_no"));
            gla06hV.addElement(gla06h);
        } // end While
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return gla06hV;
} // end selectAll

/**
* Get Rows Count 
* @param String acpt_id, String acpt_rev_no, String po_lnno
* @return int 
* @author besTeam 
* @date 2006-6-27
*/
public int count(String acpt_id, String acpt_rev_no, String po_lnno) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLA06H " +
                       " where acpt_id = ? and acpt_rev_no = ? and po_lnno = ?   ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,acpt_id); 
        pstmt.setString(2,acpt_rev_no); 
        pstmt.setString(3,po_lnno); 
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count


/**
* Get All Rows Count 
* @param String whereOption 
* @return int 
* @author besTeam 
* @date 2006-6-27
*/
public int countWhere(String whereOption) throws Exception{
    int count = 0;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try{
        String query = "SELECT COUNT(*) from HM.GLA06H  " +
                       " where 1=1  " + whereOption ;
        pstmt = connection.prepareStatement(query);
        rs = pstmt.executeQuery();

        if(rs.next()){
            count = rs.getInt(1);
        } // end if
    } finally {
        try{rs.close();}catch(Exception e){}
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
    return count;
} // end count

/*
* Add Record 
* @param GLA06HRec 
* @return void 
* @author besTeam 
* @date 2006-6-27
*/
public void insert(GLA06HRec gla06h) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Insert into HM.GLA06H( " +
                              "acpt_id, acpt_rev_no, po_lnno, po_no, part_no, stor_id, rjct_code, loc_code, unit_pr, " +
                              "arvl_qty, rjct_qty, acpt_qty, acpt_amt, acpt_amt_yuan, acpt_wt, acpt_date, rgdt, lmd, " +
                              "mode_id, mnt_date, mnt_time, mnt_emp_no"+
                       " ) values ( "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?, ?, ?, ?, ?, ?, ?, "+
                              "?, ?, ?)";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, gla06h.getAcpt_id());
        pstmt.setString(2, gla06h.getAcpt_rev_no());
        pstmt.setString(3, gla06h.getPo_lnno());
        pstmt.setString(4, gla06h.getPo_no());
        pstmt.setString(5, gla06h.getPart_no());
        pstmt.setString(6, gla06h.getStor_id());
        pstmt.setString(7, gla06h.getRjct_code());
        pstmt.setString(8, gla06h.getLoc_code());
        pstmt.setDouble(9, gla06h.getUnit_pr());
        pstmt.setInt(10, gla06h.getArvl_qty());
        pstmt.setInt(11, gla06h.getRjct_qty());
        pstmt.setInt(12, gla06h.getAcpt_qty());
        pstmt.setDouble(13, gla06h.getAcpt_amt());
        pstmt.setDouble(14, gla06h.getAcpt_amt_yuan());
        pstmt.setDouble(15, gla06h.getAcpt_wt());
        pstmt.setString(16, gla06h.getAcpt_date());
        pstmt.setString(17, gla06h.getRgdt());
        pstmt.setString(18, gla06h.getLmd());
        pstmt.setString(19, gla06h.getMode_id());
        pstmt.setString(20, gla06h.getMnt_date());
        pstmt.setString(21, gla06h.getMnt_time());
        pstmt.setString(22, gla06h.getMnt_emp_no());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new DataAlreadyExistException();

    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end insert


// Update Data 
/**
* Update Record 
* @param GLA06HRec 
* @return void 
* @author besTeam 
* @date 2006-6-27
*/
public void update(GLA06HRec gla06h) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Update HM.GLA06H SET "+
                        "acpt_id = ?, acpt_rev_no = ?, po_lnno = ?, po_no = ?, part_no = ?, stor_id = ?, rjct_code = ?, loc_code = ?, unit_pr = ?, arvl_qty = ?, " +
                              "rjct_qty = ?, acpt_qty = ?, acpt_amt = ?, acpt_amt_yuan = ?, acpt_wt = ?, acpt_date = ?, rgdt = ?, lmd = ?, mode_id = ?, " +
                              "mnt_date = ?, mnt_time = ?, mnt_emp_no = ?"+
                        " where acpt_id = ? and acpt_rev_no = ? and po_lnno = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1, gla06h.getAcpt_id());
        pstmt.setString(2, gla06h.getAcpt_rev_no());
        pstmt.setString(3, gla06h.getPo_lnno());
        pstmt.setString(4, gla06h.getPo_no());
        pstmt.setString(5, gla06h.getPart_no());
        pstmt.setString(6, gla06h.getStor_id());
        pstmt.setString(7, gla06h.getRjct_code());
        pstmt.setString(8, gla06h.getLoc_code());
        pstmt.setDouble(9, gla06h.getUnit_pr());
        pstmt.setInt(10, gla06h.getArvl_qty());
        pstmt.setInt(11, gla06h.getRjct_qty());
        pstmt.setInt(12, gla06h.getAcpt_qty());
        pstmt.setDouble(13, gla06h.getAcpt_amt());
        pstmt.setDouble(14, gla06h.getAcpt_amt_yuan());
        pstmt.setDouble(15, gla06h.getAcpt_wt());
        pstmt.setString(16, gla06h.getAcpt_date());
        pstmt.setString(17, gla06h.getRgdt());
        pstmt.setString(18, gla06h.getLmd());
        pstmt.setString(19, gla06h.getMode_id());
        pstmt.setString(20, gla06h.getMnt_date());
        pstmt.setString(21, gla06h.getMnt_time());
        pstmt.setString(22, gla06h.getMnt_emp_no());
        // Key
        pstmt.setString(23, gla06h.getAcpt_id());
        pstmt.setString(24, gla06h.getAcpt_rev_no());
        pstmt.setString(25, gla06h.getPo_lnno());
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ) throw new NoAffectedException();
        else if ( affected > 1 ) throw new TooManyAffectedException();
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally

} // end Update

/**
* Delete Record 
* @param String acpt_id, String acpt_rev_no, String po_lnno
* @return void 
* @author besTeam 
* @date 2006-6-27
*/
public void delete(String acpt_id, String acpt_rev_no, String po_lnno) throws Exception{
    PreparedStatement pstmt = null;
    try{
        String query = "Delete From HM.GLA06H "+
                       "where acpt_id = ? and acpt_rev_no = ? and po_lnno = ? ";
        pstmt = connection.prepareStatement(query);
        pstmt.setString(1,acpt_id); 
        pstmt.setString(2,acpt_rev_no); 
        pstmt.setString(3,po_lnno); 
        int affected = pstmt.executeUpdate();
        if ( affected == 0 ){
            throw new NoAffectedException();
        } else if ( affected > 1 ) {
            throw new TooManyAffectedException();
        } // end if affection
    } finally {
        try{pstmt.close();}catch(Exception e){}
    } // try-finally
} // end Delete

/**
* Delete Record 
* @param GLA06HRec 
* @return void 
* @author besTeam 
* @date 2006-6-27
*/
public void delete(GLA06HRec gla06h) throws Exception{
     delete(gla06h.getAcpt_id(), gla06h.getAcpt_rev_no(), gla06h.getPo_lnno());
} // end Delete

}// end GLA06HDBWrapBES class